package online.wtrasie.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Favorite stops + recent stops, persisted as JSON. */
public class Favorites {
    public static class Entry {
        public String city, stopId, name, code;
        public int type;
        public double lat, lon; // v1.4.0: saved so favorites can be focused without a lookup

        public Entry(String city, String stopId, String name, String code, int type) {
            this(city, stopId, name, code, type, 0, 0);
        }

        public Entry(String city, String stopId, String name, String code, int type,
                     double lat, double lon) {
            this.city = city;
            this.stopId = stopId;
            this.name = name;
            this.code = code;
            this.type = type;
            this.lat = lat;
            this.lon = lon;
        }
    }

    private final SharedPreferences p;

    public Favorites(Context c) {
        p = c.getSharedPreferences("favorites", Context.MODE_PRIVATE);
    }

    private JSONArray favArray() {
        try {
            return new JSONArray(p.getString("favs", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public boolean isFavorite(String stopId) {
        JSONArray a = favArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && stopId.equals(o.optString("id"))) return true;
        }
        return false;
    }

    public void toggle(Entry e) {
        JSONArray a = favArray();
        JSONArray out = new JSONArray();
        boolean removed = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && e.stopId.equals(o.optString("id"))) {
                removed = true;
                continue;
            }
            out.put(o);
        }
        if (!removed) {
            JSONObject o = new JSONObject();
            try {
                o.put("city", e.city).put("id", e.stopId).put("name", e.name)
                        .put("code", e.code).put("type", e.type)
                        .put("lat", e.lat).put("lon", e.lon);
            } catch (Exception ignored) {
            }
            out.put(o);
        }
        p.edit().putString("favs", out.toString()).apply();
    }

    public List<Entry> list() {
        List<Entry> out = new ArrayList<>();
        JSONArray a = favArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            out.add(new Entry(o.optString("city"), o.optString("id"), o.optString("name"),
                    o.optString("code"), o.optInt("type", 3),
                    o.optDouble("lat", 0), o.optDouble("lon", 0)));
        }
        return out;
    }

    // ---- recents ----

    public void pushRecent(Entry e) {
        try {
            JSONArray a = new JSONArray(p.getString("recent", "[]"));
            JSONArray out = new JSONArray();
            JSONObject n = new JSONObject();
            n.put("city", e.city).put("id", e.stopId).put("name", e.name)
                    .put("code", e.code).put("type", e.type)
                    .put("lat", e.lat).put("lon", e.lon);
            out.put(n);
            for (int i = 0; i < a.length() && out.length() < 12; i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null || e.stopId.equals(o.optString("id"))) continue;
                out.put(o);
            }
            p.edit().putString("recent", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public List<Entry> recents() {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString("recent", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                out.add(new Entry(o.optString("city"), o.optString("id"), o.optString("name"),
                        o.optString("code"), o.optInt("type", 3),
                        o.optDouble("lat", 0), o.optDouble("lon", 0)));
            }
        } catch (Exception ignored) {
        }
        return out;
    }
}
