package online.wtrasie.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HttpsURLConnection;

/** All network access + JSON helpers. Every callback runs on the main thread and never throws. */
public class Api {
    public static final String BASE = "https://api.zbiorkom.live/api6-open/";
    public static final String TRANSITOUS = "https://api.transitous.org/api/v1/";

    public interface Cb {
        void on(JSONObject json, String error);
    }

    static final ExecutorService EXE = Executors.newFixedThreadPool(4);
    static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static void getJson(final String url, final Cb cb) {
        EXE.execute(() -> {
            JSONObject json = null;
            String err = null;
            try {
                String body = fetch(url).trim();
                if (body.startsWith("[")) {
                    // some endpoints (geocode) return a bare JSON array -> wrap it
                    json = new JSONObject().put("content", new JSONArray(body));
                } else {
                    json = new JSONObject(body);
                }
            } catch (Throwable t) {
                err = t instanceof IOException ? "network" : "parse";
                Log.w("Api", "GET " + url + " -> " + t);
            }
            final JSONObject j = json;
            final String e = err;
            MAIN.post(() -> {
                try {
                    cb.on(j, e);
                } catch (Throwable t) {
                    Log.e("Api", "callback", t);
                }
            });
        });
    }

    private static String fetch(String urlStr) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        try {
            c.setConnectTimeout(12000);
            c.setReadTimeout(20000);
            c.setRequestProperty("Accept-Encoding", "gzip");
            c.setRequestProperty("User-Agent", "wtrasie.online/1.1 (Android)");
            int code = c.getResponseCode();
            if (code != 200 && code != 204) {
                throw new IOException("HTTP " + code + " for " + urlStr);
            }
            InputStream in = c.getInputStream();
            if ("gzip".equalsIgnoreCase(c.getContentEncoding())) {
                in = new GZIPInputStream(in);
            }
            return readAll(in);
        } finally {
            try {
                c.disconnect();
            } catch (Throwable ignored) {
            }
        }
    }

    private static String readAll(InputStream in) throws IOException {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        try {
            in.close();
        } catch (IOException ignored) {
        }
        return bo.toString("UTF-8");
    }

    public static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return s;
        }
    }

    // ---- endpoints ----

    public static String stopsUrl(String city, String bbox) {
        String u = BASE + city + "/stops";
        if (bbox != null) u += "?bbox=" + bbox;
        return u;
    }

    public static String departuresUrl(String city, String stopId, int limit) {
        return BASE + city + "/stops/" + enc(stopId) + "?limit=" + limit;
    }

    public static String positionsUrl(String city, String bbox) {
        return BASE + city + "/positions/" + bbox;
    }

    public static String geocodeUrl(String text) {
        return TRANSITOUS + "geocode?text=" + enc(text);
    }

    public static String gtfsUrl(String city, String agency) {
        return BASE + city + "/gtfs/" + (agency == null || agency.isEmpty() ? "default" : agency);
    }

    // ---- disk cache for full-city stop lists ----

    private static final long TTL = 24L * 3600 * 1000; // 24 h

    public interface StopsCb {
        void on(java.util.List<Models.Stop> stops, String error);
    }

    /** Full stop list for a city with 24h disk cache. */
    public static void getStopsCached(Context ctx, String city, final StopsCb cb) {
        final File f = stopCacheFile(ctx, city);
        EXE.execute(() -> {
            try {
                if (f.isFile() && System.currentTimeMillis() - f.lastModified() < TTL) {
                    java.util.List<Models.Stop> stops = Models.Stop.parseList(new JSONObject(readFile(f)));
                    if (!stops.isEmpty()) {
                        postStops(cb, stops, null);
                        return;
                    }
                }
            } catch (Throwable ignored) {
            }
            getJson(stopsUrl(city, null), (json, err) -> {
                if (json != null) {
                    java.util.List<Models.Stop> stops = Models.Stop.parseList(json);
                    try {
                        writeFile(f, json.toString());
                    } catch (Throwable ignored) {
                    }
                    postStops(cb, stops, null);
                } else {
                    postStops(cb, new java.util.ArrayList<>(), err);
                }
            });
        });
    }

    private static void postStops(final StopsCb cb, final java.util.List<Models.Stop> stops, final String err) {
        MAIN.post(() -> {
            try {
                cb.on(stops, err);
            } catch (Throwable t) {
                Log.e("Api", "stops cb", t);
            }
        });
    }

    private static File stopCacheFile(Context ctx, String city) {
        return new File(ctx.getCacheDir(), "stops-" + city + ".json");
    }

    private static String readFile(File f) throws IOException {
        return readAll(new java.io.FileInputStream(f));
    }

    private static void writeFile(File f, String s) throws IOException {
        File tmp = new File(f.getAbsolutePath() + ".tmp");
        FileOutputStream o = new FileOutputStream(tmp);
        o.write(s.getBytes("UTF-8"));
        o.close();
        if (!tmp.renameTo(f)) f.delete();
    }

    public static void clearCache(Context ctx) {
        try {
            File dir = ctx.getCacheDir();
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    String n = f.getName();
                    if ((n.startsWith("stops-") || n.startsWith("gtfs-")) && (n.endsWith(".json") || n.endsWith(".zip"))) f.delete();
                }
            }
            Gtfs.clearCaches();
        } catch (Throwable ignored) {
        }
    }

    // ---- geocode result model

    /** A geocoded place / stop from Transitous, with transit modes when it is a stop. */
    public static class Place {
        public String name, id, country;
        public double lat, lon;
        public boolean isStop;
        public boolean rail, metro, tram, bus, ferry;

        /** Icon that fits this place's modes (train station / bus / tram / metro…). */
        public int modeIcon() {
            if (rail) return R.drawable.ic_type_train;
            if (metro) return R.drawable.ic_metro_m;
            if (tram) return R.drawable.ic_type_tram;
            if (ferry) return R.drawable.ic_type_ferry;
            if (bus) return R.drawable.ic_type_bus;
            return R.drawable.pin;
        }

        public int modeColor() {
            if (rail) return Models.stopColor(2);
            if (metro) return Models.stopColor(1);
            if (tram) return Models.stopColor(0);
            if (ferry) return Models.stopColor(4);
            if (bus) return Models.stopColor(3);
            return 0xFF5F5F66;
        }

        public static java.util.List<Place> parse(JSONObject o) {
            java.util.List<Place> out = new java.util.ArrayList<>();
            if (o == null) return out;
            JSONArray a = o.optJSONArray("content");
            if (a == null) {
                return out;
            }
            for (int i = 0; i < a.length() && out.size() < 15; i++) {
                JSONObject p = a.optJSONObject(i);
                if (p == null) continue;
                Place pl = new Place();
                pl.name = p.optString("name", "");
                pl.id = p.optString("id", "");
                pl.lat = p.optDouble("lat", 0);
                pl.lon = p.optDouble("lon", 0);
                pl.country = p.optString("country", "");
                pl.isStop = "STOP".equalsIgnoreCase(p.optString("type", ""));
                JSONArray modes = p.optJSONArray("modes");
                if (modes != null) {
                    for (int m = 0; m < modes.length(); m++) {
                        String s = modes.optString(m, "").toUpperCase();
                        if (s.contains("RAIL") || s.contains("LONG_DISTANCE") || s.contains("HIGH_SPEED")) pl.rail = true;
                        else if (s.contains("METRO") || s.contains("SUBWAY")) pl.metro = true;
                        else if (s.contains("TRAM")) pl.tram = true;
                        else if (s.contains("FERRY") || s.contains("WATER")) pl.ferry = true;
                        else pl.bus = true;
                    }
                }
                if (!pl.name.isEmpty() && !pl.id.isEmpty() && pl.lat != 0) out.add(pl);
            }
            return out;
        }
    }
}
