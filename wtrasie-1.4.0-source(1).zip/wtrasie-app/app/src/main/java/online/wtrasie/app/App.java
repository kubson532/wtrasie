package online.wtrasie.app;

import android.app.Application;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;

public class App extends Application {
    private static final String CRASH_LOG = "crash.log";

    @Override
    public void onCreate() {
        super.onCreate();

        // Crash logger: writes to cacheDir/crash.log, then delegates to the default handler.
        final Thread.UncaughtExceptionHandler def = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                File f = new File(getCacheDir(), CRASH_LOG);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(f, true);
                fos.write(("\n==== " + System.currentTimeMillis() + " " + t.getName() + " ====\n" + sw).getBytes());
                fos.close();
            } catch (Throwable ignored) {
            }
            if (def != null) def.uncaughtException(t, e);
        });
    }

    public static String appVersion(android.content.Context ctx) {
        try {
            return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "?";
        }
    }
}
