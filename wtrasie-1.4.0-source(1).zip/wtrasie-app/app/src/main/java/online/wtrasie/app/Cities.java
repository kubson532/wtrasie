package online.wtrasie.app;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Static catalog of all feeds available in the open API. */
public class Cities {

    public static class City {
        public final String slug, name, country;
        public final double lat, lon;
        public final double zoom;
        public final boolean nationwide; // whole-country feed: stops fetched per viewport

        City(String slug, String name, String country, double lat, double lon, double zoom, boolean nationwide) {
            this.slug = slug;
            this.name = name;
            this.country = country;
            this.lat = lat;
            this.lon = lon;
            this.zoom = zoom;
            this.nationwide = nationwide;
        }
    }

    private static final City[] CITIES = {
            new City("rzeszow", "Rzeszów", "PL", 50.0412, 21.9990, 12.5, false),
            new City("bialystok", "Białystok", "PL", 53.1325, 23.1688, 12.5, false),
            new City("bielskoBiala", "Bielsko-Biała", "PL", 49.8224, 19.0584, 13.0, false),
            new City("boleslawiec", "Bolesławiec", "PL", 51.2674, 15.5656, 13.5, false),
            new City("chelm", "Chełm", "PL", 51.1431, 23.4716, 13.5, false),
            new City("cieszyn", "Cieszyn", "PL", 49.7514, 18.5908, 14.0, false),
            new City("czestochowa", "Częstochowa", "PL", 50.8118, 19.1203, 12.5, false),
            new City("elblag", "Elbląg", "PL", 54.1522, 19.4088, 13.0, false),
            new City("elk", "Ełk", "PL", 53.8280, 22.3639, 13.5, false),
            new City("gorzow", "Gorzów Wielkopolski", "PL", 52.7325, 15.2286, 13.0, false),
            new City("kalisz", "Kalisz", "PL", 51.7603, 18.0811, 13.5, false),
            new City("kielce", "Kielce", "PL", 50.8661, 20.6286, 12.5, false),
            new City("kolobrzeg", "Kołobrzeg", "PL", 54.1758, 15.5833, 13.5, false),
            new City("konin", "Konin", "PL", 52.2283, 18.2536, 13.5, false),
            new City("koszalin", "Koszalin", "PL", 54.1943, 16.1723, 12.5, false),
            new City("krakow", "Kraków", "PL", 50.0616, 19.9373, 12.5, false),
            new City("krasnik", "Kraśnik", "PL", 50.9392, 22.2186, 13.5, false),
            new City("krosno", "Krosno", "PL", 49.6874, 21.7364, 13.5, false),
            new City("kutno", "Kutno", "PL", 52.2317, 19.3640, 13.5, false),
            new City("legnica", "Legnica", "PL", 51.2104, 16.1617, 13.0, false),
            new City("leszno", "Leszno", "PL", 51.8433, 16.5745, 13.5, false),
            new City("lublin", "Lublin", "PL", 51.2465, 22.5684, 12.5, false),
            new City("lodz", "Łódź", "PL", 51.7592, 19.4559, 12.5, false),
            new City("mld", "Małopolskie Linie Dowozowe", "PL", 49.95, 20.05, 10.0, false),
            new City("gzm", "Metropolia GZM", "PL", 50.259, 19.020, 11.0, false),
            new City("mielec", "Mielec", "PL", 50.2876, 21.4299, 13.5, false),
            new City("olsztyn", "Olsztyn", "PL", 53.7784, 20.4801, 12.5, false),
            new City("opole", "Opole", "PL", 50.6751, 17.9213, 13.0, false),
            new City("ostroleka", "Ostrołęka", "PL", 53.0857, 21.5731, 13.5, false),
            new City("ostrowiecSwietokrzyski", "Ostrowiec Świętokrzyski", "PL", 50.9332, 21.3877, 13.5, false),
            new City("oswiecim", "Oświęcim", "PL", 50.0355, 19.2136, 14.0, false),
            new City("pila", "Piła", "PL", 53.1515, 16.7383, 13.5, false),
            new City("piotrkowTrybunalski", "Piotrków Trybunalski", "PL", 51.4053, 19.6953, 13.5, false),
            new City("plock", "Płock", "PL", 52.5468, 19.7063, 13.0, false),
            new City("poznan", "Poznań", "PL", 52.4082, 16.9335, 12.5, false),
            new City("przemysl", "Przemyśl", "PL", 49.7847, 22.7677, 13.5, false),
            new City("radom", "Radom", "PL", 51.4027, 21.1471, 12.5, false),
            new City("radomsko", "Radomsko", "PL", 51.0670, 19.4403, 14.0, false),
            new City("rybnik", "Rybnik i okolice", "PL", 50.0972, 18.5360, 11.5, false),
            new City("siedlce", "Siedlce", "PL", 52.1671, 22.2921, 13.5, false),
            new City("skarzyskoKamienna", "Skarżysko-Kamienna", "PL", 51.1130, 20.8433, 13.5, false),
            new City("slupsk", "Słupsk", "PL", 54.4641, 17.0285, 13.0, false),
            new City("stalowaWola", "Stalowa Wola", "PL", 50.5816, 22.0530, 13.5, false),
            new City("starachowice", "Starachowice", "PL", 51.0121, 21.0675, 13.5, false),
            new City("suwalki", "Suwałki", "PL", 54.1116, 22.9309, 13.5, false),
            new City("szczecin", "Szczecin", "PL", 53.4285, 14.5528, 12.5, false),
            new City("swinoujscie", "Świnoujście", "PL", 53.9103, 14.2475, 13.0, false),
            new City("tarnow", "Tarnów", "PL", 50.0121, 20.9856, 13.5, false),
            new City("tczew", "Tczew", "PL", 54.0926, 18.7866, 13.5, false),
            new City("tomaszowMazowiecki", "Tomaszów Mazowiecki", "PL", 51.5310, 20.0086, 13.5, false),
            new City("torun", "Toruń", "PL", 53.0138, 18.5984, 12.5, false),
            new City("tricity", "Trójmiasto", "PL", 54.4418, 18.5601, 11.5, false),
            new City("walbrzych", "Wałbrzych", "PL", 50.7705, 16.2852, 12.5, false),
            new City("warsaw", "Warszawa", "PL", 52.2297, 21.0122, 11.5, false),
            new City("wroclaw", "Wrocław", "PL", 51.1079, 17.0385, 12.5, false),
            new City("zielonaGora", "Zielona Góra", "PL", 51.9356, 15.5062, 13.0, false),
            new City("zywiec", "Żywiec", "PL", 49.6816, 19.1897, 13.5, false),
            new City("lka", "Autobusy ŁKA", "PL", 51.75, 19.35, 9.5, false),
            new City("helsinki", "Helsinki", "FI", 60.1699, 24.9384, 12.0, false),
            new City("tampere", "Tampere", "FI", 61.4978, 23.7610, 12.0, false),
            new City("stockholm", "Stockholm", "SE", 59.3293, 18.0686, 11.0, false),
            new City("pkp", "PKP", "PL", 52.10, 19.40, 6.5, true),
            new City("flixbus", "FlixBus", "EU", 52.10, 19.40, 6.0, true),
            new City("digitraffic", "Digitraffic", "FI", 63.5, 26.0, 5.5, true),
            new City("iceland", "Islandia", "IS", 64.93, -18.60, 6.5, true),
            new City("netherlands", "Holandia", "NL", 52.25, 5.60, 7.5, true),
            new City("switzerland", "Szwajcaria", "CH", 46.80, 8.20, 7.5, true),
    };

    private static List<City> sorted;

    /** Alphabetically sorted (Polish collation), duplicates impossible. */
    public static List<City> all() {
        if (sorted == null) {
            Set<String> seen = new LinkedHashSet<>();
            List<City> list = new ArrayList<>();
            for (City c : CITIES) {
                if (seen.add(c.slug)) list.add(c); // dedupe guard
            }
            final Collator coll = Collator.getInstance(new Locale("pl", "PL"));
            coll.setStrength(Collator.PRIMARY);
            Collections.sort(list, new Comparator<City>() {
                @Override
                public int compare(City a, City b) {
                    return coll.compare(a.name, b.name);
                }
            });
            sorted = list;
        }
        return sorted;
    }

    public static City bySlug(String slug) {
        if (slug == null) return null;
        for (City c : CITIES) if (c.slug.equals(slug)) return c;
        return null;
    }

    /** Nearest non-nationwide city to the given point, within maxKm. Null if none. */
    public static City nearest(double lat, double lon, double maxKm) {
        City best = null;
        double bestD = Double.MAX_VALUE;
        for (City c : CITIES) {
            if (c.nationwide) continue;
            double d = Ui.distM(lat, lon, c.lat, c.lon);
            if (d < bestD) {
                bestD = d;
                best = c;
            }
        }
        return bestD <= maxKm * 1000 ? best : null;
    }

    /** Find a local city by display name (used for geocode results like "pl-Rzeszów_628"). */
    public static City byName(String name) {
        if (name == null || name.isEmpty()) return null;
        String n = Ui.norm(name);
        for (City c : CITIES) {
            if (Ui.norm(c.name).equals(n)) return c;
        }
        // partial match as fallback
        for (City c : CITIES) {
            if (c.nationwide) continue;
            if (Ui.norm(c.name).startsWith(n) || n.startsWith(Ui.norm(c.name))) return c;
        }
        return null;
    }
}
