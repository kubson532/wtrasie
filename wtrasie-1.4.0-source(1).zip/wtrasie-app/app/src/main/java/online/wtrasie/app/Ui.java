package online.wtrasie.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.style.StrikethroughSpan;
import android.view.View;
import android.widget.TextView;

import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

/** Small formatting / drawing helpers. */
public class Ui {
    public static float density(Context c) {
        return c.getResources().getDisplayMetrics().density;
    }

    public static int dp(Context c, float v) {
        return Math.round(v * density(c));
    }

    private static final Pattern DIACRITICS = Pattern.compile("\\p{M}+");

    /** Lowercase, diacritics-stripped, for case-insensitive Polish search. */
    public static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD);
        n = DIACRITICS.matcher(n).replaceAll("");
        return n.toLowerCase(Locale.ROOT).trim();
    }

    public static String fmtTime(long epochMs) {
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(epochMs));
    }

    public static String fmtTimeSec(long epochMs) {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(epochMs));
    }

    /** "+3 min" / "-2 min" / "" */
    public static String fmtDelay(long delayMs) {
        long s = Math.round(delayMs / 1000.0);
        if (Math.abs(s) < 45) return "";
        long m = s / 60;
        if (Math.abs(m) < 1) m = s > 0 ? 1 : -1;
        return (m > 0 ? "+" : "") + m + " min";
    }

    /**
     * Countdown text for the right column: "&lt;1 min" (blink, red) when less than a minute,
     * "N min" up to an hour, the clock time above that. Returns null when the time is unknown.
     */
    public static String fmtCountdown(long epochMs, long nowMs) {
        if (epochMs <= 0) return null;
        long diff = epochMs - nowMs;
        if (diff < 60000) return "<1 min";
        long min = diff / 60000;
        if (min <= 60) return min + " min";
        return fmtTime(epochMs);
    }

    /** True when the countdown text is the blinking "&lt;1 min" variant. */
    public static boolean isBlinkCountdown(String s) {
        return "<1 min".equals(s);
    }

    /** GTFS seconds after midnight -> "HH:MM" (hours may exceed 24 for night services). */
    public static String fmtGtfsTime(int sec) {
        int h = sec / 3600;
        int m = (sec % 3600) / 60;
        return String.format(Locale.getDefault(), "%d:%02d", h, m);
    }

    /** Polish plural: plural(3, "kurs") = "3 kursy", plural(5, "kurs") = "5 kursów". */
    public static String plPlural(int n, String singular) {
        String form;
        if (n == 1) form = singular;
        else {
            int n10 = n % 10, n100 = n % 100;
            if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) form = singular + "y";
            else form = singular + "ów";
        }
        return n + " " + form;
    }

    public static int delayColor(long delayMs) {
        long m = delayMs / 60000;
        if (m >= 2) return 0xFFC62200;
        if (m <= -2) return 0xFF146C2E;
        return 0xFF5F5F66;
    }

    public static String fmtDist(double meters) {
        if (meters < 950) return Math.round(meters / 10.0) * 10 + " m";
        return String.format(Locale.getDefault(), "%.1f km", meters / 1000.0);
    }

    public static String fmtDuration(long seconds) {
        long m = seconds / 60;
        if (m < 60) return m + " min";
        return (m / 60) + " h " + (m % 60) + " min";
    }

    /** Parse "#rrggbb" safely, fallback. */
    public static int parseColor(String s, int fallback) {
        try {
            if (s != null && s.length() >= 7) return Color.parseColor(s.trim());
        } catch (Exception ignored) {
        }
        return fallback;
    }

    /** Ensure enough contrast against white text. */
    public static int ensureReadable(int color) {
        double y = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
        return y < 70 ? blend(color, Color.WHITE, 0.45) : color;
    }

    private static int blend(int a, int b, double ratio) {
        int r = (int) (Color.red(a) * (1 - ratio) + Color.red(b) * ratio);
        int g = (int) (Color.green(a) * (1 - ratio) + Color.green(b) * ratio);
        int bl = (int) (Color.blue(a) * (1 - ratio) + Color.blue(b) * ratio);
        return Color.rgb(clamp(r), clamp(g), clamp(bl));
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    /** Rounded pill background with the given color, for route badges. */
    public static GradientDrawable pillBg(int color, float radiusDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(ensureReadable(color));
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    public static void setPill(TextView tv, String text, int color) {
        tv.setText(text);
        tv.setBackground(pillBg(color, 7f, tv.getContext()));
        tv.setTextColor(Color.WHITE);
    }

    /**
     * Full stop title: the API splits "Pl. Wolności 04" into name + code —
     * always show them together; never append the code when the name already
     * ends with it (GTFS names often carry it).
     */
    public static String stopTitle(String name, String code) {
        String n = name == null ? "" : name.trim();
        String c = code == null ? "" : code.trim();
        if (c.isEmpty() || n.isEmpty()) return n;
        if (n.endsWith(" " + c) || n.endsWith(c) && n.length() > c.length()
                && !Character.isLetterOrDigit(n.charAt(n.length() - c.length() - 1))) {
            return n;
        }
        return n + " " + c;
    }

    public static void strike(TextView tv, boolean strike) {
        CharSequence t = tv.getText();
        if (strike) {
            SpannableString s = new SpannableString(t);
            s.setSpan(new StrikethroughSpan(), 0, s.length(), 0);
            tv.setText(s, TextView.BufferType.SPANNABLE);
            tv.setTextColor(0xFFB3261E);
        } else {
            if (t instanceof SpannableString) {
                tv.setText(t.toString());
            }
        }
    }

    /** Haversine distance in meters. */
    public static double distM(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371000.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    public static void setVisible(View v, boolean visible) {
        v.setVisibility(visible ? View.VISIBLE : View.GONE);
    }
}
