package online.wtrasie.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * Base draggable bottom sheet: fixed-height panel whose visible part is driven by translationY.
 * States: HIDDEN -> MINI (title + buttons only) -> PEEK (roughly half) -> FULL.
 * Drag by the grab handle at the very top or by the header view. Sheets never
 * pass touches through to the map below them.
 *
 * v1.4.0:
 *  - new MINI snap point: only the header (title + buttons) stays visible;
 *  - scrollable content height follows the state, so the bottom of a long list
 *    is reachable while the sheet is not fully expanded.
 */
public class Sheet extends FrameLayout {

    public interface DismissListener {
        void onDismissed();
    }

    public static final int HIDDEN = 0, PEEK = 1, FULL = 2, MINI = 3;

    protected int state = HIDDEN;
    protected int panelH = 1;       // full panel height in px
    protected int peekH = 1;        // peek height in px
    protected int miniH = 1;        // header-only height in px
    protected DismissListener dismissListener;
    private ValueAnimator animator;
    private float downY, startTransY;
    private boolean dragging = false;
    private int bottomInset = 0;
    private int heightRetries = 0;
    private final List<View> dragViews = new ArrayList<>();
    private View headerView;                       // subclass header -> MINI height
    private final List<View> scrollContent = new ArrayList<>(); // height follows the state

    public Sheet(Context c) {
        super(c);
        init(c, 0);
    }

    public Sheet(Context c, AttributeSet a) {
        super(c, a);
        init(c, 0);
    }

    public Sheet(Context c, int layoutRes) {
        super(c);
        init(c, layoutRes);
    }

    private void init(Context c, int layoutRes) {
        setBackgroundResource(R.drawable.bg_sheet);
        setElevation(Ui.dp(c, 14));
        setVisibility(GONE);
        setClipChildren(false);
        setClipToPadding(false);
        // A sheet must never let touches fall through to the map underneath it.
        setClickable(true);
        setFocusable(false);
        if (layoutRes != 0) {
            View v = LayoutInflater.from(c).inflate(layoutRes, this, false);
            addView(v, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        addGrabHandle(c);
        setOnApplyWindowInsetsListener((v, insets) -> {
            try {
                bottomInset = Math.max(0, insets.getSystemWindowInsetBottom());
                applyHeights();
            } catch (Throwable ignored) {
            }
            return insets;
        });
    }

    /** The visual grab bar at the top of every sheet; the whole strip is a drag area. */
    private void addGrabHandle(Context c) {
        LinearLayout strip = new LinearLayout(c);
        strip.setOrientation(LinearLayout.VERTICAL);
        strip.setGravity(Gravity.CENTER_HORIZONTAL);
        strip.setPadding(0, Ui.dp(c, 5), 0, Ui.dp(c, 1));
        View bar = new View(c);
        bar.setBackgroundResource(R.drawable.bg_grab_handle);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 4));
        strip.addView(bar, blp);
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, Ui.dp(c, 22));
        lp.gravity = Gravity.TOP;
        addView(strip, lp);
        registerDrag(strip);
    }

    public void setDismissListener(DismissListener l) {
        dismissListener = l;
    }

    /**
     * The subclass header (title + buttons). Its height defines the MINI state;
     * it is also a drag area. Call before the sheet is first shown.
     */
    protected void setDragHandle(View v) {
        registerDrag(v);
        headerView = v;
        computeMiniH();
    }

    /**
     * Views whose height must end at the visible bottom of the sheet (lists,
     * scroll views). Without this the last rows are unreachable in PEEK/MINI.
     */
    protected void setScrollableContent(View... views) {
        scrollContent.clear();
        for (View v : views) if (v != null) scrollContent.add(v);
        fitContentHeights();
    }

    private void registerDrag(View v) {
        dragViews.add(v);
        v.setOnTouchListener((view, ev) -> onHandleTouch(view, ev));
    }

    /** True when the touch lands on an interactive child (EditText / button) that should keep the event. */
    private boolean isInteractiveChild(View group, MotionEvent ev) {
        if (!(group instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) group;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == null || c.getVisibility() != View.VISIBLE) continue;
            if (ev.getX() >= c.getLeft() && ev.getX() <= c.getRight()
                    && ev.getY() >= c.getTop() && ev.getY() <= c.getBottom()) {
                if (c instanceof android.widget.EditText || c instanceof android.widget.ImageButton
                        || c instanceof android.widget.Button || c instanceof android.widget.Switch) {
                    return true;
                }
                if (c instanceof ViewGroup) {
                    MotionEvent childEv = MotionEvent.obtain(ev);
                    childEv.offsetLocation(-c.getLeft(), -c.getTop());
                    boolean r = isInteractiveChild(c, childEv);
                    childEv.recycle();
                    return r;
                }
                return false;
            }
        }
        return false;
    }

    private boolean onHandleTouch(View handle, MotionEvent ev) {
        try {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (isInteractiveChild(handle, ev)) {
                        dragging = false;
                        return false; // let the child handle it
                    }
                    dragging = true;
                    downY = ev.getRawY();
                    startTransY = getTranslationY();
                    cancelAnim();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!dragging) return true;
                    float ty = startTransY + (ev.getRawY() - downY);
                    ty = clamp(ty, 0, panelH);
                    setTranslationY(ty);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!dragging) return false;
                    dragging = false;
                    settle(ev);
                    return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    /** Pick the snap state after a drag: nearest target, fling moves one level. */
    private void settle(MotionEvent ev) {
        float end = getTranslationY();
        float dy = ev.getRawY() - downY;
        float fling = Ui.dp(getContext(), 90);
        if (dy > fling) {                       // fling down: one level down
            if (state == FULL) setState(PEEK);
            else if (state == PEEK) setState(MINI);
            else hide();
            return;
        }
        if (dy < -fling) {                      // fling up: one level up
            if (state == MINI) setState(PEEK);
            else if (state == PEEK) setState(FULL);
            return;
        }
        // nearest snap point
        float dFull = Math.abs(end - 0);
        float dPeek = Math.abs(end - (panelH - peekH));
        float dMini = Math.abs(end - (panelH - miniH));
        float dHide = Math.abs(end - panelH);
        float best = Math.min(Math.min(dFull, dPeek), Math.min(dMini, dHide));
        if (best == dHide && end > panelH - miniH + Ui.dp(getContext(), 80)) hide();
        else if (best == dMini) setState(MINI);
        else if (best == dPeek) setState(PEEK);
        else setState(FULL);
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private void cancelAnim() {
        if (animator != null) animator.cancel();
    }

    protected void applyHeights() {
        ViewGroup parent = (ViewGroup) getParent();
        if (parent == null) return;
        int h = parent.getHeight();
        if (h <= 0) {
            // not laid out yet -> retry a bounded number of times
            if (heightRetries < 10) {
                heightRetries++;
                post(this::applyHeights);
            }
            return;
        }
        heightRetries = 0;
        panelH = (int) (h * 0.86);
        peekH = (int) (h * 0.52);
        computeMiniH();
        ViewGroup.LayoutParams lp = getLayoutParams();
        boolean changed = lp.height != panelH;
        lp.height = panelH;
        if (lp.width == 0) lp.width = LayoutParams.MATCH_PARENT;
        if (changed) setLayoutParams(lp);
        // keep position consistent
        if (state == PEEK) setTranslationY(panelH - peekH);
        else if (state == FULL) setTranslationY(0);
        else if (state == MINI) setTranslationY(panelH - miniH);
        else setTranslationY(panelH);
    }

    /** MINI height: grab strip + the subclass header (title + buttons). */
    private void computeMiniH() {
        int fallback = Ui.dp(getContext(), 150);
        if (headerView == null || headerView.getHeight() <= 0) {
            miniH = fallback;
            post(this::computeMiniH);
            return;
        }
        miniH = Math.min(panelH > 1 ? panelH : fallback, headerView.getHeight() + Ui.dp(getContext(), 6));
    }

    /** Height of the registered scroll views so their bottom sits at the visible edge. */
    private void fitContentHeights() {
        if (scrollContent.isEmpty() || panelH <= 1) return;
        int visible = state == FULL ? panelH : (state == PEEK ? peekH : miniH);
        for (View v : scrollContent) {
            if (v == null || v.getVisibility() != VISIBLE) continue;
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            if (lp == null) continue;
            int top = topInSheet(v);
            int want = top > 0 ? Math.max(0, visible - top) : LayoutParams.MATCH_PARENT;
            if (lp.height != want) {
                lp.height = want;
                v.setLayoutParams(lp);
            }
        }
    }

    /** Offset of v from the sheet's own top, climbing through nested parents. */
    private int topInSheet(View v) {
        try {
            int top = v.getTop();
            android.view.ViewParent p = v.getParent();
            while (p instanceof View && p != this) {
                top += ((View) p).getTop();
                p = ((View) p).getParent();
            }
            if (p != this) return 0; // detached chain: let MATCH_PARENT stand
            return top;
        } catch (Throwable t) {
            return 0;
        }
    }

    public void setState(int s) {
        cancelAnim();
        boolean wasHidden = (state == HIDDEN);
        state = s;
        float target = targetY(s);
        if (wasHidden) {
            // start fully below the screen and slide up
            setTranslationY(panelH + bottomInset);
            setVisibility(VISIBLE);
        }
        animateTo(target);
        if (s != HIDDEN) setVisibility(VISIBLE);
        post(this::fitContentHeights); // after the snap settles the heights follow
        postDelayed(this::fitContentHeights, 300);
    }

    private float targetY(int s) {
        if (s == FULL) return 0;
        if (s == MINI) return panelH - miniH;
        if (s == PEEK) return panelH - peekH;
        return panelH;
    }

    public int getState() {
        return state;
    }

    public void show() {
        if (panelH <= 1) {
            // wait for measurement to avoid a full-screen flash
            setVisibility(INVISIBLE);
            post(() -> {
                applyHeights();
                if (panelH <= 1) {
                    panelH = Ui.dp(getContext(), 700); // absolute fallback
                    peekH = Ui.dp(getContext(), 380);
                }
                setState(PEEK);
            });
        } else {
            setState(PEEK);
        }
    }

    public void showFull() {
        if (panelH <= 1) {
            setVisibility(INVISIBLE);
            post(() -> {
                applyHeights();
                if (panelH <= 1) {
                    panelH = Ui.dp(getContext(), 700);
                    peekH = Ui.dp(getContext(), 380);
                }
                setState(FULL);
            });
        } else {
            setState(FULL);
        }
    }

    public void hide() {
        cancelAnim();
        state = HIDDEN;
        animateTo(panelH);
    }

    private void animateTo(float target) {
        cancelAnim();
        animator = ValueAnimator.ofFloat(getTranslationY(), target);
        animator.setDuration(260);
        animator.setInterpolator(new DecelerateInterpolator(1.2f));
        animator.addUpdateListener(a -> {
            float v = (float) a.getAnimatedValue();
            setTranslationY(v);
            if (state == HIDDEN && Math.abs(v - panelH) < 1f) {
                setVisibility(GONE);
                if (dismissListener != null) {
                    DismissListener l = dismissListener;
                    dismissListener = null;
                    try {
                        l.onDismissed();
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        animator.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        applyHeights();
        fitContentHeights();
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if (changed) post(this::fitContentHeights);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(this::applyHeights);
    }
}
