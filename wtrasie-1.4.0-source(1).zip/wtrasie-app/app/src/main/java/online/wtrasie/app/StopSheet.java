package online.wtrasie.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Stop board with two modes:
 *  - Odjazdy: live departures — under the headsign the delay / "Planowo" /
 *    planned time, on the right a countdown (">60 min" shows the clock time,
 *    "&lt;1 min" blinks red). Route chips filter lines; tapping a departure
 *    opens the vehicle preview when that bus is running.
 *  - Rozkłady: per-line day-type timetables with route variant colors.
 */
public class StopSheet extends Sheet {

    private static final int MODE_DEPARTURES = 0, MODE_TIMETABLE = 1;

    private final MainActivity act;
    private final FrameLayout iconWrap;
    private final ImageView iconImg;
    private final TextView name, sub;
    private final ImageButton btnFav, btnClose, btnCenter;
    private final LinearLayout chipsRow;
    private final HorizontalScrollView chipsScroll;
    private final TextView noRoutesNote;
    private final View btnRozklady;
    private final ImageView rozkladyIcon;
    private final TextView rozkladyLabel;
    private final ListView list;
    private final ScrollView timetableScroll;
    private final LinearLayout timetableBox;
    private final DepartureAdapter adapter;

    private Models.Stop stop;
    private Cities.City city;
    private int mode = MODE_DEPARTURES;
    private final List<Models.Departure> departures = new ArrayList<>();
    private final List<Models.Departure> filtered = new ArrayList<>();
    private final Set<String> selectedRoutes = new HashSet<>();
    private boolean loaded = false;
    private boolean triedOwnCity = false;
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());
    private int fetchGen = 0;
    private int ttGen = 0;

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            if (getState() == HIDDEN) return;
            if (mode == MODE_DEPARTURES) fetchDepartures();
            refreshHandler.postDelayed(this, 15000);
        }
    };

    /** Light tick: recompute countdowns without a network round-trip. */
    private final Runnable countTick = new Runnable() {
        @Override
        public void run() {
            if (getState() == HIDDEN || mode != MODE_DEPARTURES) return;
            adapter.notifyDataSetChanged();
            refreshHandler.postDelayed(this, 8000);
        }
    };

    public StopSheet(MainActivity act) {
        super(act, R.layout.sheet_stop);
        this.act = act;

        iconWrap = findViewById(R.id.stopIcon);
        iconImg = findViewById(R.id.stopIconImg);
        name = findViewById(R.id.stopName);
        sub = findViewById(R.id.stopSub);
        btnFav = findViewById(R.id.btnFav);
        btnClose = findViewById(R.id.btnCloseStop);
        btnCenter = findViewById(R.id.btnCenter);
        chipsRow = findViewById(R.id.routeChipsRow);
        chipsScroll = findViewById(R.id.routeChips);
        noRoutesNote = findViewById(R.id.noRoutesNote);
        btnRozklady = findViewById(R.id.btnRozklady);
        rozkladyIcon = findViewById(R.id.rozkladyIcon);
        rozkladyLabel = findViewById(R.id.rozkladyLabel);
        list = findViewById(R.id.departuresList);
        timetableScroll = findViewById(R.id.timetableScroll);
        timetableBox = findViewById(R.id.timetableBox);
        adapter = new DepartureAdapter();
        list.setAdapter(adapter);

        setDragHandle(findViewById(R.id.stopHeader));
        // lists must end at the visible bottom in every sheet state (v1.4.0)
        setScrollableContent(list, timetableScroll);
        // fading edge on the line-chip bar: a visible hint that more chips
        // are waiting off-screen (v1.4.0)
        chipsScroll.setHorizontalFadingEdgeEnabled(true);
        chipsScroll.setFadingEdgeLength(Ui.dp(act, 26));
        chipsScroll.setHorizontalScrollBarEnabled(false);

        btnClose.setOnClickListener(v -> hide());
        btnCenter.setOnClickListener(v -> {
            try {
                if (stop == null) return;
                double lat = stop.lat, lon = stop.lon;
                if (lat == 0 && lon == 0) { // never focus into Null Island
                    lat = city != null ? city.lat : (act.currentCity != null ? act.currentCity.lat : 52.23);
                    lon = city != null ? city.lon : (act.currentCity != null ? act.currentCity.lon : 21.01);
                }
                act.centerOn(lat, lon, 16.0);
            } catch (Throwable ignored) {
            }
        });
        btnFav.setOnClickListener(v -> {
            try {
                if (stop == null) return;
                act.favorites.toggle(new Favorites.Entry(
                        stop.city, stop.id, stop.name, stop.code, stop.primaryType(),
                        stop.lat, stop.lon));
                updateFavState();
            } catch (Throwable ignored) {
            }
        });
        btnRozklady.setOnClickListener(v -> toggleMode());

        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos < 0 || pos >= filtered.size()) return;
            Models.Departure d = filtered.get(pos);
            act.openVehicleForDeparture(d, stop);
        });
    }

    public Models.Stop getCurrentStop() {
        return stop;
    }

    /** The feed city this stop's departures are actually queried in. */
    public Cities.City getFeedCity() {
        return city;
    }

    public void open(Cities.City city, Models.Stop s) {
        this.city = city;
        this.stop = s;
        selectedRoutes.clear();
        setMode(MODE_DEPARTURES);

        int type = s.primaryType();
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Models.typeColor(type));
        iconWrap.setBackground(bg);
        iconImg.setImageResource(s.isStation() ? R.drawable.ic_station : Models.stopIcon(type));
        // v1.4.0: the number is part of the title ("Pl. Wolności 04"), and the
        // sub line stays empty — no adjacent-stop names, no direction stuffing
        name.setText(Ui.stopTitle(s.name, s.code));
        sub.setText("");
        Ui.setVisible(sub, false);
        updateFavState();

        departures.clear();
        filtered.clear();
        loaded = false;
        triedOwnCity = false;
        adapter.notifyDataSetChanged();
        buildChips();

        show();
        fetchDepartures();
        refreshHandler.removeCallbacks(refreshRunnable);
        refreshHandler.removeCallbacks(countTick);
        refreshHandler.postDelayed(refreshRunnable, 15000);
        refreshHandler.postDelayed(countTick, 8000);

        act.favorites.pushRecent(new Favorites.Entry(
                s.city, s.id, s.name, s.code, s.primaryType(), s.lat, s.lon));
    }

    @Override
    public void hide() {
        super.hide();
        refreshHandler.removeCallbacks(refreshRunnable);
        refreshHandler.removeCallbacks(countTick);
    }

    private void updateFavState() {
        boolean fav = stop != null && act.favorites.isFavorite(stop.id);
        btnFav.setImageResource(fav ? R.drawable.star : R.drawable.staroutline);
        btnFav.setColorFilter(fav ? 0xFFF9AB00 : 0xFF1C1B1F);
    }

    // ------------------------------------------------------------ modes

    private void setMode(int m) {
        mode = m;
        if (m == MODE_DEPARTURES) {
            list.setVisibility(VISIBLE);
            timetableScroll.setVisibility(GONE);
            rozkladyLabel.setText(R.string.rozkady);
            rozkladyIcon.setImageResource(R.drawable.ic_calendar);
            rozkladyIcon.setColorFilter(0xFF1C1B1F);
            rozkladyLabel.setTextColor(0xFF1C1B1F);
        } else {
            list.setVisibility(GONE);
            timetableScroll.setVisibility(VISIBLE);
            rozkladyLabel.setText(R.string.odjazdy);
            rozkladyIcon.setImageResource(R.drawable.flash);
            rozkladyIcon.setColorFilter(0xFF0B57D0);
            rozkladyLabel.setTextColor(0xFF0B57D0);
        }
    }

    private void toggleMode() {
        if (mode == MODE_DEPARTURES) {
            setMode(MODE_TIMETABLE);
            loadTimetable();
        } else {
            setMode(MODE_DEPARTURES);
        }
    }

    // ------------------------------------------------------------ chips

    private void buildChips() {
        chipsRow.removeAllViews();
        if (stop == null || stop.routes == null || stop.routes.length == 0) {
            Ui.setVisible(chipsScroll, false);
            Ui.setVisible(noRoutesNote, true);
            return;
        }
        Ui.setVisible(chipsScroll, true);
        Ui.setVisible(noRoutesNote, false);
        boolean filterTechnical = act.prefs.filterTechnical();
        int shown = 0;
        for (final Models.Route r : stop.routes) {
            if (Models.hiddenByTechnicalFilter(r.name, filterTechnical)) continue;
            TextView chip = (TextView) LayoutInflater.from(act)
                    .inflate(R.layout.chip_route, chipsRow, false);
            Ui.setPill(chip, r.name, r.color);
            chip.setTag(r.id);
            chip.setOnClickListener(v -> {
                if (selectedRoutes.contains(r.id)) selectedRoutes.remove(r.id);
                else selectedRoutes.add(r.id);
                applyFilter();
                restyleChips();
            });
            chipsRow.addView(chip);
            shown++;
        }
        if (shown == 0) {
            Ui.setVisible(chipsScroll, false);
            Ui.setVisible(noRoutesNote, true);
            return;
        }
        restyleChips();
    }

    private void restyleChips() {
        for (int i = 0; i < chipsRow.getChildCount(); i++) {
            View c = chipsRow.getChildAt(i);
            Object tag = c.getTag();
            boolean sel = tag != null && selectedRoutes.contains((String) tag);
            c.setAlpha(sel ? 1f : 0.45f);
        }
    }

    private void applyFilter() {
        filtered.clear();
        boolean filterTechnical = act.prefs.filterTechnical();
        for (Models.Departure d : departures) {
            if (Models.hiddenByTechnicalFilter(d.route.name, filterTechnical)) continue;
            if (selectedRoutes.isEmpty() || selectedRoutes.contains(d.route.id)) {
                filtered.add(d);
            }
        }
        adapter.notifyDataSetChanged();
    }

    // ------------------------------------------------------------ live departures

    private void fetchDepartures() {
        if (stop == null || city == null) return;
        final int gen = ++fetchGen;
        Api.getJson(Api.departuresUrl(city.slug, stop.id, 60), (json, err) -> {
            if (gen != fetchGen || getState() == HIDDEN || mode != MODE_DEPARTURES) return;
            if (json == null) {
                // v1.4.0: never spin forever — fall back to the stop's own city
                // once (a pkp stop opened from a city tab), then stop loading
                if (!triedOwnCity && stop.city != null && !stop.city.isEmpty()
                        && !stop.city.equals(city.slug)) {
                    Cities.City own = Cities.bySlug(stop.city);
                    if (own != null) {
                        triedOwnCity = true;
                        this.city = own;
                        fetchDepartures();
                        return;
                    }
                }
                loaded = true;
                applyFilter();
                return;
            }
            List<Models.Departure> fresh = Models.Departure.parseList(json);
            if (fresh.isEmpty() && !triedOwnCity
                    && stop.city != null && !stop.city.isEmpty() && !stop.city.equals(city.slug)) {
                Cities.City own = Cities.bySlug(stop.city);
                if (own != null) {
                    triedOwnCity = true;
                    this.city = own;
                    fetchDepartures();
                    return;
                }
            }
            departures.clear();
            departures.addAll(fresh);
            loaded = true;
            applyFilter();
        });
    }

    private class DepartureAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (filtered.isEmpty()) return 1; // loading / empty state
            return filtered.size();
        }

        @Override
        public Object getItem(int pos) {
            return pos;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public int getItemViewType(int pos) {
            return filtered.isEmpty() ? (loaded ? 1 : 2) : 0;
        }

        @Override
        public int getViewTypeCount() {
            return 3;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            if (filtered.isEmpty()) {
                if (!loaded) {
                    // v1.4.0: animated loading state instead of a static icon
                    View v = cv;
                    if (v == null || v.getId() != R.id.loadingRow) {
                        v = LayoutInflater.from(act).inflate(R.layout.row_loading, parent, false);
                    }
                    return v;
                }
                View v = cv;
                if (v == null || v.getId() != R.id.emptyText) {
                    v = LayoutInflater.from(act).inflate(R.layout.empty_state, parent, false);
                }
                ImageView iv = v.findViewById(R.id.emptyIcon);
                TextView tv = v.findViewById(R.id.emptyText);
                iv.setImageResource(R.drawable.timersand);
                tv.setText(R.string.no_results);
                return v;
            }
            View v = cv;
            if (v == null || v.getId() == R.id.emptyText || v.findViewById(R.id.depRoute) == null) {
                v = LayoutInflater.from(act).inflate(R.layout.row_departure, parent, false);
            }
            Models.Departure d = filtered.get(pos);
            long now = System.currentTimeMillis();

            TextView route = v.findViewById(R.id.depRoute);
            Ui.setPill(route, d.route.name.isEmpty() ? "?" : d.route.name, d.route.color);

            TextView head = v.findViewById(R.id.depHeadsign);
            head.setText(d.headsign != null ? d.headsign : "");
            Ui.strike(head, d.cancelled);

            // sub line: delay / Planowo / planned time
            TextView depSub = v.findViewById(R.id.depSub);
            if (d.cancelled) {
                depSub.setText(R.string.cancelled_short);
                depSub.setTextColor(0xFFB3261E);
            } else if (d.delay != null && d.realtime) {
                String dt = Ui.fmtDelay(d.delay);
                if (dt.isEmpty()) {
                    depSub.setText(R.string.planowo);
                    depSub.setTextColor(0xFF146C2E);
                } else {
                    depSub.setText(dt);
                    depSub.setTextColor(Ui.delayColor(d.delay));
                }
            } else if (d.delay != null) { // not realtime yet but delay predicted
                String dt = Ui.fmtDelay(d.delay);
                depSub.setText(dt.isEmpty() ? Ui.fmtTime(d.scheduledDeparture) : dt);
                depSub.setTextColor(dt.isEmpty() ? 0xFF5F5F66 : Ui.delayColor(d.delay));
            } else {
                depSub.setText(Ui.fmtTime(d.scheduledDeparture));
                depSub.setTextColor(0xFF5F5F66);
            }

            // right column: countdown only
            TextView count = v.findViewById(R.id.depCount);
            stopBlink(count);
            long est = d.scheduledDeparture + (d.delay == null ? 0 : d.delay);
            if (d.cancelled) {
                count.setText("—");
                count.setTextColor(0xFFB3261E);
            } else if (!d.realtime) {
                // v1.4.0: the run has not started — no "in X min", just the clock time
                count.setText(Ui.fmtTime(d.scheduledDeparture));
                count.setTextColor(0xFF5F5F66);
            } else {
                String ct = Ui.fmtCountdown(est, now);
                if (ct == null) {
                    count.setText(Ui.fmtTime(est));
                    count.setTextColor(0xFF1C1B1F);
                } else if (Ui.isBlinkCountdown(ct)) {
                    count.setText(ct);
                    startBlink(count);
                } else {
                    count.setText(ct);
                    count.setTextColor(0xFF1C1B1F);
                }
            }
            return v;
        }
    }

    // ------------------------------------------------------------ blinking

    private static void stopBlink(TextView tv) {
        Object tag = tv.getTag();
        if (tag instanceof ObjectAnimator) {
            ((ObjectAnimator) tag).cancel();
            tv.setTag(null);
            tv.setAlpha(1f);
        }
    }

    private static void startBlink(TextView tv) {
        ObjectAnimator a = ObjectAnimator.ofFloat(tv, "alpha", 1f, 0.25f);
        a.setDuration(420);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.setInterpolator(new LinearInterpolator());
        tv.setTag(a);
        a.start();
    }

    // ------------------------------------------------------------ timetables

    private void loadTimetable() {
        if (stop == null || city == null) return;
        final int gen = ++ttGen;
        timetableBox.removeAllViews();
        timetableBox.addView(loadingRow());

        // one GTFS per agency serving this stop (usually a single one)
        Set<String> agencies = new java.util.LinkedHashSet<>();
        if (stop.routes != null) {
            for (Models.Route r : stop.routes) {
                if (r.agency != null && !r.agency.isEmpty()) agencies.add(r.agency);
            }
        }
        if (agencies.isEmpty()) agencies.add("default");

        final Map<String, Gtfs.RouteTt> merged = new LinkedHashMap<>();
        final List<String> agencyList = new ArrayList<>(agencies);
        loadAgencyTimetables(0, agencyList, merged, gen);
    }

    private void loadAgencyTimetables(int idx, List<String> agencies, Map<String, Gtfs.RouteTt> merged, int gen) {
        if (idx >= agencies.size() || gen != ttGen) {
            if (gen == ttGen) buildTimetableUi(merged);
            return;
        }
        Gtfs.loadTimetable(act, city.slug, agencies.get(idx), stop.id, (routes, err) -> {
            if (gen != ttGen) return;
            if (routes != null) {
                for (Gtfs.RouteTt rt : routes.values()) {
                    String key = rt.routeName + "|" + rt.routeId;
                    if (!merged.containsKey(key)) merged.put(key, rt);
                }
            }
            loadAgencyTimetables(idx + 1, agencies, merged, gen);
        });
    }

    private View loadingRow() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        box.setPadding(Ui.dp(act, 18), Ui.dp(act, 16), Ui.dp(act, 18), Ui.dp(act, 16));
        android.widget.ProgressBar bar = new android.widget.ProgressBar(act);
        bar.setIndeterminate(true);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                Ui.dp(act, 22), Ui.dp(act, 22));
        box.addView(bar, blp);
        TextView tv = new TextView(act);
        tv.setText(R.string.loading);
        tv.setTextColor(0xFF5F5F66);
        tv.setTextSize(14);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.leftMargin = Ui.dp(act, 12);
        box.addView(tv, tlp);
        return box;
    }

    private void buildTimetableUi(Map<String, Gtfs.RouteTt> routes) {
        timetableBox.removeAllViews();
        if (routes.isEmpty()) {
            TextView tv = new TextView(act);
            tv.setText(R.string.no_results);
            tv.setTextColor(0xFF5F5F66);
            tv.setTextSize(14);
            tv.setPadding(Ui.dp(act, 18), Ui.dp(act, 18), Ui.dp(act, 18), Ui.dp(act, 18));
            timetableBox.addView(tv);
            return;
        }
        boolean filterTechnical = act.prefs.filterTechnical();
        List<Gtfs.RouteTt> list = new ArrayList<>();
        for (Gtfs.RouteTt rt : routes.values()) {
            if (Models.hiddenByTechnicalFilter(rt.routeName, filterTechnical)) continue;
            list.add(rt);
        }
        java.util.Collections.sort(list, (a, b) -> compareRouteNames(a.routeName, b.routeName));
        for (final Gtfs.RouteTt rt : list) {
            timetableBox.addView(timetableLineRow(rt));
        }
    }

    private static int compareRouteNames(String a, String b) {
        try {
            return Long.compare(Long.parseLong(a.trim()), Long.parseLong(b.trim()));
        } catch (Exception e) {
            return a.compareToIgnoreCase(b);
        }
    }

    /** Clean, flat timetable: line header, then plain wrapped times per day type. */
    private View timetableLineRow(final Gtfs.RouteTt rt) {
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(Ui.dp(act, 18), 0, Ui.dp(act, 18), 0);

        LinearLayout header = new LinearLayout(act);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, Ui.dp(act, 14), 0, Ui.dp(act, 10));
        header.setBackgroundResource(0);

        TextView pill = new TextView(act);
        Ui.setPill(pill, rt.routeName, rt.routeColor);
        pill.setTextSize(15);
        header.addView(pill, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        int total = rt.weekday.size() + rt.saturday.size() + rt.sunday.size();
        TextView count = new TextView(act);
        count.setText(Ui.plPlural(total, "kurs"));
        count.setTextColor(0xFF5F5F66);
        count.setTextSize(12);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        clp.leftMargin = Ui.dp(act, 10);
        header.addView(count, clp);

        final ImageView chev = new ImageView(act);
        chev.setImageResource(R.drawable.chevrondown);
        chev.setColorFilter(0xFF5F5F66);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(Ui.dp(act, 20), Ui.dp(act, 20));
        header.addView(chev, cl);

        final LinearLayout body = new LinearLayout(act);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(act, 2), 0, Ui.dp(act, 2), Ui.dp(act, 8));
        body.setVisibility(View.GONE);

        header.setOnClickListener(v -> {
            boolean open = body.getVisibility() == View.VISIBLE;
            body.setVisibility(open ? View.GONE : View.VISIBLE);
            chev.setRotation(open ? 0 : 180);
        });

        boolean hasWeekday = !rt.weekday.isEmpty();
        boolean hasSaturday = !rt.saturday.isEmpty();
        boolean hasSunday = !rt.sunday.isEmpty();
        if (hasWeekday) body.addView(daySection(R.string.timetable_weekday, rt.weekday, rt));
        if (hasSaturday) body.addView(daySection(R.string.timetable_saturday, rt.saturday, rt));
        if (hasSunday) body.addView(daySection(R.string.timetable_sunday, rt.sunday, rt));
        if (!hasWeekday && !hasSaturday && !hasSunday) {
            body.addView(emptyDaySection(R.string.timetable_no_service));
        }

        if (rt.variantColors.size() > 1) {
            body.addView(variantLegend(rt));
        }

        View divider = new View(act);
        divider.setBackgroundColor(0x148A8D94);
        row.addView(header);
        row.addView(body);
        row.addView(divider, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 1)));
        return row;
    }

    /** One day-type block: small gray label + wrapped plain times. */
    private View daySection(int labelRes, List<Gtfs.Tt> times, Gtfs.RouteTt rt) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, Ui.dp(act, 6), 0, Ui.dp(act, 8));
        TextView label = new TextView(act);
        label.setText(labelRes);
        label.setTextColor(0xFF5F5F66);
        label.setTextSize(11.5f);
        label.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        label.setAllCaps(true);
        label.setLetterSpacing(0.04f);
        box.addView(label);

        FlowLayout flow = new FlowLayout(act);
        flow.setPadding(0, Ui.dp(act, 4), 0, 0);
        boolean variants = rt.variantColors.size() > 1;
        for (Gtfs.Tt t : times) {
            TextView time = new TextView(act);
            time.setText(Ui.fmtGtfsTime(t.timeSec));
            time.setTextSize(14f);
            Integer vc = variants ? rt.variantColors.get(t.headsign) : null;
            if (vc != null) {
                // variant color as a small leading dot, time in the variant color
                time.setText("● " + Ui.fmtGtfsTime(t.timeSec));
                time.setTextColor(vc);
            } else {
                time.setTextColor(0xFF1C1B1F);
            }
            time.setPadding(Ui.dp(act, 2), Ui.dp(act, 2), Ui.dp(act, 8), Ui.dp(act, 2));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            flow.addView(time, lp);
        }
        box.addView(flow);
        return box;
    }

    /** Variant legend: colored dots + headsigns. */
    private View variantLegend(Gtfs.RouteTt rt) {
        LinearLayout legend = new LinearLayout(act);
        legend.setOrientation(LinearLayout.VERTICAL);
        legend.setPadding(0, Ui.dp(act, 10), 0, Ui.dp(act, 2));
        TextView title = new TextView(act);
        title.setText(R.string.timetable_variants);
        title.setTextColor(0xFF5F5F66);
        title.setTextSize(11.5f);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setAllCaps(true);
        title.setLetterSpacing(0.04f);
        legend.addView(title);
        for (Map.Entry<String, Integer> e : rt.variantColors.entrySet()) {
            LinearLayout lrow = new LinearLayout(act);
            lrow.setOrientation(LinearLayout.HORIZONTAL);
            lrow.setGravity(Gravity.CENTER_VERTICAL);
            lrow.setPadding(0, Ui.dp(act, 3), 0, 0);
            View dot = new View(act);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(e.getValue());
            dot.setBackground(g);
            lrow.addView(dot, new LinearLayout.LayoutParams(Ui.dp(act, 9), Ui.dp(act, 9)));
            TextView hs = new TextView(act);
            hs.setText(e.getKey());
            hs.setTextColor(0xFF1C1B1F);
            hs.setTextSize(12.5f);
            LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            hlp.leftMargin = Ui.dp(act, 8);
            lrow.addView(hs, hlp);
            legend.addView(lrow);
        }
        return legend;
    }

    private View emptyDaySection(int labelRes) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(0, Ui.dp(act, 6), 0, Ui.dp(act, 10));
        TextView none = new TextView(act);
        none.setText(labelRes);
        none.setTextColor(0xFF9AA0A6);
        none.setTextSize(13f);
        box.addView(none);
        return box;
    }
}
