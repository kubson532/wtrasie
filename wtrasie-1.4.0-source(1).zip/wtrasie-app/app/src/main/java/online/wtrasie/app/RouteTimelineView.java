package online.wtrasie.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * The route list of the previewed vehicle: scheduled time (struck through with
 * the estimated time below when deviating), a thick vertical route line whose
 * traveled part is gray and the remaining part keeps the route color, the
 * vehicle marker gliding between stops (animated between updates), stop name
 * with the delay line, and a countdown on the right that blinks red for
 * "&lt;1 min".
 *
 * v1.3.0: rows open a stop only on a confirmed single tap — never while
 * scrolling.
 */
public class RouteTimelineView extends View {

    public static class Row {
        public String stopId = "", name = "";
        public double lat, lon;
        public long schedMs;          // absolute scheduled arrival/departure
        public long estMs;            // estimated (sched + delay); <=0 = unknown
        public boolean passed;
        public String delayText = ""; // under the name: "Planowo" / "+3 min"
        public int delayColor;
        public String countText = ""; // right column
        public boolean blink;
    }

    public interface Listener {
        void onStopRowClicked(Row row);
    }

    private final List<Row> rows = new ArrayList<>();
    private Listener listener;
    private int routeColor = 0xFF1976D2;
    private int vehicleType = 3;
    private float progress; // 0..1 between stop idx-1 and idx (markerIndex)
    private int markerIndex; // index of the NEXT stop (0 = before first stop)
    private boolean hasMarker = false;
    private long lastBlinkToggle;
    private boolean blinkOn = true;

    // marker glide: displayed marker fraction animates toward the target
    private float markerPos;     // absolute row-fraction (idx-1 + progress)
    private float markerTarget;
    private ValueAnimator markerAnim;

    private final TextPaint timePaint = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
    private final TextPaint timeSubPaint = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
    private final TextPaint namePaint = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
    private final TextPaint subPaint = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
    private final TextPaint countPaint = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final GestureDetector gestures;

    private int rowH;
    private final Runnable blinkTick = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            if (now - lastBlinkToggle > 420) {
                lastBlinkToggle = now;
                blinkOn = !blinkOn;
            }
            if (hasBlink()) {
                postInvalidateOnAnimation();
                postDelayed(this, 60);
            }
        }
    };

    public RouteTimelineView(Context c) {
        super(c);
        gestures = buildGestures();
        init(c);
    }

    public RouteTimelineView(Context c, android.util.AttributeSet attrs) {
        super(c, attrs);
        gestures = buildGestures();
        init(c);
    }

    public RouteTimelineView(Context c, android.util.AttributeSet attrs, int defStyle) {
        super(c, attrs, defStyle);
        gestures = buildGestures();
        init(c);
    }

    private GestureDetector buildGestures() {
        return new GestureDetector(getContext(), new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                int idx = (int) ((e.getY() - Ui.dp(getContext(), 5)) / rowH);
                if (idx >= 0 && idx < rows.size()) {
                    final Row r = rows.get(idx);
                    post(() -> {
                        if (listener != null) {
                            try {
                                listener.onStopRowClicked(r);
                            } catch (Throwable ignored) {
                            }
                        }
                    });
                }
                return true;
            }
        });
    }

    private void init(Context c) {
        setClickable(true);
        timePaint.setColor(0xFF1C1B1F);
        timePaint.setTextSize(sp(13.5f));
        timePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        timeSubPaint.setTextSize(sp(11.5f));
        timeSubPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        namePaint.setColor(0xFF1C1B1F);
        namePaint.setTextSize(sp(14.5f));
        subPaint.setTextSize(sp(11f));
        countPaint.setColor(0xFF1C1B1F);
        countPaint.setTextSize(sp(14f));
        countPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(Ui.dp(c, 6f)); // v1.4.0: thicker route line per spec
        linePaint.setColor(0xFFC6C9D2);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        dotPaint.setStyle(Paint.Style.FILL);
        markerPaint.setStyle(Paint.Style.FILL);
        markerRing.setStyle(Paint.Style.STROKE);
        rowH = Ui.dp(c, 64);
    }

    private float sp(float v) {
        return v * getResources().getDisplayMetrics().scaledDensity;
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setRoute(int color, int vehicleType) {
        this.routeColor = color;
        this.vehicleType = vehicleType;
    }

    public void setRows(List<Row> r, int markerIndex, float progress, boolean hasMarker) {
        rows.clear();
        if (r != null) rows.addAll(r);
        this.markerIndex = markerIndex;
        this.progress = Math.max(0f, Math.min(1f, progress));
        this.hasMarker = hasMarker && rows.size() > 0;
        // glide the marker to the new position instead of jumping
        float target = this.markerIndex - 1 + this.progress;
        if (this.markerIndex <= 0) target = -0.5f + this.progress * 0.5f;
        if (!this.hasMarker) target = -1;
        markerTarget = target;
        if (markerAnim != null) markerAnim.cancel();
        if (hasMarker) {
            if (markerPos < 0 || markerAnim == null) {
                markerPos = target;
            } else {
                markerAnim = ValueAnimator.ofFloat(markerPos, target);
                markerAnim.setDuration(1200);
                markerAnim.setInterpolator(new android.view.animation.LinearInterpolator());
                markerAnim.addUpdateListener(a -> {
                    markerPos = (Float) a.getAnimatedValue();
                    invalidate();
                });
                markerAnim.start();
            }
        } else {
            markerPos = -1;
        }
        requestLayout();
        invalidate();
        if (hasBlink()) {
            removeCallbacks(blinkTick);
            post(blinkTick);
        }
    }

    public boolean hasBlink() {
        for (Row r : rows) if (r.blink) return true;
        return false;
    }

    /** Y position of the moving vehicle marker (for auto-scrolling). */
    public float markerY() {
        if (!hasMarker || rows.isEmpty()) return 0;
        if (markerPos >= 0) {
            float clamped = Math.max(-0.5f, Math.min(rows.size() - 0.5f, markerPos));
            return clamped * rowH + rowH * 0.5f;
        }
        float y1 = rowCenter(markerIndex - 1);
        float y2 = rowCenter(markerIndex);
        return y1 + (y2 - y1) * progress;
    }

    private float rowCenter(int idx) {
        if (idx < 0) return rowH * 0.5f;
        if (idx >= rows.size()) return rows.size() * rowH - rowH * 0.5f;
        return idx * rowH + rowH * 0.5f;
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int h = rows.size() * rowH + Ui.dp(getContext(), 10);
        setMeasuredDimension(View.MeasureSpec.getSize(widthSpec), Math.max(h, Ui.dp(getContext(), 60)));
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (rows.isEmpty()) return;
        float w = getWidth();
        float pad = Ui.dp(getContext(), 6);
        float timeX = pad + Ui.dp(getContext(), 4);
        float lineX = Ui.dp(getContext(), 74);
        float nameX = lineX + Ui.dp(getContext(), 14);
        float rightX = w - Ui.dp(getContext(), 10);
        float top = Ui.dp(getContext(), 5);

        // vertical route line: traveled part gray, remaining part in the route color
        float yStart = rowCenter(0);
        float yEnd = rowCenter(rows.size() - 1);
        float my = markerY();
        linePaint.setColor(0xFFC6C9D2);
        c.drawLine(lineX, yStart + top, lineX, Math.max(yStart + top, my + top), linePaint);
        linePaint.setColor(routeColor);
        c.drawLine(lineX, Math.max(yStart + top, my + top), lineX, yEnd + top, linePaint);

        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            float cy = rowCenter(i) + top;
            int alpha = r.passed ? 0x99 : 0xFF;

            // time column
            timePaint.setAlpha(alpha);
            if (r.estMs > 0 && r.estMs != r.schedMs) {
                // struck scheduled + estimated below
                String sched = Ui.fmtTime(r.schedMs);
                float tw = timePaint.measureText(sched);
                c.drawText(sched, timeX, cy - Ui.dp(getContext(), 6), timePaint);
                c.drawLine(timeX, cy - Ui.dp(getContext(), 11), timeX + tw, cy - Ui.dp(getContext(), 11), strikePaint(alpha));
                String est = Ui.fmtTime(r.estMs);
                timeSubPaint.setColor(Ui.delayColor(r.estMs - r.schedMs));
                c.drawText(est, timeX, cy + Ui.dp(getContext(), 8), timeSubPaint);
            } else {
                String sched = Ui.fmtTime(r.schedMs);
                timePaint.setAlpha(alpha);
                c.drawText(sched, timeX, cy + Ui.dp(getContext(), 2), timePaint);
            }

            // stop dot on the line
            dotPaint.setColor(r.passed ? 0xFFB8BABF : 0xFFFFFFFF);
            float dotR = Ui.dp(getContext(), 4);
            c.drawCircle(lineX, cy, dotR, dotPaint);
            dotPaint.setColor(r.passed ? 0xFFB8BABF : routeColor);
            c.drawCircle(lineX, cy, dotR - Ui.dp(getContext(), 1.1f), dotPaint);

            // name + delay line
            namePaint.setAlpha(alpha);
            String name = r.name == null || r.name.isEmpty() ? r.stopId : r.name;
            c.drawText(clip(namePaint, name, rightX - Ui.dp(getContext(), 78) - nameX), nameX, cy - Ui.dp(getContext(), 4), namePaint);
            if (r.delayText != null && !r.delayText.isEmpty()) {
                subPaint.setColor(r.delayColor);
                subPaint.setAlpha(alpha);
                c.drawText(r.delayText, nameX, cy + Ui.dp(getContext(), 12), subPaint);
            }

            // countdown
            if (r.countText != null && !r.countText.isEmpty()) {
                countPaint.setAlpha(alpha);
                countPaint.setColor(r.blink ? 0xFFC62200 : 0xFF1C1B1F);
                if (r.blink) {
                    float f = blinkOn ? 1f : 0.35f;
                    countPaint.setAlpha((int) (alpha * f));
                }
                float cw = countPaint.measureText(r.countText);
                c.drawText(r.countText, rightX - cw, cy + Ui.dp(getContext(), 2), countPaint);
            }
        }

        // moving vehicle marker on the line — always the full badge, never a dot
        if (hasMarker) {
            float mr = Ui.dp(getContext(), 10);
            markerRing.setColor(0xFFFFFFFF);
            markerRing.setStrokeWidth(Ui.dp(getContext(), 2));
            c.drawCircle(lineX, my + top, mr, markerRing);
            markerPaint.setColor(routeColor);
            c.drawCircle(lineX, my + top, mr - Ui.dp(getContext(), 1), markerPaint);
            try {
                Drawable d = getContext().getDrawable(Models.typeIcon(vehicleType));
                if (d != null) {
                    d.setTint(0xFFFFFFFF);
                    int inset = (int) (mr * 0.42f);
                    d.setBounds((int) lineX - inset, (int) (my + top) - inset, (int) lineX + inset, (int) (my + top) + inset);
                    d.draw(c);
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private Paint strikePaint(int alpha) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFF8A8D94);
        p.setAlpha(alpha);
        p.setStrokeWidth(Ui.dp(getContext(), 1.1f));
        return p;
    }

    private String clip(TextPaint tp, String s, float maxWidth) {
        if (maxWidth <= 0 || tp.measureText(s) <= maxWidth) return s;
        String ell = "…";
        while (s.length() > 1 && tp.measureText(s + ell) > maxWidth) {
            s = s.substring(0, s.length() - 1);
        }
        return s + ell;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        // only a confirmed single tap opens a stop; scrolling never does
        gestures.onTouchEvent(ev);
        return true;
    }
}
