package online.wtrasie.app;

import android.content.Context;
import android.content.SharedPreferences;

/** App settings persisted in SharedPreferences. */
public class Prefs {
    private final SharedPreferences p;

    public Prefs(Context c) {
        p = c.getSharedPreferences("wtrasie", Context.MODE_PRIVATE);
    }

    public int refreshInterval() {
        return p.getInt("refreshInterval", 10);
    }

    public void setRefreshInterval(int v) {
        p.edit().putInt("refreshInterval", v).apply();
    }

    public boolean showVehicles() {
        return p.getBoolean("showVehicles", true);
    }

    public void setShowVehicles(boolean v) {
        p.edit().putBoolean("showVehicles", v).apply();
    }

    public boolean showStops() {
        return p.getBoolean("showStops", true);
    }

    public void setShowStops(boolean v) {
        p.edit().putBoolean("showStops", v).apply();
    }

    /** 0 = small, 1 = medium, 2 = large */
    public int vehicleScale() {
        return p.getInt("vehicleScale", 1);
    }

    public void setVehicleScale(int v) {
        p.edit().putInt("vehicleScale", v).apply();
    }

    public boolean showBrigade() {
        return p.getBoolean("showBrigade", false);
    }

    public void setShowBrigade(boolean v) {
        p.edit().putBoolean("showBrigade", v).apply();
    }

    public boolean showFleet() {
        return p.getBoolean("showFleet", false);
    }

    public void setShowFleet(boolean v) {
        p.edit().putBoolean("showFleet", v).apply();
    }

    public boolean autoCity() {
        return p.getBoolean("autoCity", true);
    }

    public void setAutoCity(boolean v) {
        p.edit().putBoolean("autoCity", v).apply();
    }

    /**
     * "Filtruj przejazdy techniczne" — hide vehicles/departures of technical
     * runs (route names like "PT", "..." etc.). On by default.
     */
    public boolean filterTechnical() {
        return p.getBoolean("filterTechnical", true);
    }

    public void setFilterTechnical(boolean v) {
        p.edit().putBoolean("filterTechnical", v).apply();
    }

    /** "Pozostaw oryginalne kolory pojazdów" — off = unified type colors everywhere. */
    public boolean keepOriginalColors() {
        return p.getBoolean("keepOriginalColors", false);
    }

    public void setKeepOriginalColors(boolean v) {
        p.edit().putBoolean("keepOriginalColors", v).apply();
    }

    /** "Ukryj ikonę pojazdu" — on = only the line number chip, no type glyph. */
    public boolean hideVehicleIcon() {
        return p.getBoolean("hideVehicleIcon", true);
    }

    public void setHideVehicleIcon(boolean v) {
        p.edit().putBoolean("hideVehicleIcon", v).apply();
    }

    // ---------------------------------------------------------------- debug overlay

    /** "Nakładka debugu" profile: zoom thresholds shown as sliders in settings. */
    public boolean debugOverlay() {
        return p.getBoolean("debugOverlay", false);
    }

    public void setDebugOverlay(boolean v) {
        p.edit().putBoolean("debugOverlay", v).apply();
    }

    /** Vehicles become plain dots below this zoom (stored x10). */
    public int dotZoomVehicles() {
        return p.getInt("dotZoomVehicles", 130);
    }

    public void setDotZoomVehicles(int v) {
        p.edit().putInt("dotZoomVehicles", v).apply();
    }

    /** Stops are hidden below this zoom (stored x10). */
    public int dotZoomStops() {
        return p.getInt("dotZoomStops", 115);
    }

    public void setDotZoomStops(int v) {
        p.edit().putInt("dotZoomStops", v).apply();
    }

    /** PKP trains become plain dots below this zoom (stored x10). */
    public int dotZoomPkp() {
        return p.getInt("dotZoomPkp", 110);
    }

    public void setDotZoomPkp(int v) {
        p.edit().putInt("dotZoomPkp", v).apply();
    }

    // ---------------------------------------------------------------- map & city

    /** 0 = basic (vector, OpenFreeMap), 1 = OSM standard, 2 = satellite. */
    public int mapStyle() {
        if (p.contains("satellite")) { // migrate from 1.1.x
            boolean sat = p.getBoolean("satellite", false);
            p.edit().remove("satellite").putInt("mapStyle", sat ? 2 : 0).apply();
        }
        return p.getInt("mapStyle", 0);
    }

    public void setMapStyle(int v) {
        p.edit().putInt("mapStyle", v).apply();
    }

    public String lastCity() {
        return p.getString("lastCity", "warszawa");
    }

    public void setLastCity(String slug) {
        p.edit().putString("lastCity", slug).apply();
    }

    public double lastLat() {
        return Double.longBitsToDouble(p.getLong("lastLat", Double.doubleToRawLongBits(52.2297)));
    }

    public double lastLon() {
        return Double.longBitsToDouble(p.getLong("lastLon", Double.doubleToRawLongBits(21.0122)));
    }

    public double lastZoom() {
        return p.getFloat("lastZoom", 11.5f);
    }

    public void setCamera(double lat, double lon, double zoom) {
        p.edit().putLong("lastLat", Double.doubleToRawLongBits(lat))
                .putLong("lastLon", Double.doubleToRawLongBits(lon))
                .putFloat("lastZoom", (float) zoom)
                .apply();
    }

    public boolean typeFilter(int gtfsType) {
        return p.getBoolean("filter_" + filterKey(gtfsType), true);
    }

    public void setTypeFilter(int gtfsType, boolean on) {
        p.edit().putBoolean("filter_" + filterKey(gtfsType), on).apply();
    }

    public static int filterKey(int gtfsType) {
        switch (gtfsType) {
            case 0: return 0;   // tram
            case 1: return 1;   // subway
            case 2: return 2;   // rail
            case 3: return 3;   // bus
            case 4: return 4;   // ferry
            case 11: return 11; // trolleybus
            default: return 99; // gondola / funicular / monorail / other
        }
    }

    /** v1.4.0: every city starts with all vehicle types visible. */
    public void resetTypeFilters() {
        android.content.SharedPreferences.Editor e = p.edit();
        for (String key : p.getAll().keySet()) {
            if (key != null && key.startsWith("filter_")) e.putBoolean(key, true);
        }
        e.apply();
    }
}
