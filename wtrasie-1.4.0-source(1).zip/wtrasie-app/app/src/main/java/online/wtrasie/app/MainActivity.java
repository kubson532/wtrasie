package online.wtrasie.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.maplibre.android.geometry.LatLng;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity implements MapLayers.Listener {

    private static final String TAG = "Main";

    private static final int[] FILTER_ORDER = {3, 0, 1, 2, 11, 4, 99}; // bus, tram, metro, rail, trolley, ferry, other

    MapLayers map;
    Prefs prefs;
    Favorites favorites;
    Cities.City currentCity;
    CitySheet citySheet;
    SearchSheet searchSheet;
    StopSheet stopSheet;
    VehicleSheet vehicleSheet;

    private TextView cityName;
    private TextView attribution;
    private View topBar;
    private ViewGroup sheetContainer;
    private LinearLayout filterRow;
    private final Set<Integer> availableTypes = new LinkedHashSet<>();

    // tabs
    private View mapTab, routeTab, settingsTab;
    private View tabMapBtn, tabRouteBtn, tabSettingsBtn;
    private ImageView tabMapIcon, tabRouteIcon, tabSettingsIcon;
    private TextView tabMapLabel, tabRouteLabel, tabSettingsLabel;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable viewportSettled = this::viewportWork;
    private final Runnable positionsTick = new Runnable() {
        @Override
        public void run() {
            try {
                doFetchPositions(false);
            } catch (Throwable ignored) {
            }
            if (resumed) {
                handler.postDelayed(this, Math.max(3, prefs.refreshInterval()) * 1000L);
            }
        }
    };
    private Location lastLocation;
    private int tileStyle = -1;
    private long lastPositionsFetch;
    private long lastPkpFetch;
    private int switchGen = 0;
    private boolean resumed = false;
    private boolean mapReady = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // these must exist before any lifecycle callback can run
        prefs = new Prefs(this);
        favorites = new Favorites(this);
        // v1.4.0: "always show vehicles and stops" — both master toggles come back
        // ON at every app start; per-type filters reset with every city change
        prefs.setShowVehicles(true);
        prefs.setShowStops(true);
        try {
            // MapLibre native init must happen before the MapView is inflated
            try {
                org.maplibre.android.MapLibre.getInstance(this);
            } catch (Throwable ignored) {
            }
            setContentView(R.layout.activity_main);
        } catch (Throwable t) {
            android.util.Log.e(TAG, "setContentView failed", t);
            try {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {
            }
            finish();
            return;
        }

        sheetContainer = findViewById(R.id.sheetContainer);
        cityName = findViewById(R.id.cityName);
        attribution = findViewById(R.id.attribution);
        topBar = findViewById(R.id.topBar);
        filterRow = findViewById(R.id.filterRow);
        mapTab = findViewById(R.id.mapTab);
        routeTab = findViewById(R.id.routeTab);
        settingsTab = findViewById(R.id.settingsTab);

        map = new MapLayers(this, prefs, this);
        map.attach((org.maplibre.android.maps.MapView) findViewById(R.id.map));

        initTopBar();
        initFabs();
        initTabs();
        buildSettings();
        rebuildFilterRow();
        initSheets();

        // restore last session; first start defaults to Warsaw
        Cities.City last = Cities.bySlug(prefs.lastCity());
        if (last == null) last = Cities.bySlug("warszawa");
        currentCity = last;
        cityName.setText(currentCity.name);
        map.moveCamera(prefs.lastLat(), prefs.lastLon(), prefs.lastZoom());
    }

    // ------------------------------------------------------------------ MapLayers.Listener

    @Override
    public void onMapReady() {
        mapReady = true;
        applyTileSource();
        loadCityData(true);
    }

    @Override
    public void onViewportSettled() {
        handler.removeCallbacks(viewportSettled);
        // v1.4.0: dwell time — the city switches after the camera stays put for 3 s
        handler.postDelayed(viewportSettled, 3000);
    }

    @Override
    public void onRouteStopTapped(String stopId, String name, double lat, double lon) {
        openStopFromRoute(stopId, name, lat, lon);
    }

    // ------------------------------------------------------------------ tabs

    private void initTabs() {
        tabMapBtn = findViewById(R.id.tabMap);
        tabRouteBtn = findViewById(R.id.tabRoute);
        tabSettingsBtn = findViewById(R.id.tabSettings);
        tabMapIcon = findViewById(R.id.tabMapIcon);
        tabRouteIcon = findViewById(R.id.tabRouteIcon);
        tabSettingsIcon = findViewById(R.id.tabSettingsIcon);
        tabMapLabel = findViewById(R.id.tabMapLabel);
        tabRouteLabel = findViewById(R.id.tabRouteLabel);
        tabSettingsLabel = findViewById(R.id.tabSettingsLabel);

        tabMapBtn.setOnClickListener(v -> safe(() -> setTab(0)));
        tabRouteBtn.setOnClickListener(v -> safe(() -> setTab(1)));
        tabSettingsBtn.setOnClickListener(v -> safe(() -> setTab(2)));
        findViewById(R.id.helpCard).setOnClickListener(v -> safe(() ->
                startActivity(new Intent(this, HelpActivity.class))));
        setTab(0);
    }

    private void setTab(int idx) {
        mapTab.setVisibility(idx == 0 ? View.VISIBLE : View.INVISIBLE);
        routeTab.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        settingsTab.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        boolean m = idx == 0, r = idx == 1, s = idx == 2;
        tabMapIcon.setColorFilter(m ? 0xFF0B57D0 : 0xFF5F5F66);
        tabRouteIcon.setColorFilter(r ? 0xFF0B57D0 : 0xFF5F5F66);
        tabSettingsIcon.setColorFilter(s ? 0xFF0B57D0 : 0xFF5F5F66);
        tabMapLabel.setTextColor(m ? 0xFF0B57D0 : 0xFF5F5F66);
        tabRouteLabel.setTextColor(r ? 0xFF0B57D0 : 0xFF5F5F66);
        tabSettingsLabel.setTextColor(s ? 0xFF0B57D0 : 0xFF5F5F66);
        tabMapLabel.setTypeface(null, m ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabRouteLabel.setTypeface(null, r ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabSettingsLabel.setTypeface(null, s ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
    }

    // ------------------------------------------------------------------ ui

    private void initTopBar() {
        ImageButton btnChevron = findViewById(R.id.btnCityChevron);
        View searchField = findViewById(R.id.searchField);

        // FIX v1.3.0: the city sheet was never shown after openSheetAlone()
        View.OnClickListener cityClick = v -> safe(() -> {
            openSheetAlone(citySheet, citySheet);
            citySheet.show();
        });
        btnChevron.setOnClickListener(cityClick);
        cityName.setOnClickListener(cityClick);

        searchField.setOnClickListener(v -> safe(() -> {
            openSheetAlone(searchSheet, searchSheet);
            searchSheet.openWithKeyboard();
        }));
    }

    private void initFabs() {
        findViewById(R.id.fabLocate).setOnClickListener(v -> safe(this::onLocateClicked));
        findViewById(R.id.fabFavorites).setOnClickListener(v -> safe(() -> {
            openSheetAlone(searchSheet, searchSheet);
            searchSheet.show();
        }));
        initRefreshButton();
    }

    /**
     * Small manual refresh button (map positions) with a 5 s cooldown: after a
     * refresh it goes gray with a live countdown, then re-enables.
     */
    private void initRefreshButton() {
        btnRefresh = findViewById(R.id.fabRefresh);
        refreshCount = findViewById(R.id.fabRefreshCount);
        refreshIcon = findViewById(R.id.fabRefreshIcon);
        if (btnRefresh == null) return;
        btnRefresh.setOnClickListener(v -> safe(() -> {
            if (refreshCooldown > 0) return;
            doFetchPositions(true);
            refreshCooldown = 5;
            setRefreshEnabled(false);
            if (refreshCount != null) refreshCount.setText(String.valueOf(refreshCooldown));
            handler.removeCallbacks(refreshCooldownTick);
            handler.postDelayed(refreshCooldownTick, 1000);
        }));
        setRefreshEnabled(true);
    }

    private void setRefreshEnabled(boolean enabled) {
        if (btnRefresh == null) return;
        btnRefresh.setAlpha(enabled ? 1f : 0.55f);
        if (refreshIcon != null) refreshIcon.setColorFilter(enabled ? 0xFF0B57D0 : 0xFF9AA0A6);
        if (refreshCount != null) refreshCount.setVisibility(enabled ? View.INVISIBLE : View.VISIBLE);
    }

    /** Hide every sheet except `keep` (which will be opened by the caller). */
    private void openSheetAlone(Sheet keep, Sheet toOpen) {
        Sheet[] all = {citySheet, searchSheet, stopSheet, vehicleSheet};
        for (Sheet x : all) {
            if (x != null && x != keep && x.getState() != Sheet.HIDDEN) x.hide();
        }
        if (toOpen != null && toOpen != keep && toOpen.getState() != Sheet.HIDDEN) toOpen.hide();
    }

    private void safe(Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            android.util.Log.e(TAG, "ui action failed", t);
        }
    }

    // ------------------------------------------------------------------ type filters

    private void noteStopTypes(List<Models.Stop> stops) {
        boolean added = false;
        if (stops != null) {
            for (Models.Stop s : stops) {
                for (int t : s.types) {
                    if (availableTypes.add(t)) added = true;
                }
            }
        }
        if (added) rebuildFilterRow();
    }

    private void noteVehicleTypes(List<Models.Vehicle> vehicles) {
        boolean added = false;
        if (vehicles != null) {
            for (Models.Vehicle v : vehicles) {
                if (availableTypes.add(v.typeInt())) added = true;
            }
        }
        if (added) rebuildFilterRow();
    }

    private void rebuildFilterRow() {
        if (filterRow == null) return;
        filterRow.removeAllViews();
        Set<Integer> show = availableTypes.isEmpty()
                ? new LinkedHashSet<>(java.util.Arrays.asList(3, 0, 1, 2, 11, 4, 99))
                : new LinkedHashSet<>();
        if (availableTypes.isEmpty()) {
            // nothing loaded yet: show the standard set
        } else {
            for (int t : FILTER_ORDER) {
                for (int at : availableTypes) {
                    if (gtfsOf(t) == gtfsOf(at)) {
                        show.add(t);
                        break;
                    }
                }
            }
        }
        for (int filterType : show) {
            final int ft = filterType;
            FrameLayout btn = new FrameLayout(this);
            int size = Ui.dp(this, 36);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.rightMargin = Ui.dp(this, 8);
            btn.setLayoutParams(lp);
            btn.setElevation(Ui.dp(this, 4));

            View iv;
            if (ft == 1) {
                TextView tv = new TextView(this);
                tv.setText("M");
                tv.setTextSize(15);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                iv = tv;
            } else {
                ImageView im = new ImageView(this);
                FrameLayout.LayoutParams ivp = new FrameLayout.LayoutParams(
                        Ui.dp(this, 18), Ui.dp(this, 18));
                ivp.gravity = android.view.Gravity.CENTER;
                im.setLayoutParams(ivp);
                im.setImageResource(filterIcon(ft));
                iv = im;
            }
            btn.addView(iv);
            btn.setOnClickListener(v -> safe(() -> {
                boolean on = !prefs.typeFilter(gtfsOf(ft));
                prefs.setTypeFilter(gtfsOf(ft), on);
                styleFilterButton(btn, ft, on);
                if (map != null) {
                    map.rebuildPublic();
                }
            }));
            styleFilterButton(btn, ft, prefs.typeFilter(gtfsOf(ft)));
            filterRow.addView(btn);
        }
    }

    private static int gtfsOf(int filterType) {
        return filterType == 99 ? 6 : filterType; // prefs store real gtfs type; 99 collapses into 6
    }

    private int filterIcon(int filterType) {
        switch (filterType) {
            case 0: return R.drawable.ic_type_tram;
            case 1: return R.drawable.ic_metro_m;
            case 2: return R.drawable.ic_type_train;
            case 4: return R.drawable.ic_type_ferry;
            case 11: return R.drawable.ic_type_trolleybus;
            case 99: return R.drawable.ic_type_gondola;
            default: return R.drawable.ic_type_bus;
        }
    }

    private void styleFilterButton(FrameLayout btn, int filterType, boolean on) {
        int color = Models.typeColor(filterType == 99 ? 6 : filterType);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(on ? color : 0xFFE8EAED);
        btn.setBackground(bg);
        View child = btn.getChildAt(0);
        if (child instanceof ImageView) {
            ((ImageView) child).setColorFilter(on ? 0xFFFFFFFF : 0xFF5F5F66);
        } else if (child instanceof TextView) {
            ((TextView) child).setTextColor(on ? 0xFFFFFFFF : 0xFF5F5F66);
        }
    }

    // ------------------------------------------------------------------ sheets

    private void initSheets() {
        sheetContainer.removeAllViews();
        citySheet = new CitySheet(this, city -> switchCity(city, true));
        searchSheet = new SearchSheet(this, new SearchSheet.Listener() {
            @Override
            public void onLocalStopPicked(Models.Stop stop) {
                openStopFromSearch(stop);
            }

            @Override
            public void onPlacePicked(Api.Place place) {
                openPlace(place);
            }

            @Override
            public void onVehiclePicked(Models.Vehicle vehicle) {
                searchSheet.hide();
                onVehicleTapped(vehicle);
            }
        });
        stopSheet = new StopSheet(this);
        vehicleSheet = new VehicleSheet(this);

        addSheet(citySheet);
        addSheet(searchSheet);
        addSheet(stopSheet);
        addSheet(vehicleSheet);
    }

    private void addSheet(Sheet s) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = android.view.Gravity.BOTTOM;
        sheetContainer.addView(s, lp);
        s.setVisibility(View.GONE);
    }

    // ------------------------------------------------------------------ city & data

    void loadCityData(boolean fetchPositions) {
        if (currentCity == null) return;
        final int gen = ++switchGen;
        availableTypes.clear();
        map.setCity(currentCity.slug);
        if (currentCity.nationwide) {
            map.setStops(new java.util.ArrayList<>());
            fetchStopsForViewport();
        } else {
            Api.getStopsCached(this, currentCity.slug, (stops, err) -> {
                if (gen != switchGen) return;
                if (stops != null && !stops.isEmpty()) {
                    map.setStops(stops);
                    noteStopTypes(stops);
                    if (searchSheet != null) searchSheet.onStopsChanged();
                } else if (err != null && map.getStops().isEmpty()) {
                    Toast.makeText(this, R.string.error_network, Toast.LENGTH_SHORT).show();
                }
            });
        }
        if (fetchPositions) {
            handler.removeCallbacks(positionsTick);
            handler.post(positionsTick);
        }
    }

    void switchCity(Cities.City city, boolean moveCamera) {
        if (city == null || city.slug.equals(currentCity == null ? null : currentCity.slug)) {
            if (moveCamera && city != null) {
                map.centerOn(city.lat, city.lon, city.zoom);
            }
            return;
        }
        currentCity = city;
        cityName.setText(city.name);
        prefs.setLastCity(city.slug);
        map.setStops(new java.util.ArrayList<>());
        map.setVehicles(new java.util.ArrayList<>());
        availableTypes.clear();
        prefs.resetTypeFilters(); // v1.4.0: every new city starts with all types on
        rebuildFilterRow();
        if (moveCamera) {
            map.centerOn(city.lat, city.lon, city.zoom);
        }
        loadCityData(true);
    }

    void centerOn(double lat, double lon, double zoom) {
        // never fly to Null Island: stops without coordinates fall back to the city
        if ((lat == 0 && lon == 0) || Math.abs(lat) > 85 || Math.abs(lon) > 180) {
            if (currentCity != null) {
                map.centerOn(currentCity.lat, currentCity.lon, currentCity.zoom);
            }
            return;
        }
        map.centerOn(lat, lon, zoom);
    }

    private void viewportWork() {
        if (!resumed || map == null) return;
        try {
            LatLng center = map.center();
            double zoom = map.camZoom();

            // auto city switch: after 3 s of a still camera, whichever city the
            // viewport actually looks at gets selected (also from nationwide feeds)
            if (prefs.autoCity() && currentCity != null
                    && (vehicleSheet == null || vehicleSheet.getState() == Sheet.HIDDEN)) {
                double maxKm = Math.min(60, Math.max(25, map.spanKm() / 2));
                Cities.City near = Cities.nearest(center.getLatitude(), center.getLongitude(), maxKm);
                if (near != null && !near.slug.equals(currentCity.slug)) {
                    switchCity(near, false);
                    return; // switchCity already reloads data
                }
            }

            // stops for nationwide feeds (and as fallback for cities without cache)
            if (currentCity != null && currentCity.nationwide && zoom >= 10.5) {
                fetchStopsForViewport();
            }
            fetchPositions();
        } catch (Throwable t) {
            android.util.Log.e(TAG, "viewport", t);
        }
    }

    private void fetchStopsForViewport() {
        if (currentCity == null) return;
        final int gen = switchGen;
        String bbox = map.bboxString();
        Api.getJson(Api.stopsUrl(currentCity.slug, bbox), (json, err) -> {
            if (gen != switchGen || json == null) return;
            List<Models.Stop> stops = Models.Stop.parseList(json);
            map.setStops(stops);
            noteStopTypes(stops);
            if (searchSheet != null) searchSheet.onStopsChanged();
        });
    }

    void fetchPositions() {
        doFetchPositions(true);
    }

    private void doFetchPositions(boolean force) {
        if (!resumed || currentCity == null) return;
        long now = android.os.SystemClock.elapsedRealtime();
        if (!force && now - lastPositionsFetch < 2500) return;
        lastPositionsFetch = now;
        final int gen = switchGen;
        Api.getJson(Api.positionsUrl(currentCity.slug, map.bboxString()), (json, err) -> {
            if (gen != switchGen || json == null) return;
            List<Models.Vehicle> vehicles = Models.Vehicle.parseList(json);
            map.setVehicles(vehicles);
            noteVehicleTypes(vehicles);
            afterPositions(vehicles);
        });
        // PKP trains are always shown, whatever city is active (rate-limited separately)
        if (currentCity == null || !currentCity.slug.equals("pkp")) {
            if (force || now - lastPkpFetch > 20000) {
                lastPkpFetch = now;
                final int gen2 = switchGen;
                Api.getJson(Api.positionsUrl("pkp", map.bboxString()), (json, err) -> {
                    if (gen2 != switchGen || json == null) return;
                    map.setPkpVehicles(Models.Vehicle.parseList(json));
                });
            }
        }
    }

    /** Live-update an open vehicle sheet (no map tracking — v1.4.0 removed it). */
    private void afterPositions(List<Models.Vehicle> vehicles) {
        try {
            if (vehicleSheet != null && vehicleSheet.getState() != Sheet.HIDDEN) {
                String id = vehicleSheet.getCurrentVehicleId();
                if (id != null) {
                    List<Models.Vehicle> all = map.getVehicles();
                    for (Models.Vehicle v : all) {
                        if (v.id.equals(id)) {
                            vehicleSheet.update(v);
                            break;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ vehicle preview

    public void onVehicleTapped(Models.Vehicle vehicle) {
        safe(() -> {
            openSheetAlone(vehicleSheet, vehicleSheet);
            map.setHighlight(vehicle.rtKey());
            // PKP trains live in their own nationwide feed — trips must load from there
            Cities.City vc = vehicle.pkp ? Cities.bySlug("pkp") : currentCity;
            if (vc == null) vc = currentCity;
            vehicleSheet.open(vc, vehicle);
            map.clearTrip();
        });
    }

    /** Unified display color of a vehicle (type palette, or feed color when kept). */
    int vehicleColor(Models.Vehicle v) {
        if (v == null) return 0xFFD32F2F;
        return prefs.keepOriginalColors() ? v.routeColor : Models.typeColor(v.typeInt());
    }

    /** The trip finished loading: draw it on the map and zoom to fit. */
    void onVehicleTripLoaded(Gtfs.Trip trip) {
        safe(() -> {
            Models.Vehicle v = vehicleSheet == null ? null : vehicleSheet.getVehicle();
            int color = v != null ? vehicleColor(v) : 0xFF1976D2;
            map.setTrip(trip, color);
            if (trip.shape != null && trip.shape.size() >= 2) {
                double[][] pts = new double[trip.shape.size()][2];
                for (int i = 0; i < trip.shape.size(); i++) {
                    pts[i][0] = trip.shape.get(i)[0];
                    pts[i][1] = trip.shape.get(i)[1];
                }
                map.fitTrip(pts, 0.62);
            }
        });
    }

    void onVehiclePreviewClosed() {
        try {
            map.setHighlight(null);
            map.clearTrip();
        } catch (Throwable ignored) {
        }
    }

    /**
     * Best live vehicle for a departure among the given list. v1.4.0 STRICT:
     * the brigade must match — a "whatever vehicle of this line is closest"
     * fallback was opening the wrong (earliest) trip when the tapped one had
     * not departed yet.
     */
    private Models.Vehicle matchDepartureVehicle(Models.Departure d, Models.Stop stop, List<Models.Vehicle> vs) {
        if (vs == null || vs.isEmpty() || d == null) return null;
        boolean hasBrigade = d.brigade != null && !d.brigade.trim().isEmpty();
        Models.Vehicle brigadeMatch = null;
        List<Models.Vehicle> sameRoute = new ArrayList<>();
        for (Models.Vehicle v : vs) {
            if (!routeEq(v.routeName, d.route.name)) continue;
            sameRoute.add(v);
            if (hasBrigade && brigadeEq(v.brigade, d.brigade)) {
                brigadeMatch = v;
                break;
            }
        }
        if (brigadeMatch != null) return brigadeMatch;
        // no brigade info on the departure: accept the only vehicle of the line
        if (!hasBrigade && sameRoute.size() == 1) return sameRoute.get(0);
        return null;
    }

    /**
     * Open the vehicle preview for a tapped departure. v1.4.0:
     *  1. a live vehicle matches only by route + brigade (the exact run);
     *  2. when the run has not started, the GTFS trip of THAT departure opens
     *     as a planned preview — never the earliest vehicle of the line.
     */
    void openVehicleForDeparture(Models.Departure d, Models.Stop stop) {
        safe(() -> {
            Cities.City f = stopSheet == null ? currentCity : stopSheet.getFeedCity();
            final Cities.City feed = f != null ? f : currentCity;
            Models.Vehicle best = matchDepartureVehicle(d, stop, map.getVehicles());
            if (best != null) {
                onVehicleTapped(best);
                return;
            }
            if (d.realtime) {
                Toast.makeText(this, R.string.searching_vehicle, Toast.LENGTH_SHORT).show();
            }
            double lat = stop != null && stop.lat != 0 ? stop.lat
                    : (currentCity != null ? currentCity.lat : 52.23);
            double lon = stop != null && stop.lon != 0 ? stop.lon
                    : (currentCity != null ? currentCity.lon : 21.01);
            boolean rail = d.route.type == 2 || d.route.type == 1;
            fetchWideVehicles(lat, lon, rail, vehicles -> safe(() -> {
                Models.Vehicle found = matchDepartureVehicle(d, stop, vehicles);
                if (found != null) {
                    onVehicleTapped(found);
                } else {
                    // the tapped run is not on the road: show its planned trip
                    openSheetAlone(vehicleSheet, vehicleSheet);
                    vehicleSheet.openScheduled(feed, d, stop);
                }
            }));
        });
    }

    /**
     * Positions from a wide box around the given point (current city feed +
     * the nationwide PKP feed when asked). One-shot, used by departure taps
     * and the line-vehicle search list.
     */
    void fetchWideVehicles(double lat, double lon, boolean includePkp,
                           java.util.function.Consumer<List<Models.Vehicle>> done) {
        final List<Models.Vehicle> merged = new java.util.ArrayList<>();
        final String citySlug = currentCity == null ? "warszawa" : currentCity.slug;
        final boolean nationwide = currentCity != null && currentCity.nationwide;
        // ~45 km box for a city; wider for nationwide feeds
        double dLat = nationwide ? 2.2 : 0.42;
        double dLon = nationwide ? 3.4 : 0.62;
        String bbox = String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f",
                lon - dLon, lat - dLat, lon + dLon, lat + dLat);
        final boolean wantPkp = includePkp || "pkp".equals(citySlug);
        final int[] pending = {wantPkp ? 2 : 1};
        Runnable finish = () -> {
            if (pending[0] > 0) pending[0]--;
            if (pending[0] == 0) {
                try {
                    done.accept(merged);
                } catch (Throwable t) {
                    android.util.Log.e(TAG, "wide vehicles cb", t);
                }
            }
        };
        Api.getJson(Api.positionsUrl(citySlug, bbox), (json, err) -> {
            if (json != null) merged.addAll(Models.Vehicle.parseList(json));
            finish.run();
        });
        if (wantPkp && !"pkp".equals(citySlug)) {
            Api.getJson(Api.positionsUrl("pkp", bbox), (json, err) -> {
                if (json != null) {
                    List<Models.Vehicle> pkpList = Models.Vehicle.parseList(json);
                    for (Models.Vehicle v : pkpList) v.pkp = true;
                    merged.addAll(pkpList);
                }
                finish.run();
            });
        }
    }

    private static boolean routeEq(String a, String b) {
        return a != null && b != null && a.trim().equalsIgnoreCase(b.trim());
    }

    private static boolean brigadeEq(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        return a.trim().equalsIgnoreCase(b.trim());
    }

    /** A stop was tapped inside the vehicle route view (or on a route dot). */
    void openStopFromRoute(String stopId, String name, double lat, double lon) {
        safe(() -> {
            String apiId = Gtfs.apiStopId(stopId); // PKP "x----x:2" -> "x"
            Models.Stop found = null;
            for (Models.Stop s : map.getStops()) {
                if (s.id != null && (s.id.equals(apiId) || s.id.equals(stopId))) {
                    found = s;
                    break;
                }
            }
            // the trip was loaded from the vehicle's own feed city (e.g. pkp) —
            // departures must be queried there, not in the current city
            Cities.City vCity = vehicleSheet == null ? null : vehicleSheet.getCity();
            if (vCity == null) vCity = currentCity;
            if (found == null) {
                found = new Models.Stop();
                found.id = apiId.isEmpty() ? "" : apiId;
                found.name = name == null ? "" : name;
                found.lat = lat;
                found.lon = lon;
                found.city = vCity == null ? "" : vCity.slug;
                Models.Vehicle v = vehicleSheet == null ? null : vehicleSheet.getVehicle();
                found.types = new int[]{v == null ? 3 : v.typeInt()};
            }
            openSheetAlone(stopSheet, stopSheet);
            stopSheet.open(vCity, found);
        });
    }

    // ------------------------------------------------------------------ taps

    public void onStopTapped(Models.Stop stop) {
        safe(() -> {
            openSheetAlone(stopSheet, stopSheet);
            stopSheet.open(currentCity, stop);
        });
    }

    private void openStopFromSearch(Models.Stop stop) {
        safe(() -> {
            Cities.City t = Cities.bySlug(stop.city);
            if (t == null) t = currentCity;
            if (t == null) return;
            final Cities.City target = t;
            if (stop.lat == 0 && stop.lon == 0) {
                // favorite/recent without saved coordinates: resolve by id
                Api.getStopsCached(this, target.slug, (stops, err) -> {
                    Models.Stop found = null;
                    if (stops != null) {
                        for (Models.Stop s : stops) {
                            if (s.id != null && s.id.equals(stop.id)) {
                                found = s;
                                break;
                            }
                        }
                    }
                    final Models.Stop fs = found;
                    runOnUiThread(() -> safe(() -> {
                        Models.Stop finalStop;
                        if (fs != null) {
                            finalStop = fs;
                        } else {
                            // not in the list: fall back to the city center so the
                            // favorite still opens something sane
                            stop.lat = target.lat;
                            stop.lon = target.lon;
                            finalStop = stop;
                        }
                        reallyOpenStop(target, finalStop);
                    }));
                });
                return;
            }
            reallyOpenStop(target, stop);
        });
    }

    private void reallyOpenStop(Cities.City target, Models.Stop stop) {
        if (currentCity == null || !target.slug.equals(currentCity.slug)) {
            switchCity(target, false);
        }
        searchSheet.hide();
        centerOn(stop.lat, stop.lon, 16.0);
        openSheetAlone(stopSheet, stopSheet);
        stopSheet.open(target, stop);
    }

    /**
     * Geocoded place -> resolve the real stop. Train stations (rail modes) are
     * matched by NAME first (both the PKP feed and the city feed), so searching
     * a station no longer dumps you on a random nearby bus stop. Stops in other
     * cities switch the city automatically.
     */
    private void openPlace(Api.Place place) {
        safe(() -> {
            searchSheet.hide();
            Cities.City target = cityFromPlace(place);
            if (target == null) {
                Toast.makeText(this, R.string.no_results, Toast.LENGTH_SHORT).show();
                return;
            }
            if (currentCity == null || !target.slug.equals(currentCity.slug)) {
                switchCity(target, false);
            }
            centerOn(place.lat, place.lon, 16.0);
            String bbox = String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f",
                    place.lon - 0.008, place.lat - 0.005, place.lon + 0.008, place.lat + 0.005);
            final Cities.City city = target;
            final boolean rail = place.rail;
            final String name = place.name == null ? "" : place.name;
            // for rail stations also query the nationwide PKP feed
            if (rail) {
                Api.getJson(Api.stopsUrl("pkp", bbox), (json, err) -> {
                    Models.Stop found = json == null ? null
                            : findStopFor(Models.Stop.parseList(json), place, true);
                    if (found != null) {
                        openResolvedStop(found, city, place);
                    }
                });
            }
            Api.getJson(Api.stopsUrl(city.slug, bbox), (json, err) -> {
                if (json == null) return;
                Models.Stop best = findStopFor(Models.Stop.parseList(json), place, rail);
                if (best == null && rail) return; // PKP query may still deliver
                openResolvedStop(best, city, place);
            });
        });
    }

    private void openResolvedStop(Models.Stop best, Cities.City city, Api.Place place) {
        if (best != null) {
            openSheetAlone(stopSheet, stopSheet);
            stopSheet.open(city, best);
        }
    }

    /** Prefer stops whose name matches the geocoded station; fall back to the nearest one. */
    private Models.Stop findStopFor(List<Models.Stop> stops, Api.Place place, boolean preferRail) {
        if (stops == null || stops.isEmpty()) return null;
        String pn = Ui.norm(place.name);
        Models.Stop nameMatch = null, railMatch = null, nearest = null;
        double bestD = Double.MAX_VALUE;
        for (Models.Stop s : stops) {
            double d = Ui.distM(place.lat, place.lon, s.lat, s.lon);
            if (d < bestD) {
                bestD = d;
                nearest = s;
            }
            if (nameMatch == null && !pn.isEmpty()
                    && (Ui.norm(s.name).contains(pn) || pn.contains(Ui.norm(s.name)))) {
                nameMatch = s;
                for (int t : s.types) {
                    if (t == 2 || t == 1) {
                        railMatch = s;
                        break;
                    }
                }
            }
        }
        if (preferRail && railMatch != null) return railMatch;
        if (nameMatch != null) return nameMatch;
        return bestD < 400 ? nearest : null;
    }

    /** "pl-Rzeszów_628" -> Rzeszów city; falls back to nearest city by coordinates. */
    private Cities.City cityFromPlace(Api.Place place) {
        try {
            String id = place.id;
            if (id != null && id.contains("-") && id.lastIndexOf('_') > id.indexOf('-')) {
                String cityPart = id.substring(id.indexOf('-') + 1, id.lastIndexOf('_'));
                Cities.City c = Cities.byName(cityPart.replace('_', ' '));
                if (c != null) return c;
            }
        } catch (Throwable ignored) {
        }
        return Cities.nearest(place.lat, place.lon, 80);
    }

    // ------------------------------------------------------------------ location

    private void onLocateClicked() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            return;
        }
        enableLocation();
    }

    private void enableLocation() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) {
                try {
                    Location last = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (last == null) last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (last != null) {
                        lastLocation = last;
                        map.setLocation(last.getLatitude(), last.getLongitude());
                        centerOn(last.getLatitude(), last.getLongitude(), 15.0);
                    }
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 15000, 20, locationListener);
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10, locationListener);
                } catch (SecurityException | IllegalArgumentException ignored) {
                }
            }
        } catch (Throwable t) {
            android.util.Log.e(TAG, "location", t);
        }
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            lastLocation = l;
            try {
                map.setLocation(l.getLatitude(), l.getLongitude());
            } catch (Throwable ignored) {
            }
        }

        @Override
        public void onStatusChanged(String p, int s, Bundle e) {
        }

        @Override
        public void onProviderEnabled(String p) {
        }

        @Override
        public void onProviderDisabled(String p) {
        }
    };

    Location getLastLocation() {
        if (lastLocation != null) return lastLocation;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) {
                Location l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (l == null) l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (l != null) lastLocation = l;
            }
        } catch (Throwable ignored) {
        }
        return lastLocation;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (code == 1 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            enableLocation();
        }
    }

    // ------------------------------------------------------------------ settings tab

    private static final int[] REFRESH_VALUES = {5, 10, 15, 30};
    private static final String[] SCALE_NAMES = {"S", "M", "L"};

    // manual map refresh button: 5 s cooldown with a live countdown
    private View btnRefresh;
    private TextView refreshCount;
    private ImageView refreshIcon;
    private int refreshCooldown = 0;
    private final Runnable refreshCooldownTick = new Runnable() {
        @Override
        public void run() {
            refreshCooldown--;
            if (refreshCooldown <= 0) {
                setRefreshEnabled(true);
                return;
            }
            if (refreshCount != null) refreshCount.setText(String.valueOf(refreshCooldown));
            handler.postDelayed(this, 1000);
        }
    };

    private void buildSettings() {
        LinearLayout list = findViewById(R.id.settingsList);
        list.removeAllViews();

        // ---- Widoczność obiektów na mapie ----
        addSectionHeader(list, getString(R.string.settings_section_visibility));
        addSwitchRow(list, R.drawable.bus, getString(R.string.settings_vehicles_on_map),
                prefs.showVehicles(), on -> {
                    prefs.setShowVehicles(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.pin, getString(R.string.settings_stops_on_map),
                prefs.showStops(), on -> {
                    prefs.setShowStops(on);
                    if (map != null) map.rebuildPublic();
                });
        addSliderRow(list, R.drawable.bus, getString(R.string.settings_debug_vehicles),
                prefs.dotZoomVehicles(), 60, 190, v -> {
                    prefs.setDotZoomVehicles(v);
                    if (map != null) map.refreshThresholds();
                });
        addSliderRow(list, R.drawable.pin, getString(R.string.settings_debug_stops),
                prefs.dotZoomStops(), 60, 190, v -> {
                    prefs.setDotZoomStops(v);
                    if (map != null) map.refreshThresholds();
                });
        addSliderRow(list, R.drawable.ic_type_train, getString(R.string.settings_debug_pkp),
                prefs.dotZoomPkp(), 60, 190, v -> {
                    prefs.setDotZoomPkp(v);
                    if (map != null) map.refreshThresholds();
                });
        addSwitchRow(list, R.drawable.bus, getString(R.string.settings_hide_vehicle_icon),
                prefs.hideVehicleIcon(), on -> {
                    prefs.setHideVehicleIcon(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.layers, getString(R.string.settings_keep_colors),
                prefs.keepOriginalColors(), on -> {
                    prefs.setKeepOriginalColors(on);
                    if (map != null) map.rebuildPublic();
                });

        addSectionHeader(list, getString(R.string.settings_section_general));
        addValueRow(list, R.drawable.clockoutline, getString(R.string.settings_refresh),
                prefs.refreshInterval() + " s", () -> {
                    int cur = prefs.refreshInterval();
                    int next = REFRESH_VALUES[0];
                    for (int i = 0; i < REFRESH_VALUES.length; i++) {
                        if (REFRESH_VALUES[i] == cur) next = REFRESH_VALUES[(i + 1) % REFRESH_VALUES.length];
                    }
                    prefs.setRefreshInterval(next);
                    return next + " s";
                });
        addValueRow(list, R.drawable.tune, getString(R.string.settings_marker_size),
                SCALE_NAMES[prefs.vehicleScale()], () -> {
                    int next = (prefs.vehicleScale() + 1) % 3;
                    prefs.setVehicleScale(next);
                    return SCALE_NAMES[next];
                });
        addSwitchRow(list, R.drawable.tag, getString(R.string.settings_brigade),
                prefs.showBrigade(), on -> {
                    prefs.setShowBrigade(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.numeric, getString(R.string.settings_fleet),
                prefs.showFleet(), on -> {
                    prefs.setShowFleet(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.transitconnection, getString(R.string.settings_filter_technical),
                prefs.filterTechnical(), on -> {
                    prefs.setFilterTechnical(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.crosshairsgps, getString(R.string.settings_autocity),
                prefs.autoCity(), on -> prefs.setAutoCity(on));
        addValueRow(list, R.drawable.layers, getString(R.string.settings_tiles),
                tileName(prefs.mapStyle()), () -> {
                    int next = (prefs.mapStyle() + 1) % 3;
                    prefs.setMapStyle(next);
                    applyTileSource();
                    return tileName(next);
                });

        addActionRow(list, R.drawable.delete, getString(R.string.settings_cache_clear))
                .setOnClickListener(v -> safe(() -> {
                    Api.clearCache(this);
                    Toast.makeText(this, R.string.settings_cache_cleared, Toast.LENGTH_SHORT).show();
                }));
        addActionRow(list, R.drawable.informationoutline, getString(R.string.settings_about))
                .setOnClickListener(v -> safe(this::showAbout));
    }

    /** Gray all-caps section title inside the settings list. */
    private void addSectionHeader(LinearLayout list, String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(0xFF5F5F66);
        tv.setTextSize(12f);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setAllCaps(true);
        tv.setLetterSpacing(0.05f);
        tv.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 6));
        list.addView(tv);
    }

    private String tileName(int style) {
        switch (style) {
            case 1: return getString(R.string.settings_tiles_osm);
            case 2: return getString(R.string.settings_tiles_sat);
            default: return getString(R.string.settings_tiles_basic);
        }
    }

    private void applyTileSource() {
        if (prefs == null || map == null) return;
        int style = prefs.mapStyle();
        if (style != tileStyle) {
            tileStyle = style;
            map.applyStyle(style);
            switch (style) {
                case 1:
                    attribution.setText("© OpenStreetMap");
                    break;
                case 2:
                    attribution.setText("Esri, Maxar, Earthstar Geographics");
                    break;
                default:
                    attribution.setText("© OpenStreetMap · © OpenFreeMap");
                    break;
            }
        }
    }

    private interface ValueCycler {
        String cycle();
    }

    private interface BoolSetter {
        void set(boolean v);
    }

    private View buildRow(LinearLayout list, int iconRes, String label) {
        View v = LayoutInflater.from(this).inflate(R.layout.row_setting, list, false);
        list.addView(v);
        ImageView icon = v.findViewById(R.id.setIcon);
        TextView labelTv = v.findViewById(R.id.setLabel);
        icon.setImageResource(iconRes);
        icon.setColorFilter(0xFF1C1B1F);
        labelTv.setText(label);
        return v;
    }

    private View addSwitchRow(LinearLayout list, int iconRes, String label, boolean checked, BoolSetter setter) {
        View v = buildRow(list, iconRes, label);
        Switch sw = v.findViewById(R.id.setSwitch);
        TextView value = v.findViewById(R.id.setValue);
        Ui.setVisible(sw, true);
        Ui.setVisible(value, false);
        sw.setChecked(checked);
        sw.setOnCheckedChangeListener((btn, on) -> setter.set(on));
        v.setOnClickListener(x -> sw.setChecked(!sw.isChecked()));
        return v;
    }

    private View addValueRow(LinearLayout list, int iconRes, String label, String current, ValueCycler cycler) {
        View v = buildRow(list, iconRes, label);
        Switch sw = v.findViewById(R.id.setSwitch);
        TextView value = v.findViewById(R.id.setValue);
        Ui.setVisible(sw, false);
        Ui.setVisible(value, true);
        value.setText(current);
        v.setOnClickListener(x -> value.setText(cycler.cycle()));
        return v;
    }

    /** Debug-overlay slider: zoom threshold in 0.5 steps with a live numeric readout. */
    private View addSliderRow(LinearLayout list, int iconRes, String label,
                              int valueX10, int min, int max, final java.util.function.IntConsumer setter) {
        View v = buildRow(list, iconRes, label);
        Switch sw = v.findViewById(R.id.setSwitch);
        Ui.setVisible(sw, false);
        // turn the value TextView into the live numeric readout
        TextView value = v.findViewById(R.id.setValue);
        Ui.setVisible(value, true);
        value.setText(String.format(Locale.US, "%.1f", valueX10 / 10f));
        SeekBar bar = new SeekBar(this);
        bar.setMax((max - min) / 5);
        bar.setProgress((valueX10 - min) / 5);
        bar.setPadding(Ui.dp(this, 4), Ui.dp(this, 2), Ui.dp(this, 4), Ui.dp(this, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        v.setOnClickListener(null);
        LinearLayout row = (LinearLayout) v;
        row.setOrientation(LinearLayout.VERTICAL);
        // rebuild content vertically: keep the header row, put the slider under it
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageView icon = v.findViewById(R.id.setIcon);
        TextView labelTv = v.findViewById(R.id.setLabel);
        android.view.ViewGroup parent = (android.view.ViewGroup) icon.getParent();
        parent.removeView(icon);
        parent.removeView(labelTv);
        parent.removeView(value);
        parent.removeView(sw);
        header.addView(icon);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        llp.leftMargin = Ui.dp(this, 14);
        header.addView(labelTv, llp);
        header.addView(value);
        row.removeAllViews();
        row.addView(header);
        row.addView(bar, lp);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int vx = min + progress * 5;
                value.setText(String.format(Locale.US, "%.1f", vx / 10f));
                if (fromUser) setter.accept(vx);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        return v;
    }

    private View addActionRow(LinearLayout list, int iconRes, String label) {
        View v = buildRow(list, iconRes, label);
        Ui.setVisible(v.findViewById(R.id.setSwitch), false);
        Ui.setVisible(v.findViewById(R.id.setValue), false);
        v.setClickable(true);
        return v;
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.app_name)
                .setMessage(getString(R.string.about_text, App.appVersion(this)))
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onStart() {
        super.onStart();
        try {
            if (map != null) map.onStart();
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onStop() {
        try {
            if (map != null) map.onStop();
        } catch (Throwable ignored) {
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sheetContainer == null) return; // layout failed, activity is finishing
        resumed = true;
        map.onResume();
        applyTileSource();
        if (map != null) map.rebuildPublic();
        schedulePositions();
    }

    private void schedulePositions() {
        handler.removeCallbacks(positionsTick);
        handler.postDelayed(positionsTick, 1200);
    }

    @Override
    protected void onPause() {
        resumed = false;
        handler.removeCallbacks(viewportSettled);
        handler.removeCallbacks(positionsTick);
        try {
            LatLng c = map.center();
            prefs.setCamera(c.getLatitude(), c.getLongitude(), map.camZoom());
            prefs.setLastCity(currentCity == null ? "warszawa" : currentCity.slug);
        } catch (Throwable ignored) {
        }
        map.onPause();
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) lm.removeUpdates(locationListener);
        } catch (Throwable ignored) {
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        map.onDestroy();
        super.onDestroy();
    }
}
