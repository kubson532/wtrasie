package online.wtrasie.app;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Minimal read-only GTFS-Realtime (protobuf) parser — just enough to read the
 * vehiclePositions feed: FeedMessage -> FeedEntity -> VehiclePosition
 * -> TripDescriptor + VehicleDescriptor. No external dependencies.
 */
public class GtfsRt {

    public static class Vp {
        public String vehicleId = "";   // "3:118"
        public String tripId = "";      // GTFS trip_id
        public String routeId = "";
        public String startDate = "";   // "YYYYMMDD" service day
        public String startTime = "";   // "HH:MM:SS" (may exceed 24h)
        public double lat, lon;
    }

    public interface Cb {
        void on(Map<String, Vp> vehicles, String error);
    }

    /**
     * Feed keys are "type:AGENCY_id" (e.g. "3:PKSRZESZOW_R9040", "2:IC__5422")
     * while positions report plain ids ("R9040", "_5422"). Try the full key,
     * then the id with leading underscores stripped, then the suffix after
     * the last underscore.
     */
    public static Vp find(Map<String, Vp> map, String rtKey) {
        if (map == null || rtKey == null) return null;
        Vp vp = map.get(rtKey);
        if (vp != null) return vp;
        int c = rtKey.indexOf(':');
        if (c <= 0 || c + 1 >= rtKey.length()) return null;
        String type = rtKey.substring(0, c + 1);
        String id = rtKey.substring(c + 1);
        // "2:_5422" -> "2:5422"
        String noLead = id.replaceFirst("^_+", "");
        if (!noLead.equals(id)) {
            vp = map.get(type + noLead);
            if (vp != null) return vp;
        }
        // "3:PKSRZESZOW_R9040" -> "3:R9040"
        int u = id.lastIndexOf('_');
        if (u >= 0 && u + 1 < id.length()) {
            vp = map.get(type + id.substring(u + 1));
            if (vp != null) return vp;
            String tail = id.substring(u + 1).replaceFirst("^_+", "");
            if (!tail.equals(id.substring(u + 1))) vp = map.get(type + tail);
        }
        return vp;
    }

    /** Fetch (on Api's executor) and parse the vehiclePositions feed for one agency. */
    public static void vehicleTrips(final String city, final String agency, final Cb cb) {
        final String url = Api.BASE + city + "/gtfsRealtime/" + (agency == null || agency.isEmpty() ? "default" : agency)
                + "/vehiclePositions";
        Api.EXE.execute(() -> {
            Map<String, Vp> out = new HashMap<>();
            String err = null;
            try {
                byte[] data = httpGet(url);
                parseFeed(data, out);
            } catch (Throwable t) {
                err = "network";
                android.util.Log.w("GtfsRt", "GET " + url + " -> " + t);
            }
            final Map<String, Vp> res = out;
            final String e = err;
            Api.MAIN.post(() -> {
                try {
                    cb.on(res, e);
                } catch (Throwable ignored) {
                }
            });
        });
    }

    private static byte[] httpGet(String urlStr) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        try {
            c.setConnectTimeout(12000);
            c.setReadTimeout(20000);
            c.setRequestProperty("Accept-Encoding", "gzip");
            c.setRequestProperty("User-Agent", "wtrasie.online/1.2 (Android)");
            int code = c.getResponseCode();
            if (code != 200 && code != 204) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            if ("gzip".equalsIgnoreCase(c.getContentEncoding())) in = new GZIPInputStream(in);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            try {
                in.close();
            } catch (IOException ignored) {
            }
            return bo.toByteArray();
        } finally {
            try {
                c.disconnect();
            } catch (Throwable ignored) {
            }
        }
    }

    // ---------------------------------------------------------------- wire format

    private static final int WT_VARINT = 0, WT_64 = 1, WT_LEN = 2, WT_32 = 5;

    private static final class Reader {
        final byte[] b;
        int p;

        Reader(byte[] b, int off) {
            this.b = b;
            this.p = off;
        }

        boolean hasMore(int end) {
            return p < end;
        }

        long varint() {
            long v = 0;
            int shift = 0;
            while (true) {
                if (p >= b.length) return v;
                byte by = b[p++];
                v |= (long) (by & 0x7F) << shift;
                if ((by & 0x80) == 0) break;
                shift += 7;
                if (shift > 63) break;
            }
            return v;
        }

        int tag() {
            return (int) varint();
        }

        int field(int tag) {
            return tag >>> 3;
        }

        int wire(int tag) {
            return tag & 7;
        }

        int len() {
            return (int) varint();
        }

        float fixed32() {
            int bits = (b[p] & 0xFF) | ((b[p + 1] & 0xFF) << 8) | ((b[p + 2] & 0xFF) << 16) | ((b[p + 3] & 0xFF) << 24);
            p += 4;
            return Float.intBitsToFloat(bits);
        }

        String str(int len) {
            if (p + len > b.length) len = Math.max(0, b.length - p);
            String s;
            try {
                s = new String(b, p, len, "UTF-8");
            } catch (Exception e) {
                s = "";
            }
            p += len;
            return s;
        }

        void skip(int wire) {
            switch (wire) {
                case WT_VARINT:
                    varint();
                    break;
                case WT_64:
                    p += 8;
                    break;
                case WT_LEN: {
                    int l = len(); // read length first: p += len() would capture p before len() advances it
                    p += l;
                    break;
                }
                case WT_32:
                    p += 4;
                    break;
                default:
                    p = b.length; // unknown wire type: bail out of this message
            }
        }
    }

    static void parseFeed(byte[] data, Map<String, Vp> out) {
        try {
            Reader r = new Reader(data, 0);
            while (r.hasMore(data.length)) {
                int tag = r.tag();
                if (r.field(tag) == 2 && r.wire(tag) == WT_LEN) { // FeedEntity
                    int len = r.len();
                    int end = Math.min(data.length, r.p + len);
                    parseEntity(data, r.p, end, out);
                    r.p = end;
                } else {
                    r.skip(r.wire(tag));
                }
            }
        } catch (Throwable t) {
            android.util.Log.w("GtfsRt", "parse: " + t);
        }
    }

    private static void parseEntity(byte[] b, int off, int end, Map<String, Vp> out) {
        try {
            Reader r = new Reader(b, off);
            Vp vp = new Vp();
            boolean hasVehicle = false, hasTrip = false;
            while (r.p < end) {
                int tag = r.tag();
                int f = r.field(tag), w = r.wire(tag);
                if (f == 4 && w == WT_LEN) { // FeedEntity.vehicle -> VehiclePosition
                    int len = r.len();
                    int vend = Math.min(b.length, r.p + len);
                    hasVehicle = parseVehiclePosition(b, r.p, vend, vp);
                    if (hasVehicle && vp.tripId != null && !vp.tripId.isEmpty()) hasTrip = true;
                    r.p = vend;
                } else {
                    r.skip(w);
                }
            }
            if (hasVehicle && hasTrip && !vp.vehicleId.isEmpty()) {
                out.put(vp.vehicleId, vp);
                // also key by the short id (suffix after the last '_') so that
                // "3:PKSRZESZOW_R9040" is found as "3:R9040"
                int u = vp.vehicleId.lastIndexOf(':');
                if (u >= 0) {
                    String idPart = vp.vehicleId.substring(u + 1);
                    int us = idPart.lastIndexOf('_');
                    if (us >= 0 && us + 1 < idPart.length()) {
                        out.putIfAbsent(vp.vehicleId.substring(0, u + 1) + idPart.substring(us + 1), vp);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static boolean parseVehiclePosition(byte[] b, int off, int end, Vp vp) {
        Reader r = new Reader(b, off);
        boolean hasVehicle = false;
        while (r.p < end) {
            int tag = r.tag();
            int f = r.field(tag), w = r.wire(tag);
            if (f == 2 && w == WT_LEN) { // VehiclePosition.position
                int len = r.len();
                int pend = Math.min(b.length, r.p + len);
                parsePosition(b, r.p, pend, vp);
                r.p = pend;
            } else if (f == 1 && w == WT_LEN) { // VehiclePosition.trip
                int len = r.len();
                int tend = Math.min(b.length, r.p + len);
                parseTrip(b, r.p, tend, vp);
                r.p = tend;
            } else if (f == 8 && w == WT_LEN) { // VehiclePosition.vehicle
                int len = r.len();
                int vend = Math.min(b.length, r.p + len);
                String id = parseVehicleDesc(b, r.p, vend);
                if (!id.isEmpty()) {
                    vp.vehicleId = id;
                    hasVehicle = true;
                }
                r.p = vend;
            } else {
                r.skip(w);
            }
        }
        return hasVehicle;
    }

    private static void parsePosition(byte[] b, int off, int end, Vp vp) {
        Reader r = new Reader(b, off);
        while (r.p < end) {
            int tag = r.tag();
            int f = r.field(tag), w = r.wire(tag);
            if (f == 1 && w == WT_32) vp.lat = r.fixed32();       // latitude
            else if (f == 2 && w == WT_32) vp.lon = r.fixed32();  // longitude
            else r.skip(w);
        }
    }

    private static void parseTrip(byte[] b, int off, int end, Vp vp) {
        Reader r = new Reader(b, off);
        while (r.p < end) {
            int tag = r.tag();
            int f = r.field(tag), w = r.wire(tag);
            if (f == 1 && w == WT_LEN) vp.tripId = r.str(r.len());        // trip_id
            else if (f == 2 && w == WT_LEN) vp.startTime = r.str(r.len()); // start_time
            else if (f == 3 && w == WT_LEN) vp.startDate = r.str(r.len()); // start_date
            else if (f == 5 && w == WT_LEN) vp.routeId = r.str(r.len());   // route_id
            else r.skip(w);
        }
    }

    private static String parseVehicleDesc(byte[] b, int off, int end) {
        Reader r = new Reader(b, off);
        String id = "";
        while (r.p < end) {
            int tag = r.tag();
            int f = r.field(tag), w = r.wire(tag);
            if (f == 1 && w == WT_LEN) id = r.str(r.len()); // id
            else r.skip(w);
        }
        return id;
    }
}
