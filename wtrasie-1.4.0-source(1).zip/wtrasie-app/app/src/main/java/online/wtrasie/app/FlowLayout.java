package online.wtrasie.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/** Minimal wrapping flow layout for timetable time chips. */
public class FlowLayout extends ViewGroup {

    private final int hGap, vGap;

    public FlowLayout(Context c) {
        super(c);
        hGap = Ui.dp(c, 5);
        vGap = Ui.dp(c, 5);
    }

    public FlowLayout(Context c, AttributeSet a) {
        super(c, a);
        hGap = Ui.dp(c, 5);
        vGap = Ui.dp(c, 5);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int width = View.MeasureSpec.getSize(wSpec) - getPaddingLeft() - getPaddingRight();
        int x = getPaddingLeft(), y = getPaddingTop(), rowH = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View c = getChildAt(i);
            if (c.getVisibility() == GONE) continue;
            measureChild(c, wSpec, hSpec);
            if (x > getPaddingLeft() && x + c.getMeasuredWidth() > width + getPaddingLeft()) {
                x = getPaddingLeft();
                y += rowH + vGap;
                rowH = 0;
            }
            x += c.getMeasuredWidth() + hGap;
            rowH = Math.max(rowH, c.getMeasuredHeight());
        }
        int h = y + rowH + getPaddingBottom();
        setMeasuredDimension(View.MeasureSpec.getSize(wSpec),
                Math.max(h, View.MeasureSpec.getSize(hSpec) > 1 << 24 ? 0 : View.MeasureSpec.getSize(hSpec)));
        if (View.MeasureSpec.getMode(hSpec) == View.MeasureSpec.AT_MOST) {
            setMeasuredDimension(View.MeasureSpec.getSize(wSpec), h);
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int width = getWidth() - getPaddingLeft() - getPaddingRight();
        int x = getPaddingLeft(), y = getPaddingTop(), rowH = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View c = getChildAt(i);
            if (c.getVisibility() == GONE) continue;
            if (x > getPaddingLeft() && x + c.getMeasuredWidth() > width + getPaddingLeft()) {
                x = getPaddingLeft();
                y += rowH + vGap;
                rowH = 0;
            }
            c.layout(x, y, x + c.getMeasuredWidth(), y + c.getMeasuredHeight());
            x += c.getMeasuredWidth() + hGap;
            rowH = Math.max(rowH, c.getMeasuredHeight());
        }
    }
}
