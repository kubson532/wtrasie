package online.wtrasie.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Data models + defensive JSON parsing. Never throws on malformed input. */
public class Models {

    public static class Route {
        public String id = "", name = "", longName = "", agency = "";
        public int type = 3;
        public int color = 0xFFD32F2F;

        public static Route parse(JSONArray a) {
            Route r = new Route();
            if (a == null) return r;
            r.id = a.optString(0, "");
            r.name = a.optString(2, a.optString(0, ""));
            r.longName = a.optString(3, "");
            r.agency = a.optString(4, "default");
            r.type = a.optInt(5, 3);
            r.color = Ui.parseColor(a.optString(6, null), typeColor(r.type));
            return r;
        }
    }

    public static class Stop {
        public String id = "", city = "", name = "", code = "", direction = "";
        public double lon, lat;
        public int[] types = {3};
        public Integer bearing; // may be null
        public Route[] routes = new Route[0];

        public int primaryType() {
            return types.length > 0 ? types[0] : 3;
        }

        /** The "strongest" type decides the dot color: rail > metro > tram > trolley > rest. */
        public int mainType() {
            int best = 3;
            for (int t : types) {
                if (t == 2) return 2;
                if (t == 1 && best != 2) best = 1;
                else if (t == 0 && best != 1 && best != 2) best = 0;
                else if (t == 11 && best == 3) best = 11;
            }
            return best;
        }

        /** True when only buses (and trolleybuses) serve this stop — those need a strong zoom. appear */
        public boolean busOnly() {
            for (int t : types) {
                if (t != 3 && t != 11) return false;
            }
            return types.length > 0;
        }

        /** Stations (dworzec) get a dedicated marker icon. */
        public boolean isStation() {
            String n = name == null ? "" : name.toLowerCase();
            return n.contains("dworzec") || n.contains("dw. ") || n.contains(" stacja ");
        }

        public static Stop parse(JSONArray a) {
            Stop s = new Stop();
            if (a == null || a.length() < 5) return s;
            try {
                s.id = a.optString(0, "");
                s.city = a.optString(1, "");
                s.name = a.optString(2, "");
                s.code = a.optString(3, "");
                JSONArray loc = a.optJSONArray(4);
                if (loc != null && loc.length() >= 2) {
                    s.lon = loc.optDouble(0, 0);
                    s.lat = loc.optDouble(1, 0);
                }
                JSONArray t = a.optJSONArray(5);
                if (t != null && t.length() > 0) {
                    s.types = new int[t.length()];
                    for (int i = 0; i < t.length(); i++) s.types[i] = t.optInt(i, 3);
                }
                if (!a.isNull(6) && a.length() > 6) {
                    Object b = a.opt(6);
                    if (b instanceof Integer || b instanceof Long || b instanceof Double) {
                        s.bearing = a.optInt(6);
                    }
                }
                s.direction = a.optString(7, "");
                JSONArray rs = a.optJSONArray(8);
                if (rs != null) {
                    List<Route> list = new ArrayList<>();
                    for (int i = 0; i < rs.length(); i++) {
                        JSONArray ra = rs.optJSONArray(i);
                        if (ra != null) list.add(Route.parse(ra));
                    }
                    s.routes = list.toArray(new Route[0]);
                }
            } catch (Exception ignored) {
            }
            return s;
        }

        public static List<Stop> parseList(JSONObject o) {
            List<Stop> out = new ArrayList<>();
            if (o == null) return out;
            JSONArray arr = o.optJSONArray("stops");
            if (arr == null) return out;
            for (int i = 0; i < arr.length(); i++) {
                JSONArray a = arr.optJSONArray(i);
                if (a == null) continue;
                Stop s = parse(a);
                if (!s.id.isEmpty() && s.name != null && !s.name.isEmpty()) out.add(s);
            }
            return out;
        }
    }

    public static class Departure {
        public Route route = new Route();
        public String headsign = "", brigade = "", shortName = "", platform = "";
        public long scheduledDeparture;
        public Long delay; // ms, null = unknown
        public boolean realtime, cancelled;

        public static List<Departure> parseList(JSONObject o) {
            List<Departure> out = new ArrayList<>();
            if (o == null) return out;
            JSONArray arr = o.optJSONArray("departures");
            if (arr == null) return out;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject d = arr.optJSONObject(i);
                if (d == null) continue;
                Departure dep = new Departure();
                JSONObject trip = d.optJSONObject("trip");
                if (trip != null) {
                    JSONObject route = trip.optJSONObject("route");
                    if (route != null) {
                        dep.route.id = route.optString("id", "");
                        dep.route.name = route.optString("name", "");
                        dep.route.agency = route.optString("agency", "default");
                        dep.route.type = route.optInt("type", 3);
                        dep.route.color = Ui.parseColor(route.optString("color", null), typeColor(dep.route.type));
                    }
                    dep.headsign = trip.optString("headsign", "");
                    dep.brigade = trip.optString("brigade", "");
                    dep.shortName = trip.optString("shortName", "");
                }
                dep.scheduledDeparture = d.optLong("scheduledDeparture", 0);
                if (d.has("delay") && !d.isNull("delay")) dep.delay = d.optLong("delay", 0);
                dep.realtime = d.optBoolean("isRealtime", false);
                dep.cancelled = d.optBoolean("isCancelled", false);
                dep.platform = d.optString("platform", "");
                out.add(dep);
            }
            return out;
        }
    }

    public static class Upcoming {
        public String name = "";
        public int sequence = -1;
        public long scheduledArrival, scheduledDeparture;
    }

    public static class Vehicle {
        public String id = "", type = "3", agency = "", model = "";
        public String routeName = "", brigade = "", headsign = "", url = "";
        public int routeColor = 0xFFD32F2F;
        public double lon, lat;
        public long timestamp;
        public Long delay; // ms, null = unknown
        public Integer bearing; // may be null
        public Upcoming[] upcoming = new Upcoming[0];
        public boolean pkp; // from the always-on PKP nationwide feed

        /** Key used to match with the GTFS-Realtime feed ("type:id"). */
        public String rtKey() {
            return type + ":" + id;
        }

        public int typeInt() {
            try {
                return Integer.parseInt(type.trim());
            } catch (Exception e) {
                return 3;
            }
        }

        public static List<Vehicle> parseList(JSONObject o) {
            List<Vehicle> out = new ArrayList<>();
            if (o == null) return out;
            JSONArray arr = o.optJSONArray("positions");
            if (arr == null) return out;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject v = arr.optJSONObject(i);
                if (v == null) continue;
                Vehicle ve = new Vehicle();
                JSONObject veh = v.optJSONObject("vehicle");
                if (veh != null) {
                    ve.id = veh.optString("id", "");
                    ve.type = veh.optString("type", "3");
                    ve.agency = veh.optString("agency", "default");
                    if (!veh.isNull("model")) ve.model = veh.optString("model", "");
                }
                ve.routeName = v.optString("routeName", "");
                ve.routeColor = Ui.parseColor(v.optString("routeColor", null), 0xFFD32F2F);
                ve.brigade = v.optString("brigade", "");
                JSONArray loc = v.optJSONArray("location");
                if (loc != null && loc.length() >= 2) {
                    ve.lon = loc.optDouble(0, 0);
                    ve.lat = loc.optDouble(1, 0);
                }
                ve.timestamp = v.optLong("timestamp", 0);
                if (v.has("bearing") && !v.isNull("bearing")) ve.bearing = v.optInt("bearing", 0);
                if (v.has("delay") && !v.isNull("delay")) ve.delay = v.optLong("delay", 0);
                if (!v.isNull("headsign")) ve.headsign = v.optString("headsign", "");
                ve.url = v.optString("url", "");
                JSONArray up = v.optJSONArray("upcomingStops");
                if (up != null) {
                    List<Upcoming> list = new ArrayList<>();
                    for (int j = 0; j < up.length(); j++) {
                        JSONObject u = up.optJSONObject(j);
                        if (u == null) continue;
                        Upcoming uu = new Upcoming();
                        uu.name = u.optString("name", "");
                        uu.sequence = u.optInt("sequence", -1);
                        uu.scheduledArrival = u.optLong("scheduledArrival", 0);
                        uu.scheduledDeparture = u.optLong("scheduledDeparture", 0);
                        list.add(uu);
                    }
                    ve.upcoming = list.toArray(new Upcoming[0]);
                }
                if (!ve.id.isEmpty()) out.add(ve);
            }
            return out;
        }
    }

    /**
     * GTFS route_type -> VEHICLE type color.
     * Per user spec: red buses, blue trams, pink metro (with M glyph), green trains.
     */
    public static int typeColor(int t) {
        switch (t) {
            case 0: return 0xFF1976D2; // tram - blue
            case 1: return 0xFFD81B60; // subway - pink
            case 2: return 0xFF2E7D32; // rail - green
            case 3: return 0xFFD32F2F; // bus - red
            case 4: return 0xFF00838F; // ferry - cyan
            case 5: return 0xFF6D4C41; // cable car
            case 6: return 0xFF795548; // aerial lift - brown
            case 7: return 0xFF7B1FA2; // funicular - purple
            case 11: return 0xFF00695C; // trolleybus - teal
            case 12: return 0xFFEF6C00; // monorail - orange
            default: return 0xFFD32F2F;
        }
    }

    /**
     * STOP dot colors — a different palette per user spec:
     * bus stops green, train stations orange, metro pink, trams blue.
     */
    public static int stopColor(int t) {
        switch (t) {
            case 0: return 0xFF1976D2; // tram - blue
            case 1: return 0xFFD81B60; // metro - pink
            case 2: return 0xFFF57C00; // rail station - orange
            case 3: return 0xFF2E9E44; // bus stop - green
            case 4: return 0xFF00838F; // ferry - cyan
            case 5: return 0xFF6D4C41; // cable car
            case 6: return 0xFF795548; // aerial lift
            case 7: return 0xFF7B1FA2; // funicular
            case 11: return 0xFF00876A; // trolleybus - green-teal
            case 12: return 0xFFEF6C00; // monorail
            default: return 0xFF2E9E44;
        }
    }

    /** Vehicle type icon drawable resource. */
    public static int typeIcon(int t) {
        switch (t) {
            case 0: return R.drawable.ic_type_tram;
            case 1: return R.drawable.ic_metro_m;
            case 2: return R.drawable.ic_type_train;
            case 4: return R.drawable.ic_type_ferry;
            case 11: return R.drawable.ic_type_trolleybus;
            case 6:
            case 7:
            case 12: return R.drawable.ic_type_gondola;
            default: return R.drawable.ic_type_bus;
        }
    }

    /** Icon drawn inside stop markers. */
    public static int stopIcon(int t) {
        switch (t) {
            case 0: return R.drawable.ic_type_tram;
            case 1: return R.drawable.ic_metro_m;
            case 2: return R.drawable.ic_type_train;
            case 4: return R.drawable.ic_type_ferry;
            case 11: return R.drawable.ic_type_trolleybus;
            default: return R.drawable.ic_stop_sign;
        }
    }

    // ---------------------------------------------------------------- technical runs

    private static final String[] TECH_NAMES = {"pt", "p.t.", "p.t", "...", "..", "?", "-", "--", "x", "null"};

    /**
     * Technical runs ("przejazd techniczny"): route names like "PT", "..." and
     * other abominations that are not real passenger lines.
     */
    public static boolean isTechnicalRoute(String name) {
        if (name == null) return true;
        String n = name.trim().toLowerCase();
        if (n.isEmpty()) return true;
        for (String t : TECH_NAMES) {
            if (n.equals(t)) return true;
        }
        // "PT 12"-style: PT followed only by digits
        if (n.startsWith("pt ") || n.startsWith("pt-")) {
            String rest = n.substring(3).replace("-", "").replace(" ", "");
            if (rest.matches("\\d*")) return true;
        }
        return false;
    }

    /** True when the vehicle/departure should be hidden by the technical-runs filter. */
    public static boolean hiddenByTechnicalFilter(String routeName, boolean filterOn) {
        return filterOn && isTechnicalRoute(routeName);
    }
}
