package online.wtrasie.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** "Jak używać" — FAQ screen with expandable dropdown sections. */
public class HelpActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_help);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        LinearLayout box = findViewById(R.id.faqBox);
        int[] titles = {R.string.faq_map_title, R.string.faq_vehicle_title, R.string.faq_stop_title,
                R.string.faq_timetable_title, R.string.faq_search_title, R.string.faq_settings_title};
        int[] bodies = {R.string.faq_map_body, R.string.faq_vehicle_body, R.string.faq_stop_body,
                R.string.faq_timetable_body, R.string.faq_search_body, R.string.faq_settings_body};
        for (int i = 0; i < titles.length; i++) {
            box.addView(faqRow(titles[i], bodies[i], i == 0));
        }
    }

    private View faqRow(final int titleRes, final int bodyRes, boolean expanded) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), 0);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14));

        TextView title = new TextView(this);
        title.setText(titleRes);
        title.setTextColor(0xFF1C1B1F);
        title.setTextSize(16);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        header.addView(title, tlp);

        ImageView chev = new ImageView(this);
        chev.setImageResource(R.drawable.chevrondown);
        chev.setColorFilter(0xFF5F5F66);
        header.addView(chev, new LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)));

        final TextView body = new TextView(this);
        body.setText(bodyRes);
        body.setTextColor(0xFF44474E);
        body.setTextSize(14);
        body.setLineSpacing(Ui.dp(this, 2), 1f);
        body.setVisibility(expanded ? View.VISIBLE : View.GONE);
        chev.setRotation(expanded ? 180 : 0);
        body.setPadding(0, 0, 0, Ui.dp(this, 12));

        header.setOnClickListener(v -> {
            boolean open = body.getVisibility() == View.VISIBLE;
            body.setVisibility(open ? View.GONE : View.VISIBLE);
            chev.animate().rotation(open ? 0 : 180).setDuration(180).start();
        });

        box.addView(header);
        box.addView(body);

        View divider = new View(this);
        divider.setBackgroundColor(0xFFE1E3E8);
        box.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 1)));
        return box;
    }
}
