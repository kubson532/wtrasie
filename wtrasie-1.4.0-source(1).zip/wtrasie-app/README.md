# wtrasie.online

Natywna aplikacja na Androida (10+) do podglądu transportu publicznego w czasie rzeczywistym.
Mapa, pojazdy na żywo, tablice odjazdów z przystanków, wyszukiwanie, planowanie podróży A→B.

## Funkcje

- Mapa wektorowa MapLibre (styl zbiorkom.live / OpenFreeMap) z automatycznym przełączaniem miasta przy przesuwaniu
  (66 miast + sieci ogólnokrajowe: PKP, FlixBus, Digitraffic, Islandia, Holandia, Szwajcaria)
- Pozycje pojazdów na żywo (odświeżanie co 5/10/15/30 s), kolorowe plakietki linii ze strzałką kierunku
- Przystanki z ikonami typów (tramwaj, autobus, trolejbus, kolej, metro, prom, kolejka)
- Tablica odjazdów z przystanku: czas, opóźnienie, realtime, odwołane kursy, filtr linii
- Szczegóły pojazdu: model, brygada, opóźnienie, najbliższe przystanki, link do strony pojazdu
- Wyszukiwanie przystanków (z X do czyszczenia pola), w tym w innych miastach — automatyczna zmiana miasta
- Ulubione przystanki + ostatnio otwierane + najbliższe przystanki (z lokalizacji)
- Filtry typów pojazdów na mapie (ikony na dole ekranu)
- Planowanie podróży A→B (Transitous) z listą przesiadek
- Ustawienia: częstotliwość odświeżania, rozmiar ikon, podkład mapy (OSM / satelita Esri),
  brygada/tabor na ikonie, automatyczna zmiana miasta, czyszczenie pamięci podręcznej
- Biały, minimalistyczny interfejs oparty na ikonach SVG (Material Design Icons)

## Dane

- Pozycje pojazdów / przystanki / odjazdy: otwarte API `api.zbiorkom.live/api6-open`
- Wyszukiwanie miejsc i planowanie podróży: otwarte API `api.transitous.org`
- Kafle mapy: OpenStreetMap (© OpenStreetMap contributors), satelita: Esri World Imagery

## Budowanie

Wymagania: JDK 17+, Android SDK (platform 34, build-tools 34).

```bash
# local.properties:
# sdk.dir=/path/to/android-sdk

./gradlew assembleRelease   # lub: gradle assembleRelease
```

Podpisany APK: `app/build/outputs/apk/release/app-release.apk`.

Klucz podpisujący `release.keystore` jest dołączony do repozytorium
(hasło: `wtrasie2026`, alias: `wtrasie`), więc kolejne kompilacje mają ten sam podpis
i instalują się jako aktualizacja. Uruchom `./gradlew assembleDebug` lub podmień
klucz, jeśli chcesz własny podpis.

## Struktura

```
app/src/main/java/online/wtrasie/app/
  MainActivity.java      - mapa, paski, przełączanie miast, pętla pozycji
  StopsOverlay.java      - rysowanie i klikanie przystanków
  VehiclesOverlay.java   - rysowanie i klikanie pojazdów
  Sheet.java             - bazowa klasa wysuwanych paneli (przeciąganie palcem)
  CitySheet.java         - wybór miasta (wyszukiwarka z X)
  SearchSheet.java       - wyszukiwanie przystanków / ulubione / ostatnie / najbliższe
  StopSheet.java         - tablica odjazdów z przystanku
  VehicleSheet.java      - szczegóły pojazdu
  RoutingActivity.java   - planowanie podróży A→B
  SettingsActivity.java  - ustawienia
  Api.java               - warstwa HTTP + cache przystanków na dysku
  Models.java            - modele + obrona przed błędnym JSON
  Cities.java            - katalog 66 miast/sieci
  Prefs.java, Favorites.java, Ui.java, App.java
```

Licencja ikon: Material Design Icons (Pictogrammers), Apache 2.0.


## 1.4.0

- Krytyczna poprawka: klik w konkretny odjazd (np. 15:03) otwiera TEN kurs — dopasowanie
  wyłącznie po linii + brygadzie; jeśli pojazd jeszcze nie wyjechał, otwiera się planowany
  przebieg z GTFS zamiast "najszybszego" pojazdu linii
- Kurs planowy (pojazd niewyjechał): podgląd trasy z rozkładu, godzina odjazdu zamiast
  opóźnienia, bez "za X min" i bez "Planowo" na liście przystanków i tablicy odjazdów
- Menu pojazdu: czwarty stan MINI (sam tytuł + przyciski), treść panelu dopasowuje wysokość
  do stanu — lista daje się zescrollować do samego dołu także bez rozwijania na całość
- Pogrubiona linia trasy (podgląd i mapa); marker pojazdu na podglądzie i jego trasie
  nigdy nie zamienia się w kropkę
- Zanikanie krawędzi paska z liniami, gdy jest więcej kafelków do scrollowania
- Miasto zmienia się automatycznie po 3 s spokoju kamery (także z feedów ogólnopolskich);
  przycisk ręcznego odświeżania z 5-sekundowym licznikiem cooldownu
- Pojazdy i przystanki włączone przy każdym starcie; filtry typów resetują się po zmianie miasta
- Poprawka focuseowania ulubionych/w trasie (brak lotów "w świat" przy braku współrzędnych)

## 1.3.0

- Mapa wektorowa MapLibre — ten sam styl co zbiorkom.live (OpenFreeMap / OpenMapTiles);
  3 podkłady lokalnie: Podstawowa (wektor), Standard (OSM), Satelita (Esri)
- Przystanki jako kolorowe kropki: zielone autobusowe (tylko po mocnym zoomie),
  pomarańczowe stacje kolejowe, różowe metro, niebieskie tramwaje
- Pojazdy jako obiekty na trasie z numerem linii nad symbolem, snapowane do przebiegów
  GTFS i płynnie jadące po trasie między odświeżeniami
- Pociągi PKP zawsze widoczne na mapie, niezależnie od miasta
- Progi zoomu konfigurowalne w profilu "Nakładka debugu" (3 suwaki z odczytem liczbowym)
- Wyszukiwanie: bez lagów (indeks + debounce), stacje kolejowe z ikonami, wyniki
  z innych miast automatycznie przełączają miasto
- Filtr "przejazdy techniczne" (PT, "...") — domyślnie włączony
- Rozkłady bez ramki przycisku, przebudowana czytelna tabela godzin
- Poprawki: przycisk miasta, przewijanie listy w pojeździe, znikanie pojazdu przy przesuwaniu
