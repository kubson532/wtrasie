package online.wtrasie.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Favorite stops + recent stops, persisted as JSON. */
public class Favorites {
    public static class Entry {
        public String city, stopId, name, code;
        public int type;

        public Entry(String city, String stopId, String name, String code, int type) {
            this.city = city;
            this.stopId = stopId;
            this.name = name;
            this.code = code;
            this.type = type;
        }
    }

    private final SharedPreferences p;

    public Favorites(Context c) {
        p = c.getSharedPreferences("favorites", Context.MODE_PRIVATE);
    }

    private JSONArray favArray() {
        try {
            return new JSONArray(p.getString("favs", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public boolean isFavorite(String stopId) {
        JSONArray a = favArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && stopId.equals(o.optString("id"))) return true;
        }
        return false;
    }

    public void toggle(Entry e) {
        JSONArray a = favArray();
        JSONArray out = new JSONArray();
        boolean removed = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && e.stopId.equals(o.optString("id"))) {
                removed = true;
                continue;
            }
            out.put(o);
        }
        if (!removed) {
            JSONObject o = new JSONObject();
            try {
                o.put("city", e.city).put("id", e.stopId).put("name", e.name)
                        .put("code", e.code).put("type", e.type);
            } catch (Exception ignored) {
            }
            out.put(o);
        }
        p.edit().putString("favs", out.toString()).apply();
    }

    public List<Entry> list() {
        List<Entry> out = new ArrayList<>();
        JSONArray a = favArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            out.add(new Entry(o.optString("city"), o.optString("id"), o.optString("name"),
                    o.optString("code"), o.optInt("type", 3)));
        }
        return out;
    }

    // ---- recents ----

    public void pushRecent(Entry e) {
        try {
            JSONArray a = new JSONArray(p.getString("recent", "[]"));
            JSONArray out = new JSONArray();
            JSONObject n = new JSONObject();
            n.put("city", e.city).put("id", e.stopId).put("name", e.name)
                    .put("code", e.code).put("type", e.type);
            out.put(n);
            for (int i = 0; i < a.length() && out.length() < 12; i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null || e.stopId.equals(o.optString("id"))) continue;
                out.put(o);
            }
            p.edit().putString("recent", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public List<Entry> recents() {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString("recent", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                out.add(new Entry(o.optString("city"), o.optString("id"), o.optString("name"),
                        o.optString("code"), o.optInt("type", 3)));
            }
        } catch (Exception ignored) {
        }
        return out;
    }
}
