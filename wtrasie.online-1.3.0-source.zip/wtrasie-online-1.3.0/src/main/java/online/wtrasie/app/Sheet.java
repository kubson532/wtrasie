package online.wtrasie.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * Base draggable bottom sheet: fixed-height panel whose visible part is driven by translationY.
 * States: HIDDEN -> PEEK (roughly half) -> FULL. Drag by the grab handle at the very top
 * or by the header view. Sheets never pass touches through to the map below them.
 */
public class Sheet extends FrameLayout {

    public interface DismissListener {
        void onDismissed();
    }

    public static final int HIDDEN = 0, PEEK = 1, FULL = 2;

    protected int state = HIDDEN;
    protected int panelH = 1;       // full panel height in px
    protected int peekH = 1;        // peek height in px
    protected DismissListener dismissListener;
    private ValueAnimator animator;
    private float downY, startTransY;
    private boolean dragging = false;
    private int bottomInset = 0;
    private int heightRetries = 0;
    private final List<View> dragViews = new ArrayList<>();

    public Sheet(Context c) {
        super(c);
        init(c, 0);
    }

    public Sheet(Context c, AttributeSet a) {
        super(c, a);
        init(c, 0);
    }

    public Sheet(Context c, int layoutRes) {
        super(c);
        init(c, layoutRes);
    }

    private void init(Context c, int layoutRes) {
        setBackgroundResource(R.drawable.bg_sheet);
        setElevation(Ui.dp(c, 14));
        setVisibility(GONE);
        setClipChildren(false);
        setClipToPadding(false);
        // A sheet must never let touches fall through to the map underneath it.
        setClickable(true);
        setFocusable(false);
        if (layoutRes != 0) {
            View v = LayoutInflater.from(c).inflate(layoutRes, this, false);
            addView(v, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        addGrabHandle(c);
        setOnApplyWindowInsetsListener((v, insets) -> {
            try {
                bottomInset = Math.max(0, insets.getSystemWindowInsetBottom());
                applyHeights();
            } catch (Throwable ignored) {
            }
            return insets;
        });
    }

    /** The visual grab bar at the top of every sheet; the whole strip is a drag area. */
    private void addGrabHandle(Context c) {
        LinearLayout strip = new LinearLayout(c);
        strip.setOrientation(LinearLayout.VERTICAL);
        strip.setGravity(Gravity.CENTER_HORIZONTAL);
        strip.setPadding(0, Ui.dp(c, 5), 0, Ui.dp(c, 1));
        View bar = new View(c);
        bar.setBackgroundResource(R.drawable.bg_grab_handle);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 4));
        strip.addView(bar, blp);
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, Ui.dp(c, 22));
        lp.gravity = Gravity.TOP;
        addView(strip, lp);
        registerDrag(strip);
    }

    public void setDismissListener(DismissListener l) {
        dismissListener = l;
    }

    protected void setDragHandle(View v) {
        registerDrag(v);
    }

    private void registerDrag(View v) {
        dragViews.add(v);
        v.setOnTouchListener((view, ev) -> onHandleTouch(view, ev));
    }

    /** True when the touch lands on an interactive child (EditText / button) that should keep the event. */
    private boolean isInteractiveChild(View group, MotionEvent ev) {
        if (!(group instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) group;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == null || c.getVisibility() != View.VISIBLE) continue;
            if (ev.getX() >= c.getLeft() && ev.getX() <= c.getRight()
                    && ev.getY() >= c.getTop() && ev.getY() <= c.getBottom()) {
                if (c instanceof android.widget.EditText || c instanceof android.widget.ImageButton
                        || c instanceof android.widget.Button || c instanceof android.widget.Switch) {
                    return true;
                }
                if (c instanceof ViewGroup) {
                    MotionEvent childEv = MotionEvent.obtain(ev);
                    childEv.offsetLocation(-c.getLeft(), -c.getTop());
                    boolean r = isInteractiveChild(c, childEv);
                    childEv.recycle();
                    return r;
                }
                return false;
            }
        }
        return false;
    }

    private boolean onHandleTouch(View handle, MotionEvent ev) {
        try {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (isInteractiveChild(handle, ev)) {
                        dragging = false;
                        return false; // let the child handle it
                    }
                    dragging = true;
                    downY = ev.getRawY();
                    startTransY = getTranslationY();
                    cancelAnim();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!dragging) return true;
                    float ty = startTransY + (ev.getRawY() - downY);
                    ty = clamp(ty, 0, panelH);
                    setTranslationY(ty);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!dragging) return false;
                    dragging = false;
                    float end = getTranslationY();
                    boolean flingDown = (ev.getRawY() - downY) > Ui.dp(getContext(), 90)
                            && end > panelH - peekH - 1;
                    if (flingDown && state == PEEK) {
                        hide();
                    } else {
                        float dPeek = Math.abs(end - (panelH - peekH));
                        float dFull = Math.abs(end - 0);
                        if (dFull < dPeek && end < panelH - peekH * 0.55f) setState(FULL);
                        else if (dPeek < dFull) setState(PEEK);
                        else if (end > panelH - peekH + Ui.dp(getContext(), 80)) hide();
                        else setState(PEEK);
                    }
                    return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private void cancelAnim() {
        if (animator != null) animator.cancel();
    }

    protected void applyHeights() {
        ViewGroup parent = (ViewGroup) getParent();
        if (parent == null) return;
        int h = parent.getHeight();
        if (h <= 0) {
            // not laid out yet -> retry a bounded number of times
            if (heightRetries < 10) {
                heightRetries++;
                post(this::applyHeights);
            }
            return;
        }
        heightRetries = 0;
        panelH = (int) (h * 0.86);
        peekH = (int) (h * 0.52);
        ViewGroup.LayoutParams lp = getLayoutParams();
        boolean changed = lp.height != panelH;
        lp.height = panelH;
        if (lp.width == 0) lp.width = LayoutParams.MATCH_PARENT;
        if (changed) setLayoutParams(lp);
        // keep position consistent
        if (state == PEEK) setTranslationY(panelH - peekH);
        else if (state == FULL) setTranslationY(0);
        else setTranslationY(panelH);
    }

    public void setState(int s) {
        cancelAnim();
        boolean wasHidden = (state == HIDDEN);
        state = s;
        float target = s == FULL ? 0 : (panelH - peekH);
        if (wasHidden) {
            // start fully below the screen and slide up
            setTranslationY(panelH + bottomInset);
            setVisibility(VISIBLE);
        }
        animateTo(target);
        if (s != HIDDEN) setVisibility(VISIBLE);
    }

    public int getState() {
        return state;
    }

    public void show() {
        if (panelH <= 1) {
            // wait for measurement to avoid a full-screen flash
            setVisibility(INVISIBLE);
            post(() -> {
                applyHeights();
                if (panelH <= 1) {
                    panelH = Ui.dp(getContext(), 700); // absolute fallback
                    peekH = Ui.dp(getContext(), 380);
                }
                setState(PEEK);
            });
        } else {
            setState(PEEK);
        }
    }

    public void showFull() {
        if (panelH <= 1) {
            setVisibility(INVISIBLE);
            post(() -> {
                applyHeights();
                if (panelH <= 1) {
                    panelH = Ui.dp(getContext(), 700);
                    peekH = Ui.dp(getContext(), 380);
                }
                setState(FULL);
            });
        } else {
            setState(FULL);
        }
    }

    public void hide() {
        cancelAnim();
        state = HIDDEN;
        animateTo(panelH);
    }

    private void animateTo(float target) {
        cancelAnim();
        animator = ValueAnimator.ofFloat(getTranslationY(), target);
        animator.setDuration(260);
        animator.setInterpolator(new DecelerateInterpolator(1.2f));
        animator.addUpdateListener(a -> {
            float v = (float) a.getAnimatedValue();
            setTranslationY(v);
            if (state == HIDDEN && Math.abs(v - panelH) < 1f) {
                setVisibility(GONE);
                if (dismissListener != null) {
                    DismissListener l = dismissListener;
                    dismissListener = null;
                    try {
                        l.onDismissed();
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        animator.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        applyHeights();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(this::applyHeights);
    }
}
