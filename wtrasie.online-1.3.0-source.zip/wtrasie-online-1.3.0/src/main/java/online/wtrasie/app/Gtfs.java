package online.wtrasie.app;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Static GTFS access: downloads (and caches for 24 h) the agency GTFS zip and
 * extracts, on demand:
 *  - the full stop list + times of one trip (vehicle route preview),
 *  - the shape polyline of a trip,
 *  - full-day timetables for a stop, grouped into weekday / Saturday / Sunday.
 * All parsing streams the zip entries; only the requested rows are kept.
 */
public class Gtfs {

    private static final long TTL = 24L * 3600 * 1000;
    private static final int TRIP_CACHE_MAX = 24;
    private static final int TT_CACHE_MAX = 12;

    public static class StopTime {
        public String stopId = "";
        public int seq;
        public int arrSec, depSec; // seconds after midnight of the service day
        public String name = "";
        public double lat, lon;
    }

    public static class Trip {
        public String tripId = "", routeId = "", serviceId = "", shapeId = "", headsign = "", brigade = "";
        public List<StopTime> stops = new ArrayList<>();
        public List<double[]> shape = new ArrayList<>(); // {lat, lon}
    }

    public static class Tt {
        public int timeSec;
        public String headsign = "";
        public int variantColor; // assigned per headsign
    }

    public static class RouteTt {
        public String routeId = "", routeName = "";
        public int routeColor;
        public List<Tt> weekday = new ArrayList<>(), saturday = new ArrayList<>(), sunday = new ArrayList<>();
        public Map<String, Integer> variantColors = new LinkedHashMap<>(); // headsign -> color
    }

    public interface TripCb {
        void on(Trip trip, String error);
    }

    public interface TtCb {
        void on(Map<String, RouteTt> routes, String error);
    }

    // ---------------------------------------------------------------- caches

    /** trip cache: city/agency/tripId -> Trip */
    private static final LinkedHashMap<String, Trip> TRIP_CACHE = new LinkedHashMap<String, Trip>() {
        @Override
        protected boolean removeEldestEntry(Entry<String, Trip> eldest) {
            return size() > TRIP_CACHE_MAX;
        }
    };

    /** timetable cache: city/agency/stopId -> routes */
    private static final LinkedHashMap<String, Map<String, RouteTt>> TT_CACHE = new LinkedHashMap<String, Map<String, RouteTt>>() {
        @Override
        protected boolean removeEldestEntry(Entry<String, Map<String, RouteTt>> eldest) {
            return size() > TT_CACHE_MAX;
        }
    };

    private static final Set<String> IN_FLIGHT_ZIPS = new HashSet<>();

    public static void clearCaches() {
        synchronized (TRIP_CACHE) {
            TRIP_CACHE.clear();
        }
        synchronized (TT_CACHE) {
            TT_CACHE.clear();
        }
    }

    // ---------------------------------------------------------------- public API

    /** Full trip (stops + shape + names + coords) for a GTFS trip id. */
    public static void loadTrip(Context ctx, String city, String agency, String tripId, TripCb cb) {
        final String key = city + "/" + agency + "/" + tripId;
        synchronized (TRIP_CACHE) {
            Trip t = TRIP_CACHE.get(key);
            if (t != null) {
                cb.on(t, null);
                return;
            }
        }
        withZip(ctx, city, agency, (zip, err) -> {
            Trip trip = null;
            String e = err;
            if (zip != null) {
                try {
                    trip = readTrip(zip, tripId);
                    if (trip == null) e = "notfound";
                } catch (Throwable t) {
                    e = "parse";
                    android.util.Log.w("Gtfs", "readTrip", t);
                }
            }
            if (trip != null) {
                synchronized (TRIP_CACHE) {
                    TRIP_CACHE.put(key, trip);
                }
            }
            final Trip tr = trip;
            final String er = e;
            Api.MAIN.post(() -> {
                try {
                    cb.on(tr, er);
                } catch (Throwable ignored) {
                }
            });
        });
    }

    /** Day-type timetables of every route serving a stop. */
    public static void loadTimetable(Context ctx, String city, String agency, String stopId, TtCb cb) {
        final String key = city + "/" + agency + "/" + stopId;
        synchronized (TT_CACHE) {
            Map<String, RouteTt> cached = TT_CACHE.get(key);
            if (cached != null) {
                cb.on(cached, null);
                return;
            }
        }
        withZip(ctx, city, agency, (zip, err) -> {
            Map<String, RouteTt> routes = null;
            String e = err;
            if (zip != null) {
                try {
                    routes = readTimetable(zip, stopId);
                    if (routes != null && routes.isEmpty()) e = "notfound";
                } catch (Throwable t) {
                    e = "parse";
                    android.util.Log.w("Gtfs", "readTimetable", t);
                }
            }
            if (routes != null && e == null) {
                synchronized (TT_CACHE) {
                    TT_CACHE.put(key, routes);
                }
            }
            final Map<String, RouteTt> res = routes;
            final String er = e;
            Api.MAIN.post(() -> {
                try {
                    cb.on(res, er);
                } catch (Throwable ignored) {
                }
            });
        });
    }

    private interface ZipCb {
        void on(ZipFile zip, String error);
    }

    /** Gives the caller an open ZipFile (valid until the callback returns — it is closed afterwards). */
    private static void withZip(Context ctx, String city, String agency, ZipCb cb) {
        final File f = zipFile(ctx, city, agency);
        Api.EXE.execute(() -> {
            // valid cache?
            if (f.isFile()) {
                if (System.currentTimeMillis() - f.lastModified() < TTL) {
                    ZipFile z = openZip(f);
                    if (z != null) {
                        runZipCb(cb, z);
                        return;
                    }
                }
                f.delete();
            }
            // one download at a time per file
            synchronized (IN_FLIGHT_ZIPS) {
                if (IN_FLIGHT_ZIPS.contains(f.getAbsolutePath())) {
                    // somebody else downloads; wait a bit and retry once
                    IN_FLIGHT_ZIPS.add(f.getAbsolutePath() + ":waiter");
                    try {
                        IN_FLIGHT_ZIPS.wait(30000);
                    } catch (InterruptedException ignored) {
                    }
                }
                IN_FLIGHT_ZIPS.add(f.getAbsolutePath());
            }
            try {
                if (!f.isFile() || System.currentTimeMillis() - f.lastModified() >= TTL) {
                    download(Api.gtfsUrl(city, agency), f);
                }
            } catch (Throwable t) {
                android.util.Log.w("Gtfs", "download " + city + "/" + agency + " " + t);
            }
            synchronized (IN_FLIGHT_ZIPS) {
                IN_FLIGHT_ZIPS.remove(f.getAbsolutePath());
                IN_FLIGHT_ZIPS.notifyAll();
            }
            ZipFile z = f.isFile() ? openZip(f) : null;
            runZipCb(cb, z);
        });
    }

    private static void runZipCb(ZipCb cb, ZipFile z) {
        String err = z == null ? "network" : null;
        try {
            cb.on(z, err);
        } catch (Throwable t) {
            android.util.Log.w("Gtfs", "zipcb", t);
        } finally {
            if (z != null) {
                try {
                    z.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static ZipFile openZip(File f) {
        try {
            return new ZipFile(f);
        } catch (Throwable t) {
            return null;
        }
    }

    private static File zipFile(Context ctx, String city, String agency) {
        return new File(ctx.getCacheDir(), "gtfs-" + city + "-" + (agency == null || agency.isEmpty() ? "default" : agency) + ".zip");
    }

    private static void download(String urlStr, File target) throws IOException {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(urlStr).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(90000);
            c.setRequestProperty("User-Agent", "wtrasie.online/1.2 (Android)");
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            File tmp = new File(target.getAbsolutePath() + ".tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            try {
                in.close();
            } catch (IOException ignored) {
            }
            if (!tmp.renameTo(target)) {
                target.delete();
                tmp.renameTo(target);
            }
        } finally {
            try {
                c.disconnect();
            } catch (Throwable ignored) {
            }
        }
    }

    // ---------------------------------------------------------------- CSV helpers

    /** Returns a fast field extractor for a CSV line, given the header column order. */
    private static int[] colIdx(String header, String... names) {
        int[] idx = new int[names.length];
        List<String> cols = splitCsv(header);
        for (int i = 0; i < names.length; i++) {
            idx[i] = cols.indexOf(names[i]);
        }
        return idx;
    }

    private static List<String> splitCsv(String line) {
        List<String> out = new ArrayList<>();
        int start = 0;
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') quoted = !quoted;
            else if (ch == ',' && !quoted) {
                out.add(line.substring(start, i));
                start = i + 1;
            }
        }
        out.add(line.substring(start));
        return out;
    }

    private static BufferedReader reader(ZipFile zip, String entry) throws IOException {
        ZipEntry e = zip.getEntry(entry);
        if (e == null) return null;
        InputStream in = zip.getInputStream(e);
        return new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8), 1 << 16);
    }

    private static String fieldAt(String line, int idx) {
        if (idx < 0) return "";
        int cur = -1, start = 0;
        for (int i = 0; i <= line.length(); i++) {
            if (i == line.length() || line.charAt(i) == ',') {
                cur++;
                if (cur == idx) return line.substring(start, i);
                start = i + 1;
                if (cur > idx) break;
            }
        }
        return "";
    }

    /** "25:36:00" -> seconds after midnight. */
    private static int hms(String s) {
        if (s == null || s.length() < 4) return 0;
        try {
            String[] p = s.split(":");
            int h = Integer.parseInt(p[0].trim());
            int m = p.length > 1 ? Integer.parseInt(p[1].trim()) : 0;
            int sec = p.length > 2 ? Integer.parseInt(p[2].trim()) : 0;
            return h * 3600 + m * 60 + sec;
        } catch (Exception e) {
            return 0;
        }
    }

    // ---------------------------------------------------------------- trip reading

    private static Trip readTrip(ZipFile zip, String tripId) throws IOException {
        // 1. trip row
        Trip trip = null;
        BufferedReader r = reader(zip, "trips.txt");
        if (r == null) return null;
        try {
            String header = r.readLine();
            if (header == null) return null;
            int[] ix = colIdx(header, "trip_id", "route_id", "service_id", "shape_id", "trip_headsign", "brigade");
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isEmpty()) continue;
                if (line.startsWith(tripId) && fieldAt(line, ix[0]).equals(tripId)) {
                    trip = new Trip();
                    trip.tripId = tripId;
                    trip.routeId = fieldAt(line, ix[1]);
                    trip.serviceId = fieldAt(line, ix[2]);
                    trip.shapeId = fieldAt(line, ix[3]);
                    trip.headsign = fieldAt(line, ix[4]);
                    trip.brigade = fieldAt(line, ix[5]);
                    break;
                }
            }
        } finally {
            r.close();
        }
        if (trip == null) return null;

        // 2. stop_times of the trip
        r = reader(zip, "stop_times.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "trip_id", "arrival_time", "departure_time", "stop_id", "stop_sequence");
                    String line;
                    List<StopTime> sts = new ArrayList<>();
                    while ((line = r.readLine()) != null) {
                        if (line.isEmpty()) continue;
                        if (line.startsWith(tripId) && fieldAt(line, ix[0]).equals(tripId)) {
                            StopTime st = new StopTime();
                            st.arrSec = hms(fieldAt(line, ix[1]));
                            st.depSec = hms(fieldAt(line, ix[2]));
                            st.stopId = fieldAt(line, ix[3]);
                            try {
                                st.seq = Integer.parseInt(fieldAt(line, ix[4]).trim());
                            } catch (Exception ignored) {
                            }
                            sts.add(st);
                        }
                    }
                    Collections.sort(sts, (a, b) -> Integer.compare(a.seq, b.seq));
                    trip.stops = sts;
                }
            } finally {
                r.close();
            }
        }

        // 3. stop names + coords for the used ids
        if (!trip.stops.isEmpty()) {
            Set<String> ids = new HashSet<>();
            for (StopTime st : trip.stops) ids.add(st.stopId);
            r = reader(zip, "stops.txt");
            if (r != null) {
                try {
                    String header = r.readLine();
                    if (header != null) {
                        int[] ix = colIdx(header, "stop_id", "stop_name", "stop_lat", "stop_lon");
                        String line;
                        while ((line = r.readLine()) != null) {
                            String id = fieldAt(line, ix[0]);
                            if (!ids.contains(id)) continue;
                            for (StopTime st : trip.stops) {
                                if (st.stopId.equals(id)) {
                                    st.name = fieldAt(line, ix[1]);
                                    try {
                                        st.lat = Double.parseDouble(fieldAt(line, ix[2]));
                                        st.lon = Double.parseDouble(fieldAt(line, ix[3]));
                                    } catch (Exception ignored) {
                                    }
                                }
                            }
                        }
                    }
                } finally {
                    r.close();
                }
            }
        }

        // 4. shape points
        if (trip.shapeId != null && !trip.shapeId.isEmpty()) {
            r = reader(zip, "shapes.txt");
            if (r != null) {
                try {
                    String header = r.readLine();
                    if (header != null) {
                        int[] ix = colIdx(header, "shape_id", "shape_pt_lat", "shape_pt_lon", "shape_pt_sequence");
                        String line;
                        List<double[]> pts = new ArrayList<>();
                        while ((line = r.readLine()) != null) {
                            if (line.startsWith(trip.shapeId) && fieldAt(line, ix[0]).equals(trip.shapeId)) {
                                try {
                                    double lat = Double.parseDouble(fieldAt(line, ix[1]));
                                    double lon = Double.parseDouble(fieldAt(line, ix[2]));
                                    int seq = 0;
                                    try {
                                        seq = Integer.parseInt(fieldAt(line, ix[3]).trim());
                                    } catch (Exception ignored) {
                                    }
                                    pts.add(new double[]{lat, lon, seq});
                                } catch (Exception ignored) {
                                }
                            }
                        }
                        if (!pts.isEmpty()) {
                            pts.sort(Comparator.comparingDouble(a -> a[2]));
                            List<double[]> shape = new ArrayList<>(pts.size());
                            for (double[] p : pts) shape.add(new double[]{p[0], p[1]});
                            trip.shape = shape;
                        }
                    }
                } finally {
                    r.close();
                }
            }
        }
        // fallback shape: straight lines through stops
        if (trip.shape.isEmpty()) {
            for (StopTime st : trip.stops) {
                if (st.lat != 0 || st.lon != 0) trip.shape.add(new double[]{st.lat, st.lon});
            }
        }
        return trip;
    }

    // ---------------------------------------------------------------- timetable reading

    private static Map<String, RouteTt> readTimetable(ZipFile zip, String stopId) throws IOException {
        // sample dates: next weekday, next Saturday, next Sunday (from tomorrow)
        Calendar now = Calendar.getInstance();
        String weekdayDate = nextDow(now, Calendar.MONDAY, Calendar.FRIDAY);
        String saturdayDate = nextDow(now, Calendar.SATURDAY, Calendar.SATURDAY);
        String sundayDate = nextDow(now, Calendar.SUNDAY, Calendar.SUNDAY);

        // 1. services active on each sample date
        Map<String, Set<String>> serviceDates = new HashMap<>(); // serviceId -> dates
        BufferedReader r = reader(zip, "calendar_dates.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "service_id", "date", "exception_type");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String svc = fieldAt(line, ix[0]);
                        String date = fieldAt(line, ix[1]);
                        String exc = fieldAt(line, ix[2]);
                        if (svc.isEmpty() || date.length() != 8) continue;
                        Set<String> set = serviceDates.get(svc);
                        if (set == null) {
                            set = new HashSet<>();
                            serviceDates.put(svc, set);
                        }
                        if ("2".equals(exc.trim())) set.remove(date);
                        else set.add(date);
                    }
                }
            } finally {
                r.close();
            }
        }

        // 2. all trips
        Map<String, String> tripRoute = new HashMap<>();     // tripId -> routeId
        Map<String, String> tripService = new HashMap<>();   // tripId -> serviceId
        Map<String, String> tripHeadsign = new HashMap<>();  // tripId -> headsign
        r = reader(zip, "trips.txt");
        if (r == null) return null;
        try {
            String header = r.readLine();
            if (header == null) return null;
            int[] ix = colIdx(header, "trip_id", "route_id", "service_id", "trip_headsign");
            String line;
            while ((line = r.readLine()) != null) {
                String tripId = fieldAt(line, ix[0]);
                if (tripId.isEmpty()) continue;
                tripRoute.put(tripId, fieldAt(line, ix[1]));
                tripService.put(tripId, fieldAt(line, ix[2]));
                tripHeadsign.put(tripId, fieldAt(line, ix[3]));
            }
        } finally {
            r.close();
        }

        // 3. stop_times rows at our stop
        Map<String, RouteTt> routes = new LinkedHashMap<>();
        Map<String, Set<String>> routeVariantNames = new HashMap<>();
        r = reader(zip, "stop_times.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "trip_id", "departure_time", "stop_id");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String sid = fieldAt(line, ix[2]);
                        if (!sid.equals(stopId)) continue;
                        String tripId = fieldAt(line, ix[0]);
                        String routeId = tripRoute.get(tripId);
                        if (routeId == null) continue;
                        String service = tripService.get(tripId);
                        Set<String> dates = serviceDates.get(service);
                        if (dates == null) continue; // no calendar info
                        Tt tt = new Tt();
                        tt.timeSec = hms(fieldAt(line, ix[1]));
                        tt.headsign = tripHeadsign.get(tripId);
                        RouteTt rt = routes.get(routeId);
                        if (rt == null) {
                            rt = new RouteTt();
                            rt.routeId = routeId;
                            rt.routeName = routeId;
                            routes.put(routeId, rt);
                            routeVariantNames.put(routeId, new HashSet<>());
                        }
                        if (tt.headsign != null && !tt.headsign.isEmpty()) {
                            routeVariantNames.get(routeId).add(tt.headsign);
                        }
                        if (dates.contains(weekdayDate)) rt.weekday.add(tt);
                        if (dates.contains(saturdayDate)) rt.saturday.add(tt);
                        if (dates.contains(sundayDate)) rt.sunday.add(tt);
                    }
                }
            } finally {
                r.close();
            }
        }

        // 4. route names/colors + variant colors, drop empty routes, sort
        Map<String, RouteTt> out = new LinkedHashMap<>();
        int[] palette = {0xFF1976D2, 0xFFD32F2F, 0xFF2E7D32, 0xFFD81B60, 0xFFEF6C00, 0xFF00838F, 0xFF7B1FA2, 0xFF795548};
        r = reader(zip, "routes.txt");
        Map<String, String[]> routeMeta = new HashMap<>();
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "route_id", "route_short_name", "route_long_name", "route_color");
                    String line;
                    while ((line = r.readLine()) != null) {
                        routeMeta.put(fieldAt(line, ix[0]), new String[]{
                                fieldAt(line, ix[1]), fieldAt(line, ix[2]), fieldAt(line, ix[3])});
                    }
                }
            } finally {
                r.close();
            }
        }
        for (Map.Entry<String, RouteTt> e : routes.entrySet()) {
            RouteTt rt = e.getValue();
            if (rt.weekday.isEmpty() && rt.saturday.isEmpty() && rt.sunday.isEmpty()) continue;
            String[] meta = routeMeta.get(e.getKey());
            if (meta != null) {
                rt.routeName = meta[0] == null || meta[0].isEmpty() ? (meta[1] == null ? e.getKey() : meta[1]) : meta[0];
                rt.routeColor = Ui.parseColor(meta[2] == null || meta[2].isEmpty() ? null : "#" + meta[2], 0xFFD32F2F);
            }
            List<String> variants = new ArrayList<>(routeVariantNames.get(e.getKey()));
            Collections.sort(variants);
            if (variants.size() > 1) {
                for (int i = 0; i < variants.size(); i++) {
                    rt.variantColors.put(variants.get(i), palette[i % palette.length]);
                }
            }
            Comparator<Tt> cmp = (a, b) -> Integer.compare(a.timeSec, b.timeSec);
            Collections.sort(rt.weekday, cmp);
            Collections.sort(rt.saturday, cmp);
            Collections.sort(rt.sunday, cmp);
            out.put(e.getKey(), rt);
        }
        return out;
    }

    /** Date (YYYYMMDD) of the next day-of-week in [minDow..maxDow], strictly after today. */
    private static String nextDow(Calendar now, int minDow, int maxDow) {
        Calendar c = new GregorianCalendar();
        c.setTimeZone(TimeZone.getDefault());
        c.set(Calendar.HOUR_OF_DAY, 12);
        for (int add = 1; add <= 8; add++) {
            Calendar t = (Calendar) c.clone();
            t.add(Calendar.DAY_OF_YEAR, add);
            int dow = t.get(Calendar.DAY_OF_WEEK);
            if (dow >= minDow && dow <= maxDow) {
                return String.format(java.util.Locale.US, "%04d%02d%02d",
                        t.get(Calendar.YEAR), t.get(Calendar.MONTH) + 1, t.get(Calendar.DAY_OF_MONTH));
            }
        }
        return "";
    }

    /** Midnight (device tz) of the GTFS service date "YYYYMMDD" in epoch ms. */
    public static long serviceDayEpoch(String yyyymmdd) {
        if (yyyymmdd == null || yyyymmdd.length() != 8) return 0;
        try {
            int y = Integer.parseInt(yyyymmdd.substring(0, 4));
            int m = Integer.parseInt(yyyymmdd.substring(4, 6));
            int d = Integer.parseInt(yyyymmdd.substring(6, 8));
            Calendar c = new GregorianCalendar();
            c.setTimeZone(TimeZone.getDefault());
            c.clear();
            c.set(y, m - 1, d, 0, 0, 0);
            return c.getTimeInMillis();
        } catch (Exception e) {
            return 0;
        }
    }

    // ---------------------------------------------------------------- route shapes (vehicle snapping)

    /** A shape polyline with cumulative distances for along-path interpolation. */
    public static class Polyline {
        public final List<double[]> pts = new ArrayList<>(); // {lat, lon}
        public final List<Double> cum = new ArrayList<>();   // meters at each point

        public void add(double lat, double lon, double distFromPrev) {
            pts.add(new double[]{lat, lon});
            cum.add((cum.isEmpty() ? 0 : cum.get(cum.size() - 1)) + distFromPrev);
        }

        public double length() {
            return cum.isEmpty() ? 0 : cum.get(cum.size() - 1);
        }

        /** Position at distance d (meters) along the polyline. */
        public double[] at(double d) {
            if (cum.isEmpty()) return new double[]{0, 0};
            if (d <= 0) return pts.get(0);
            double total = cum.get(cum.size() - 1);
            if (d >= total) return pts.get(pts.size() - 1);
            for (int i = 1; i < cum.size(); i++) {
                if (d <= cum.get(i)) {
                    double seg = cum.get(i) - cum.get(i - 1);
                    double f = seg <= 0 ? 0 : (d - cum.get(i - 1)) / seg;
                    double[] a = pts.get(i - 1), b = pts.get(i);
                    return new double[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f};
                }
            }
            return pts.get(pts.size() - 1);
        }

        /** Nearest point on the polyline: {lat, lon, distAlongM, distanceToLineM}. */
        public double[] nearest(double lat, double lon) {
            double bestD = Double.MAX_VALUE, bestAlong = 0, bestLat = lat, bestLon = lon;
            for (int i = 1; i < pts.size(); i++) {
                double[] a = pts.get(i - 1), b = pts.get(i);
                double ax = a[1], ay = a[0], bx = b[1], by = b[0];
                double dx = bx - ax, dy = by - ay;
                double len2 = dx * dx + dy * dy;
                double t = len2 <= 0 ? 0 : ((lon - ax) * dx + (lat - ay) * dy) / len2;
                t = Math.max(0, Math.min(1, t));
                double px = ax + dx * t, py = ay + dy * t;
                double dM = Ui.distM(lat, lon, py, px);
                if (dM < bestD) {
                    bestD = dM;
                    bestLat = py;
                    bestLon = px;
                    bestAlong = cum.get(i - 1) + (cum.get(i) - cum.get(i - 1)) * t;
                }
            }
            return new double[]{bestLat, bestLon, bestAlong, bestD};
        }
    }

    public interface ShapesCb {
        void on(Map<String, List<Polyline>> shapes, String error);
    }

    private static final Map<String, Map<String, List<Polyline>>> SHAPE_CACHE = new HashMap<>();
    private static final Set<String> SHAPES_IN_FLIGHT = new HashSet<>();

    /**
     * All shape polylines of the given routes (a route usually has several:
     * directions and variants). Cached per (city, agency). Rows of shapes.txt
     * are streamed; only wanted shape_ids are kept in memory.
     */
    public static void loadRouteShapes(Context ctx, String city, String agency,
                                       final Set<String> routeIds, final ShapesCb cb) {
        if (routeIds == null || routeIds.isEmpty()) {
            cb.on(new HashMap<>(), null);
            return;
        }
        final String key = city + "|" + (agency == null || agency.isEmpty() ? "default" : agency);
        Map<String, List<Polyline>> cached = SHAPE_CACHE.get(key);
        if (cached != null) {
            Map<String, List<Polyline>> out = new HashMap<>();
            for (String r : routeIds) {
                List<Polyline> pl = cached.get(r);
                if (pl != null) out.put(r, pl);
            }
            cb.on(out, null);
            return;
        }
        synchronized (SHAPES_IN_FLIGHT) {
            if (SHAPES_IN_FLIGHT.contains(key)) return; // another load running; caller retries later
            SHAPES_IN_FLIGHT.add(key);
        }
        withZip(ctx, city, agency, (zip, err) -> {
            Map<String, List<Polyline>> result = new HashMap<>();
            try {
                if (zip != null) result = readRouteShapes(zip, routeIds);
            } catch (Throwable t) {
                android.util.Log.w("Gtfs", "shapes " + t);
            } finally {
                synchronized (SHAPES_IN_FLIGHT) {
                    SHAPES_IN_FLIGHT.remove(key);
                }
            }
            if (!result.isEmpty()) SHAPE_CACHE.put(key, result);
            cb.on(result, result.isEmpty() ? (zip == null ? "network" : "empty") : null);
        });
    }

    private static Map<String, List<Polyline>> readRouteShapes(ZipFile zip, Set<String> routeIds) throws IOException {
        // 1. trips.txt: route_id -> shape_ids (wanted routes only)
        Map<String, Set<String>> routeShapes = new HashMap<>();
        BufferedReader r = reader(zip, "trips.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "route_id", "shape_id");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String rid = fieldAt(line, ix[0]);
                        if (!routeIds.contains(rid)) continue;
                        String sid = fieldAt(line, ix[1]);
                        if (sid.isEmpty()) continue;
                        Set<String> s = routeShapes.get(rid);
                        if (s == null) {
                            s = new HashSet<>();
                            routeShapes.put(rid, s);
                        }
                        s.add(sid);
                    }
                }
            } finally {
                r.close();
            }
        }
        Set<String> wantedShapes = new HashSet<>();
        for (Set<String> s : routeShapes.values()) wantedShapes.addAll(s);
        if (wantedShapes.isEmpty()) return new HashMap<>();

        // 2. shapes.txt: shape_id -> points (sequence-ordered)
        Map<String, List<double[]>> shapePts = new HashMap<>();
        Map<String, List<Integer>> shapeSeq = new HashMap<>();
        r = reader(zip, "shapes.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "shape_id", "shape_pt_lat", "shape_pt_lon", "shape_pt_sequence");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String sid = fieldAt(line, ix[0]);
                        if (!wantedShapes.contains(sid)) continue;
                        double lat = Double.parseDouble(fieldAt(line, ix[1]));
                        double lon = Double.parseDouble(fieldAt(line, ix[2]));
                        int seq = Integer.parseInt(fieldAt(line, ix[3]));
                        List<double[]> pts = shapePts.get(sid);
                        if (pts == null) {
                            pts = new ArrayList<>();
                            shapePts.put(sid, pts);
                            shapeSeq.put(sid, new ArrayList<>());
                        }
                        pts.add(new double[]{lat, lon});
                        shapeSeq.get(sid).add(seq);
                    }
                }
            } finally {
                r.close();
            }
        }

        // 3. build polylines per route
        Map<String, List<Polyline>> out = new HashMap<>();
        for (Map.Entry<String, Set<String>> e : routeShapes.entrySet()) {
            List<Polyline> list = new ArrayList<>();
            for (String sid : e.getValue()) {
                List<double[]> pts = shapePts.get(sid);
                if (pts == null || pts.size() < 2) continue;
                // sort by sequence
                List<Integer> seq = shapeSeq.get(sid);
                Integer[] order = new Integer[pts.size()];
                for (int i = 0; i < order.length; i++) order[i] = i;
                java.util.Arrays.sort(order, (a, b) -> Integer.compare(seq.get(a), seq.get(b)));
                Polyline pl = new Polyline();
                double[] prev = null;
                for (int i : order) {
                    double[] p = pts.get(i);
                    if (prev != null
                            && Math.abs(prev[0] - p[0]) < 1e-9 && Math.abs(prev[1] - p[1]) < 1e-9) continue;
                    pl.add(p[0], p[1], prev == null ? 0 : Ui.distM(prev[0], prev[1], p[0], p[1]));
                    prev = p;
                }
                if (pl.pts.size() >= 2) list.add(pl);
            }
            if (!list.isEmpty()) out.put(e.getKey(), list);
        }
        return out;
    }
}
