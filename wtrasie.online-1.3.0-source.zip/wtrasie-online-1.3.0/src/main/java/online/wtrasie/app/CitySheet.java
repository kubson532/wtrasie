package online.wtrasie.app;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** City picker bottom sheet: search field with X, clean alphabetically sorted list, no duplicates. */
public class CitySheet extends Sheet {

    public interface Listener {
        void onCityPicked(Cities.City city);
    }

    private final MainActivity act;
    private final Listener listener;
    private final EditText search;
    private final ImageButton clear;
    private final ListView list;
    private final CityAdapter adapter;
    // NOTE: must be initialized here, BEFORE setAdapter() below -
    // AbsListView.setAdapter() synchronously calls adapter.getCount().
    private List<Cities.City> shown = Cities.all();

    public CitySheet(MainActivity act, Listener listener) {
        super(act, R.layout.sheet_city);
        this.act = act;
        this.listener = listener;

        search = findViewById(R.id.citySearch);
        clear = findViewById(R.id.cityClear);
        list = findViewById(R.id.cityList);
        adapter = new CityAdapter();
        list.setAdapter(adapter);

        setDragHandle(findViewById(R.id.cityHeader));

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                Ui.setVisible(clear, s.length() > 0);
                filter(s.toString());
            }
        });

        clear.setOnClickListener(v -> {
            search.setText("");
            filter("");
        });

        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos >= 0 && pos < shown.size()) {
                Cities.City c = shown.get(pos);
                hide();
                try {
                    listener.onCityPicked(c);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    private void filter(String q) {
        String n = Ui.norm(q);
        if (n.isEmpty()) {
            shown = Cities.all();
        } else {
            List<Cities.City> f = new ArrayList<>();
            for (Cities.City c : Cities.all()) {
                if (Ui.norm(c.name).contains(n)
                        || Ui.norm(c.country).contains(n)
                        || c.slug.toLowerCase().contains(n)) {
                    f.add(c);
                }
            }
            shown = f;
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void show() {
        super.show();
        search.setText("");
        filter("");
        shown = Cities.all();
        adapter.notifyDataSetChanged();
    }

    private class CityAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int pos) {
            return shown.get(pos);
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            View v = cv;
            if (v == null) {
                v = LayoutInflater.from(act).inflate(R.layout.row_city, parent, false);
            }
            Cities.City c = shown.get(pos);
            TextView name = v.findViewById(R.id.cityRowName);
            TextView country = v.findViewById(R.id.cityRowCountry);
            ImageView icon = v.findViewById(R.id.cityRowIcon);
            name.setText(c.name);
            if (c.nationwide) {
                country.setText("");
                icon.setImageResource(R.drawable.earth);
            } else {
                country.setText(c.country);
                icon.setImageResource(R.drawable.city);
            }
            return v;
        }
    }
}
