package online.wtrasie.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextPaint;

import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.maplibre.android.style.layers.CircleLayer;
import org.maplibre.android.style.layers.Layer;
import org.maplibre.android.style.layers.LineLayer;
import org.maplibre.android.style.layers.PropertyValue;
import org.maplibre.android.style.layers.SymbolLayer;
import org.maplibre.android.style.sources.GeoJsonSource;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.FeatureCollection;
import org.maplibre.geojson.LineString;
import org.maplibre.geojson.Point;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.maplibre.android.style.expressions.Expression.exponential;
import static org.maplibre.android.style.expressions.Expression.get;
import static org.maplibre.android.style.expressions.Expression.interpolate;
import static org.maplibre.android.style.expressions.Expression.stop;
import static org.maplibre.android.style.expressions.Expression.zoom;

/**
 * All map rendering on top of a MapLibre vector map (the same style the
 * zbiorkom.live web app uses — OpenFreeMap/OpenMapTiles).
 *
 * Stops are colored dots; at strong zoom they grow type icons (green bus,
 * orange train station, pink M, blue tram). Bus-only stops appear only at a
 * strong zoom and vanish completely once vehicles collapse into dots.
 * Vehicles are route-colored badges sitting ON their route (snapped to the
 * GTFS shape) with the line number above; they glide along the shape between
 * refreshes. Below the dot-zoom threshold vehicles become plain dots.
 * PKP trains are fetched in parallel and always shown, whatever the city.
 */
public class MapLayers {

    public interface Listener {
        void onMapReady();

        void onViewportSettled();

        void onVehicleTapped(Models.Vehicle v);

        void onStopTapped(Models.Stop s);

        void onRouteStopTapped(String stopId, String name, double lat, double lon);
    }

    private static final float BUS_STOP_ZOOM = 15.5f;   // bus stops need a strong zoom
    private static final float STOP_ICON_ZOOM = 14.5f;  // tram/metro/ferry dots -> icons
    private static final float STATION_ICON_ZOOM = 13.5f;
    private static final long KEEP_MS = 35000;          // keep briefly-missing vehicles

    private final Context ctx;
    private final Prefs prefs;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());

    MapView mapView;
    MapLibreMap map;
    Style style;
    private boolean ready = false;
    private int currentStyleIdx = -1;

    // ---- data ----
    private final List<Models.Stop> stops = new ArrayList<>();
    private final List<Models.Vehicle> vehicles = new ArrayList<>();   // current city
    private final List<Models.Vehicle> pkpVehicles = new ArrayList<>(); // nationwide PKP overlay
    private final Map<String, VState> vstates = new HashMap<>();
    private String highlightKey;                 // vehicle preview ("type:id")
    private Gtfs.Polyline previewPath;           // shape of the previewed trip
    private Gtfs.Trip previewTrip;
    private int previewColor = 0xFF1976D2;
    private final Snapper snapper = new Snapper();
    private String snapperCity;

    /** Per-vehicle display state: interpolated position between two snapped fixes. */
    private static class VState {
        double dispLat, dispLon;     // what is on screen right now
        double fromLat, fromLon;     // animation start
        double toLat, toLon;         // animation target (snapped when possible)
        Gtfs.Polyline path;          // shape to follow (may be null -> straight line)
        double pathFrom, pathTo;     // cumulative meters along that shape
        long startMs, durMs = 4000;
        long lastSeen, bornAt;
        boolean arrived = true;
    }

    private final Runnable animTick = new Runnable() {
        @Override
        public void run() {
            try {
                if (ready && stepAnimation()) rebuildVehicleSources();
            } catch (Throwable ignored) {
            }
            handler.postDelayed(this, 100);
        }
    };

    public MapLayers(Context ctx, Prefs prefs, Listener listener) {
        this.ctx = ctx;
        this.prefs = prefs;
        this.listener = listener;
        ctxHolder = ctx.getApplicationContext();
        handler.post(animTick);
    }

    // ---------------------------------------------------------------- attach / style

    public void attach(MapView view) {
        this.mapView = view;
        view.getMapAsync(m -> {
            map = m;
            m.getUiSettings().setAttributionEnabled(false);
            m.getUiSettings().setLogoEnabled(false);
            m.setMinZoomPreference(4);
            m.setMaxZoomPreference(19);
            m.addOnMapClickListener(this::onMapClick);
            m.addOnCameraIdleListener(() -> {
                if (ready) listener.onViewportSettled();
                applyZoomThresholds(); // layer min/max zoom may follow the sliders
            });
            applyStyle(prefs.mapStyle());
        });
    }

    /** 0 = basic vector (OpenFreeMap), 1 = OSM raster, 2 = Esri satellite. */
    public void applyStyle(int idx) {
        if (map == null || idx == currentStyleIdx) return;
        currentStyleIdx = idx;
        ready = false;
        String uri = idx == 1 ? "asset://style_osm.json"
                : idx == 2 ? "asset://style_sat.json"
                : "asset://style_basic.json";
        map.setStyle(new Style.Builder().fromUri(uri), s -> {
            style = s;
            ready = true;
            try {
                buildLayers();
                registerStopIcons();
                pushAllData();
                applyZoomThresholds();
            } catch (Throwable t) {
                android.util.Log.e("MapLayers", "style ready", t);
            }
            listener.onMapReady();
        });
    }

    private void buildLayers() {
        addSource("route-src");
        style.addLayer(new LineLayer("route-casing", "route-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.lineColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.lineWidth(7.5f),
                org.maplibre.android.style.layers.PropertyFactory.lineCap(
                        org.maplibre.android.style.layers.Property.LINE_CAP_ROUND),
                org.maplibre.android.style.layers.PropertyFactory.lineJoin(
                        org.maplibre.android.style.layers.Property.LINE_JOIN_ROUND)));
        style.addLayer(new LineLayer("route-line", "route-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.lineColor(0xFF1976D2),
                org.maplibre.android.style.layers.PropertyFactory.lineWidth(4.5f),
                org.maplibre.android.style.layers.PropertyFactory.lineCap(
                        org.maplibre.android.style.layers.Property.LINE_CAP_ROUND),
                org.maplibre.android.style.layers.PropertyFactory.lineJoin(
                        org.maplibre.android.style.layers.Property.LINE_JOIN_ROUND)));

        addSource("route-stops-src");
        style.addLayer(new CircleLayer("route-stops", "route-stops-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(4f),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(0xFF1976D2),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth(2.5f)));

        // stops: dots first, icons above
        addSource("stops-bus-src");
        style.addLayer(new SymbolLayer("stops-bus-icons", "stops-bus-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.3), zoom(), stop(15.5f, 0.75f), stop(18f, 1.1f)))));

        addSource("stops-major-src");
        style.addLayer(new CircleLayer("stops-major-dots", "stops-major-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(get("color")),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(
                        interpolate(exponential(1.3), zoom(), stop(10f, 2.4f), stop(14f, 3.6f), stop(18f, 4.8f))),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth(1.2f)));
        style.addLayer(new SymbolLayer("stops-major-icons", "stops-major-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.3), zoom(), stop(14.5f, 0.7f), stop(18f, 1.05f)))));

        addSource("stops-station-src");
        style.addLayer(new CircleLayer("stops-station-dots", "stops-station-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(get("color")),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(
                        interpolate(exponential(1.3), zoom(), stop(10f, 2.8f), stop(14f, 4f), stop(18f, 5.2f))),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth(1.2f)));
        style.addLayer(new SymbolLayer("stops-station-icons", "stops-station-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.3), zoom(), stop(13.5f, 0.75f), stop(18f, 1.1f)))));

        // vehicles: dots below the threshold, rotated badges + number text above
        addSource("veh-dot-src");
        style.addLayer(new CircleLayer("veh-dots", "veh-dot-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(get("color")),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(
                        interpolate(exponential(1.4), zoom(), stop(5f, 2.5f), stop(12f, 3.4f)))));

        addSource("veh-full-src");
        style.addLayer(new SymbolLayer("veh-badges", "veh-full-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconRotate(get("rot")),
                org.maplibre.android.style.layers.PropertyFactory.iconRotationAlignment(
                        org.maplibre.android.style.layers.Property.ICON_ROTATION_ALIGNMENT_MAP),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.2), zoom(), stop(13f, 0.85f), stop(17f, 1.15f)))));
        style.addLayer(new SymbolLayer("veh-texts", "veh-full-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.textField(get("label")),
                org.maplibre.android.style.layers.PropertyFactory.textFont(
                        new String[]{"Noto Sans Regular"}),
                org.maplibre.android.style.layers.PropertyFactory.textSize(12.5f),
                org.maplibre.android.style.layers.PropertyFactory.textColor(0xFF1C1B1F),
                org.maplibre.android.style.layers.PropertyFactory.textHaloColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.textHaloWidth(1.6f),
                org.maplibre.android.style.layers.PropertyFactory.textOffset(new Float[]{0f, -1.55f}),
                org.maplibre.android.style.layers.PropertyFactory.textAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.textIgnorePlacement(true)));

        // PKP trains: own sources, own dot threshold — always visible
        addSource("pkp-dot-src");
        style.addLayer(new CircleLayer("pkp-dots", "pkp-dot-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(get("color")),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(
                        interpolate(exponential(1.4), zoom(), stop(5f, 2.8f), stop(12f, 3.6f)))));
        addSource("pkp-full-src");
        style.addLayer(new SymbolLayer("pkp-badges", "pkp-full-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconRotate(get("rot")),
                org.maplibre.android.style.layers.PropertyFactory.iconRotationAlignment(
                        org.maplibre.android.style.layers.Property.ICON_ROTATION_ALIGNMENT_MAP),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.2), zoom(), stop(11f, 0.85f), stop(17f, 1.15f)))));
        style.addLayer(new SymbolLayer("pkp-texts", "pkp-full-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.textField(get("label")),
                org.maplibre.android.style.layers.PropertyFactory.textFont(
                        new String[]{"Noto Sans Regular"}),
                org.maplibre.android.style.layers.PropertyFactory.textSize(12.5f),
                org.maplibre.android.style.layers.PropertyFactory.textColor(0xFF1C1B1F),
                org.maplibre.android.style.layers.PropertyFactory.textHaloColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.textHaloWidth(1.6f),
                org.maplibre.android.style.layers.PropertyFactory.textOffset(new Float[]{0f, -1.55f}),
                org.maplibre.android.style.layers.PropertyFactory.textAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.textIgnorePlacement(true)));

        // user location dot
        addSource("loc-src");
        style.addLayer(new SymbolLayer("loc-marker", "loc-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage("loc_dot"),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true)));
        try {
            style.addImage("loc_dot", locationBitmap());
        } catch (Throwable ignored) {
        }
    }

    private void addSource(String id) {
        try {
            style.addSource(new GeoJsonSource(id, FeatureCollection.fromFeatures(new ArrayList<>())));
        } catch (Throwable ignored) {
        }
    }

    private void setSource(String id, FeatureCollection fc) {
        if (!ready) return;
        try {
            GeoJsonSource src = style.getSourceAs(id);
            if (src != null) src.setGeoJson(fc);
        } catch (Throwable t) {
            android.util.Log.w("MapLayers", "setSource " + id + " " + t);
        }
    }

    private void setLayerVisible(String id, boolean visible) {
        if (!ready) return;
        try {
            Layer l = style.getLayer(id);
            if (l != null) l.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.visibility(
                            visible ? org.maplibre.android.style.layers.Property.VISIBLE
                                    : org.maplibre.android.style.layers.Property.NONE));
        } catch (Throwable ignored) {
        }
    }

    /** Layer zoom thresholds follow the debug-overlay sliders. */
    private void applyZoomThresholds() {
        if (!ready) return;
        float vehDot = prefs.dotZoomVehicles() / 10f;
        float stopsMin = prefs.dotZoomStops() / 10f;
        float pkpDot = prefs.dotZoomPkp() / 10f;
        float busMin = Math.max(BUS_STOP_ZOOM, Math.max(stopsMin, vehDot));
        trySetZoom("veh-badges", vehDot, -1);
        trySetZoom("veh-texts", vehDot, -1);
        trySetZoom("veh-dots", -1, vehDot);
        trySetZoom("pkp-badges", pkpDot, -1);
        trySetZoom("pkp-texts", pkpDot, -1);
        trySetZoom("pkp-dots", -1, pkpDot);
        trySetZoom("stops-bus-icons", busMin, -1);
        trySetZoom("stops-major-dots", stopsMin, STOP_ICON_ZOOM);
        trySetZoom("stops-major-icons", STOP_ICON_ZOOM, -1);
        trySetZoom("stops-station-dots", stopsMin, STATION_ICON_ZOOM);
        trySetZoom("stops-station-icons", STATION_ICON_ZOOM, -1);
    }

    private void trySetZoom(String layerId, float min, float max) {
        try {
            Layer l = style.getLayer(layerId);
            if (l == null) return;
            if (min >= 0) l.setMinZoom(min);
            if (max >= 0) l.setMaxZoom(max);
        } catch (Throwable ignored) {
        }
    }

    public void refreshThresholds() {
        applyZoomThresholds();
    }

    /** Rebuild stop + vehicle sources after settings/filters changed. */
    public void rebuildPublic() {
        rebuildStopSources();
        rebuildVehicleSources();
    }

    // ---------------------------------------------------------------- stop icons

    private final Map<String, Bitmap> stopIconCache = new HashMap<>();

    /** Colored disc + white type glyph, registered per type in the style. */
    private void registerStopIcons() {
        int[] types = {0, 1, 2, 3, 4, 11};
        for (int t : types) {
            String name = "st_ic_" + t;
            if (style.getImage(name) == null) {
                try {
                    style.addImage(name, stopIconBitmap(t, false));
                } catch (Throwable ignored) {
                }
            }
        }
        // station variant (building glyph)
        if (style.getImage("st_ic_station") == null) {
            try {
                style.addImage("st_ic_station", stopIconBitmap(2, true));
            } catch (Throwable ignored) {
            }
        }
    }

    private Bitmap stopIconBitmap(int type, boolean station) {
        String key = type + "_" + station;
        Bitmap cached = stopIconCache.get(key);
        if (cached != null) return cached;
        int size = Ui.dp(ctx, 26);
        int pad = Ui.dp(ctx, 2);
        Bitmap b = Bitmap.createBitmap(size + pad * 2, size + pad * 2, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        float cx = (size + pad * 2) / 2f, cy = cx;
        float r = size / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Models.stopColor(type));
        c.drawCircle(cx, cy, r, p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, r, p);
        p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Models.stopColor(type));
        c.drawCircle(cx, cy, r - Ui.dp(ctx, 1.5f), p);
        try {
            int res = station ? R.drawable.ic_station : Models.stopIcon(type);
            Drawable d = ctx.getDrawable(res);
            if (d != null) {
                d.setTint(0xFFFFFFFF);
                float inset = r * 0.52f;
                d.setBounds((int) (cx - inset), (int) (cy - inset), (int) (cx + inset), (int) (cy + inset));
                d.draw(c);
            }
        } catch (Throwable ignored) {
        }
        stopIconCache.put(key, b);
        return b;
    }

    private Bitmap locationBitmap() {
        int size = Ui.dp(ctx, 26);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = size / 2f;
        p.setColor(0x330B57D0);
        c.drawCircle(r, r, r, p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(r, r, r * 0.72f, p);
        p.setColor(0xFF1A73E8);
        c.drawCircle(r, r, r * 0.56f, p);
        return b;
    }

    // ---------------------------------------------------------------- vehicle badges

    private final Map<String, Bitmap> badgeCache = new LinkedHashMap<String, Bitmap>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Bitmap> eldest) {
            return size() > 260;
        }
    };

    /**
     * A vehicle "object" sitting on the route: rounded rectangle in the route
     * color with the white type glyph and a small direction chevron at the
     * front (points up = bearing 0, the layer rotates it).
     */
    private Bitmap vehicleBadge(int type, int color) {
        String key = type + "_" + color;
        Bitmap cached = badgeCache.get(key);
        if (cached != null) return cached;

        float w = Ui.dp(ctx, 23), h = Ui.dp(ctx, 30);
        int bw = (int) (w + Ui.dp(ctx, 4)), bh = (int) (h + Ui.dp(ctx, 4));
        Bitmap b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        float ox = (bw - w) / 2f, oy = (bh - h) / 2f;

        Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        body.setColor(color);
        float rad = Ui.dp(ctx, 6.5f);
        RectF rect = new RectF(ox, oy + Ui.dp(ctx, 3), ox + w, oy + h);
        // direction chevron above the body
        Path chev = new Path();
        float cx = ox + w / 2f;
        chev.moveTo(cx, oy);
        chev.lineTo(cx - Ui.dp(ctx, 6), oy + Ui.dp(ctx, 6));
        chev.lineTo(cx + Ui.dp(ctx, 6), oy + Ui.dp(ctx, 6));
        chev.close();
        body.setStyle(Paint.Style.FILL);
        c.drawPath(chev, body);
        c.drawRoundRect(rect, rad, rad, body);
        // white outline for contrast on any background
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Ui.dp(ctx, 1.6f));
        ring.setColor(0xFFFFFFFF);
        c.drawRoundRect(rect, rad, rad, ring);

        // white type glyph
        try {
            Drawable d = ctx.getDrawable(Models.typeIcon(type));
            if (d != null) {
                d.setTint(0xFFFFFFFF);
                float inset = Math.min(w, h) * 0.30f;
                d.setBounds((int) (rect.centerX() - inset), (int) (rect.centerY() - inset),
                        (int) (rect.centerX() + inset), (int) (rect.centerY() + inset));
                d.draw(c);
            }
        } catch (Throwable ignored) {
        }
        badgeCache.put(key, b);
        return b;
    }

    private void ensureBadgeIcon(int type, int color) {
        String name = "veh_" + type + "_" + (color & 0xFFFFFF);
        try {
            if (style.getImage(name) == null) style.addImage(name, vehicleBadge(type, color));
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- data push

    private void pushAllData() {
        rebuildStopSources();
        rebuildVehicleSources();
        pushRoute();
    }

    public void setStops(List<Models.Stop> s) {
        stops.clear();
        if (s != null) stops.addAll(s);
        rebuildStopSources();
    }

    public List<Models.Stop> getStops() {
        return stops;
    }

    public void setVehicles(List<Models.Vehicle> v) {
        vehicles.clear();
        if (v != null) vehicles.addAll(v);
        ingestVehicles(vehicles, false);
        rebuildVehicleSources();
        maybeSnap();
    }

    public void setPkpVehicles(List<Models.Vehicle> v) {
        pkpVehicles.clear();
        if (v != null) {
            for (Models.Vehicle x : v) x.pkp = true;
            pkpVehicles.addAll(v);
        }
        ingestVehicles(pkpVehicles, true);
        rebuildVehicleSources();
    }

    public List<Models.Vehicle> getVehicles() {
        List<Models.Vehicle> all = new ArrayList<>(vehicles);
        all.addAll(pkpVehicles);
        return all;
    }

    public Models.Vehicle highlightedVehicle() {
        if (highlightKey == null) return null;
        for (Models.Vehicle v : getVehicles()) {
            if (v.rtKey().equals(highlightKey)) return v;
        }
        return null;
    }

    private void ingestVehicles(List<Models.Vehicle> list, boolean pkp) {
        long now = System.currentTimeMillis();
        for (Models.Vehicle v : list) {
            VState st = vstates.get(v.rtKey());
            if (st == null) {
                st = new VState();
                st.dispLat = v.lat;
                st.dispLon = v.lon;
                st.fromLat = v.lat;
                st.fromLon = v.lon;
                st.toLat = v.lat;
                st.toLon = v.lon;
                st.bornAt = now;
                st.arrived = true;
                vstates.put(v.rtKey(), st);
            } else {
                // start a new glide from the current displayed position
                boolean moved = Math.abs(st.toLat - v.lat) > 1e-7 || Math.abs(st.toLon - v.lon) > 1e-7;
                if (moved || st.arrived) {
                    st.fromLat = st.dispLat;
                    st.fromLon = st.dispLon;
                    st.toLat = v.lat;
                    st.toLon = v.lon;
                    st.startMs = now;
                    st.durMs = Math.max(900, (pkp ? 20 : prefs.refreshInterval()) * 1000L * 85 / 100);
                    st.arrived = false;
                }
            }
            st.lastSeen = now;
        }
        Iterator<Map.Entry<String, VState>> it = vstates.entrySet().iterator();
        while (it.hasNext()) {
            if (now - it.next().getValue().lastSeen > KEEP_MS) it.remove();
        }
    }

    /** Advance every animation; true when something moved (source needs update). */
    private boolean stepAnimation() {
        long now = System.currentTimeMillis();
        boolean moved = false;
        for (Map.Entry<String, VState> e : vstates.entrySet()) {
            VState st = e.getValue();
            if (st.arrived) continue;
            float f = st.durMs <= 0 ? 1f : (now - st.startMs) / (float) st.durMs;
            if (f >= 1) f = 1;
            f = f * f * (3 - 2 * f); // smoothstep
            if (st.path != null) {
                double along = st.pathFrom + (st.pathTo - st.pathFrom) * f;
                double[] p = st.path.at(along);
                st.dispLat = p[0];
                st.dispLon = p[1];
            } else {
                st.dispLat = st.fromLat + (st.toLat - st.fromLat) * f;
                st.dispLon = st.fromLon + (st.toLon - st.fromLon) * f;
            }
            moved = true;
            if (f >= 1) st.arrived = true;
        }
        return moved;
    }

    // ---------------------------------------------------------------- snapping

    /**
     * Snap vehicle animations to their route shapes (GTFS). Runs once per city
     * (+ once the static zip is cached); afterwards every refresh snaps directly.
     */
    private void maybeSnap() {
        if (snapper.city == null || !snapper.city.equals(currentCitySlug)) return;
        if (highlightKey != null || previewPath != null) return;
        resnapAll();
    }

    private String currentCitySlug;

    public void setCity(String slug) {
        currentCitySlug = slug;
        snapper.prepare(slug, vehicles, () -> resnapAll());
    }

    /** Recompute targets with shape snapping; animations restart from displayed positions. */
    private void resnapAll() {
        if (!ready) return;
        long now = System.currentTimeMillis();
        for (Models.Vehicle v : vehicles) {
            if (highlightKey != null && v.rtKey().equals(highlightKey) && previewPath != null) {
                snapVehicleTo(v, previewPath, now);
                continue;
            }
            Gtfs.Polyline path = snapper.pathFor(v);
            if (path != null) snapVehicleTo(v, path, now);
        }
        for (Models.Vehicle v : pkpVehicles) {
            Gtfs.Polyline path = snapper.pathFor(v);
            if (path != null) snapVehicleTo(v, path, now);
        }
        rebuildVehicleSources();
    }

    private void snapVehicleTo(Models.Vehicle v, Gtfs.Polyline path, long now) {
        VState st = vstates.get(v.rtKey());
        if (st == null) return;
        double[] n = path.nearest(v.lat, v.lon);
        if (n[3] > 400) return; // too far from this shape — keep the raw fix
        double along = n[2];
        double curAlong = along;
        if (st.path == path && !st.arrived) {
            curAlong = st.pathTo; // continue from where the current glide is heading
        }
        st.path = path;
        st.fromLat = st.dispLat;
        st.fromLon = st.dispLon;
        // animate along the path between the two along-distances
        double a0, a1;
        if (Math.abs(along - curAlong) < Math.abs(along + path.length() - curAlong)
                && Math.abs(along - curAlong) < Math.abs(along - path.length() - curAlong)) {
            a0 = curAlong;
            a1 = along;
        } else if (Math.abs(along + path.length() - curAlong) < Math.abs(along - path.length() - curAlong)) {
            a0 = curAlong;
            a1 = along + path.length();
        } else {
            a0 = curAlong;
            a1 = along - path.length();
        }
        st.pathFrom = Math.max(0, a0);
        st.pathTo = Math.min(path.length(), a1);
        st.startMs = now;
        st.durMs = Math.max(900, prefs.refreshInterval() * 1000L * 85 / 100);
        st.arrived = false;
        double[] at0 = path.at(st.pathFrom);
        st.dispLat = at0[0];
        st.dispLon = at0[1];
        st.toLat = n[0];
        st.toLon = n[1];
    }

    // ---------------------------------------------------------------- sources rebuild

    private boolean vehicleVisible(Models.Vehicle v) {
        if (!prefs.showVehicles()) return false;
        if (Models.hiddenByTechnicalFilter(v.routeName, prefs.filterTechnical())) return false;
        if (highlightKey != null) return v.rtKey().equals(highlightKey);
        return prefs.typeFilter(v.typeInt());
    }

    private void rebuildStopSources() {
        if (!ready) return;
        boolean previewOpen = highlightKey != null;
        List<Feature> bus = new ArrayList<>();
        List<Feature> major = new ArrayList<>();
        List<Feature> stations = new ArrayList<>();
        if (!previewOpen && prefs.showStops()) {
            for (Models.Stop s : stops) {
                boolean anyType = false;
                for (int t : s.types) {
                    if (prefs.typeFilter(t)) {
                        anyType = true;
                        break;
                    }
                }
                if (!anyType) continue;
                Feature f = Feature.fromGeometry(Point.fromLngLat(s.lon, s.lat));
                int mt = s.mainType();
                f.addStringProperty("color", hex(Models.stopColor(mt)));
                if (s.isStation() && (mt == 2 || mt == 1)) {
                    f.addStringProperty("icon", "st_ic_station");
                    stations.add(f);
                } else if (s.busOnly()) {
                    f.addStringProperty("icon", "st_ic_" + mt);
                    bus.add(f);
                } else {
                    f.addStringProperty("icon", "st_ic_" + mt);
                    major.add(f);
                }
            }
        }
        setSource("stops-bus-src", FeatureCollection.fromFeatures(bus));
        setSource("stops-major-src", FeatureCollection.fromFeatures(major));
        setSource("stops-station-src", FeatureCollection.fromFeatures(stations));
    }

    private void rebuildVehicleSources() {
        if (!ready) return;
        List<Feature> dots = new ArrayList<>();
        List<Feature> full = new ArrayList<>();
        List<Feature> pkpDots = new ArrayList<>();
        List<Feature> pkpFull = new ArrayList<>();
        for (Models.Vehicle v : vehicles) {
            if (!vehicleVisible(v)) continue;
            addVehicleFeature(v, dots, full);
        }
        boolean hl = highlightKey != null;
        for (Models.Vehicle v : pkpVehicles) {
            if (Models.hiddenByTechnicalFilter(v.routeName, prefs.filterTechnical())) continue;
            if (hl && !v.rtKey().equals(highlightKey)) continue;
            if (!hl && !prefs.typeFilter(v.typeInt())) continue;
            addVehicleFeature(v, pkpDots, pkpFull);
        }
        setSource("veh-dot-src", FeatureCollection.fromFeatures(dots));
        setSource("veh-full-src", FeatureCollection.fromFeatures(full));
        setSource("pkp-dot-src", FeatureCollection.fromFeatures(pkpDots));
        setSource("pkp-full-src", FeatureCollection.fromFeatures(pkpFull));
    }

    private void addVehicleFeature(Models.Vehicle v, List<Feature> dots, List<Feature> full) {
        VState st = vstates.get(v.rtKey());
        double lat = st == null ? v.lat : st.dispLat;
        double lon = st == null ? v.lon : st.dispLon;
        Feature dot = Feature.fromGeometry(Point.fromLngLat(lon, lat));
        dot.addStringProperty("color", hex(v.pkp ? Models.typeColor(2) : v.routeColor));
        dots.add(dot);
        ensureBadgeIcon(v.typeInt(), v.pkp ? Models.typeColor(2) : v.routeColor);
        Feature f = Feature.fromGeometry(Point.fromLngLat(lon, lat));
        f.addStringProperty("icon", "veh_" + v.typeInt() + "_"
                + ((v.pkp ? Models.typeColor(2) : v.routeColor) & 0xFFFFFF));
        String label = v.routeName == null || v.routeName.isEmpty() ? "?" : v.routeName;
        if (prefs.showBrigade() && v.brigade != null && !v.brigade.isEmpty()) label += "/" + v.brigade;
        if (prefs.showFleet() && v.id != null && !v.id.isEmpty() && !v.id.startsWith("_")) label += "/" + v.id;
        f.addStringProperty("label", label);
        f.addNumberProperty("rot", v.bearing == null ? 0 : v.bearing);
        full.add(f);
    }

    private static String hex(int color) {
        return String.format("%06X", 0xFFFFFF & color);
    }

    // ---------------------------------------------------------------- route preview

    /** Vehicle preview mode: only this vehicle stays on the map. */
    public void setHighlight(String key) {
        highlightKey = key;
        if (key == null) previewPath = null;
        rebuildStopSources();
        rebuildVehicleSources();
    }

    public String getHighlight() {
        return highlightKey;
    }

    public void setTrip(Gtfs.Trip trip, int color) {
        previewTrip = trip;
        previewColor = color;
        previewPath = tripToPath(trip);
        pushRoute();
        // re-snap the highlighted vehicle onto its precise trip shape
        if (highlightKey != null && previewPath != null) {
            Models.Vehicle v = highlightedVehicle();
            if (v != null) snapVehicleTo(v, previewPath, System.currentTimeMillis());
            rebuildVehicleSources();
        }
        try {
            Layer l = style.getLayer("route-line");
            if (l != null) l.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.lineColor(color));
            Layer st = style.getLayer("route-stops");
            if (st != null) st.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(color));
        } catch (Throwable ignored) {
        }
    }

    private Gtfs.Polyline tripToPath(Gtfs.Trip trip) {
        if (trip == null || trip.shape == null || trip.shape.size() < 2) return null;
        Gtfs.Polyline pl = new Gtfs.Polyline();
        double[] prev = null;
        for (double[] p : trip.shape) {
            if (prev != null && Math.abs(prev[0] - p[0]) < 1e-9 && Math.abs(prev[1] - p[1]) < 1e-9) continue;
            pl.add(p[0], p[1], prev == null ? 0 : Ui.distM(prev[0], prev[1], p[0], p[1]));
            prev = p;
        }
        return pl.pts.size() < 2 ? null : pl;
    }

    public void clearTrip() {
        previewTrip = null;
        previewPath = null;
        pushRoute();
    }

    private void pushRoute() {
        if (!ready) return;
        if (previewTrip == null || previewTrip.shape == null || previewTrip.shape.isEmpty()) {
            setSource("route-src", FeatureCollection.fromFeatures(new ArrayList<>()));
            setSource("route-stops-src", FeatureCollection.fromFeatures(new ArrayList<>()));
            return;
        }
        List<Point> pts = new ArrayList<>();
        for (double[] p : previewTrip.shape) pts.add(Point.fromLngLat(p[1], p[0]));
        Feature line = Feature.fromGeometry(LineString.fromLngLats(pts));
        List<Feature> stopFeats = new ArrayList<>();
        for (Gtfs.StopTime st : previewTrip.stops) {
            if (st.lat == 0 && st.lon == 0) continue;
            stopFeats.add(Feature.fromGeometry(Point.fromLngLat(st.lon, st.lat)));
        }
        setSource("route-src", FeatureCollection.fromFeatures(new ArrayList<>(java.util.Collections.singletonList(line))));
        setSource("route-stops-src", FeatureCollection.fromFeatures(stopFeats));
    }

    // ---------------------------------------------------------------- location

    public void setLocation(double lat, double lon) {
        if (!ready || lat == 0 && lon == 0) return;
        Feature f = Feature.fromGeometry(Point.fromLngLat(lon, lat));
        setSource("loc-src", FeatureCollection.fromFeatures(
                new ArrayList<>(java.util.Collections.singletonList(f))));
    }

    // ---------------------------------------------------------------- camera

    public void moveCamera(double lat, double lon, double zoom) {
        if (map == null) return;
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), zoom));
    }

    public void centerOn(double lat, double lon, double zoom) {
        if (map == null) return;
        try {
            map.easeCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), zoom), 700);
        } catch (Throwable t) {
            moveCamera(lat, lon, zoom);
        }
    }

    public void follow(double lat, double lon) {
        if (map == null) return;
        try {
            CameraPosition pos = map.getCameraPosition();
            map.easeCamera(CameraUpdateFactory.newLatLngZoom(
                    new LatLng(lat, lon), pos.zoom), 650);
        } catch (Throwable ignored) {
        }
    }

    public void fitTrip(double[][] latlon, double padSouthRatio) {
        if (map == null || latlon == null || latlon.length < 2) return;
        try {
            double minLat = 90, maxLat = -90, minLon = 180, maxLon = -180;
            for (double[] p : latlon) {
                minLat = Math.min(minLat, p[0]);
                maxLat = Math.max(maxLat, p[0]);
                minLon = Math.min(minLon, p[1]);
                maxLon = Math.max(maxLon, p[1]);
            }
            double latSpan = maxLat - minLat;
            double lonSpan = maxLon - minLon;
            minLat -= latSpan * 0.62; // the sheet covers the bottom of the screen
            minLon -= lonSpan * 0.12;
            maxLat += latSpan * 0.12;
            maxLon += lonSpan * 0.12;
            map.easeCamera(CameraUpdateFactory.newLatLngBounds(
                    new LatLngBounds.Builder()
                            .include(new LatLng(maxLat, maxLon))
                            .include(new LatLng(minLat, minLon))
                            .build(), Ui.dp(ctx, 28)), 700);
            mapView.post(() -> {
                try {
                    if (map.getCameraPosition().zoom > 16.2)
                        map.easeCamera(CameraUpdateFactory.newLatLngZoom(
                                map.getCameraPosition().target, 16.2), 400);
                } catch (Throwable ignored) {
                }
            });
        } catch (Throwable ignored) {
        }
    }

    public double camZoom() {
        try {
            return map.getCameraPosition().zoom;
        } catch (Throwable t) {
            return 12;
        }
    }

    public LatLng center() {
        try {
            return map.getCameraPosition().target;
        } catch (Throwable t) {
            return new LatLng(50.04, 21.99);
        }
    }

    public String bboxString() {
        try {
            LatLngBounds b = map.getProjection().getVisibleRegion().latLngBounds;
            double minLon = clampLon(b.getLonWest()), maxLon = clampLon(b.getLonEast());
            double minLat = Math.max(-85, b.getLatSouth()), maxLat = Math.min(85, b.getLatNorth());
            LatLng c = center();
            minLon = Math.max(minLon, c.getLongitude() - 4);
            maxLon = Math.min(maxLon, c.getLongitude() + 4);
            minLat = Math.max(minLat, c.getLatitude() - 4);
            maxLat = Math.min(maxLat, c.getLatitude() + 4);
            if (maxLon <= minLon) maxLon = minLon + 0.02;
            if (maxLat <= minLat) maxLat = minLat + 0.02;
            return String.format(java.util.Locale.US, "%.5f,%.5f,%.5f,%.5f", minLon, minLat, maxLon, maxLat);
        } catch (Throwable t) {
            return "19.0,50.0,20.0,51.0";
        }
    }

    private double clampLon(double lon) {
        if (lon > 180) return 180;
        if (lon < -180) return -180;
        return lon;
    }

    public double spanKm() {
        try {
            LatLngBounds b = map.getProjection().getVisibleRegion().latLngBounds;
            return Ui.distM(b.getLatSouth(), b.getLonWest(), b.getLatNorth(), b.getLonEast()) / 1000.0;
        } catch (Throwable t) {
            return 20;
        }
    }

    public PointF toScreen(double lat, double lon) {
        try {
            return map.getProjection().toScreenLocation(new LatLng(lat, lon));
        } catch (Throwable t) {
            return new PointF(-9999, -9999);
        }
    }

    public void onStart() {
        try {
            if (mapView != null) mapView.onStart();
        } catch (Throwable ignored) {
        }
    }

    public void onStop() {
        try {
            if (mapView != null) mapView.onStop();
        } catch (Throwable ignored) {
        }
    }

    public void onResume() {
        try {
            if (mapView != null) mapView.onResume();
        } catch (Throwable ignored) {
        }
    }

    public void onPause() {
        try {
            if (mapView != null) mapView.onPause();
        } catch (Throwable ignored) {
        }
    }

    public void onDestroy() {
        try {
            handler.removeCallbacks(animTick);
        } catch (Throwable ignored) {
        }
        try {
            if (mapView != null) mapView.onDestroy();
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- clicks

    private boolean onMapClick(LatLng point) {
        try {
            PointF click = toScreen(point.getLatitude(), point.getLongitude());
            float cx = click.x, cy = click.y;
            float maxVeh = Ui.dp(ctx, 30);
            // vehicles first (they sit above stops)
            Models.Vehicle bestV = null;
            float bestVD = maxVeh;
            for (Models.Vehicle v : getVehicles()) {
                if (!vehicleVisible(v)) continue;
                PointF p = toScreen(v.lat, v.lon);
                double d = Math.hypot(p.x - cx, p.y - cy);
                if (d < bestVD) {
                    bestVD = (float) d;
                    bestV = v;
                }
            }
            if (bestV != null) {
                listener.onVehicleTapped(bestV);
                return true;
            }
            // preview route stops
            if (previewTrip != null) {
                float maxRs = Ui.dp(ctx, 22);
                Gtfs.StopTime bestRs = null;
                float bestRsD = maxRs;
                for (Gtfs.StopTime st : previewTrip.stops) {
                    if (st.lat == 0 && st.lon == 0) continue;
                    PointF p = toScreen(st.lat, st.lon);
                    double d = Math.hypot(p.x - cx, p.y - cy);
                    if (d < bestRsD) {
                        bestRsD = (float) d;
                        bestRs = st;
                    }
                }
                if (bestRs != null) {
                    listener.onRouteStopTapped(bestRs.stopId, bestRs.name, bestRs.lat, bestRs.lon);
                    return true;
                }
            }
            // normal stops, respecting every visibility rule
            Models.Stop best = null;
            float bestD = Ui.dp(ctx, 26);
            double z = camZoom();
            float vehDot = prefs.dotZoomVehicles() / 10f;
            float stopsMin = prefs.dotZoomStops() / 10f;
            float busMin = Math.max(BUS_STOP_ZOOM, Math.max(stopsMin, vehDot));
            for (Models.Stop s : stops) {
                boolean anyType = false;
                for (int t : s.types) {
                    if (prefs.typeFilter(t)) {
                        anyType = true;
                        break;
                    }
                }
                if (!anyType || highlightKey != null) continue;
                float minZ;
                if (s.busOnly()) minZ = busMin;
                else minZ = stopsMin;
                if (z < minZ) continue;
                PointF p = toScreen(s.lat, s.lon);
                double d = Math.hypot(p.x - cx, p.y - cy);
                if (d < bestD) {
                    bestD = (float) d;
                    best = s;
                }
            }
            if (best != null) {
                listener.onStopTapped(best);
                return true;
            }
        } catch (Throwable t) {
            android.util.Log.w("MapLayers", "click " + t);
        }
        return false;
    }

    // ---------------------------------------------------------------- snapper

    /**
     * Maps vehicles -> GTFS routes and caches route shapes so that vehicle
     * positions can be snapped onto their real routes.
     */
    static class Snapper {
        String city;
        private final Map<String, String> rtToRoute = new HashMap<>();   // rtKey -> route_id
        private final Map<String, List<Gtfs.Polyline>> shapes = new HashMap<>();
        private long mappedAt;
        private boolean preparing;

        void prepare(String citySlug, List<Models.Vehicle> vehicles, Runnable done) {
            if (city != null && city.equals(citySlug)
                    && System.currentTimeMillis() - mappedAt < 10 * 60_000L) {
                ensureShapesForMapped(vehicles, done);
                return;
            }
            if (preparing) return;
            preparing = true;
            city = citySlug;
            rtToRoute.clear();
            shapes.clear();
            final Set<String> agencies = new HashSet<>();
            for (Models.Vehicle v : vehicles) {
                if (v.agency != null && !v.agency.isEmpty()) agencies.add(v.agency);
            }
            if (agencies.isEmpty()) agencies.add("default");
            final List<String> agencyList = new ArrayList<>(agencies);
            fetchMapping(0, agencyList, citySlug, () -> {
                preparing = false;
                mappedAt = System.currentTimeMillis();
                ensureShapesForMapped(vehicles, done);
            });
        }

        private void fetchMapping(int idx, List<String> agencies, String citySlug, Runnable done) {
            if (idx >= agencies.size()) {
                done.run();
                return;
            }
            GtfsRt.vehicleTrips(citySlug, agencies.get(idx), (map, err) -> {
                if (map != null) {
                    for (Map.Entry<String, GtfsRt.Vp> e : map.entrySet()) {
                        if (e.getValue().routeId != null && !e.getValue().routeId.isEmpty()) {
                            rtToRoute.put(e.getKey(), e.getValue().routeId);
                        }
                    }
                }
                fetchMapping(idx + 1, agencies, citySlug, done);
            });
        }

        private void ensureShapesForMapped(List<Models.Vehicle> vehicles, Runnable done) {
            Set<String> routeIds = new HashSet<>();
            for (Models.Vehicle v : vehicles) {
                String rid = rtToRoute.get(v.rtKey());
                if (rid != null && !shapes.containsKey(rid)) routeIds.add(rid);
            }
            if (routeIds.isEmpty()) {
                done.run();
                return;
            }
            Set<String> agencies = new HashSet<>();
            for (Models.Vehicle v : vehicles) {
                if (v.agency != null && !v.agency.isEmpty()) agencies.add(v.agency);
            }
            if (agencies.isEmpty()) agencies.add("default");
            loadShapes(0, new ArrayList<>(agencies), routeIds, done);
        }

        private void loadShapes(int idx, List<String> agencies, Set<String> routeIds, Runnable done) {
            if (idx >= agencies.size()) {
                done.run();
                return;
            }
            Gtfs.loadRouteShapes(ctxHolder, city, agencies.get(idx), routeIds, (result, err) -> {
                if (result != null) shapes.putAll(result);
                loadShapes(idx + 1, agencies, routeIds, done);
            });
        }

        /** Best shape polyline for a vehicle (nearest to its current fix), or null. */
        Gtfs.Polyline pathFor(Models.Vehicle v) {
            String rid = rtToRoute.get(v.rtKey());
            if (rid == null) return null;
            List<Gtfs.Polyline> pls = shapes.get(rid);
            if (pls == null || pls.isEmpty()) return null;
            Gtfs.Polyline best = null;
            double bestD = Double.MAX_VALUE;
            for (Gtfs.Polyline pl : pls) {
                double[] n = pl.nearest(v.lat, v.lon);
                if (n[3] < bestD) {
                    bestD = n[3];
                    best = pl;
                }
            }
            return bestD <= 400 ? best : null;
        }
    }

    // the Snapper needs a Context for Gtfs.loadRouteShapes — set in the constructor
    private static Context ctxHolder;
}
