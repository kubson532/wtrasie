/**
 * Service worker aplikacji — czytelny odpowiednik workbox-cli (generateSW)
 * z oryginału. Cache-first dla zasobów aplikacji, network-only dla API.
 * Nowa wersja SW aktywuje się po zamknięciu wszystkich kart (skipWaiting
 * celowo NIE jest wywoływane — CheckUpdate pokazuje pasek pobierania
 * i przeładowuje stronę po controllerchange, jak w oryginale).
 *
 * Odporność hostingowa:
 *  - żądania nawigacji (HTML) są zawsze najpierw z sieci — uszkodzony
 *    lub pusty dokument nigdy nie zostanie "zamrożony" w cache;
 *  - precache powłoki liczony względem scope — działa też w podkatalogu;
 *  - numer wersji cache jest podbijany przy każdej poprawce, a stara
 *    zawartość jest usuwana przy aktywacji (naprawa "zamrożonej" bieli
 *    po błędnych wdrożeniach).
 */

const CACHE_NAME = 'zbiorkom-live-v4.12.0';

// Powłoka aplikacji (precache przy instalacji) — ścieżki względem scope
const APP_SHELL = [
    './',
    './index.php',
    './assets/css/main.css',
    './assets/css/maplibre-gl.css',
    './assets/js/main.js',
    './assets/js/vendor/maplibre-gl.js',
    './style.json',
    './manifest.json',
    './favicon.svg',
    './logo512.png',
].map((url) => new URL(url, self.registration.scope).pathname);

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches
            .open(CACHE_NAME)
            .then((cache) =>
                Promise.all(
                    APP_SHELL.map((url) =>
                        cache.add(new Request(url, { cache: 'reload' })).catch(() => {}),
                    ),
                ),
            ),
    );
});

self.addEventListener('activate', (event) => {
    // Usuń stare wersje cache (w tym ewentualne zepsute wpisy)
    event.waitUntil(
        caches
            .keys()
            .then((keys) =>
                Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))),
            )
            .then(() => self.clients.claim()),
    );
});

self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // API i strumienie SSE zawsze z sieci
    if (url.hostname === 'api.zbiorkom.live' || url.hostname === '4.zbiorkom.live' || url.pathname.includes('/stream')) {
        return;
    }

    if (url.origin !== self.location.origin) {
        return;
    }

    // Sonda wsparcia rewrite — zawsze z sieci (decyzja o trybie routingu
    // musi opierać się na świeżej odpowiedzi serwera, nie na cache).
    if (url.pathname.includes('/rewrite-probe-')) {
        return;
    }

    // Nawigacja (dokument HTML): najpierw sieć, cache tylko jako awaryjny
    // fallback offline — nigdy nie "mrozimy" uszkodzonego shella.
    if (event.request.mode === 'navigate') {
        event.respondWith(
            fetch(event.request)
                .then((response) => {
                    if (response.ok) {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
                    }
                    return response;
                })
                .catch(() => caches.match(event.request).then((cached) => cached || Response.error())),
        );
        return;
    }

    // Zasoby własne: cache-first z uzupełnianiem w tle
    event.respondWith(
        caches.match(event.request).then((cached) => {
            const fetchPromise = fetch(event.request)
                .then((response) => {
                    if (response.ok) {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
                    }
                    return response;
                })
                .catch(() => cached);

            return cached || fetchPromise;
        }),
    );
});
