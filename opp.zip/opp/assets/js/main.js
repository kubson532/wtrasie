/**
 * Punkt wejścia aplikacji — port src/index.tsx + App.tsx + Root layout:
 *   1. Wczytaj listę miast z API (odpowiednik useBackendStore + loadCities)
 *   2. Zainicjuj mapę (Map.tsx) i motyw (ThemeProvider)
 *   3. Zamontuj trwały layout: FAB menu, FABy miasta, GPS, szuflada menu
 *   4. Reaguj na zmiany trasy i montuj odpowiednie widoki (Router.tsx)
 *   5. Zarejestruj service workera (CheckUpdate.tsx)
 */

import { el, fab, dialog, alert } from './ui.js';
import { renderIcon } from './icons.js';
import { t } from './i18n.js';
import { loadCities, BackendError } from './api.js';
import { applyTheme, themeStore, locationStore } from './store.js';
import { initMap, getMap, updateUserMarker } from './map.js';
import { onRouteChange, resolveRoute, render, pathname, segments, navigate, query, setRoutingMode, getRoutingMode, isMenuState } from './router.js';
import { mountMarkers, mountCityFabs, mountMenuFab, createMenuDrawer, mountWelcomeAlert, showSuggestedCity } from './pages/city.js';
import { mountCitiesDialog } from './pages/cities.js';
import { mountStopSheet } from './pages/stop.js';
import { mountTripSheet, mountVehicleInfoDialog, mountTripAlertsDialog } from './pages/trip.js';
import { mountRouteSheet } from './pages/route.js';
import { mountSearchDialog } from './pages/search.js';
import { mountRoutesDialog } from './pages/routes.js';
import { mountSettingsDialog, mountThemeDialog } from './pages/settings.js';
import { mountBlogDialog, mountBlogPostDialog } from './pages/blog.js';
import { mountBrigadesDialog, mountBrigadeSchedule } from './pages/brigades.js';
import { mountFavoriteStopsSheet, mountAddToFavDialog } from './pages/favorites.js';
import { mountFilterSheet } from './pages/filter.js';
import { mountLayersSheet } from './pages/layers.js';
import { mountExecutionsDialog } from './pages/executions.js';
import { mountStopTimePicker } from './pages/timepicker.js';
import { mountPlannerSheet } from './pages/planner.js';
import { vehicleStore } from './store.js';

/* --------------------------- Stan widoków ---------------------------- */

let sheetHost = null;
let currentView = null; // { destroy() }
let markersView = null;
let cityFabsView = null;
let menuFabView = null;
let menuDrawer = null;
let currentCity = null;

/** Niszczy bieżący widok (arkusz/dialog). */
function destroyCurrentView() {
    currentView?.destroy?.();
    currentView = null;
}

/* ------------------------ Layout trwały ------------------------------ */

/** Kontener arkuszy (odpowiednik Sheet w drzewie Router.tsx). */
function ensureSheetHost() {
    if (!sheetHost) {
        sheetHost = el('div', { className: 'sheet-host' });
        document.getElementById('root').append(sheetHost);
    }
    return sheetHost;
}

/** Layout miasta: FAB menu + FABy + znaczniki (port Root.tsx + City.tsx). */
function mountCityLayout(city) {
    const root = document.getElementById('root');

    if (!menuFabView) {
        menuFabView = mountMenuFab(root);
    }

    if (cityFabsView) {
        cityFabsView();
    }
    cityFabsView = mountCityFabs(city, root);

    if (markersView) {
        markersView.destroy();
    }
    markersView = mountMarkers(city, root);

    // Odświeżanie strumienia po zmianie filtrów (odpowiednik subskrypcji useFilterStore)
    window.removeEventListener('zbiorkom:filters-changed', onFiltersChanged);
    window.addEventListener('zbiorkom:filters-changed', onFiltersChanged);

    if (!menuDrawer) {
        menuDrawer = createMenuDrawer();
    }

    mountWelcomeAlert(city);
}

function onFiltersChanged() {
    markersView?.refresh();
}

/** Koniec trybu SOLO (opuszczenie widoku kursu): pojazdy, kropki i
 * przystanki miasta muszą natychmiast wrócić na mapę — odświeżamy
 * strumień markerów, bo jego zdarzenie „initial” (z przystankami)
 * nadchodzi tylko przy połączeniu. */
function onMarkersRestore() {
    markersView?.refresh();
}

/** Wybór miasta przy wejściu na "/" (port CityRedirect.tsx).
 *  UWAGA HOSTINGOWA: nawigacja idzie przez router (history.replaceState),
 *  a NIE przez window.location.replace — czyli bez przeładowania strony.
 *  Dzięki temu start nie kończy się 404 na serwerach, które nie
 *  przepisują adresów (brak/ignorowany .htaccess, brak mod_rewrite). */
function cityRedirect() {
    const city = localStorage.getItem('city');
    const to = city && window.cities?.[city] ? `/${city}` : '/cities';
    navigate(to, { replace: true });
}

/* --------------------- Lokalizacja użytkownika ----------------------- */

/** Port LocationMarker.tsx — FAB GPS + znacznik + orientacja urządzenia. */
let userPermitted = false;
let bearing = undefined;

function mountLocationMarker() {
    const root = document.getElementById('root');

    const gpsFab = fab({
        icon: 'LocationDisabled',
        title: 'GPS',
        id: 'gps',
        position: { right: '16px', bottom: '16px' },
        onClick: moveToUser,
    });
    gpsFab.classList.add('large');
    root.append(gpsFab);

    const handleLocation = ({ coords }) => {
        const location = [coords.longitude, coords.latitude];
        locationStore.setUserLocation(location);
        updateUserMarker(location, bearing);

        gpsFab.replaceChildren(renderIcon('GpsNotFixed', { size: 24 }));

        localStorage.setItem(
            'userLocation',
            JSON.stringify({ location, lastUpdate: Date.now() }),
        );
    };

    const moveToLocation = (location) => {
        const map = getMap();
        if (map) {
            const zoom = map.getZoom();
            map.easeTo({ center: location, zoom: zoom > 15 ? zoom : 15 });
        }
    };

    function moveToUser() {
        if (!navigator.geolocation) {
            alert('Twoja przeglądarka nie obsługuje geolokalizacji.');
            return;
        }

        if (!userPermitted) {
            navigator.geolocation.getCurrentPosition(
                (location) => {
                    userPermitted = true;
                    handleLocation(location);
                    moveToLocation([location.coords.longitude, location.coords.latitude]);
                },
                (error) => {
                    console.error(error);
                    alert('Nie można określić Twojej lokalizacji.');
                },
            );
        } else if (locationStore.userLocation?.[0]) {
            moveToLocation(locationStore.userLocation);
        }
    }

    if (navigator.permissions?.query && navigator.geolocation) {
        navigator.permissions
            .query({ name: 'geolocation' })
            .then(({ state }) => {
                userPermitted = state === 'granted';

                if (userPermitted) {
                    navigator.geolocation.getCurrentPosition(handleLocation, undefined, {
                        enableHighAccuracy: false,
                        timeout: 5000,
                        maximumAge: 0,
                    });
                    navigator.geolocation.watchPosition(handleLocation, undefined, {
                        enableHighAccuracy: true,
                        timeout: 5000,
                        maximumAge: 0,
                    });
                    gpsFab.replaceChildren(renderIcon('GpsNotFixed', { size: 24 }));
                }
            })
            .catch(() => {});
    }

    const eventName = 'ondeviceorientationabsolute' in window ? 'deviceorientationabsolute' : 'deviceorientation';
    window.addEventListener(eventName, (event) => {
        if (event.absolute === true && event.alpha !== null) {
            bearing = event.alpha * -1;
            if (locationStore.userLocation) {
                updateUserMarker(locationStore.userLocation, bearing);
            }
        }
    });
}

/* -------------------------- Błąd backendu ----------------------------- */

/** Port BackendError.tsx — dialog z ponawianiem, gdy /api6 nie odpowiada. */
function showBackendError(errorKind, retry) {
    document.querySelector('.backend-error')?.remove();

    const icons = { network: 'WifiOff', server: 'CloudOff', unknown: 'ErrorOutline' };

    const d = el('div', { className: 'dialog-backdrop backend-error' });
    const paper = el(
        'div',
        { className: 'dialog-paper backend-error-paper' },
        el(
            'div',
            { className: 'backend-error-content' },
            el('div', { className: 'backend-error-icon' }, renderIcon(icons[errorKind] ?? 'ErrorOutline', { size: 32 })),
            el('h6', {}, t(`Backend.error.${errorKind}.title`)),
            el('p', { className: 'backend-error-message' }, t(`Backend.error.${errorKind}.message`)),
            el(
                'button',
                { className: 'button contained', onClick: retry },
                t('Backend.error.retry'),
            ),
        ),
    );

    d.append(paper);
    document.body.append(d);
}

function hideBackendError() {
    document.querySelector('.backend-error')?.remove();
}

/* --------------------------- Aktualizacje ----------------------------- */

/** Port CheckUpdate.tsx — rejestracja SW + pasek pobierania aktualizacji. */
function checkUpdate() {
    if (window.location.hostname === 'localhost' || !('serviceWorker' in navigator)) return;

    let refreshing = false;
    let isUpdate = false;

    navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (!refreshing && isUpdate) {
            refreshing = true;
            window.location.reload();
        }
    });

    navigator.serviceWorker
        .register((window.Gay?.basePath || '') + '/service-worker.js', {
            scope: (window.Gay?.basePath || '') + '/',
        })
        .then((registration) => {
        isUpdate = !!registration.active;

        registration.onupdatefound = () => {
            if (registration.installing && isUpdate) {
                const banner = el(
                    'div',
                    { className: 'update-banner' },
                    el('div', { className: 'update-banner-icon' }, renderIcon('Update', { size: 32 })),
                    el('div', { className: 'update-banner-text' }, el('span', {}, t('Updates.downloadingUpdate')), el('div', { className: 'linear-progress' })),
                );
                document.body.append(banner);
            }
        };
    })
    // Rejestracja SW jest best-effort: nie zawalaj startu aplikacji,
    // gdy hosting jej nie wspiera (np. zwykłe HTTP bez localhost).
    .catch(() => {});
}

/* --------------------- Wykrywanie trybu routingu --------------------- */

/* --------------------- Instalacja aplikacji (PWA) --------------------- */

/** Przechwytuje prompt instalacji (menu → „Zainstaluj aplikację”). */
function captureInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (event) => {
        event.preventDefault();
        window.__installPrompt = event;
    });
    window.addEventListener('appinstalled', () => {
        window.__installPrompt = null;
    });
}

/**
 * Sprawdza sondą, czy serwer serwuje powłokę pod dowolną ścieżką (czyste
 * adresy), i ustawia tryb routingu ("path" albo "hash" — patrz router.js).
 *
 * Sonda: /rewrite-probe-<wersja> — taki plik nie istnieje fizycznie, więc:
 *  - odpowiedź 200 "OK"  → przepisywanie adresów działa → tryb "path",
 *  - 404/inny błąd       → serwer bez mod_rewrite → tryb "hash" (#/…),
 *    który działa na KAŻDYM hostingu bez żadnej konfiguracji.
 *
 * Wynik jest cache'owany per wersja aplikacji; w trybie hash sonda
 * powtarza się raz na sesję (gdyby .htaccess został później wgrany,
 * aplikacja sama wróci do czystych adresów).
 */
async function detectRoutingMode() {
    const base = window.Gay?.basePath || '';
    const version = String(window.Gay?.version || 'x');

    // Głęboki link (np. /kielce/trip/123) bez hasha: ponieważ JS w ogóle
    // wystartował, serwer serwuje powłokę pod tą ścieżką — czyste adresy
    // ewidentnie działają. Bez sondy.
    const rawPath = window.location.pathname.slice(base.length) || '/';
    const isShellPath = rawPath === '/' || /\/index\.(php|html)$/.test(rawPath);
    if (!isShellPath && !window.location.hash) {
        setRoutingMode('path');
        return;
    }

    let probed = false;
    try {
        probed =
            localStorage.getItem('routingModeVersion') === version &&
            localStorage.getItem('routingMode') !== null;
    } catch {
        probed = false;
    }
    if (probed) {
        if (getRoutingMode() === 'path') return; // stabilnie OK — nie sonduj
        // W trybie hash raz na sesję sprawdź, czy serwer nie zaczął wspierać
        // czystych adresów (np. po ręcznym wgraniu .htaccess).
        if (sessionStorage.getItem('routingProbe') === '1') return;
    }
    try {
        sessionStorage.setItem('routingProbe', '1');
    } catch {
        /* ignoruj */
    }

    try {
        const response = await fetch(`${base}/rewrite-probe-${encodeURIComponent(version)}`, {
            cache: 'no-store',
        });
        const body = response.ok ? await response.text() : '';
        // Ścisła weryfikacja treści chroni przed „soft-404” niektórych
        // serwerów (strona błędu z kodem 200).
        setRoutingMode(body.trim() === 'OK' ? 'path' : 'hash');
    } catch {
        // Brak odpowiedzi (np. offline) — bezpieczniej działać w trybie hash.
        setRoutingMode('hash');
    }
    try {
        localStorage.setItem('routingModeVersion', version);
    } catch {
        /* ignoruj */
    }
}

/* --------------------------- Routing widoków --------------------------- */

/** Montuje widok dla trasy (odpowiednik elementów Router.tsx). */
let routeGeneration = 0;
let lastRouteKey = null;

async function mountRoute(route, state) {
    // Ochrona przed wyścigiem: tylko najnowsza nawigacja może montować widoki
    const generation = ++routeGeneration;
    const isCurrent = () => generation === routeGeneration;

    const root = document.getElementById('root');
    ensureSheetHost();

    // Stan "menu" otwiera szufladę (odpowiednik Root.tsx)
    if (menuDrawer) {
        if (isMenuState(state)) menuDrawer.open();
        else menuDrawer.close();
    }

    /* Podgląd planera i wybór punktu z mapy dopisują WŁASNE wpisy historii
     * („preview”/„picking”) bez zmiany trasy — zamknięcie ich przyciskiem
     * back telefonu wraca do TEGO SAMEGO widoku. Nie demontuj i nie montuj
     * ponownie identycznej trasy (zapobiega miganiu i utracie stanu). */
    const routeKey = JSON.stringify(route);
    if (
        routeKey === lastRouteKey &&
        currentView &&
        !isMenuState(state) &&
        route.view !== 'city' && // widok miasta jest idempotentny, ale odświeżamy FAB-y
        route.view !== 'root'
    ) {
        return;
    }
    lastRouteKey = routeKey;

    switch (route.view) {
        case 'root':
            cityRedirect();
            break;

        case 'cities': {
            destroyCurrentView();
            currentView = mountCitiesDialog();
            break;
        }

        case 'city': {
            destroyCurrentView();
            if (currentCity !== route.city) {
                currentCity = route.city;
            }
            mountCityLayout(route.city);
            break;
        }

        case 'stop': {
            destroyCurrentView();
            if (currentCity !== route.city) {
                currentCity = route.city;
                mountCityLayout(route.city);
            }
            currentView = mountStopSheet(
                query().get('city') || route.city,
                route.stop,
                sheetHost,
            );
            break;
        }

        case 'trip': {
            destroyCurrentView();
            if (currentCity !== route.city) {
                currentCity = route.city;
                mountCityLayout(route.city);
            }
            currentView = mountTripSheet(
                query().get('city') || route.city,
                route.kind,
                route.id,
                sheetHost,
            );
            break;
        }

        case 'route': {
            destroyCurrentView();
            if (currentCity !== route.city) {
                currentCity = route.city;
                mountCityLayout(route.city);
            }
            const routeSheet = await mountRouteSheet(
                query().get('city') || route.city,
                route.route,
                sheetHost,
            );
            if (!isCurrent()) {
                routeSheet.destroy();
                break;
            }
            currentView = routeSheet;
            break;
        }

        case 'search': {
            destroyCurrentView();
            if (currentCity !== route.city) {
                currentCity = route.city;
                mountCityLayout(route.city);
            }
            currentView = mountSearchDialog(route.city);
            break;
        }

        case 'planner': {
            destroyCurrentView();
            if (currentCity !== route.city) {
                currentCity = route.city;
                mountCityLayout(route.city);
            }
            currentView = mountPlannerSheet(sheetHost);
            break;
        }

        case 'favoriteStops': {
            destroyCurrentView();
            currentView = (await import('./pages/favorites.js')).mountFavoriteStopsSheet(sheetHost);
            break;
        }

        case 'filter': {
            destroyCurrentView();
            currentView = mountFilterSheet(sheetHost);
            break;
        }

        case 'layers': {
            destroyCurrentView();
            currentView = mountLayersSheet(sheetHost);
            break;
        }

        case 'routes': {
            destroyCurrentView();
            const routesDialog = await mountRoutesDialog(route.city);
            if (!isCurrent()) {
                routesDialog.destroy();
                break;
            }
            currentView = routesDialog;
            break;
        }

        case 'blog': {
            destroyCurrentView();
            const blogDialog = await mountBlogDialog(route.city);
            if (!isCurrent()) {
                blogDialog.destroy();
                break;
            }
            currentView = blogDialog;
            break;
        }

        case 'blogPost': {
            destroyCurrentView();
            const blogPostDialog = await mountBlogPostDialog(route.id);
            if (!isCurrent()) {
                blogPostDialog.destroy();
                break;
            }
            currentView = blogPostDialog;
            break;
        }

        case 'settings': {
            destroyCurrentView();
            currentView = mountSettingsDialog();
            break;
        }

        case 'settingsTheme': {
            destroyCurrentView();
            currentView = mountThemeDialog();
            break;
        }

        case 'executions': {
            destroyCurrentView();
            const executionsDialog = await mountExecutionsDialog(route.city);
            if (!isCurrent()) {
                executionsDialog.destroy();
                break;
            }
            currentView = executionsDialog;
            break;
        }

        case 'stopTime': {
            // Czas odjazdów: podwidok przystanku (arkusz przystanku zostaje pod spodem)
            currentView?.destroy?.();
            currentView = mountStopTimePicker();
            break;
        }

        case 'addToFav': {
            currentView?.destroy?.();
            const addToFavDialog = await (await import('./pages/favorites.js')).mountAddToFavDialog(
                query().get('city') || route.city,
                route.stop,
            );
            if (!isCurrent()) {
                addToFavDialog.destroy();
                break;
            }
            currentView = addToFavDialog;
            break;
        }

        case 'vehicleInfo': {
            currentView?.destroy?.();
            const infoDialog = await mountVehicleInfoDialog(
                query().get('city') || route.city,
                route.id,
            );
            if (!isCurrent()) {
                infoDialog.destroy();
                break;
            }
            currentView = infoDialog;
            break;
        }

        case 'brigadeFromVehicle': {
            // Rozkład brygady pojazdu: /:city/:kind/:id/brigade
            // Odczytaj numer linii i brygady PRZED zniszczeniem widoku kursu
            // (destroy resetuje magazyn vehicleStore)
            const brigade = vehicleStore.vehicle?.[3];
            const routeId = (vehicleStore.trip?.[2] || vehicleStore.vehicle?.[2])?.[0];
            const brigadeCity =
                query().get('city') || route.city;

            currentView?.destroy?.();

            if (brigade && routeId) {
                const brigadeDialog = await mountBrigadeSchedule(brigadeCity, routeId, brigade);
                if (!isCurrent()) {
                    brigadeDialog.destroy();
                    break;
                }
                currentView = brigadeDialog;
            } else {
                window.history.back();
            }
            break;
        }

        case 'tripAlerts': {
            currentView?.destroy?.();
            currentView = mountTripAlertsDialog(vehicleStore.alerts);
            break;
        }

        case 'brigades': {
            destroyCurrentView();
            const brigadesDialog = await mountBrigadesDialog(
                query().get('city') || route.city,
                route.route,
            );
            if (!isCurrent()) {
                brigadesDialog.destroy();
                break;
            }
            currentView = brigadesDialog;
            break;
        }

        case 'brigade': {
            destroyCurrentView();
            const brigadeDialog = await mountBrigadeSchedule(
                query().get('city') || route.city,
                route.route,
                route.brigade,
            );
            if (!isCurrent()) {
                brigadeDialog.destroy();
                break;
            }
            currentView = brigadeDialog;
            break;
        }

        default:
            break;
    }

    menuFabView?.refresh();
}

/* ------------------------------- Start --------------------------------- */

async function boot() {
    // Usuń statyczny ekran startowy z powłoki (index.php) — aplikacja
    // przejmuje #root i renderuje własne interfejsy.
    document.getElementById('boot-screen')?.remove();

    applyTheme();

    // Ładowanie miast (port useBackendStore.load)
    try {
        await loadCities();
    } catch (error) {
        const kind = error instanceof BackendError ? error.kind : 'unknown';
        showBackendError(kind, () => {
            hideBackendError();
            boot();
        });
        return;
    }

    // Ustal tryb routingu (czyste adresy vs #/…) ZANIM mapa i widoki
    // zaczną czytać parametry adresu (sonda /rewrite-probe-…).
    await detectRoutingMode();

    // Mapa jest zawsze widoczna (odpowiednik Map w korzeniu routera)
    initMap();
    mountLocationMarker();
    captureInstallPrompt();
    checkUpdate();

    // Powrót z trybu SOLO (widok kursu) → odśwież markery miasta
    window.addEventListener('zbiorkom:markers-restore', onMarkersRestore);

    onRouteChange((route, state) => mountRoute(route, state));
    render();

    // Aplikacja wystartowała — późniejsze błędy przeglądarki nie są
    // już traktowane jako błędy startu (powłoka nie podmienia widoku).
    window.__appBooted = true;
}

boot().catch((error) => {
    if (window.bootFail) {
        window.bootFail('Błąd startu aplikacji: ' + (error && error.message ? error.message : 'nieznany'));
    }
});
