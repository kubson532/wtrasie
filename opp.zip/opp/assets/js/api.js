/**
 * Warstwa API — port plików:
 *   - src/cities.ts                  (loadCities, isOnline, BackendError)
 *   - src/components/util/fetchFunctions.ts (getFromAPI, getFromCloudAPI)
 *   - src/components/hooks/useEventQuery.ts (klient SSE z ponawianiem)
 *
 * Wszystkie strumienie (mapFeatures, stops, trips, positions) działają na
 * Server-Sent Events — dokładnie tak samo jak w oryginale.
 */

import { API_BASE, CLOUD_BASE, REQUEST_TIMEOUT, CONNECTIVITY_TIMEOUT, CONNECTIVITY_CHECK_URL, DEFAULT_TIMEZONE } from './config.js';

/** Rodzaj błędu backendu (odpowiednik BackendErrorKind). */
export class BackendError extends Error {
    constructor(kind) {
        super(kind);
        this.name = 'BackendError';
        this.kind = kind;
    }
}

/** Lista miast (odpowiednik cityList / cities z cities.ts). */
export const cities = {};
export const cityList = [];

const timedFetch = (url, timeout, init) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);

    return fetch(url, { ...init, signal: controller.signal, cache: 'no-store' }).finally(() =>
        clearTimeout(timer),
    );
};

/**
 * Odróżnia martwy backend od braku internetu — sonda jest nieprzezroczysta
 * (no-cors), więc mówi tylko, czy cokolwiek w ogóle wyszło z urządzenia.
 */
export const isOnline = async () => {
    if (navigator.onLine === false) return false;

    try {
        await timedFetch(CONNECTIVITY_CHECK_URL, CONNECTIVITY_TIMEOUT, { mode: 'no-cors' });
        return true;
    } catch {
        return false;
    }
};

/** Pobiera listę miast z /api6 (odpowiednik loadCities). */
export const loadCities = async () => {
    let res;

    try {
        res = await timedFetch(`${API_BASE}/api6`, REQUEST_TIMEOUT);
    } catch {
        throw new BackendError((await isOnline()) ? 'server' : 'network');
    }

    let data;

    try {
        data = await res.json();
    } catch {
        throw new BackendError('server');
    }

    if (data.error || !res.ok || !data.cities?.length) throw new BackendError('server');

    for (const id of Object.keys(cities)) delete cities[id];
    cityList.length = 0;

    for (const c of data.cities) {
        const city = {
            id: c.id,
            name: c.name,
            description: c.description,
            location: c.location,
            timezone: c.timezone || DEFAULT_TIMEZONE,
            zoom: c.zoom,
            agencies: c.agencies,
            virtual: c.virtual,
            showNewTag: c.showNewTag,
        };

        cities[c.id] = city;
        cityList.push(city);
    }

    // Globalna lista miast dla narzędzi (getCityTimezone)
    window.cities = cities;
};

/** GET na API miasta (odpowiednik getFromAPI). */
export const getFromAPI = async (city, endpoint, query = {}, signal) => {
    const url = new URL(`${API_BASE}/api6/${city}/${endpoint}`);
    Object.entries(query).forEach(([key, value]) => {
        if (value) url.searchParams.append(key, String(value));
    });

    return fetch(url.toString(), { signal, credentials: 'include' }).then((res) => res.json());
};

/** GET na API chmury, np. blog (odpowiednik getFromCloudAPI). */
export const getFromCloudAPI = async (endpoint, query = {}, signal) => {
    const url = new URL(`${CLOUD_BASE}/${endpoint}`);
    Object.entries(query).forEach(([key, value]) => {
        if (value) url.searchParams.append(key, String(value));
    });

    return fetch(url.toString(), { signal }).then((res) => res.json());
};

/**
 * Klient strumienia SSE z obsługą ponawiania i widoczności karty —
 * odpowiednik hooka useEventQuery (bez Reacta).
 *
 * connect() zwraca obiekt z metodą close(); zdarzenia przekazywane są
 * do callbacków onInitial(data) i onMessage(data), a zmiany stanu ładowania
 * do onState({ loading, error }).
 */
export function createEventQuery({ city, endpoint, enabled = true, onInitial, onMessage, onState }) {
    let es = null;
    let retryCount = 0;
    let hideTimeout = null;
    let hiddenAt = 0;
    let closed = false;

    const HIDE_GRACE_MS = 45000;
    const STALE_AFTER_MS = 10000;

    const setLoading = (loading, error) => onState?.({ loading, error });

    const parseErrorData = (raw) => {
        try {
            const parsed = JSON.parse(raw);
            return typeof parsed === 'string' ? parsed : JSON.stringify(parsed);
        } catch {
            return raw;
        }
    };

    const connect = () => {
        if (closed || !enabled || !city || document.hidden) {
            if (es) {
                es.close();
                es = null;
            }
            if (!enabled || !city) setLoading(false, undefined);
            return;
        }

        if (es) es.close();

        setLoading(true, undefined);

        const url = `${API_BASE}/api6/${city}/${endpoint}`;
        es = new EventSource(url);

        let terminalError = false;

        es.addEventListener('open', () => {
            retryCount = 0;
        });

        es.addEventListener('initial', (event) => {
            try {
                onInitial?.(JSON.parse(event.data));
                setLoading(false, undefined);
            } catch {
                terminalError = true;
                setLoading(false, 'PARSE_ERROR');
                es.close();
            }
        });

        es.addEventListener('message', (event) => {
            try {
                onMessage?.(JSON.parse(event.data));
                setLoading(false, undefined);
            } catch {
                terminalError = true;
                setLoading(false, 'PARSE_ERROR');
                es.close();
            }
        });

        es.addEventListener('errorCode', (event) => {
            terminalError = true;
            setLoading(false, parseErrorData(event.data));
            es.close();
        });

        es.addEventListener('error', () => {
            if (terminalError) {
                es.close();
                return;
            }

            if (retryCount < 5) {
                retryCount++;
            } else {
                setLoading(false, 'NETWORK_ERROR');
            }
            es.close();
            if (es === null) return;
            es = null;

            if (!document.hidden && enabled && retryCount < 5 && !closed) {
                setTimeout(() => {
                    // Ponów tylko, gdy nic innego (np. obsługa widoczności) nie połączyło się w międzyczasie
                    if (!document.hidden && enabled && !es && !closed) {
                        connect();
                    }
                }, 2000);
            }
        });
    };

    const handleVisibilityChange = () => {
        if (document.hidden) {
            hiddenAt = Date.now();
            if (hideTimeout) clearTimeout(hideTimeout);
            hideTimeout = setTimeout(() => {
                if (document.hidden && es) {
                    es.close();
                    es = null;
                }
            }, HIDE_GRACE_MS);
        } else {
            if (hideTimeout) {
                clearTimeout(hideTimeout);
                hideTimeout = null;
            }
            if (!es || es.readyState !== EventSource.OPEN || Date.now() - hiddenAt > STALE_AFTER_MS) {
                retryCount = 0;
                connect();
            }
        }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    connect();

    return {
        // destroy() i close() są równoważne — obie nazwy używane w widokach
        close() {
            closed = true;
            document.removeEventListener('visibilitychange', handleVisibilityChange);
            if (hideTimeout) clearTimeout(hideTimeout);
            if (es) {
                es.close();
                es = null;
            }
        },
        destroy() {
            closed = true;
            document.removeEventListener('visibilitychange', handleVisibilityChange);
            if (hideTimeout) clearTimeout(hideTimeout);
            if (es) {
                es.close();
                es = null;
            }
        },
    };
}
