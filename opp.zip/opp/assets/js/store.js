/**
 * Magazyny stanu — port wszystkich hooków zustand z oryginału na
 * proste obiekty zapisywane w localStorage. Klucze localStorage są
 * identyczne jak w oryginale (city, themeColor, brigade, fleet,
 * mapStyle, mapStyleBasicVariant, userLocation, moveToLastLocation,
 * useLocationSorting, useStopCodeAsIcon, disableLiquidGlass,
 * starredCities, lastSeenAlert, {city}.favs).
 */

import { generateDarkScheme } from './util.js';
import { segments } from './router.js';

const read = (key, fallback) => {
    try {
        const value = localStorage.getItem(key);
        return value === null ? fallback : JSON.parse(value);
    } catch {
        return fallback;
    }
};

const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));

/* ----------------------------- Motyw ----------------------------- */

export const themeStore = {
    color: localStorage.getItem('themeColor') || '#276b2b',

    setColor(color) {
        localStorage.setItem('themeColor', color);
        document.querySelector('meta[name=theme-color]')?.setAttribute('content', color);
        themeStore.color = color;
        applyTheme();
    },
};

/** Aktualny schemat MD3 (odpowiednik useMemo w App.tsx). */
export function currentTheme() {
    return generateDarkScheme(themeStore.color);
}

/** Ustawia zmienne CSS motywu na elemencie :root (odpowiednik ThemeProvider). */
export function applyTheme() {
    const theme = currentTheme();
    const root = document.documentElement.style;

    root.setProperty('--primary', theme.primary);
    root.setProperty('--on-primary', theme.onPrimary);
    root.setProperty('--primary-container', theme.primaryContainer);
    root.setProperty('--on-primary-container', theme.onPrimaryContainer);
    root.setProperty('--secondary', theme.secondary);
    root.setProperty('--on-secondary', theme.onSecondary);
    root.setProperty('--secondary-container', theme.secondaryContainer);
    root.setProperty('--on-secondary-container', theme.onSecondaryContainer);
    root.setProperty('--tertiary', theme.tertiary);
    root.setProperty('--on-tertiary', theme.onTertiary);
    root.setProperty('--tertiary-container', theme.tertiaryContainer);
    root.setProperty('--on-tertiary-container', theme.onTertiaryContainer);
    root.setProperty('--error', theme.error);
    root.setProperty('--on-error', theme.onError);
    root.setProperty('--error-container', theme.errorContainer);
    root.setProperty('--on-error-container', theme.onErrorContainer);
    root.setProperty('--background', theme.background);
    root.setProperty('--on-background', theme.onBackground);
    root.setProperty('--surface', theme.surface);
    root.setProperty('--on-surface', theme.onSurface);
    root.setProperty('--surface-variant', theme.surfaceVariant);
    root.setProperty('--on-surface-variant', theme.onSurfaceVariant);
    root.setProperty('--outline', theme.outline);
    root.setProperty('--outline-variant', theme.outlineVariant);
    root.setProperty('--inverse-surface', theme.inverseSurface);
    root.setProperty('--inverse-on-surface', theme.inverseOnSurface);
    root.setProperty('--inverse-primary', theme.inversePrimary);

    /* Warianty pomocnicze używane w arkuszu stylów (korespondują z MUI):
     * palette.primary.main = md3.onPrimary, primary.contrastText = md3.primary,
     * background.paper = md3.inverseOnSurface, text.primary = md3.onSurface,
     * action.active = md3.onBackground. */
    root.setProperty('--text-secondary', theme.onSurfaceVariant);
    root.setProperty('--paper', theme.inverseOnSurface);
    root.setProperty('--divider', theme.outlineVariant);
}

/* --------------------------- Styl mapy --------------------------- */

export const mapStyleStore = {
    selectedStyle: localStorage.getItem('mapStyle') || 'basic',
    basicAppearance: localStorage.getItem('mapStyleBasicVariant') || 'light',

    selectStyle(style) {
        localStorage.setItem('mapStyle', style);
        mapStyleStore.selectedStyle = style;
    },

    setBasicAppearance(appearance) {
        localStorage.setItem('mapStyleBasicVariant', appearance);
        mapStyleStore.basicAppearance = appearance;
    },
};

/* --------------------------- Ulubione ---------------------------- */

const favKey = () => `${segments()[0] || 'cities'}.favs`;

export const favStore = {
    get favorites() {
        return read(favKey(), []);
    },

    addFavoriteDirection(id, location, isStation, direction) {
        const favorites = favStore.favorites;
        const favorite = favorites.find((fav) => fav.id === id);

        if (favorite) {
            favorite.directions.push(direction);
        } else {
            favorites.push({ id, location, directions: [direction], isStation });
        }

        write(favKey(), favorites);
    },

    removeFavoriteDirection(id, directionIndex) {
        const favorites = favStore.favorites;
        const favorite = favorites.find((fav) => fav.id === id);
        if (!favorite) return;

        favorite.directions = favorite.directions.filter((_, index) => index !== directionIndex);
        write(favKey(), favorites);
    },

    removeFavoriteStop(id) {
        write(
            favKey(),
            favStore.favorites.filter((fav) => fav.id !== id),
        );
    },

    toggleFavoriteStop(id, location, isStation) {
        const favorites = favStore.favorites;
        const exists = favorites.some((fav) => fav.id === id);

        const next = exists
            ? favorites.filter((fav) => fav.id !== id)
            : [...favorites, { id, location, directions: [], isStation }];

        write(favKey(), next);
    },

    reset() {
        localStorage.removeItem(favKey());
    },
};

/* --------------------------- Filtrowanie -------------------------- */

export const filterStore = {
    search: '',
    routes: [],
    tempRoutes: [],
    models: [],
    tempModels: [],
    initialPosition: undefined,

    setSearch(search) {
        filterStore.search = search;
    },

    addRoute(route) {
        filterStore.tempRoutes = [...filterStore.tempRoutes, route];
    },

    removeRoute(route) {
        filterStore.tempRoutes = filterStore.tempRoutes.filter(
            (r) => r[0] !== route[0],
        );
    },

    addModel(model) {
        filterStore.tempModels = [...filterStore.tempModels, model];
    },

    removeModel(model) {
        filterStore.tempModels = filterStore.tempModels.filter((m) => m !== model);
    },

    addMany(searchResults) {
        filterStore.tempRoutes = [
            ...filterStore.tempRoutes,
            ...searchResults.filter((r) => typeof r !== 'string'),
        ];
        filterStore.tempModels = [
            ...filterStore.tempModels,
            ...searchResults.filter((r) => typeof r === 'string'),
        ];
    },

    setInitialPosition(position) {
        filterStore.initialPosition = position;
    },

    useTemp() {
        filterStore.tempRoutes = filterStore.routes;
        filterStore.tempModels = filterStore.models;
    },

    applyChanges() {
        filterStore.routes = filterStore.tempRoutes;
        filterStore.models = filterStore.tempModels;
        filterStore.tempRoutes = [];
        filterStore.tempModels = [];
        filterStore.initialPosition = undefined;
    },

    reset() {
        filterStore.search = '';
        filterStore.routes = [];
        filterStore.tempRoutes = [];
        filterStore.models = [];
        filterStore.tempModels = [];
        filterStore.initialPosition = undefined;
    },
};

/* ------------------------- Stan przystanku ------------------------ */

export const stopStore = {
    limit: 20,
    time: undefined,
    destination: undefined,
    destinationName: undefined,

    expandLimit(by) {
        stopStore.limit += by;
    },

    setTime(time) {
        stopStore.time = time;
    },

    setDestination(destination, destinationName) {
        stopStore.destination = destination;
        stopStore.destinationName = destinationName;
    },

    reset() {
        stopStore.limit = 20;
        stopStore.time = undefined;
        stopStore.destination = undefined;
        stopStore.destinationName = undefined;
    },
};

/* --------------------------- Pojazd/kurs -------------------------- */

export const vehicleStore = {
    fresh: undefined,
    vehicle: undefined,
    trip: undefined,
    stops: undefined,
    sequence: undefined,
    lastPing: undefined,
    itinerary: undefined,
    alerts: [],
    streamError: undefined,
    streamLoading: undefined,

    setFresh(fresh) {
        vehicleStore.fresh = fresh;
    },

    setVehicle(vehicle) {
        vehicleStore.vehicle = vehicle;
    },

    setTrip(trip) {
        vehicleStore.trip = trip;
    },

    setStops(stops) {
        vehicleStore.stops = stops;
    },

    setSequence(sequence) {
        vehicleStore.sequence = sequence;
    },

    setLastPing(lastPing) {
        vehicleStore.lastPing = lastPing;
    },

    setItinerary(itinerary) {
        vehicleStore.itinerary = itinerary;
    },

    setAlerts(alerts) {
        vehicleStore.alerts = alerts;
    },

    setStreamStatus({ error, loading }) {
        vehicleStore.streamError = error;
        vehicleStore.streamLoading = loading;
    },

    reset() {
        Object.assign(vehicleStore, {
            fresh: undefined,
            vehicle: undefined,
            trip: undefined,
            stops: undefined,
            sequence: undefined,
            lastPing: undefined,
            itinerary: undefined,
            alerts: [],
            streamError: undefined,
            streamLoading: undefined,
        });
    },
};

/* ------------------------ Śledzenie pojazdu ----------------------- */

export const followStore = {
    isFollowing: true,

    setIsFollowing(isFollowing) {
        followStore.isFollowing = isFollowing;
    },

    reset() {
        followStore.isFollowing = true;
    },
};

/* ------------------- Kierunek linii (graf linii) ------------------ */

export const directionStore = {
    direction: 0,

    setDirection(direction) {
        directionStore.direction = direction;
    },
};

/* ---------------- Lokalizacja pojazdów na grafie linii ------------ */

export const routePlacementsStore = {
    placements: [],

    setPlacements(placements) {
        routePlacementsStore.placements = placements;
    },
};

/* ------------------------- Lokalizacja ---------------------------- */

export const locationStore = {
    userLocation: undefined,

    setUserLocation(userLocation) {
        locationStore.userLocation = userLocation;
    },
};

/* ---------------------- Ustawienia (flagi) ------------------------ */

/** Flagi czytane tak jak w Markers.tsx i ustawieniach (localStorage). */
export const settings = {
    get brigade() {
        return localStorage.getItem('brigade') === 'true';
    },
    set brigade(value) {
        localStorage.setItem('brigade', JSON.stringify(value));
    },
    get fleet() {
        return localStorage.getItem('fleet') === 'true';
    },
    set fleet(value) {
        localStorage.setItem('fleet', JSON.stringify(value));
    },
    get moveToLastLocation() {
        return localStorage.getItem('moveToLastLocation') === 'true';
    },
    set moveToLastLocation(value) {
        localStorage.setItem('moveToLastLocation', JSON.stringify(value));
    },
    get useLocationSorting() {
        return localStorage.getItem('useLocationSorting') === 'true';
    },
    set useLocationSorting(value) {
        localStorage.setItem('useLocationSorting', JSON.stringify(value));
    },
    get useStopCodeAsIcon() {
        return localStorage.getItem('useStopCodeAsIcon') === 'true';
    },
    set useStopCodeAsIcon(value) {
        localStorage.setItem('useStopCodeAsIcon', JSON.stringify(value));
    },
    get disableLiquidGlass() {
        return localStorage.getItem('disableLiquidGlass') === 'true';
    },
    set disableLiquidGlass(value) {
        localStorage.setItem('disableLiquidGlass', JSON.stringify(value));
        document.body.classList.toggle('disable-liquid-glass', value);
    },
};
