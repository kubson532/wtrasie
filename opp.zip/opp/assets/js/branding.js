/**
 * branding.js — JEDEN PLIK Z COLRAMI, LOGOTYPAMI I USTAWIENIAMI WYGLĄDU.
 * ---------------------------------------------------------------------------
 * Chcesz przemianować aplikację (inna nazwa, inne logo, inne kolory)?
 * Edytuj WYŁĄCZNIE ten plik — reszta kodu czyta stąd wszystkie wartości.
 *
 * Struktura:
 *   APP             — nazwa aplikacji (menu, PWA, dialogi)
 *   LOGO            — jak rysowane jest logo (kolory ścieżek SVG)
 *   VEHICLE_COLORS  — kolory typów pojazdów (autobus/pociąg/tramwaj/…)
 *   PLANNER         — kolory planera: przejścia piesze, logotypy przewoźników,
 *                     paleta awaryjna przy kolizjach kolorów linii, kreskowanie
 *   MAP             — geometria linii trasy: szerokość, przezroczystość
 *                     nadjeżdżających odcinków, wzór kreskowania
 *   THEME_COLORS    — kolory motywu do wyboru w ustawieniach
 */

export const APP = {
    /** Nazwa w menu i nagłówkach (menu boczne ją pokazuje). */
    name: 'Zbiorkom.live',
    /** Krótki opis używany przy instalacji aplikacji (PWA). */
    tagline: 'Odkrywaj komunikację miejską na nowo',
};

/** Kolory ścieżek logo (viewBox 0 0 500 500, patrz icons.js renderLogo). */
export const LOGO = {
    color: 'hsla(0, 0%, 100%, 0.9)',
    /** Rozmiar logo w nagłówku menu. */
    menuSize: 72,
};

/**
 * Kolory typów pojazdów — dokładne wartości z oryginalnego Icon.tsx.
 * 0=tramwaj, 1=metro, 2=pociąg/kolej, 3=autobus, 4=tramwaj wodny/prom,
 * 6=trolejbus(?), 7=?, 11=?, 12=? — numery VehicleType z typings.ts.
 * Zmień tu, jeśli chcesz np. pociągi w innym kolorze niż autobusy.
 */
export const VEHICLE_COLORS = {
    0: '#be0d05', // tramwaj
    1: '#ba0059', // metro
    2: '#415f91', // pociąg
    3: '#2b6c00', // autobus
    4: '#0061a4', // prom/tramwaj wodny
    6: '#88511e', // kolej podmiejska/np. inny typ
    7: '#705289', // kolej wąskotorowa/np. inny typ
    11: '#006c46', // wsiobus (podmiejski)
    12: '#895120', // PKS
};

/** Kolory planera tras (Transitous). */
export const PLANNER = {
    /** Kolor przejścia pieszego (nogi WALK) na mapie i na listach. */
    walkColor: '#9e9e9e',

    /**
     * Kolor MOJEJ trasy — odcinki, które mam przejechać wybranym wariantem,
     * rysowane na mapie NA CZERWONO (zgłoszenie: „trasa którą mam jechać
     * zaznaczaj na czerwono”). Odcinki w kolorach linii zostają w listach
     * (badge'y, kreski przy nogach) — na mapie wyróżniamy całą podróż.
     */
    routeHighlight: '#ff5252',

    /**
     * Kolor ścieżki DOJAZDU pojazdu — od bieżącej pozycji żywego pojazdu
     * do mojego przystanku wsiadania, rysowany półprzezroczysto.
     */
    approachColor: '#ff5252',

    /** Logotypy kategorii przewoźników (plakietki w przełącznikach wykluczeń). */
    carriers: {
        wsiobus: { bg: '#2b6c00', label: 'WSIOBUS', labelColor: '#c0efb5', icon: 'bus' },
        pks: { bg: '#0d47a1', label: 'PKS', labelColor: '#ffd54f', icon: 'bus' },
        trains: { bg: '#1a237e', label: '', labelColor: '#fff', icon: 'train' },
    },

    /**
     * Paleta awaryjna: gdy dwie nogi tej samej podróży mają TEN SAM kolor
     * (np. dwie linie autobusowe bez routeColor w GTFS), kolejna noga dostaje
     * kolor stąd, żeby linie dało się odróżnić na mapie.
     */
    collisionPalette: [
        '#0b57d0', // niebieski
        '#8e24aa', // fioletowy
        '#00897b', // morski
        '#d81b60', // różowy
        '#f4511e', // pomarańczowy
        '#3949ab', // indygo
        '#00838f', // cyjan
        '#6d4c41', // brązowy
    ],

    /** Ile stopni odcienia odsunąć kolor przy kolizji (obrót w HSL). */
    collisionHueShift: 36,
};

/** Geometria i style linii trasy na mapie. */
export const MAP = {
    /** Szerokość linii trasy (px). */
    routeWidth: 4,
    /** Przezroczystość odcinka, na który pojazd jeszcze nie dojechał. */
    upcomingOpacity: 0.45,
    /** Wzór kreskowania wspólnych odcinków dwóch linii (kreska, przerwa). */
    sharedDash: [3, 3],
    /** Przezroczystość wspólnego odcinka kreskowanego. */
    sharedOpacity: 0.9,
    /** Szerokość linii przejścia pieszego. */
    walkWidth: 4,
    /** Wzór linii przejścia pieszego. */
    walkDash: [1.5, 1.5],
    /** Przezroczystość ścieżki DOJAZDU pojazdu (od jego pozycji do mnie). */
    approachOpacity: 0.45,
    /** Maks. odległość (w stopniach, ~550 m) pojazdu od ścieżki dojazdu,
     * przy której pojazd uznajemy za „mój nadjeżdżający”. */
    approachSnapDist: 0.005,
};

/** Kolory motywu do wyboru w Ustawieniach (dokładnie jak w oryginale). */
export const THEME_COLORS = [
    '#ff3c36',
    '#ffd336',
    '#94ff36',
    '#276b2b',
    '#36f9ff',
    '#3662ff',
    '#720546',
    '#ff36c7',
];

/** Domyślny kolor motywu. */
export const DEFAULT_THEME = '#276b2b';
