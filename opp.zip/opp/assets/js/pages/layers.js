/**
 * Warstwy mapy — port sheet/MapStyle:
 *   MapStyleHeader — nagłówek
 *   MapStyleContent — wybór stylu, ciemny motyw, atrybucje
 */

import { el, bottomSheet } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { goBack } from '../router.js';
import { mapStyleStore } from '../store.js';
import { mapStyles, setMapStyle, setMapAppearance } from '../map.js';

export function mountLayersSheet(sheetHost) {
    const header = el('h5', { className: 'layers-header' }, t('Layers.layers'));
    const content = el('div', { className: 'layers-content' });

    const sheet = bottomSheet({
        blocking: true,
        onDismiss: () => goBack(),
    });

    sheet.header.append(header);
    sheet.scroll.append(content);
    sheetHost.append(sheet.root);

    const render = () => {
        content.replaceChildren();

        const selectedDefinition = mapStyles[mapStyleStore.selectedStyle] ?? mapStyles.basic;

        const styleGrid = el(
            'div',
            { className: 'layers-grid' },
            Object.entries(mapStyles).map(([id, definition]) => {
                const isSelected = id === mapStyleStore.selectedStyle;

                return el(
                    'button',
                    {
                        className: 'layers-style' + (isSelected ? ' selected' : ''),
                        onClick: () => {
                            mapStyleStore.selectStyle(id);
                            setMapStyle(id);
                            if (!definition.supportsDark) {
                                mapStyleStore.setBasicAppearance('light');
                                setMapAppearance('light');
                            }
                            render();
                        },
                    },
                    el('img', { src: `/assets/img/${id}.webp`, alt: definition.name }),
                    el('span', {}, definition.name),
                );
            }),
        );

        content.append(styleGrid);

        if (selectedDefinition.supportsDark) {
            const label = el(
                'label',
                { className: 'switch-row' },
                el('span', {}, t('Layers.darkMode')),
            );

            const checkbox = el('input', {
                type: 'checkbox',
                checked: mapStyleStore.basicAppearance === 'dark',
            });
            checkbox.addEventListener('change', () => {
                const appearance = checkbox.checked ? 'dark' : 'light';
                mapStyleStore.setBasicAppearance(appearance);
                setMapAppearance(appearance);
            });

            label.prepend(checkbox);
            content.append(label);
        }

        content.append(
            el(
                'div',
                { className: 'layers-attribution' },
                selectedDefinition.attribution.map((html, index) =>
                    el('div', { html, key: index }),
                ),
            ),
        );
    };

    render();

    return {
        sheet,
        destroy() {
            sheet.close();
        },
    };
}
