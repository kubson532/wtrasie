/**
 * Brygady — port komponentów:
 *   pages/Brigades/Select.tsx     — wybór brygady dla linii (+ DayPicker)
 *   pages/Brigades/Brigade.tsx    — rozkład brygady (Schedule)
 *   pages/Brigades/BrigadeTrip.tsx — pojedynczy kurs brygady
 *   hooks/useQueryBrigades.ts     — zapytania i lista dni
 */

import { el, dialog, alert, loading } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, goBack, query as queryParams, segments, replaceSearch } from '../router.js';
import { getFromAPI } from '../api.js';
import { getDaysSince2020, getCityTimezone, getTime, msToTime, parseVehicleId, share, generateDarkScheme } from '../util.js';
import { routeTag, routeChip } from './widgets.js';
import { i18n } from '../i18n.js';

/** Lista 7 dni serwisowych (port getBrigadeDays). */
export function getBrigadeDays(timezone) {
    const localHour = +new Intl.DateTimeFormat('en-US', {
        timeZone: timezone,
        hour: 'numeric',
        hourCycle: 'h23',
    })
        .formatToParts(Date.now())
        .find((part) => part.type === 'hour').value;

    const includeYesterday = localHour < 4 ? 1 : 0;
    const todayIndex = getDaysSince2020(Date.now(), timezone);

    return Array.from({ length: 7 }, (_, index) => {
        const dayIndex = todayIndex + index - includeYesterday;
        const timestamp = (dayIndex + 18262) * 86400000 + 43200000;

        return {
            valueDate: dayIndex.toString(),
            displayDate: new Intl.DateTimeFormat(i18n.language, {
                timeZone: timezone,
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
            }).format(timestamp),
            dayOfWeek: new Intl.DateTimeFormat(i18n.language, {
                timeZone: timezone,
                weekday: 'long',
            }).format(timestamp),
        };
    });
}

/** Selector dni (port ui/DayPicker.tsx). */
function dayPicker(value, setValue, days) {
    return el(
        'div',
        { className: 'day-picker' },
        days.map((day) =>
            el(
                'button',
                {
                    className: 'day-picker-day' + (day.valueDate === value ? ' selected' : ''),
                    onClick: () => setValue(day.valueDate),
                },
                el('span', { className: 'day-picker-weekday' }, day.dayOfWeek),
                el('span', { className: 'day-picker-date' }, day.displayDate),
            ),
        ),
    );
}

/** Aktualizacja parametru ?date= w URL (odpowiednik useSearchState). */
function setUrlParam(key, value) {
    const params = queryParams();
    if (value) params.set(key, value);
    else params.delete(key);
    replaceSearch(params);
}

/** Dialog wyboru brygady. Zwraca destroy(). */
export async function mountBrigadesDialog(city, routeId) {
    const d = dialog({ fullscreen: window.innerWidth <= 900, closeable: false });

    let date = queryParams().get('date') || getBrigadeDays(getCityTimezone(city))[0].valueDate;

    const header = el(
        'div',
        { className: 'page-header' },
        el('button', { className: 'icon-button', onClick: () => goBack({ ignoreState: true }) }, renderIcon('ArrowBack')),
        el('h5', {}, t('Brigades.selectBrigade').replace(/<[^>]*>/g, '')),
    );

    const host = el('div', { className: 'brigades-host' });
    d.content.append(header, host);
    document.body.append(d);

    let routeData = null;

    const render = async () => {
        host.replaceChildren(loading({ height: 300 }));

        try {
            if (!routeData) {
                routeData = await getFromAPI(city, `routes/${routeId}`, {});
            }

            const brigades = await getFromAPI(city, `brigades/${routeId}/${date}`, {});

            host.replaceChildren();

            // Tytuł z tagiem linii
            host.append(
                el(
                    'h5',
                    { className: 'brigades-title' },
                    t('Brigades.selectBrigade').replace(/<[^>]*>/g, ''),
                    ' ',
                    routeTag(routeData.route),
                ),
            );

            // Wybór dnia
            host.append(
                dayPicker(date, (value) => {
                    date = value;
                    setUrlParam('date', value);
                    render();
                }, getBrigadeDays(getCityTimezone(city))),
            );

            // Lista brygad
            if (!brigades?.length) {
                host.append(alert({ icon: 'Dangerous', title: t('Brigades.noDuty') }));
                return;
            }

            host.append(
                el(
                    'div',
                    { className: 'brigade-list' },
                    brigades.map((brigade) =>
                        el(
                            'button',
                            {
                                className: 'brigade-row',
                                onClick: () => {
                                    const suffix =
                                        city === segmentsCity() ? '' : `&city=${encodeURIComponent(city)}`;
                                    navigate(
                                        `${brigade[0]}?date=${date}${suffix}`,
                                        { state: -2 },
                                    );
                                },
                            },
                            el('span', { className: 'brigade-number', style: { backgroundColor: routeData.route[6] } }, brigade[0]),
                            el(
                                'span',
                                { className: 'brigade-info' },
                                [
                                    t('Brigades.trips', { tripsLength: brigade[1] }),
                                    brigade[2]
                                        ?.map(([start, end]) => `${getTime(start)} – ${getTime(end)}`)
                                        .join(', '),
                                ]
                                    .filter(Boolean)
                                    .join(' · '),
                            ),
                        ),
                    ),
                ),
            );
        } catch {
            host.replaceChildren(alert({ title: t('Shared.loadError') }));
        }
    };

    function segmentsCity() {
        return segments()[0];
    }

    await render();

    return {
        destroy() {
            d.remove();
        },
    };
}

/** Rozkład brygady (port Schedule.tsx). Zwraca destroy(). */
export async function mountBrigadeSchedule(city, routeId, brigade) {
    const d = dialog({ fullscreen: window.innerWidth <= 900, closeable: false });

    let date = queryParams().get('date') || getBrigadeDays(getCityTimezone(city))[0].valueDate;

    const header = el(
        'div',
        { className: 'page-header space-between' },
        el(
            'div',
            { className: 'page-header-left' },
            el('button', { className: 'icon-button', onClick: () => goBack({ ignoreState: true }) }, renderIcon('ArrowBack')),
            el('h5', {}, t('Brigades.brigadeSchedule').replace(/<[^>]*>/g, '')),
        ),
        el('button', { className: 'icon-button', onClick: () => share(window.location.href) }, renderIcon('Share')),
    );

    const host = el('div', { className: 'brigades-host' });
    d.content.append(header, host);
    document.body.append(d);

    let filteredRoutes = [];

    const render = async () => {
        host.replaceChildren(loading({ height: 300 }));

        try {
            const [routeInfo, trips] = await Promise.all([
                getFromAPI(city, `routes/${routeId}`, {}),
                getFromAPI(city, `brigades/${routeId}/${brigade}/${date}`, {}),
            ]);

            host.replaceChildren();

            host.append(
                el(
                    'h5',
                    { className: 'brigades-title' },
                    t('Brigades.brigadeSchedule').replace(/<[^>]*>/g, ''),
                    ' ',
                    routeTag(routeInfo.route, undefined, brigade),
                ),
            );

            host.append(
                dayPicker(date, (value) => {
                    date = value;
                    setUrlParam('date', value);
                    render();
                }, getBrigadeDays(getCityTimezone(city))),
            );

            // Linie w brygadzie (brygady wieloliniowe)
            const routeKeys = [];
            const routes = [];
            for (const trip of trips || []) {
                const r = trip[2];
                if (!routeKeys.includes(r[0])) {
                    routeKeys.push(r[0]);
                    routes.push(r);
                }
            }

            if (routeKeys.length > 1) {
                host.append(
                    el(
                        'div',
                        { className: 'brigade-routes' },
                        routes.map((route) =>
                            routeChip(route, () => {
                                filteredRoutes = filteredRoutes.includes(route[0])
                                    ? filteredRoutes.filter((r) => r !== route[0])
                                    : [...filteredRoutes, route[0]];
                                renderTrips(trips, routes, routeKeys);
                            }, {
                                opacity: (filteredRoutes.length ? filteredRoutes : routeKeys).includes(route[0]) ? 1 : 0.5,
                            }),
                        ),
                    ),
                    el('p', { className: 'multiline-alert' }, t('Brigades.multilineAlert')),
                );
            }

            renderTrips(trips, routes, routeKeys);
        } catch {
            host.replaceChildren(alert({ title: t('Shared.loadError') }));
        }
    };

    function renderTrips(trips, routes, routeKeys) {
        host.querySelector('.brigade-trips')?.remove();

        const filteredTrips = (trips || []).filter(
            (trip) => !filteredRoutes.length || filteredRoutes.includes(trip[2][0]),
        );

        // Znajdź aktualny kurs
        let currentTripIndex = -1;
        if (filteredTrips.length) {
            currentTripIndex = filteredTrips.findIndex(
                (trip) =>
                    !!trip[8] &&
                    !!trip[7] &&
                    trip[8][1] > Date.now() &&
                    trip[7][1] <= Date.now() + 2 * 60 * 60 * 1000,
            );
        }

        const list = el('div', { className: 'brigade-trips' });

        filteredTrips.forEach((trip, index) => {
            list.append(brigadeTripRow(trip, index === currentTripIndex, routeKeys.length > 1));
        });

        if (!filteredTrips.length) {
            list.append(alert({ icon: 'Dangerous', title: t('Brigades.noDuty') }));
        }

        // Przewinięcie do aktualnego kursu
        if (currentTripIndex > 0) {
            requestAnimationFrame(() => {
                list.children[currentTripIndex]?.scrollIntoView({ block: 'center' });
            });
        }

        host.append(list);
    }

    await render();

    return {
        destroy() {
            d.remove();
        },
    };
}

/** Wiersz kursu brygady (port BrigadeTrip.tsx). */
function brigadeTripRow(trip, isActive, showRoute) {
    const firstStop = trip[7];
    const lastStop = trip[8];
    const distance = trip[9];
    const vehicle = trip.vehicle;

    const background = isActive || vehicle
        ? generateDarkScheme(trip[2][6]).secondaryContainer
        : undefined;

    const row = el(
        'button',
        {
            className: 'brigade-trip' + (isActive ? ' active' : ''),
            style: background ? { backgroundColor: background } : {},
            onClick: () => {
                const tripCity = trip[1] || segments()[0];
                navigate(
                    (vehicle
                        ? `/${tripCity}/vehicle/${encodeURIComponent(vehicle)}`
                        : `/${tripCity}/trip/${encodeURIComponent(trip[0])}`),
                    { state: -3 },
                );
            },
        },
        el('span', { className: 'vehicleStopIconLine tripLine', style: { backgroundColor: trip[2][6] } }),
        el(
            'span',
            { className: 'tripRow' },
            el('span', { className: 'tripTime' }, firstStop && getTime(firstStop[1])),
            el('span', { className: 'vehicleStopIcon', style: { border: `3px solid ${trip[2][6]}` } }),
            el('span', { className: 'tripHeadsign' }, showRoute && routeTag(trip[2]), firstStop?.[0]),
        ),
        el(
            'div',
            { className: 'tripInfo' },
            el(
                'span',
                {},
                [
                    firstStop && lastStop && t('Brigades.travelTime', { time: msToTime(lastStop[1] - firstStop[1]) }),
                    distance !== undefined &&
                        `${distance.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} m`,
                ]
                    .filter(Boolean)
                    .join(' · '),
            ),
            el('span', {}, vehicleLabel(vehicle)),
        ),
        el(
            'span',
            { className: 'tripRow' },
            el('span', { className: 'tripTime' }, lastStop && getTime(lastStop[1])),
            el('span', { className: 'vehicleStopIcon', style: { border: `3px solid ${trip[2][6]}` } }),
            el('span', { className: 'tripHeadsign' }, lastStop?.[0]),
        ),
    );

    return row;
}

function vehicleLabel(vehicle) {
    if (!vehicle) return t('Brigades.clickForTrip');
    const { vehicleNumber } = parseVehicleId(vehicle);
    if (vehicleNumber.startsWith('_')) return t('Brigades.clickForTrip');
    return t('Brigades.operatedBy', { vehicle: vehicleNumber });
}
