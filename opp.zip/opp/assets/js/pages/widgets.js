/**
 * Wspólne widgety widoków — porty komponentów współdzielonych:
 *   ui/RouteChip.tsx, ui/StopTag.tsx, map/RouteTag.tsx,
 *   sheet/Trip/TripHeadsign.tsx, sheet/Trip/TripDelay.tsx
 */

import { renderIcon, vehicleTypeIcon, defaultColors } from '../icons.js';
import { el } from '../ui.js';
import { t } from '../i18n.js';
import { getDelay } from '../util.js';
import { settings } from '../store.js';

/** Chip linii z kolorem i ikoną (odpowiednik ui/RouteChip.tsx). */
export function routeChip(route, onClick, style) {
    const chip = el(
        'div',
        { className: 'routeChip', style: { backgroundColor: route[6], ...style }, onClick },
        (() => {
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('viewBox', '0 0 24 24');
            svg.setAttribute('width', '1.1em');
            svg.setAttribute('height', '1.1em');
            svg.setAttribute('fill', 'currentColor');
            svg.innerHTML = vehicleTypeIcon(route[5], route[1], route[4]);
            return svg;
        })(),
        route[2],
    );
    return chip;
}

/** Tag linii w nagłówku arkusza (odpowiednik map/RouteTag.tsx). */
export function routeTag(route, shortName, brigade) {
    const tag = el(
        'div',
        { className: 'vehicle', style: { zIndex: 5, backgroundColor: route[6] } },
        (() => {
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('viewBox', '0 0 24 24');
            svg.setAttribute('width', '1.2em');
            svg.setAttribute('height', '1.2em');
            svg.setAttribute('fill', 'currentColor');
            svg.style.marginRight = '2px';
            svg.innerHTML = vehicleTypeIcon(route[5], route[1], route[4]);
            return svg;
        })(),
        el('b', {}, route[2] + (shortName ? ' ' + shortName : '')),
        brigade && el('span', {}, `/${brigade}`),
    );
    return tag;
}

/** Nagłówek pojazdu: tag linii + kierunek (odpowiednik TripHeadsign.tsx). */
export function vehicleHeadsign(route, { shortName, headsign, brigade } = {}) {
    return el(
        'div',
        { className: 'vehicleHeader' },
        routeTag(route, shortName, settings.brigade ? brigade : undefined),
        headsign || '',
    );
}

/** Tag przystanku z ikoną (odpowiednik ui/StopTag.tsx). */
export function stopTag(stop, fontSize = 16) {
    const type = stop[5][0];

    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.setAttribute('viewBox', '0 0 24 24');
    icon.setAttribute('width', '1em');
    icon.setAttribute('height', '1em');
    icon.setAttribute('fill', 'currentColor');
    icon.innerHTML = vehicleTypeIcon(type);

    const box = el(
        'span',
        {
            className: 'stop-tag-icon',
            style: {
                backgroundColor: defaultColors[type] ?? defaultColors[3],
                width: `${fontSize * 1.8}px`,
                height: `${fontSize * 1.8}px`,
            },
        },
        icon,
    );

    return el(
        'div',
        { className: 'stopTag' },
        box,
        el('span', { className: 'stopTag-name' }, `${stop[2]} ${stop[3] || ''}`.trim()),
    );
}

/** Znacznik opóźnienia (odpowiednik sheet/Trip/TripDelay.tsx). */
export function vehicleDelay(delay, status, showGPS) {
    const [delayClass, delayTime] = getDelay(delay);

    const isLiveStatus = status !== 3 && status !== 0; // Cancelled=3, Scheduled=0
    const visualClass = isLiveStatus ? delayClass : 'unknown';

    const node = el('span', { className: `delay delay-${visualClass}` });

    if (showGPS === true && status !== 0) node.append(renderIcon('GpsFixed', { size: 14 }));
    if (status === 0) node.append(renderIcon('GpsOff', { size: 14 }));

    if (status === 3) {
        node.append(t('Vehicle.cancelled'));
    } else if (status === 0) {
        node.append(t('Vehicle.scheduled'));
    } else if (delayTime) {
        node.append(t(delay > 0 ? 'Vehicle.delayed' : 'Vehicle.early', { time: delayTime }));
    } else {
        node.append(t('Vehicle.onTime'));
    }

    return node;
}

/** Przyciski nagłówka arkusza (odpowiednik Box z IconButton z TripHeader/StopHeader). */
export function sheetHeaderButtons(buttons) {
    return el(
        'div',
        { className: 'sheet-header-buttons' },
        buttons.map(({ icon, onClick, id, title, active }) =>
            el(
                'button',
                {
                    className: 'icon-button' + (active ? ' active' : ''),
                    id,
                    title,
                    onClick,
                    'aria-label': title,
                },
                renderIcon(icon, { size: 22 }),
            ),
        ),
    );
}

/** Tygodniowe "sekundy/minuty" odliczanie (odpowiednik useTime). */
export function useCountdown(time, useSeconds = false, onChange) {
    let value;
    const compute = () => {
        const diff = time - Date.now();
        return useSeconds ? Math.round(diff / 1000) : Math.round(diff / 60000);
    };

    value = compute();
    const interval = setInterval(() => {
        const next = compute();
        if (next !== value) {
            value = next;
            onChange?.(value);
        }
    }, useSeconds ? 500 : 7500);

    return {
        get value() {
            return value;
        },
        stop() {
            clearInterval(interval);
        },
    };
}

/** Lista wyjść stacji jako elementy menu (pomocnicze). */
export function platformLabel(key, value) {
    return t(key, { value });
}
