/**
 * Widok przystanku — port komponentów:
 *   pages/Stop.tsx          — markery pojazdów odjeżdżających, wyjścia stacji
 *   sheet/Stop/StopHeader   — tag przystanku, gwiazdka, zegar, zamknięcie
 *   sheet/Stop/StopContent  — lista odjazdów (strumień SSE + ładowanie kolejnych)
 *   sheet/Stop/StopDeparture — pojedynczy odjazd
 */

import { el, alert, loading, bottomSheet } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, goBack, pathname, search } from '../router.js';
import { createEventQuery, getFromAPI } from '../api.js';
import { stopStore, favStore, settings } from '../store.js';
import { getTime, buildCitySuffix } from '../util.js';
import { stopTag, vehicleHeadsign, vehicleDelay, sheetHeaderButtons, useCountdown } from './widgets.js';
import { getMap, updateVehicleMarkers, updateStopMarkers, updateStopExits, clearVehicleMarkers, removeStopExits } from '../map.js';

/** Strumień odjazdów przystanku (port useQueryStopDepartures). */
function createStopDeparturesStream(city, stop, callbacks) {
    let stream = null;

    const connect = () => {
        stream?.close();

        const query = new URLSearchParams();
        if (stopStore.time) query.set('time', stopStore.time.toString());
        query.set('limit', String(stopStore.limit + 1));
        if (stopStore.destination) query.set('destinations', stopStore.destination);

        let stopTuple = null;

        stream = createEventQuery({
            city,
            endpoint: `stops/${encodeURIComponent(stop)}/stream?${query.toString()}`,
            onInitial: (data) => {
                stopTuple = data;
                push();
            },
            onMessage: (data) => {
                rawDepartures = data;
                push();
            },
            onState: ({ loading, error }) => callbacks.onState?.({ loading, error }),
        });

        let rawDepartures = null;

        function push() {
            if (!stopTuple || !rawDepartures) return;

            const hasMore = rawDepartures.length > stopStore.limit;
            const departures = hasMore ? rawDepartures.slice(0, stopStore.limit) : rawDepartures;

            callbacks.onData?.([stopTuple, departures, hasMore]);
        }
    };

    connect();

    return {
        reconnect: connect,
        destroy() {
            stream?.close();
        },
    };
}

/**
 * Montuje arkusz przystanku (nagłówek + odjazdy).
 * Zwraca obiekt z metodą destroy().
 */
export function mountStopSheet(city, stopId, sheetHost) {
    let data = null;
    let hasFetched = false;
    let isLoading = true;
    let loadError = undefined;
    const countdownTimers = []; // liczniki wierszy — czyszczone w destroy()

    const header = el('div', { className: 'stop-header' });
    const content = el('div', { className: 'stop-content' });

    const sheet = bottomSheet({
        blocking: false,
        onDismiss: () => goBack(),
    });

    sheet.header.append(header);
    sheet.scroll.append(content);
    sheetHost.append(sheet.root);

    const renderHeader = () => {
        header.replaceChildren();

        if (!data) {
            header.append(
                el('div', { style: { display: 'flex', gap: '8px' } },
                    el('div', { className: 'skeleton', style: { width: '32px', height: '32px', borderRadius: '4px' } }),
                    el('div', { className: 'skeleton', style: { width: '160px', height: '32px' } }),
                ),
            );
            return;
        }

        const stopData = data[0];
        const isFavorite = favStore.favorites.some((fav) => fav.id === stopId);

        header.append(
            el('div', { className: 'stop-header-left' }, stopTag(stopData)),
            sheetHeaderButtons([
                {
                    icon: isFavorite ? 'Star' : 'StarBorder',
                    title: t('Vehicle.favoriteStops'),
                    onClick: () => {
                        favStore.toggleFavoriteStop(stopData[0], stopData[4], stopData[1] === 'pkp');
                        renderHeader();
                    },
                },
                {
                    icon: 'AccessTime',
                    title: t('Time.enterTime'),
                    onClick: () => navigate(pathname() + '/time' + search()),
                },
                { icon: 'Close', title: 'Zamknij', onClick: () => goBack() },
            ]),
        );
    };

    const renderContent = () => {
        content.replaceChildren();

        if (!data && loadError) {
            content.append(
                alert({ title: t('Shared.loadError'), description: String(loadError) }),
            );
            return;
        }
        if (!data && loading) {
            content.append(loading({ height: '50vh' }));
            return;
        }
        if (!data) {
            content.append(alert({ title: t('Shared.loadError') }));
            return;
        }

        const departures = data[1];
        if (!departures?.length) {
            content.append(alert({ title: t('Schedules.noDepartures'), icon: 'Bedtime' }));
            return;
        }

        const list = el('div', { className: 'departure-list' });
        for (const departure of departures) {
            list.append(departureRow(city, departure));
        }
        content.append(list);

        // Nieskończone ładowanie: gdy scroll dojedzie do końca i jest więcej (port endReached)
        if (data[2]) {
            list.append(loading({ height: 60 }));
            list.addEventListener('scroll', () => {
                if (!data?.[2]) return;
                if (list.scrollTop + list.clientHeight >= list.scrollHeight - 80) {
                    stopStore.expandLimit(20);
                    stream.reconnect();
                }
            });
        }
    };

    /** Pojedynczy wiersz odjazdu (port StopDeparture.tsx). */
    function departureRow(city, departure) {
        const trip = departure[0];
        const vehicle = departure[1];
        const departureData = departure[2];
        const scheduled = departureData[0];
        const delay = departureData[1];
        const status = departureData[2];
        const platform = departureData[3];

        const route = trip[2];
        const headsign = trip[3];
        const shortName = trip[5];
        const brigade = trip[4];

        const estimated = scheduled + delay;
        const hasDelay = Math.abs(delay) >= 59000;
        const isCancelled = status === 3;

        const row = el(
            'button',
            {
                className: 'departure-row' + (isCancelled ? ' cancelled' : ''),
                onClick: () =>
                    navigate(
                        `/${city}/trip/${encodeURIComponent(trip[0])}` + buildCitySuffix(trip[1], city),
                        { state: -2 },
                    ),
            },
            el(
                'div',
                { className: 'departure-row-primary' },
                vehicleHeadsign(route, { headsign, shortName, brigade }),
                (() => {
                    const countdown = el('span', {}, '');
                    const update = (value) => {
                        const showCountdown = !isCancelled && estimated > Date.now();
                        countdown.textContent = showCountdown
                            ? String(value > 0 ? value : '<1')
                            : '';
                    };
                    const timer = useCountdown(estimated, false, update);
                    countdownTimers.push(timer);
                    update(timer.value);
                    return countdown;
                })(),
            ),
            el(
                'div',
                { className: 'departure-row-secondary' },
                el(
                    'span',
                    { className: 'departure-row-times' },
                    vehicleDelay(delay, status, !!vehicle && route[5] === 2),
                    ' · ',
                    hasDelay || isCancelled
                        ? el('span', { style: { textDecoration: 'line-through' } }, getTime(scheduled))
                        : el('span', {}, getTime(estimated)),
                    hasDelay && el('span', {}, ' ' + getTime(estimated)),
                    platform && el('span', {}, ` · ${t('Vehicle.platform')} `, el('b', {}, platform)),
                ),
                (() => {
                    // "min" po prawej — pokazywane gdy odjazd w przyszłości
                    const minutes = el('span', {}, '');
                    const show = !isCancelled && estimated > Date.now();
                    minutes.textContent = show ? t('Vehicle.min') : '';
                    return minutes;
                })(),
            ),
        );

        return row;
    }

    renderHeader();
    renderContent();

    const stream = createStopDeparturesStream(city, stopId, {
        onData: (value) => {
            data = value;
            isLoading = false;
            loadError = undefined;
            renderHeader();
            renderContent();

            // Port Stop.tsx: przesuń mapę do przystanku przy pierwszych danych
            const stopData = value[0];
            if (!hasFetched) {
                const map = getMap();
                map?.flyTo({
                    center: stopData[4],
                    zoom: map.getZoom() > 15 ? map.getZoom() : 15,
                    padding: { top: 0, left: 0, right: 0, bottom: 0 },
                });
                hasFetched = true;

                // Markery: przystanek + wyjścia (port Stop.tsx)
                updateStopMarkers([stopData], () => {});
                if (stopData[9]?.length) updateStopExits(stopData[9]);

                // Odjeżdżające pojazdy na żywo (port liveDepartures)
                updateLiveMarkers(city, value);
            } else {
                updateLiveMarkers(city, value);
            }
        },
        onState: ({ loading, error }) => {
            isLoading = loading;
            loadError = error;
            renderContent();
        },
    });

    /** Markery pojazdów, które zaraz odjeżdżają (port liveDepartures). */
    function updateLiveMarkers(city, value) {
        const seenVehicles = new Set();
        const live = [];

        for (const departure of value[1] ?? []) {
            const vehicle = departure[1];
            if (!vehicle) continue;

            const status = departure[2][2];
            if (status === 2) continue; // OnPreviousTrip

            if (seenVehicles.has(vehicle[0])) continue;
            seenVehicles.add(vehicle[0]);
            live.push(vehicle);
        }

        updateVehicleMarkers(live, (vehicle) => {
            navigate(
                `/${city}/vehicle/${encodeURIComponent(vehicle[0])}` + buildCitySuffix(vehicle[1], city),
                { state: -2 },
            );
        });
    }

    return {
        sheet,
        destroy() {
            for (const timer of countdownTimers) timer.stop();
            stream.destroy();
            sheet.close();
            clearVehicleMarkers();
            removeStopExits();
            stopStore.reset();
        },
    };
}
