/**
 * Wybór miasta — port komponentów:
 *   pages/Cities/index.tsx    — dialog powitalny z logo i cząsteczkami
 *   pages/Cities/CitySelect.tsx — lista miast z wyszukiwaniem i gwiazdkami
 */

import { el, dialog, textField } from '../ui.js';
import { renderIcon, renderLogo } from '../icons.js';
import { t } from '../i18n.js';
import { navigate } from '../router.js';
import { cityList } from '../api.js';
import { normalizeSearch } from '../util.js';
import { getMap } from '../map.js';

const DISPLAY_AGENCY_LIMIT = 3;

/** Filtr miast (port filterCities z CitySelect.tsx). */
export function filterCities(cities, needle) {
    const selectable = [...cities].sort((a, b) => a.name.localeCompare(b.name));

    if (!needle) return selectable.filter((city) => !city.virtual);

    return selectable.filter((city) => {
        if (city.virtual) return needle === normalizeSearch(city.id);

        return (
            normalizeSearch(city.name).includes(needle) ||
            Object.entries(city.agencies || {}).some(
                ([, agency]) => agency.name && normalizeSearch(agency.name).includes(needle),
            )
        );
    });
}

/** Dialog wyboru miasta. Zwraca destroy(). */
export function mountCitiesDialog() {
    const d = dialog({ closeable: true, className: 'cities-dialog' });

    const color = '#cdeda3';
    const logo = renderLogo({ size: 128, color });
    logo.style.filter = `drop-shadow(0 0 16px ${color})`;

    d.content.append(
        el(
            'div',
            { className: 'cities-header' },
            logo,
            el('h5', { className: 'cities-title' }, t('Settings.welcomeTo'), ' ', el('b', {}, 'zbiorkom.live')),
            el('p', { className: 'cities-subtitle' }, t('Settings.welcomeText')),
        ),
    );

    const list = el('div', { className: 'cities-list' });

    let search = '';
    const starred = () => JSON.parse(localStorage.getItem('starredCities') || '[]');

    const renderList = () => {
        list.replaceChildren();

        const needle = normalizeSearch(search.trim());
        const filtered = filterCities(cityList, needle);

        const makeList = (cities) => {
            const groups = el('div', { className: 'city-group' });

            for (const city of cities) {
                const isStarred = starred().includes(city.id);
                const entries = Object.entries(city.agencies || {});

                let agencyChips = null;
                if (entries.length) {
                    const matchedSide = needle
                        ? entries.filter(
                              ([key, agency]) =>
                                  key !== 'default' &&
                                  agency.name &&
                                  normalizeSearch(agency.name).includes(needle),
                          )
                        : [];

                    let prefix = null;
                    let nameChips;
                    let extra;

                    if (matchedSide.length > 0) {
                        prefix = t('Settings.containsAgencies');
                        nameChips = [matchedSide[0][1].name];
                        extra = matchedSide.length - 1;
                    } else {
                        const carriers = entries.map(([, agency]) => agency.name).filter(Boolean);
                        nameChips = carriers.slice(0, DISPLAY_AGENCY_LIMIT);
                        extra = carriers.length - nameChips.length;
                    }

                    agencyChips = el(
                        'div',
                        { className: 'city-agencies' },
                        prefix && el('span', { className: 'city-agencies-prefix' }, prefix),
                        ...nameChips.map((name) =>
                            el('span', { className: 'city-agency-chip' }, name),
                        ),
                        extra > 0 && el('span', { className: 'city-agency-extra' }, `+${extra}`),
                    );
                }

                groups.append(
                    el(
                        'button',
                        {
                            className: 'city-row',
                            onClick: () => {
                                localStorage.setItem('city', city.id);

                                window.skipPadding = true;
                                getMap()?.flyTo({
                                    center: city.location,
                                    zoom: city.zoom || 16,
                                    duration: 0,
                                    padding: { top: 0, right: 0, bottom: 0, left: 0 },
                                });

                                setTimeout(() => navigate(`/${city.id}`), 100);
                            },
                        },
                        el(
                            'button',
                            {
                                className: 'city-star' + (isStarred ? ' starred' : ''),
                                onClick: (event) => {
                                    event.stopPropagation();
                                    const newStarred = isStarred
                                        ? starred().filter((id) => id !== city.id)
                                        : [...starred(), city.id];
                                    localStorage.setItem('starredCities', JSON.stringify(newStarred));
                                    renderList();
                                },
                            },
                            renderIcon(isStarred ? 'Star' : 'StarBorder', { size: 20 }),
                        ),
                        el(
                            'div',
                            { className: 'city-row-text' },
                            el(
                                'span',
                                { className: 'city-name' },
                                city.name,
                                city.showNewTag && el('span', { className: 'city-new-tag' }, 'NEW'),
                            ),
                            agencyChips,
                        ),
                        renderIcon('NavigateNext', { size: 22 }),
                    ),
                );
            }

            return groups;
        };

        if (starred().length > 0 && !search) {
            list.append(makeList(filtered.filter((city) => starred().includes(city.id))));
        }
        list.append(makeList(filtered));
    };

    const input = textField({
        placeholder: t('Settings.searchCities'),
        onChange: (value) => {
            search = value;
            renderList();
        },
        adornment: 'Search',
    });

    d.content.append(input, list);
    document.body.append(d);

    renderList();

    return {
        destroy() {
            d.remove();
        },
    };
}
