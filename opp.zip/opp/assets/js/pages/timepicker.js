/**
 * Wybór czasu odjazdów — port:
 *   sheet/Stop/StopTimePicker.tsx + ui/TimePicker.tsx
 */

import { el, dialog } from '../ui.js';
import { t } from '../i18n.js';
import { goBack } from '../router.js';
import { stopStore } from '../store.js';

export function mountStopTimePicker() {
    const value = stopStore.time || Date.now();
    const date = new Date(value);

    let hours = String(date.getHours()).padStart(2, '0');
    let minutes = String(date.getMinutes()).padStart(2, '0');

    const d = dialog({ onClose: () => goBack() });

    d.content.append(el('h5', { className: 'dialog-title' }, t('Time.enterTime')));

    const hoursInput = el('input', {
        type: 'number',
        min: 0,
        max: 23,
        step: 1,
        inputmode: 'numeric',
        pattern: '[0-9]*',
        value: hours,
    });
    const minutesInput = el('input', {
        type: 'number',
        min: 0,
        max: 59,
        step: 1,
        inputmode: 'numeric',
        pattern: '[0-9]*',
        value: minutes,
    });

    for (const input of [hoursInput, minutesInput]) {
        input.className = 'time-field';
        input.addEventListener('focus', () => (input.value = ''));
        input.addEventListener('wheel', (event) => event.preventDefault(), { passive: true });
    }

    const blurFormat = (input, max) => {
        if (input.value === '') input.value = input.dataset.prev || '00';
        input.value = String(Math.min(max, parseInt(input.value) || 0)).padStart(2, '0');
        input.dataset.prev = input.value;
    };

    hoursInput.dataset.prev = hours;
    minutesInput.dataset.prev = minutes;

    hoursInput.addEventListener('blur', () => blurFormat(hoursInput, 23));
    minutesInput.addEventListener('blur', () => blurFormat(minutesInput, 59));

    const save = () => {
        const newDate = new Date(value);
        newDate.setHours(parseInt(hoursInput.value) || 0, parseInt(minutesInput.value) || 0);
        stopStore.setTime(newDate.getTime());
        goBack();
    };

    hoursInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') save();
        const val = hoursInput.value;
        if (event.key.match(/[0-9]/) && (val.length === 2 || !['0', '1', '2'].includes(val))) {
            setTimeout(() => {
                blurFormat(hoursInput, 23);
                minutesInput.focus();
                minutesInput.select();
            }, 0);
        }
    });

    minutesInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') save();
        if (event.key === 'Backspace' && minutesInput.value === '') {
            hoursInput.focus();
        }
        const val = minutesInput.value;
        if (event.key.match(/[0-9]/) && !['0', '1', '2', '3', '4', '5'].includes(val)) {
            setTimeout(() => {
                blurFormat(minutesInput, 59);
                minutesInput.blur();
            }, 0);
        }
    });

    // Sugestie +/- 1h (port porady w TimePicker)
    const suggestions = el(
        'div',
        { className: 'time-suggestions' },
        [-1, 1].map((offset) => {
            const suggested = new Date(date.getTime() + offset * 3600000);
            const label = `${String(suggested.getHours()).padStart(2, '0')}:${String(suggested.getMinutes()).padStart(2, '0')}`;
            return el(
                'button',
                {
                    className: 'button outlined',
                    onClick: () => {
                        hoursInput.value = label.split(':')[0];
                        minutesInput.value = label.split(':')[1];
                    },
                },
                label,
            );
        }),
    );

    const actions = el(
        'div',
        { className: 'dialog-actions' },
        el('button', { className: 'button text', onClick: () => goBack() }, t('Time.cancel')),
        el('button', { className: 'button contained', onClick: save }, t('Time.save')),
    );

    const displaySuggestions = !navigator.userAgent.includes('iPhone');

    d.content.append(
        el(
            'div',
            { className: 'time-fields' },
            el('div', {}, hoursInput, el('span', { className: 'time-label' }, t('Time.hour'))),
            el('span', { className: 'time-colon' }, ':'),
            el('div', {}, minutesInput, el('span', { className: 'time-label' }, t('Time.minute'))),
        ),
    );

    if (displaySuggestions) d.content.append(suggestions);
    d.content.append(actions);

    document.body.append(d);

    requestAnimationFrame(() => hoursInput.focus());

    return {
        destroy() {
            d.remove();
        },
    };
}
