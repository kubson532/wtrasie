/**
 * Widok linii — port komponentów:
 *   pages/Route.tsx            — pobranie grafu linii, kształty na mapie, markery
 *   util/routeLayout.ts        — algorytm układania pnia + gałęzi w pasy (lane)
 *   sheet/Route/RouteHeader    — nagłówek z przełącznikiem kierunku
 *   sheet/Route/RouteContent   — lista wierszy grafu
 *   sheet/Route/RouteStop      — wiersz przystanku / zwinięta gałąź
 *   sheet/Route/RouteTimeline  — SVG osi z pasami i zakrętami
 *   sheet/Route/RouteBead      — "koraliki" pojazdów na osi
 *   sheet/Route/RouteActions   — przyciski: rozkład brygady, udostępnij
 */

import { el, alert, bottomSheet } from '../ui.js';
import { renderIcon, vehicleTypeIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, goBack, pathname, search } from '../router.js';
import { getFromAPI, createEventQuery } from '../api.js';
import { directionStore, routePlacementsStore } from '../store.js';
import { polylineToGeoJson, fadeColor, share, getSheetHeight } from '../util.js';
import { vehicleHeadsign, sheetHeaderButtons } from './widgets.js';
import {
    getMap,
    updateTripRoute,
    removeTripRoute,
    updateVehicleMarkers,
    clearVehicleMarkers,
    fitBounds,
} from '../map.js';

export const ROW_HEIGHT = 56;
const SHEET_BACKGROUND = '#1a1c19';
const laneX = (lane) => 24 + 20 * lane;

/* ------------------------------------------------------------------ */
/* Port src/components/util/routeLayout.ts (bez zmian w logice)        */
/* ------------------------------------------------------------------ */

export function layoutDirection({ trunk, branches }, expanded) {
    const leaving = trunk.map(() => []);
    const arriving = trunk.map(() => []);
    const islands = [];

    for (let i = 0; i < branches.length; i++) {
        const { from, to } = branches[i];

        if (from >= 0) leaving[from].push(i);
        else if (to >= 0) arriving[to].push(i);
        else islands.push(i);
    }

    const rows = [];
    const trunkRows = [];
    const firstRows = [];
    const lastRows = [];

    const lanes = (key) => ({
        key,
        lane: 0,
        above: false,
        below: false,
        through: [],
        forks: [],
        joins: [],
        shifts: [],
    });

    const pushBranch = (index) => {
        const { stops, collapse } = branches[index];
        const [foldStart, foldEnd] = collapse ?? [stops.length, stops.length];
        const unfolded = expanded.has(index);
        firstRows[index] = rows.length;

        for (let j = 0; j < stops.length; j++) {
            const folded = j >= foldStart && j <= foldEnd;

            if (folded && !unfolded) {
                if (j === foldStart) {
                    rows.push({
                        kind: 'hidden',
                        branch: index,
                        stops: stops.slice(foldStart, foldEnd + 1),
                        ...lanes(`hidden:${index}`),
                    });
                }

                continue;
            }

            rows.push({ kind: 'stop', stop: stops[j], ...lanes(`branch:${index}:${j}`) });
        }

        lastRows[index] = rows.length - 1;
    };

    for (let i = 0; i < trunk.length; i++) {
        for (const index of arriving[i]) {
            pushBranch(index);
        }

        trunkRows.push(rows.length);
        rows.push({ kind: 'stop', stop: trunk[i], ...lanes(`trunk:${i}`) });

        for (const index of leaving[i]) {
            pushBranch(index);
        }
    }

    for (const index of islands) {
        pushBranch(index);
    }

    for (let i = 0; i < trunk.length; i++) {
        rows[trunkRows[i]].above = i > 0;
        rows[trunkRows[i]].below = i < trunk.length - 1;
    }

    const forksAtStop = branches.map((branch) => branch.from >= 0 && branch.from === trunk.length - 1);
    const skipsStops = branches.map((branch) => branch.from >= 0 && branch.to > branch.from + 1);
    const joinsAtStop = branches.map((branch, index) => branch.to === 0 || skipsStops[index]);

    const spans = branches.map((branch, index) => ({
        index,
        start: forksAtStop[index] ? trunkRows[branch.from] : firstRows[index],
        end: joinsAtStop[index] ? trunkRows[branch.to] : lastRows[index],
    }));
    spans.sort((a, b) => a.start - b.start || a.end - b.end);

    const branchLanes = [];
    const laneEnds = [];
    for (const { index, start, end } of spans) {
        let lane = 0;
        while (lane < laneEnds.length && laneEnds[lane] > start) {
            lane++;
        }
        laneEnds[lane] = end;
        lane++;
        branchLanes[index] = lane;

        const { from, to } = branches[index];
        const first = firstRows[index];
        const last = lastRows[index];

        for (let r = first; r <= last; r++) {
            rows[r].lane = lane;
            rows[r].above = r > first || forksAtStop[index];
            rows[r].below = r < last || joinsAtStop[index];
        }

        for (let r = start + 1; r < first; r++) {
            rows[r].through.push(lane);
        }

        for (let r = last + 1; r < end; r++) {
            rows[r].through.push(lane);
        }

        if (forksAtStop[index]) rows[start].forks.push(lane);
        else if (from >= 0) rows[first].joins.push(0);

        if (joinsAtStop[index]) rows[end].joins.push(lane);
        else if (to >= 0) rows[last].forks.push(0);
    }

    const dropThrough = (row, lane) => {
        rows[row].through = rows[row].through.filter((candidate) => candidate !== lane);
    };

    for (let i = 1; i < trunk.length; i++) {
        const joining = branches.flatMap((branch, index) =>
            branch.to === i && joinsAtStop[index] ? [index] : [],
        );
        joining.sort((a, b) => branchLanes[a] - branchLanes[b]);

        for (let j = 0; j < joining.length - 1; j++) {
            const index = joining[j];
            const lane = branchLanes[index];
            const row = Math.max(trunkRows[i] - (joining.length - 1 - j), firstRows[index]);

            if (row <= lastRows[index]) {
                rows[row].below = false;
                rows[row].forks.push(0);
            } else {
                dropThrough(row, lane);
                rows[row].shifts.push({ from: lane, to: 0 });
            }

            for (let r = row + 1; r < trunkRows[i]; r++) {
                dropThrough(r, lane);
            }

            rows[trunkRows[i]].joins = rows[trunkRows[i]].joins.filter((candidate) => candidate !== lane);
        }
    }

    const trunkStart = trunkRows[0] ?? -1;
    const trunkEnd = trunkRows[trunkRows.length - 1] ?? -1;

    for (let r = trunkStart + 1; r < trunkEnd; r++) {
        if (rows[r].lane > 0) rows[r].through.push(0);
    }

    const mainLanes = rows.map(() => 0);
    for (let index = 0; index < branches.length; index++) {
        if (!skipsStops[index]) continue;

        for (let r = lastRows[index] + 1; r < trunkRows[branches[index].to]; r++) {
            mainLanes[r] = Math.max(mainLanes[r], branchLanes[index]);
        }
    }

    const swapped = (lane, mainLane) => {
        if (lane === 0) return mainLane;
        if (lane === mainLane) return 0;
        return lane;
    };

    return rows.map(({ lane, above, below, through, forks, joins, shifts, ...row }, r) => {
        const top = mainLanes[r];
        const bottom = mainLanes[r + 1] ?? 0;
        const x = swapped(lane, top);
        const exit = swapped(lane, bottom);
        const runs = [];

        for (const crossing of through) {
            const from = swapped(crossing, top);
            const to = crossing === top && bottom === 0 ? from : swapped(crossing, bottom);
            const main = crossing === 0;

            if (from === to) {
                runs.push({ from, to, main });
            } else {
                runs.push({ from, to: from, half: 'upper', main });
                runs.push({ from, to, half: 'lower', main });
            }
        }

        for (const into of forks) {
            runs.push({ from: x, to: swapped(into, bottom), half: 'lower', main: false });
        }

        for (const from of joins) {
            if (from > 0 && from === mainLanes[r - 1] && top === 0) continue;

            runs.push({ from: swapped(from, top), to: x, half: 'upper', main: false });
        }

        for (const shift of shifts) {
            runs.push({ from: swapped(shift.from, top), to: swapped(shift.to, bottom), main: false });
        }

        if (below && exit !== x) {
            runs.push({ from: x, to: exit, half: 'lower', main: lane === 0 });
        }

        return { ...row, lane: x, main: lane === 0, above, below: below && exit === x, runs };
    });
}

/** Klucz wiersza dla lokacji pojazdu (port placementRowKey). */
export function placementRowKey(branch, position, { branches }, expanded) {
    if (branch === -1) return `trunk:${position}`;

    const collapse = branches[branch]?.collapse;
    if (collapse && !expanded.has(branch) && position >= collapse[0] && position <= collapse[1]) {
        return `hidden:${branch}`;
    }

    return `branch:${branch}:${position}`;
}

/* ------------------------------------------------------------------ */
/* Układ koralików (port layoutBeads z RouteContent.tsx)                */
/* ------------------------------------------------------------------ */

function layoutBeads(placements, rows, direction, expanded) {
    const rowIndices = new Map(rows.map((row, index) => [row.key, index]));
    const beads = [];

    for (const entry of placements) {
        const placement = entry[2];
        const fromKey = placementRowKey(placement[0], placement[1], direction, expanded);
        const toKey = placementRowKey(placement[2], placement[3], direction, expanded);
        const from = rowIndices.get(fromKey);
        const to = rowIndices.get(toKey);
        if (from === undefined || to === undefined) continue;

        const percent = placement[4];
        const progress = from + ((to - from) * percent) / 100;

        beads.push({
            key: `${entry[1]}:${entry[0]}`,
            row: Math.ceil(progress),
            progress,
            lane: rows[percent < 50 ? from : to].lane,
        });
    }

    beads.sort((a, b) => a.lane - b.lane || b.progress - a.progress);

    const shown = [];
    let front = 0;
    for (let i = 1; i <= beads.length; i++) {
        const piled =
            i < beads.length &&
            beads[i].lane === beads[front].lane &&
            beads[front].progress - beads[i].progress < 0.6;
        if (piled) continue;

        const size = i - front;
        const { row, progress } = beads[front];
        shown.push({ ...beads[front], depth: 0, count: size > 2 ? size - 1 : undefined });
        if (size > 1) {
            shown.push({ ...beads[front + 1], row, progress, depth: 1 });
        }
        front = i;
    }

    shown.sort((a, b) => a.progress - b.progress || b.depth - a.depth);

    const byRow = new Map();
    for (const bead of shown) {
        byRow.set(bead.row, [...(byRow.get(bead.row) ?? []), bead]);
    }

    return byRow;
}

/* ------------------------------------------------------------------ */
/* Rysowanie osi (port RouteTimeline.tsx)                               */
/* ------------------------------------------------------------------ */

function bend(fromX, fromY, toX, toY) {
    const midY = (fromY + toY) / 2;
    return `M${fromX} ${fromY} C${fromX} ${midY} ${toX} ${midY} ${toX} ${toY}`;
}

function routeTimelineSVG({ color, lane, main, gap, above, below, runs }) {
    const variantStroke = fadeColor(color, 0.5, SHEET_BACKGROUND);
    const stroke = main ? color : variantStroke;
    const outermost = Math.max(lane, ...runs.flatMap((run) => [run.from, run.to]));
    const width = 48 + 20 * outermost;
    const x = laneX(lane);

    const bottom = ROW_HEIGHT + 2;
    const middle = ROW_HEIGHT / 2 + 1;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', width);
    svg.setAttribute('height', bottom);
    svg.style.cssText = 'display:block;margin-top:-1px';

    const paint = (run) => {
        const x1 = laneX(run.from);
        const x2 = laneX(run.to);
        const y1 = run.half === 'lower' ? middle : 0;
        const y2 = run.half === 'upper' ? middle : bottom;
        const runStroke = run.main ? color : variantStroke;

        let shape;
        if (x1 === x2) {
            shape = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            shape.setAttribute('x1', x1);
            shape.setAttribute('y1', y1);
            shape.setAttribute('x2', x2);
            shape.setAttribute('y2', y2);
        } else {
            shape = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            shape.setAttribute('d', bend(x1, y1, x2, y2));
            shape.setAttribute('fill', 'none');
        }
        shape.setAttribute('stroke', runStroke);
        shape.setAttribute('stroke-width', 6);
        return shape;
    };

    const ownLine = () => {
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', x);
        line.setAttribute('y1', above ? 0 : middle);
        line.setAttribute('x2', x);
        line.setAttribute('y2', below ? bottom : middle);
        line.setAttribute('stroke', stroke);
        line.setAttribute('stroke-width', 6);
        if (gap) line.setAttribute('stroke-dasharray', '6 5');
        return line;
    };

    // Główna linia malowana nad wariantami
    for (const run of runs.filter((run) => !run.main)) svg.append(paint(run));
    if (!main) svg.append(ownLine());
    for (const run of runs.filter((run) => run.main)) svg.append(paint(run));
    if (main) svg.append(ownLine());

    if (!gap) {
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', x);
        circle.setAttribute('cy', middle);
        circle.setAttribute('r', 6.5);
        circle.setAttribute('fill', '#ffffff');
        circle.setAttribute('stroke', stroke);
        circle.setAttribute('stroke-width', 3);
        svg.append(circle);
    }

    return svg;
}

/** Koralik pojazdu (port RouteBead.tsx). */
function renderBead(bead, route) {
    const top = Math.min(50, Math.max(-50, (bead.progress - bead.row) * 100 + 50));

    const outer = el('div', {
        className: 'route-bead',
        style: {
            top: `${top}%`,
            left: `${laneX(bead.lane) - 15}px`,
            marginTop: `${-15 - 12 * bead.depth}px`,
        },
    });

    const inner = el(
        'div',
        { className: 'route-bead-inner', style: { backgroundColor: route[6] } },
        (() => {
            if (bead.count !== undefined) {
                return el(
                    'span',
                    { className: 'route-bead-count' },
                    `+${bead.count}`,
                );
            }
            const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            icon.setAttribute('viewBox', '0 0 24 24');
            icon.setAttribute('width', '16');
            icon.setAttribute('height', '16');
            icon.setAttribute('fill', 'rgba(255, 255, 255, 0.8)');
            icon.innerHTML = vehicleTypeIcon(route[5], route[1], route[4]);
            return icon;
        })(),
    );

    outer.append(inner);
    return outer;
}

/* ------------------------------------------------------------------ */
/* Montowanie widoku linii                                             */
/* ------------------------------------------------------------------ */

export async function mountRouteSheet(city, routeId, sheetHost) {
    const header = el('div', { className: 'route-header' });
    const content = el('div', { className: 'route-content' });

    const sheet = bottomSheet({
        blocking: false,
        onDismiss: () => goBack(),
    });

    sheet.header.append(header);
    sheet.scroll.append(content);
    sheetHost.append(sheet.root);

    let data = null;
    const expanded = new Set();

    // Pobranie grafu linii (port useQueryRouteGraph)
    try {
        const raw = await getFromAPI(city, `routes/${routeId}`, {});
        if ('error' in raw) throw new Error(raw.error);

        data = {
            ...raw,
            shapes: raw.shapes.map((direction) => direction.map(polylineToGeoJson)),
        };
    } catch {
        goBack();
        return { sheet, destroy: () => sheet.dismiss() };
    }

    /* Kształty i markery na mapie (port Route.tsx) */
    const direction = () => directionStore.direction;
    let graph = data.graph[direction()];
    let shapes = data.shapes[direction()] ?? [];

    const drawMap = () => {
        graph = data.graph[direction()];
        shapes = data.shapes[direction()] ?? [];

        const lines = shapes.slice(0, 1);
        const variantLines = shapes.slice(1);

        if (lines.length > 0 && graph) {
            const feature = (stopTuple, variant) => ({
                type: 'Feature',
                geometry: { type: 'Point', coordinates: stopTuple[4] },
                properties: { id: stopTuple[0], name: stopTuple[3] ? `${stopTuple[2]} ${stopTuple[3]}` : stopTuple[2], variant },
            });

            const stopsGeoJson = {
                type: 'FeatureCollection',
                features: [
                    ...graph.branches.flatMap((branch) => branch.stops.map((s) => feature(s, true))),
                    ...graph.trunk.map((s) => feature(s, false)),
                ],
            };

            const shapeGeoJson = {
                type: 'FeatureCollection',
                features: [
                    ...variantLines.map((line) => ({ ...line, properties: { variant: true } })),
                    ...lines.map((line) => ({ ...line, properties: { variant: false } })),
                ],
            };

            updateTripRoute(shapeGeoJson, stopsGeoJson, data.route[6]);
        }

        // Dopasuj widok do kształtów
        if (shapes.length) {
            let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity;
            for (const shape of shapes) {
                for (const [lng, lat] of shape.geometry.coordinates) {
                    if (lng < minLng) minLng = lng;
                    if (lat < minLat) minLat = lat;
                    if (lng > maxLng) maxLng = lng;
                    if (lat > maxLat) maxLat = lat;
                }
            }

            fitBounds(
                [[minLng, minLat], [maxLng, maxLat]],
                { padding: { top: 30, left: 30, right: 30, bottom: getSheetHeight() }, maxDuration: 1000 },
            );
        }
    };

    drawMap();

    /* Strumień lokacji pojazdów (port useQueryMarkers z graph=1) */
    let markersStreamHandle = null;
    function reconnectMarkers() {
        markersStreamHandle?.close();
        markersStreamHandle = createEventQuery({
            city,
            endpoint: `mapFeatures/0/0,0,0,0/stream?filterRoutes=${encodeURIComponent(routeId)}&filterDirection=${direction()}&graph=1`,
            onMessage: (streamData) => {
                routePlacementsStore.setPlacements(streamData.placements || []);
                updateVehicleMarkers(streamData.positions || [], (vehicle) => {
                    navigate(`/${city}/vehicle/${encodeURIComponent(vehicle[0])}`, { state: -3 });
                });
                renderContent();
            },
        });
    }

    reconnectMarkers();

    /* Nagłówek (port RouteHeader.tsx) */
    const renderHeader = () => {
        header.replaceChildren();

        header.append(vehicleHeadsign(data.route, { headsign: data.graph[direction()]?.headsign }));

        const canSwitch = data.graph.length >= 2;

        header.append(
            sheetHeaderButtons([
                {
                    icon: canSwitch ? 'ImportExport' : 'AllInclusive',
                    title: 'Kierunek',
                    onClick: () => {
                        directionStore.setDirection((direction() + 1) % data.graph.length);
                        renderHeader();
                        renderContent();
                        drawMap();
                        reconnectMarkers();
                    },
                },
                { icon: 'Close', title: 'Zamknij', onClick: () => window.history.back() },
            ]),
        );

        const switchButton = header.querySelectorAll('.icon-button')[0];
        if (switchButton) {
            switchButton.style.transition = 'transform 0.3s';
            switchButton.style.transform = `rotate(${direction() === 0 ? 0 : 180}deg)`;
        }
    };

    /* Treść (port RouteContent.tsx + RouteStop.tsx) */
    function renderContent() {
        content.replaceChildren();

        const currentGraph = data.graph[direction()];

        if (!currentGraph) {
            content.append(
                el('p', { className: 'route-empty' }, t('Vehicle.routeEmpty')),
            );
            return;
        }

        const rows = layoutDirection(currentGraph, expanded);
        const beadsByRow = layoutBeads(routePlacementsStore.placements, rows, currentGraph, expanded);

        const list = el('div', { className: 'route-rows' });

        // Przyciski akcji na górze (port RouteActions.tsx — nagłówek listy)
        list.append(
            el(
                'div',
                { className: 'route-actions' },
                el(
                    'button',
                    {
                        className: 'route-action-button left',
                        onClick: () =>
                            navigate(pathname() + '/brigades' + search()),
                    },
                    renderIcon('EventNote', { size: 20 }),
                    t('Vehicle.brigadeSchedule'),
                ),
                el(
                    'button',
                    {
                        className: 'route-action-button right',
                        onClick: () => share(window.location.href),
                    },
                    renderIcon('Share', { size: 20 }),
                    el('span', {}, t('Shared.share')),
                ),
            ),
        );

        rows.forEach((row, index) => {
            const timeline = el(
                'div',
                { className: 'route-timeline' },
                routeTimelineSVG({
                    color: data.route[6],
                    lane: row.lane,
                    main: row.main,
                    gap: row.kind === 'hidden',
                    above: row.above,
                    below: row.below,
                    runs: row.runs,
                }),
            );

            for (const bead of beadsByRow.get(index) ?? []) {
                timeline.append(renderBead(bead, data.route));
            }

            let text;
            if (row.kind === 'stop') {
                text = el(
                    'button',
                    {
                        className: 'route-stop-name',
                        onClick: () => {
                            const map = getMap();
                            map?.flyTo({
                                center: row.stop[4],
                                zoom: map.getZoom() > 15 ? map.getZoom() : 15,
                            });
                        },
                    },
                    row.stop[3] ? `${row.stop[2]} ${row.stop[3]}` : row.stop[2],
                );
            } else {
                text = el(
                    'button',
                    {
                        className: 'route-stop-name collapsed',
                        onClick: () => {
                            expanded.add(row.branch);
                            renderContent();
                        },
                    },
                    renderIcon('UnfoldMore', { size: 20 }),
                    t('Vehicle.showStops', { count: row.stops.length }),
                );
            }

            list.append(
                el(
                    'div',
                    { className: 'route-row', style: { height: `${ROW_HEIGHT}px` } },
                    timeline,
                    text,
                ),
            );
        });

        content.append(list);
    }

    renderHeader();
    renderContent();

    return {
        sheet,
        destroy() {
            markersStreamHandle?.close();
            sheet.close();
            removeTripRoute();
            clearVehicleMarkers();
            directionStore.setDirection(0);
            routePlacementsStore.setPlacements([]);
        },
    };
}
