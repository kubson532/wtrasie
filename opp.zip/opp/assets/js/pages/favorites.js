/**
 * Ulubione przystanki — port komponentów:
 *   sheet/FavoriteStops/* — nagłówek + lista ulubionych z odjazdami
 *   sheet/FavoriteStops/AddToFav (pages/AddToFav) — wybór kierunków
 */

import { el, bottomSheet, alert, loading } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, goBack, segments } from '../router.js';
import { createEventQuery } from '../api.js';
import { favStore, settings } from '../store.js';
import { getDelay } from '../util.js';
import { stopTag, vehicleHeadsign, useCountdown } from './widgets.js';
import { getFromAPI } from '../api.js';

/** Arkusz ulubionych przystanków. Zwraca destroy(). */
export function mountFavoriteStopsSheet(sheetHost) {
    const city = segments()[0];
    const favorites = favStore.favorites;

    const header = el('h5', { className: 'favorites-header' }, t('Vehicle.favoriteStops'));
    const content = el('div', { className: 'favorites-content' });

    const sheet = bottomSheet({
        blocking: true,
        onDismiss: () => goBack(),
    });

    sheet.header.append(header);
    sheet.scroll.append(content);
    sheetHost.append(sheet.root);

    const streams = [];

    const sortedFavorites = (() => {
        const useSorting = settings.useLocationSorting;
        if (!useSorting) return favorites;

        const userLocation = JSON.parse(localStorage.getItem('userLocation') || 'null');
        if (!userLocation || userLocation.lastUpdate < Date.now() - 60000 * 5) return favorites;

        return [...favorites].sort((a, b) => {
            const distanceA = calculateDistance(userLocation.location, a.location);
            const distanceB = calculateDistance(userLocation.location, b.location);
            return distanceA - distanceB;
        });
    })();

    if (!sortedFavorites.length) {
        content.append(
            alert({ icon: 'Star', title: t('Favorites.addStopsHere'), description: t('Favorites.howToAddStopsHere') }),
        );
    } else {
        const list = el('div', { className: 'favorites-list' });

        sortedFavorites.forEach((stop, index) => {
            const card = el('div', { className: 'fav-stop' });
            if (index !== 0) card.style.borderTop = '1px solid #44474a';

            const path = `/${city}/${stop.isStation ? 'station' : 'stop'}/${stop.id}`;
            const search = stop.isStation && city !== 'pkp' ? '?city=pkp' : '';

            const headerRow = el('div', { className: 'fav-header' });
            const departuresBox = el('div', { className: 'fav-departures' });

            card.append(headerRow, departuresBox);

            card.addEventListener('click', () => navigate(path + search, { state: -2 }));
            list.append(card);

            const isFiltered = stop.directions.length > 0;

            if (isFiltered) {
                card.append(
                    el(
                        'div',
                        { className: 'fav-directions' },
                        renderIcon('SubdirectoryArrowRight', { size: 16 }),
                        el('span', {}, stop.directions.map((direction) => direction[1]).join(', ')),
                    ),
                );
            }

            // Strumień odjazdów z limitem 3 (port useQueryStopDepartures w FavStop)
            let stopTuple = null;
            let rawDepartures = null;

            const render = () => {
                if (stopTuple) {
                    headerRow.replaceChildren(
                        stopTag(stopTuple),
                        el(
                            'div',
                            { className: 'fav-actions' },
                            el(
                                'button',
                                {
                                    className: 'icon-button',
                                    title: t('Favorites.editDirections'),
                                    onClick: (event) => {
                                        event.stopPropagation();
                                        navigate(`${path}/addToFav${search}`, { state: -2 });
                                    },
                                },
                                renderIcon(isFiltered ? 'FilterAlt' : 'FilterAltOutlined', { size: 20 }),
                            ),
                            el(
                                'button',
                                {
                                    className: 'icon-button',
                                    title: 'Usuń',
                                    onClick: (event) => {
                                        event.stopPropagation();
                                        favStore.removeFavoriteStop(stop.id);
                                        card.remove();
                                    },
                                },
                                renderIcon('Delete', { size: 20 }),
                            ),
                        ),
                    );
                }

                if (stopTuple && rawDepartures) {
                    departuresBox.replaceChildren();

                    if (!rawDepartures.length) {
                        departuresBox.append(el('span', {}, t('Schedules.noDepartures')));
                    }

                    for (const departure of rawDepartures) {
                        const departureTime = departure[2];
                        const estimated = departureTime[0] + departureTime[1];

                        const isLive = (status) => status !== 3 && status !== 0;
                        const [rawClass] = getDelay(departureTime[1]);
                        const departureClass = isLive(departureTime[2]) ? rawClass : 'unknown';

                        const countdown = el('span', { className: `delay delay-${departureClass}` }, '');
                        const timer = useCountdown(estimated, false, (value) => {
                            countdown.textContent = `${value > 0 ? value : '<1'} min`;
                        });
                        countdown.textContent = `${timer.value > 0 ? timer.value : '<1'} min`;

                        departuresBox.append(
                            el(
                                'div',
                                { className: 'fav-departure' },
                                vehicleHeadsign(departure[0][2], { headsign: departure[0][3] }),
                                countdown,
                            ),
                        );
                    }
                } else {
                    departuresBox.append(loading({ height: 80 }));
                }
            };

            render();

            const query = new URLSearchParams();
            query.set('limit', '4'); // limit 3 + 1
            if (stop.directions.length) {
                query.set('destinations', stop.directions.map((direction) => direction[0]).join(','));
            }

            const stream = createEventQuery({
                city: stop.isStation ? 'pkp' : city,
                endpoint: `stops/${encodeURIComponent(stop.id)}/stream?${query.toString()}`,
                onInitial: (data) => {
                    stopTuple = data;
                    render();
                },
                onMessage: (data) => {
                    rawDepartures = data.slice(0, 3);
                    render();
                },
            });

            streams.push(stream);
        });

        content.append(list);
    }

    return {
        sheet,
        destroy() {
            for (const stream of streams) stream.destroy();
            sheet.close();
        },
    };
}

/** Odległość między punktami (port calculateDistance). */
function calculateDistance(loc1, loc2) {
    const [lng1, lat1] = loc1;
    const [lng2, lat2] = loc2;
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a =
        0.5 -
        Math.cos(dLat) / 2 +
        (Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * (1 - Math.cos(dLng))) / 2;
    return R * 2 * Math.asin(Math.sqrt(a));
}

/* ------------------------------------------------------------------ */
/* Dodawanie kierunków (port pages/AddToFav)                            */
/* ------------------------------------------------------------------ */

export async function mountAddToFavDialog(city, stopId) {
    const d = dialog({ onClose: () => goBack() });

    const content = d.content;
    content.append(el('h5', { className: 'dialog-title' }, t('Favorites.selectDirection')));

    const host = el('div', { className: 'addtofav-host' });
    content.append(host);
    host.append(loading({ height: 200 }));

    document.body.append(d);

    try {
        const stops = await getFromAPI(city, `stops/${encodeURIComponent(stopId)}/destinations`, {});

        host.replaceChildren();

        if (!Array.isArray(stops) || !stops.length) {
            host.append(alert({ title: t('Shared.loadError') }));
        } else {
            for (const stop of stops) {
                const isAdded = favStore.favorites
                    .find((fav) => fav.id === stopId)
                    ?.directions.some(([, name]) => name === stop[2]);

                host.append(
                    el(
                        'button',
                        {
                            className: 'addtofav-row' + (isAdded ? ' added' : ''),
                            onClick: () => {
                                const favorite = favStore.favorites.find((fav) => fav.id === stopId);

                                if (favorite?.directions.some(([, name]) => name === stop[2])) {
                                    const index = favorite.directions.findIndex(
                                        ([, name]) => name === stop[2],
                                    );
                                    favStore.removeFavoriteDirection(stopId, index);
                                } else {
                                    favStore.addFavoriteDirection(stopId, stop[4], stop[1] === 'pkp', [
                                        stop[0],
                                        stop[2],
                                    ]);
                                }
                                d.remove();
                                mountAddToFavDialog(city, stopId);
                            },
                        },
                        el('span', {}, stop[2]),
                        renderIcon(isAdded ? 'Star' : 'StarBorder', { size: 22 }),
                    ),
                );
            }
        }
    } catch {
        host.replaceChildren(alert({ title: t('Shared.loadError') }));
    }

    return {
        destroy() {
            d.remove();
        },
    };
}
