/**
 * Wyszukiwarka — port komponentów:
 *   pages/Search/index.tsx        — dialog z polem wyszukiwania
 *   pages/Search/SearchInfo.tsx   — instrukcja bez zapytania
 *   pages/Search/Result.tsx + ... — wyniki (pojazdy, przystanki, stacje, linie, relacje)
 */

import { el, dialog, textField, alert, loading } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, goBack, query, replaceSearch } from '../router.js';
import { getFromAPI } from '../api.js';
import { buildCitySuffix, parseVehicleId, getTime, searchTokens, matchesTokens } from '../util.js';
import { vehicleHeadsign, routeChip, stopTag } from './widgets.js';

/** Stan wyszukiwania w URL (odpowiednik useSearchState). */
function getSearchFromUrl(initial) {
    return query().get('query') || initial || '';
}

function setSearchParam(value) {
    const params = query();
    if (value) params.set('query', value);
    else params.delete('query');

    replaceSearch(params);
}

/** Dialog wyszukiwarki. Zwraca destroy(). */
export function mountSearchDialog(city) {
    let search = getSearchFromUrl('');
    let data = null;
    let isLoading = false;
    let searchError = null;
    let expandedStop;
    let debounceTimer = null;

    const d = dialog({
        onClose: () => goBack(),
        fullscreen: window.innerWidth <= 600,
    });

    const results = el('div', { className: 'search-results' });

    const input = textField({
        placeholder: 'Szukaj',
        value: search,
        autoFocus: true,
        onChange: (value) => {
            search = value;
            setSearchParam(value);

            // Debounce 300 ms — dokładnie jak useQuerySearch
            data = null;
            searchError = null;
            renderResults();
            clearTimeout(debounceTimer);
            if (value) {
                isLoading = true;
                renderResults();
                debounceTimer = setTimeout(() => runSearch(value), 300);
            } else {
                isLoading = false;
                renderResults();
            }
        },
        endAdornment: el(
            'button',
            {
                className: 'icon-button',
                onClick: () => {
                    input.input.value = '';
                    search = '';
                    setSearchParam('');
                    isLoading = false;
                    data = null;
                    renderResults();
                    input.input.focus();
                },
            },
            renderIcon('HighlightOff', { size: 20 }),
        ),
    });

    const header = el(
        'div',
        { className: 'search-header' },
        el('button', { className: 'icon-button', onClick: () => goBack({ ignoreState: true }) }, renderIcon('ArrowBack')),
        input,
    );

    d.content.append(header, results);
    document.body.append(d);

    /**
     * Tekst wyszukiwania danego wyniku (nazwa linii/przystanku/pojazdu/relacji).
     * Używany przez filtr rozmyty (spacja = osobne filtry, bez ogonków/cyfr).
     */
    const itemText = (item) => {
        if (item.route) return `${item.route[2] ?? ''} ${item.route[3] ?? ''}`;
        if (item.stop) return item.stop[2] ?? '';
        if (item.station) return item.station[2] ?? '';
        if (item.vehicle) return `${item.vehicle[1]?.[2] ?? ''} ${item.vehicle[3] ?? ''}`;
        if (item.relation) return `${item.relation[1]?.[2] ?? ''} ${item.relation[5] ?? ''}`;
        return '';
    };

    /**
     * Filtr rozmyty wyników: każdy wynik musi spełniać WSZYSTKIE filtry
     * (tokeny z zapytania). Przebudowuje liczniki grup (groups/groupNames),
     * by nagłówki sekcji odpowiadały faktycznej zawartości.
     */
    function filterResultsFuzzy(data, tokens) {
        if (!tokens.length || !data?.results) return data;

        const keptResults = [];
        const keptGroups = [];
        const keptGroupNames = [];

        let index = 0;
        (data.groups || []).forEach((count, groupIndex) => {
            let keptCount = 0;
            for (let i = 0; i < count; i++, index++) {
                const item = data.results[index];
                if (item && matchesTokens(itemText(item), '', tokens)) {
                    keptResults.push(item);
                    keptCount++;
                }
            }
            if (keptCount > 0) {
                keptGroups.push(keptCount);
                keptGroupNames.push(data.groupNames?.[groupIndex]);
            }
        });

        return { ...data, results: keptResults, groups: keptGroups, groupNames: keptGroupNames };
    }

    async function runSearch(value) {
        try {
            let response = await getFromAPI(city, 'search', { query: value });
            if (response?.error) throw new Error(response.error);

            /* Fallback rozmyty: gdy pełne zapytanie nic nie zwraca, próbuj
             * kolejno z mniejszą liczbą filtrów (odrzucaj ostatnie słowa),
             * a potem przefiltruj wyniki CAŁĄ listą filtrów — dzięki temu
             * „Podkarpacka Politechnika 01” znajdzie przystanek także wtedy,
             * gdy serwer nie umie dopasować całej frazy. */
            const tokens = searchTokens(value);
            if (!response?.results?.length && tokens.length > 1) {
                for (let take = tokens.length - 1; take >= 1 && !response?.results?.length; take--) {
                    const shorter = tokens.slice(0, take).join(' ');
                    const retry = await getFromAPI(city, 'search', { query: shorter });
                    if (!retry?.error) response = retry;
                }
            }

            response = filterResultsFuzzy(response, tokens);

            if (search !== value) return; // nieaktualne zapytanie
            data = response;
            isLoading = false;
        } catch (err) {
            if (search !== value) return;
            searchError = err;
            isLoading = false;
        }
        renderResults();
    }

    /* Instrukcja bez zapytania (port SearchInfo.tsx) */
    function renderInfo() {
        const items = [
            { icon: 'DirectionsBus', color: '#561f0f', bg: '#ffb5a0', title: 'Search.howToVehicles', description: 'Search.vehiclesDescription' },
            { icon: 'PinDrop', color: '#1f3701', bg: '#b1d18a', title: 'Search.howToStops', description: 'Search.stopsDescription' },
            { icon: 'AltRoute', color: '#0a305f', bg: '#aac7ff', title: 'Search.howToRoutes', description: 'Search.routesDescription' },
            { icon: 'Train', color: '#3a3000', bg: '#dbc66e', title: 'Search.howToRelations', description: 'Search.relationsDescription' },
        ];

        return el(
            'div',
            { className: 'search-info' },
            el('h5', {}, t('Search.howToUse')),
            items.map((item) => {
                const icon = renderIcon(item.icon, { size: 36 });
                icon.style.color = item.color;
                icon.style.backgroundColor = item.bg;
                icon.style.borderRadius = '8px';
                icon.style.padding = '8px';
                return el(
                    'div',
                    { className: 'search-info-row' },
                    icon,
                    el('div', {}, el('b', {}, t(item.title)), el('span', {}, t(item.description))),
                );
            }),
        );
    }

    /* Pojedyncze wyniki — porty *Result.tsx */
    function resultRow(children, onClick, { borderTop, borderBottom } = {}) {
        return el(
            'button',
            {
                className:
                    'search-result' +
                    (borderTop ? ' border-top' : '') +
                    (borderBottom ? ' border-bottom' : ''),
                onClick,
            },
            children,
        );
    }

    function renderResults() {
        results.replaceChildren();

        if (!search.length) {
            results.append(renderInfo());
            return;
        }

        if (searchError && !isLoading) {
            results.append(
                alert({ title: t('Shared.loadError'), description: String(searchError.message ?? searchError) }),
            );
            return;
        }

        if (isLoading) {
            results.append(loading({ height: 200 }));
            return;
        }

        if (!data?.results?.length) {
            results.append(alert({ icon: 'SearchOff', title: t('Executions.noResults') }));
            return;
        }

        let index = 0;
        const groups = data.groups ?? [];
        const groupNames = data.groupNames ?? [];

        groups.forEach((count, groupIndex) => {
            // Nagłówek grupy (odpowiednik GroupedVirtuoso + ListSubheader)
            results.append(el('div', { className: 'search-group-header' }, t(`Search.${groupNames[groupIndex]}`)));

            for (let i = 0; i < count; i++, index++) {
                const item = data.results[index];
                const last = i === count - 1;
                results.append(renderItem(item, last));
            }
        });
    }

    function renderItem(item, last) {
        if (item.route) {
            return resultRow(
                [vehicleHeadsign(item.route, { headsign: item.route[3], fontSize: '0.92em' })],
                () =>
                    navigate(
                        `/${city}/route/${item.route[0]}` + buildCitySuffix(item.route[1], city),
                        { state: -2 },
                    ),
                { borderBottom: item.borderBottom, borderTop: item.borderTop },
            );
        }

        if (item.stop) {
            const stop = item.stop;
            const stops = stop[3];

            const wrapper = el('div', { className: 'search-stop-wrapper' });

            wrapper.append(
                resultRow(
                    [
                        el('span', {}, stop[2]),
                        (() => {
                            const arrow = renderIcon('KeyboardArrowDown', { size: 22 });
                            arrow.style.transition = 'transform 0.2s ease-in-out';
                            if (expandedStop === stop[0]) arrow.style.transform = 'rotate(180deg)';
                            return arrow;
                        })(),
                    ],
                    () => {
                        expandedStop = expandedStop === stop[0] ? undefined : stop[0];
                        renderResults();
                    },
                    { borderTop: item.borderTop, borderBottom: item.borderBottom && expandedStop !== stop[0] },
                ),
            );

            if (expandedStop === stop[0]) {
                const box = el('div', { className: 'search-stop-expanded' });
                stops?.forEach((expanded, i) => {
                    const hasBottomBorder = item.borderBottom && i === (stops.length || 0) - 1;
                    box.append(
                        el(
                            'button',
                            {
                                className:
                                    'search-result expanded' + (hasBottomBorder ? ' border-bottom' : ''),
                                onClick: () =>
                                    navigate(
                                        `/${city}/stop/${expanded[0]}` + buildCitySuffix(expanded[1], city),
                                        { state: -2 },
                                    ),
                            },
                            (() => {
                                const iconBox = el('span', { className: 'search-stop-marker' });
                                return iconBox;
                            })(),
                            el(
                                'div',
                                { className: 'search-stop-text' },
                                el('span', { className: 'search-stop-name' }, `${expanded[2]} ${expanded[3] || ''}`),
                                el(
                                    'span',
                                    { className: 'search-stop-secondary' },
                                    expanded[6] || expanded[8]?.length
                                        ? (expanded[6] ? `» ${expanded[6]}, ` : '') +
                                              expanded[8].map((route) => route[2]).join(', ')
                                        : t('Vehicle.terminus'),
                                ),
                            ),
                        ),
                    );
                });
                wrapper.append(box);
            }

            return wrapper;
        }

        if (item.station) {
            return resultRow(
                [el('span', {}, item.station[2])],
                () =>
                    navigate(
                        `/${city}/station/${item.station[0]}` + buildCitySuffix(item.station[1], city),
                        { state: -2 },
                    ),
                { borderTop: item.borderTop, borderBottom: item.borderBottom },
            );
        }

        if (item.vehicle) {
            const vehicle = item.vehicle;
            const { vehicleNumber } = parseVehicleId(vehicle[0]);
            const showVehicleNumber = !vehicleNumber.startsWith('_');
            const model = vehicle[4];
            const secondary = [showVehicleNumber ? `#${vehicleNumber}` : null, model || null]
                .filter(Boolean)
                .join(', ');

            return resultRow(
                [
                    vehicleHeadsign(vehicle[1], {
                        headsign: vehicle[3],
                        brigade: vehicle[2],
                        fontSize: '0.92em',
                    }),
                    secondary && el('span', { className: 'search-result-secondary' }, secondary),
                ],
                () => navigate(`/${city}/vehicle/${encodeURIComponent(vehicle[0])}`, { state: -2 }),
                { borderTop: item.borderTop, borderBottom: item.borderBottom },
            );
        }

        if (item.relation) {
            const relation = item.relation;
            const route = relation[1];

            return resultRow(
                [
                    vehicleHeadsign(route, { headsign: relation[5], fontSize: '0.92em' }),
                    el(
                        'span',
                        { className: 'search-result-secondary' },
                        `${getTime(relation[3])} – ${getTime(relation[4])}`,
                    ),
                ],
                () =>
                    navigate(
                        `/${city}/trip/${encodeURIComponent(relation[0])}` + buildCitySuffix(route[1], city),
                        { state: -2 },
                    ),
                { borderTop: item.borderTop, borderBottom: item.borderBottom },
            );
        }

        return null;
    }

    renderResults();
    if (search) {
        isLoading = true;
        renderResults();
        debounceTimer = setTimeout(() => runSearch(search), 300);
    }

    return {
        destroy() {
            clearTimeout(debounceTimer);
            d.remove();
        },
    };
}
