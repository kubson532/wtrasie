/**
 * Blog — port komponentów:
 *   pages/Blog/BlogPosts.tsx — lista kart wpisów
 *   pages/Blog/BlogPost.tsx  — pojedynczy wpis (markdown)
 *   pages/Blog/BlogCard.tsx  — karta wpisu
 */

import { el, dialog, loading } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, pathname } from '../router.js';
import { getFromCloudAPI } from '../api.js';

export async function mountBlogDialog(city) {
    const d = dialog({ fullscreen: window.innerWidth <= 900, closeable: false });

    const header = el(
        'div',
        { className: 'page-header' },
        el(
            'button',
            {
                className: 'icon-button',
                onClick: () => navigate(pathname(), { state: 'menu' }),
            },
            renderIcon('Menu'),
        ),
        el('h5', {}, t('Blog.blog')),
    );

    const host = el('div', { className: 'blog-host' });
    d.content.append(header, host);
    document.body.append(d);

    host.append(loading({ height: 300 }));

    try {
        const posts = await getFromCloudAPI('blog', {});

        host.replaceChildren(
            el(
                'div',
                { className: 'blog-grid' },
                posts.map((post) =>
                    el(
                        'button',
                        {
                            className: 'blog-card',
                            onClick: () => navigate(`/${city}/blog/${post.id}`),
                        },
                        el('img', { src: post.image, alt: post.title, className: 'blog-card-image' }),
                        el(
                            'div',
                            { className: 'blog-card-content' },
                            el('h6', {}, post.title),
                            el('span', { className: 'blog-card-meta' }, `${post.date} · ${post.description}`),
                        ),
                    ),
                ),
            ),
        );
    } catch {
        host.replaceChildren(el('p', { className: 'dialog-text' }, t('Shared.loadError')));
    }

    return {
        destroy() {
            d.remove();
        },
    };
}

export async function mountBlogPostDialog(id) {
    const d = dialog({ fullscreen: window.innerWidth <= 900, closeable: false });

    const header = el(
        'div',
        { className: 'page-header' },
        el(
            'button',
            { className: 'icon-button', onClick: () => window.history.back() },
            renderIcon('ArrowBack'),
        ),
        el('h5', {}, t('Blog.blog')),
    );

    const host = el('div', { className: 'blog-host' });
    d.content.append(header, host);
    document.body.append(d);

    host.append(loading({ height: 300 }));

    try {
        const post = await getFromCloudAPI(`blog/${id}`, {});

        // Prosty renderer markdown (odpowiednik ui/Markdown.tsx)
        const body = el('div', { className: 'blog-post' });
        renderMarkdown(body, post.content || '');

        host.replaceChildren(
            el('h1', { className: 'blog-post-title' }, post.title),
            el('span', { className: 'blog-card-meta' }, post.date),
            el('img', { src: post.image, alt: post.title, className: 'blog-post-image' }),
            body,
        );
    } catch {
        host.replaceChildren(el('p', { className: 'dialog-text' }, t('Shared.loadError')));
    }

    return {
        destroy() {
            d.remove();
        },
    };
}

/** Minimalny renderer markdown (nagłówki, pogrubienia, listy, linki, obrazy). */
function renderMarkdown(container, markdown) {
    const lines = markdown.split('\n');
    let inList = false;

    const inline = (text) => {
        const span = el('span');
        // **pogrubienie**, *kursywa*, [tekst](url), ![alt](url)
        const html = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" />')
            .replace(
                /\[([^\]]+)\]\(([^)]+)\)/g,
                '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>',
            )
            .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
            .replace(/\*([^*]+)\*/g, '<i>$1</i>');
        span.innerHTML = html;
        return span;
    };

    const closeList = () => {
        inList = false;
    };

    for (const line of lines) {
        if (line.startsWith('# ')) {
            closeList();
            container.append(el('h2', {}, inline(line.slice(2))));
        } else if (line.startsWith('## ')) {
            closeList();
            container.append(el('h3', {}, inline(line.slice(3))));
        } else if (line.startsWith('### ')) {
            closeList();
            container.append(el('h4', {}, inline(line.slice(4))));
        } else if (/^[-*] /.test(line)) {
            if (!inList) {
                inList = true;
                container.append(el('ul', { 'data-list': 'open' }));
            }
            container.lastElementChild?.append(el('li', {}, inline(line.slice(2))));
        } else if (line.trim() === '') {
            closeList();
        } else {
            closeList();
            container.append(el('p', {}, inline(line)));
        }
    }
}
