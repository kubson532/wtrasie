/**
 * Widok miasta — port komponentów:
 *   pages/Root.tsx  — FAB menu/wstecz, szuflada menu, alert powitalny
 *   pages/City.tsx  — FAB wyszukiwania, ulubionych, warstw
 *   hooks/useMarkers.ts + map/Markers.tsx — strumień mapFeatures i znaczniki
 */

import { el, fab, dialog, drawer } from '../ui.js';
import { renderIcon, renderLogo, renderDiscordIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, pathname, segments, goBack, isMenuState } from '../router.js';
import { createEventQuery } from '../api.js';
import { filterStore, settings } from '../store.js';
import { APP } from '../branding.js';
import {
    getMap,
    updateVehicleMarkers,
    updateStopMarkers,
    updateDotMarkers,
    removeDotMarkers,
    clearStopMarkers,
    clearVehicleMarkers,
    getBoundsString,
} from '../map.js';
import { buildCitySuffix } from '../util.js';

/** Znaczniki + strumień mapFeatures (port useMarkers + Markers). */
export function mountMarkers(city, host) {
    let stream = null;
    let mapState = { bounds: null, zoom: 0 };

    const badge = el(
        'div',
        { className: 'filter-badge' },
        el('span', { className: 'filter-badge-count' }),
    );
    const filterFab = fab({
        icon: 'FilterAltOutlined',
        title: t('Filter.filter'),
        onClick: () => navigate(`/${city}/filter`),
    });

    const badgeWrapper = el('div', { className: 'filter-fab' }, badge, filterFab);
    host.append(badgeWrapper);

    const refreshBadge = () => {
        const count = filterStore.routes.length + filterStore.models.length;
        badge.classList.toggle('visible', count > 0);
        badge.querySelector('.filter-badge-count').textContent = count;
        filterFab.replaceChildren(
            renderIcon(count > 0 ? 'FilterAlt' : 'FilterAltOutlined', { size: 24 }),
        );
    };

    const connect = () => {
        stream?.close();

        const isFiltering = filterStore.tempRoutes.length > 0 || filterStore.tempModels.length > 0;

        const params = new URLSearchParams();
        const activeRoutes = isFiltering ? filterStore.tempRoutes : filterStore.routes;
        const activeModels = isFiltering ? filterStore.tempModels : filterStore.models;

        const filterRoutes = activeRoutes.map((r) => r[0]).join(',');
        const filterModels = activeModels.join(',');

        if (filterRoutes) params.set('filterRoutes', filterRoutes);
        if (filterModels) params.set('filterModels', filterModels);

        const query = params.toString();

        let endpoint;
        if (isFiltering) {
            endpoint = `mapFeatures/0/0,0,0,0/stream${query ? `?${query}` : ''}`;
        } else if (mapState.bounds) {
            endpoint = `mapFeatures/${mapState.zoom}/${mapState.bounds}/stream${query ? `?${query}` : ''}`;
        } else {
            return;
        }

        let useDots = false;

        stream = createEventQuery({
            city,
            endpoint,
            onInitial: (data) => {
                updateStopMarkers(data.stops || [], (stop) => {
                    const stopType = stop[1] === 'pkp' ? 'station' : 'stop';
                    navigate(
                        `/${city}/${stopType}/${encodeURIComponent(stop[0])}` +
                            buildCitySuffix(stop[1], city),
                    );
                });
            },
            onMessage: (data) => {
                if (data.positions?.length) {
                    if (useDots) {
                        removeDotMarkers();
                        useDots = false;
                    }
                    updateVehicleMarkers(data.positions, (vehicle) => {
                        navigate(
                            `/${city}/vehicle/${encodeURIComponent(vehicle[0])}` +
                                buildCitySuffix(vehicle[1], city),
                        );
                    });
                }
                if (data.dots?.length) {
                    useDots = true;
                    clearVehicleMarkers();
                    updateDotMarkers(data.dots);
                } else if (data.positions) {
                    removeDotMarkers();
                    useDots = false;
                }
            },
        });
    };

    const onMoveEnd = (event) => {
        if (event.originalEvent) {
            mapState = { bounds: getBoundsString(), zoom: Math.floor(getMap().getZoom()) };
            connect();
        }
    };

    const map = getMap();

    // Początkowy stan mapy
    mapState = { bounds: getBoundsString(), zoom: Math.floor(map.getZoom()) };
    map.on('moveend', onMoveEnd);

    refreshBadge();
    connect();

    return {
        refresh: () => {
            refreshBadge();
            connect();
        },
        destroy() {
            stream?.close();
            map.off('moveend', onMoveEnd);
            badgeWrapper.remove();
            clearVehicleMarkers();
            clearStopMarkers();
            removeDotMarkers();
        },
    };
}

/** FABy prawej kolumny (port City.tsx). */
export function mountCityFabs(city, host) {
    const searchFab = fab({
        icon: 'Search',
        title: t('Search.bestResults') && 'Szukaj',
        position: { right: '16px', top: '16px' },
        onClick: () => navigate(`/${city}/search`),
    });

    const favFab = fab({
        icon: 'StarBorder',
        title: t('Vehicle.favoriteStops'),
        position: { right: '16px', top: `${16 * 7}px` },
        onClick: () => navigate(`/${city}/favoriteStops`),
    });

    const layersFab = fab({
        icon: 'LayersOutlined',
        title: t('Layers.layers'),
        position: { right: '16px', top: `${16 * 10}px` },
        onClick: () => navigate(`/${city}/layers`),
    });

    host.append(searchFab, favFab, layersFab);

    return () => {
        searchFab.remove();
        favFab.remove();
        layersFab.remove();
    };
}

/** FAB menu/wstecz (port Root.tsx). */
export function mountMenuFab(host) {
    const button = fab({
        icon: 'Menu',
        title: t('Menu.welcome'),
        position: { left: '16px', top: '16px' },
        onClick: () => {
            const showBackButton = !!pathname().split('/')[3];
            if (showBackButton) {
                goBack({ ignoreState: true });
            } else {
                navigate(pathname(), { state: 'menu' });
            }
        },
    });

    host.append(button);

    return {
        refresh() {
            const showBackButton = !!pathname().split('/')[3];
            button.replaceChildren(renderIcon(showBackButton ? 'ArrowBack' : 'Menu', { size: 24 }));
        },
        destroy() {
            button.remove();
        },
    };
}

/** Dialog z instrukcją instalacji (gdy przeglądarka nie oferuje promptu). */
function showInstallHintDialog() {
    const d = dialog({ onClose: () => d.remove() });

    d.content.append(
        el('h5', { className: 'dialog-title' }, t('Menu.installTitle')),
        el(
            'div',
            { className: 'install-hint' },
            el(
                'div',
                { className: 'install-hint-row' },
                el('span', { className: 'install-hint-icon' }, renderIcon('Smartphone', { size: 24 })),
                el(
                    'div',
                    {},
                    el('b', {}, t('Menu.installAndroid')),
                    el('span', {}, t('Menu.installAndroidHint')),
                ),
            ),
            el(
                'div',
                { className: 'install-hint-row' },
                el('span', { className: 'install-hint-icon' }, renderIcon('Smartphone', { size: 24 })),
                el(
                    'div',
                    {},
                    el('b', {}, t('Menu.installIos')),
                    el('span', {}, t('Menu.installIosHint')),
                ),
            ),
            el(
                'div',
                { className: 'install-hint-row' },
                el('span', { className: 'install-hint-icon' }, renderIcon('Laptop', { size: 24 })),
                el(
                    'div',
                    {},
                    el('b', {}, t('Menu.installDesktop')),
                    el('span', {}, t('Menu.installDesktopHint')),
                ),
            ),
        ),
        el(
            'button',
            { className: 'button contained dialog-close', onClick: () => d.close() },
            'OK',
        ),
    );

    document.body.append(d);
}

/** Instalacja aplikacji (PWA): prompt przeglądarki albo instrukcja. */
function installApp() {
    const prompt = window.__installPrompt;
    if (prompt) {
        prompt.prompt();
        prompt.userChoice?.finally(() => {
            window.__installPrompt = null;
        });
    } else {
        showInstallHintDialog();
    }
}

/** Szuflada menu (port Menu/index.tsx + MenuItem.tsx). */
export function createMenuDrawer() {
    const city = segments()[0] || localStorage.getItem('city') || 'cities';
    const path = pathname().split('/')[2];

    const items = [
        { icon: 'Place', outlinedIcon: 'PlaceOutlined', name: t('Menu.map'), active: !path, to: `/${city}` },
        { icon: 'Directions', outlinedIcon: 'Directions', name: t('Planner.title'), active: path === 'planner', to: `/${city}/planner` },
        {
            icon: 'EventNote',
            outlinedIcon: 'EventNoteOutlined',
            name: t('Menu.schedules'),
            active: path === 'routes',
            to: `/${city}/routes`,
        },
        { icon: 'History', outlinedIcon: 'History', name: t('Menu.executions'), active: path === 'executions', to: `/${city}/executions` },
        {
            icon: 'Settings',
            outlinedIcon: 'SettingsOutlined',
            name: t('Menu.settings'),
            active: path === 'settings',
            to: `/${city}/settings`,
        },
        {
            icon: 'Download',
            outlinedIcon: 'Download',
            name: t('Menu.installApp'),
            active: false,
            onClick: installApp,
        },
    ];

    const list = el(
        'div',
        { className: 'menu-list' },
        items.map((item) =>
            el(
                'button',
                {
                    className: 'menu-drawer-item' + (item.active ? ' active' : ''),
                    onClick: () => {
                        if (item.onClick) item.onClick();
                        else navigate(item.to, { state: undefined });
                        drawerElement.close();
                    },
                },
                renderIcon(item.active ? item.icon : item.outlinedIcon || item.icon),
                el('span', {}, item.name),
            ),
        ),
    );

    const header = el(
        'div',
        {
            className: 'menu-header',
            onClick: () => {
                navigate('/cities');
                drawerElement.close();
            },
        },
        renderLogo({ size: 72, color: 'hsla(0, 0%, 100%, 0.9)' }),
        el(
            'div',
            { className: 'menu-header-text' },
            el('b', {}, APP.name),
            el(
                'span',
                {},
                window.cities?.[city]?.name || city,
                renderIcon('KeyboardArrowDown', { size: 18 }),
            ),
        ),
    );

    const socials = el(
        'div',
        { className: 'menu-socials' },
        ...[
            ['Facebook', 'https://www.facebook.com/profile.php?id=61558868339377'],
            ['Instagram', 'https://www.instagram.com/zbiorkom.live/'],
            ['GitHub', 'https://github.com/DomeQdev/zbiorkom.live'],
        ].map(([icon, href]) =>
            el(
                'a',
                { href, target: '_blank', className: 'menu-social' },
                renderIcon(icon, { size: 22 }),
            ),
        ),
        el('a', { href: 'https://discord.gg/gUhMz2Wckf', target: '_blank', className: 'menu-social' }, renderDiscordIcon({ size: 22 })),
        el('a', { href: 'mailto:admin@zbiorkom.live', target: '_blank', className: 'menu-social' }, renderIcon('Email', { size: 22 })),
    );

    const footer = el(
        'div',
        { className: 'menu-footer' },
        socials,
        el(
            'a',
            { href: '/privacy-policy.pdf', target: '_blank', rel: 'noopener noreferrer', className: 'menu-footer-link' },
            t('Menu.privacyPolicy'),
        ),
        el(
            'span',
            {
                className: 'menu-footer-link',
                onClick: () => window.open('https://www.openstreetmap.org/copyright', '_blank'),
            },
            '\u00A9 OpenStreetMap contributors',
        ),
    );

    const content = el('div', { className: 'menu-drawer' }, header, list, footer);
    // Zamknięcie szuflady przez użytkownika = goBack (jak Root.tsx: setClose)
    const drawerElement = drawer(content, { onClose: () => goBack({ ignoreState: true }) });
    document.body.append(drawerElement);

    return drawerElement;
}

/** Alert powitalny (port WelcomeAlert.tsx). */
export async function mountWelcomeAlert(city) {
    if (!city) return;

    try {
        const lastSeenAlert = JSON.parse(localStorage.getItem('lastSeenAlert') || '0');
        const res = await fetch(`${window.Gay.welcomeAlertUrl}/${city}?version=6`);
        const data = await res.json();

        if (!data || (data.closeable && data.published <= lastSeenAlert)) return;

        localStorage.setItem('lastSeenAlert', String(data.published));

        const alertDialog = dialog({
            onClose: () => {},
        });

        alertDialog.content.append(
            el('div', { className: 'welcome-alert' }, el('h5', {}, data.title)),
            el('div', { html: data.body }),
        );

        if (data.closeable) {
            alertDialog.content.querySelector('.welcome-alert').append(
                el(
                    'button',
                    { className: 'icon-button', onClick: () => alertDialog.close() },
                    renderIcon('Close'),
                ),
            );
        }

        document.body.append(alertDialog);
    } catch {
        // Błąd pobierania alertu jest ignorowany (jak w oryginale)
    }
}

/** Propozycja przełączenia miasta (port suggestedCity z Markers.tsx). */
export function showSuggestedCity(suggestedCity, city) {
    document.querySelector('.suggested-city')?.remove();

    if (!suggestedCity || !window.cities?.[suggestedCity]) return;

    const box = el(
        'div',
        { className: 'suggested-city' },
        el('span', { style: { marginLeft: '8px' } }, t('Menu.switchTo'), ' ', el('b', {}, window.cities[suggestedCity].name), '?'),
        el(
            'button',
            {
                className: 'button contained',
                onClick: () => {
                    navigate(`/${suggestedCity}`, { replace: true });
                    localStorage.setItem('city', suggestedCity);
                },
            },
            t('Menu.yes'),
        ),
    );

    document.getElementById('root').append(box);
}
