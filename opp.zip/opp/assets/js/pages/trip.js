/**
 * Widok kursu/pojazdu — port komponentów:
 *   pages/Trip/index.tsx    — strumień, mapa, śledzenie pojazdu
 *   sheet/Trip/TripHeader   — nagłówek z przyciskami (śledź, menu, zamknij)
 *   sheet/Trip/TripMenu     — menu: ostatni sygnał, udostępnij, utrudnienia,
 *                             rozkład brygady, informacje o pojeździe
 *   sheet/Trip/TripContent  — oś czasu przystanków z opóźnieniami
 *   sheet/Trip/TripStop     — pojedynczy przystanek na osi czasu
 *   sheet/Trip/TripFooter   — opis kursu (przewoźnik itd.)
 *   pages/Trip/VehicleInfo  — informacje o pojeździe
 *   pages/Trip/TripAlerts   — utrudnienia
 */

import { el, alert, loading, bottomSheet, menu, dialog } from '../ui.js';
import { renderIcon, vehicleTypeIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, goBack, pathname, search, segments } from '../router.js';
import { createEventQuery, getFromAPI } from '../api.js';
import { vehicleStore, followStore, settings } from '../store.js';
import {
    getTime,
    msToTime,
    polylineToGeoJson,
    parseVehicleId,
    share,
    getSheetHeight,
    generateDarkScheme,
    buildCitySuffix,
    AlightType,
} from '../util.js';
import { vehicleHeadsign, vehicleDelay, sheetHeaderButtons } from './widgets.js';
import {
    getMap,
    updateTripRoute,
    removeTripRoute,
    updateTripVehicleMarker,
    getTripRoutePaths,
    fitBounds,
    setSoloVehicleMode,
} from '../map.js';

/**
 * Montuje arkusz kursu/pojazdu. kind: "trip" | "vehicle".
 * Zwraca obiekt z metodą destroy().
 */
export function mountTripSheet(city, kind, id, sheetHost) {
    vehicleStore.reset();
    followStore.reset();

    // Tryb SOLO: na mapie zostaje TYLKO ten pojazd — jego trasa, jego
    // przystanki (warstwa trip-stops) i jego ikonka. Pozostałe pojazdy,
    // kropki i przystanki miasta są ukrywane (map.js setSoloVehicleMode).
    setSoloVehicleMode(true);

    const header = el('div', { className: 'trip-header' });
    const content = el('div', { className: 'trip-content' });

    const sheet = bottomSheet({
        blocking: false,
        onDismiss: () => goBack(),
    });

    sheet.header.append(header);
    sheet.scroll.append(content);
    sheetHost.append(sheet.root);

    const map = getMap();

    // Śledzenie wyłącza się przy ręcznym przesuwaniu mapy (port Trip/index.tsx)
    const onMoveStart = (event) => {
        if (event.originalEvent) followStore.setIsFollowing(false);
        renderHeader();
    };
    map?.on('movestart', onMoveStart);

    /* ------------------------- Nagłówek ------------------------- */

    let pingInterval = null;

    const renderHeader = () => {
        header.replaceChildren();

        const trip = vehicleStore.trip;
        const vehicle = vehicleStore.vehicle;

        if (!trip && !vehicle) {
            header.append(
                el(
                    'div',
                    { style: { display: 'flex', gap: '8px' } },
                    el('div', { className: 'skeleton', style: { width: '72px', height: '26px', borderRadius: '4px' } }),
                    el('div', { className: 'skeleton', style: { width: '160px', height: '26px' } }),
                ),
            );
        } else {
            header.append(
                vehicleHeadsign(trip?.[2] || vehicle?.[2], {
                    shortName: trip?.[5],
                    headsign: trip?.[3],
                }),
            );
        }

        const buttons = [];

        if (vehicle?.[4]) {
            buttons.push({
                icon: followStore.isFollowing ? 'GpsFixed' : 'GpsNotFixed',
                title: 'Śledź pojazd',
                active: followStore.isFollowing,
                onClick: () => {
                    followStore.setIsFollowing(true);
                    renderHeader();
                },
            });
        }

        buttons.push({
            icon: 'MoreVert',
            title: 'Menu',
            onClick: (event) => openTripMenu(event.currentTarget),
        });

        buttons.push({ icon: 'Close', title: 'Zamknij', onClick: () => goBack() });

        header.append(sheetHeaderButtons(buttons));
    };

    /** Menu kursu (port TripMenu.tsx). */
    function openTripMenu(anchor) {
        const items = [];

        // Ostatni ping (tylko wyświetlenie)
        if (vehicleStore.lastPing) {
            const pingLabel = el(
                'span',
                {},
                el('b', { id: 'lastPing' }, msToTime(Date.now() - vehicleStore.lastPing, true)),
                ` ${t('Shared.ago')}`,
            );
            items.push({ label: pingLabel, disabled: true });

            if (pingInterval) clearInterval(pingInterval);
            pingInterval = setInterval(() => {
                const node = document.getElementById('lastPing');
                if (!node || !vehicleStore.lastPing) return;
                node.textContent = msToTime(Date.now() - vehicleStore.lastPing, true);
            }, 1000);
        }

        items.push({
            icon: 'Share',
            label: t('Shared.share'),
            onClick: () => share(window.location.href),
        });

        if (vehicleStore.alerts.length > 0) {
            items.push({
                icon: 'Report',
                label: t('Vehicle.alerts'),
                trailing: el('span', { className: 'menu-item-count' }, String(vehicleStore.alerts.length)),
                onClick: () =>
                    navigate(pathname() + '/alerts' + search()),
            });
        }

        if (vehicleStore.vehicle?.[3]) {
            items.push({
                icon: 'EventNote',
                label: t('Vehicle.brigadeSchedule'),
                onClick: () =>
                    navigate(pathname() + '/brigade' + search()),
            });
        }

        const vehicleNumber = vehicleStore.vehicle
            ? parseVehicleId(vehicleStore.vehicle[0]).vehicleNumber
            : null;
        if (vehicleStore.vehicle && vehicleNumber && !vehicleNumber.startsWith('_')) {
            items.push({
                icon: 'Build',
                label: t('Vehicle.vehicleInfo'),
                onClick: () => navigate(pathname() + '/info' + search()),
            });
        }

        menu(anchor, items);
    }

    /* ------------------------ Oś czasu --------------------------- */

    const renderContent = () => {
        content.replaceChildren();

        const trip = vehicleStore.trip;
        const itinerary = vehicleStore.itinerary;
        const stops = vehicleStore.stops;
        const vehicle = vehicleStore.vehicle;
        const sequence = vehicleStore.sequence;

        if (!trip && !itinerary) {
            if (vehicleStore.streamError) {
                content.append(
                    alert({
                        title: t('Shared.loadError'),
                        description: String(vehicleStore.streamError),
                    }),
                );
                return;
            }
            if (vehicleStore.streamLoading || vehicleStore.fresh) {
                content.append(loading({ height: '50vh' }));
                return;
            }
            content.append(alert({ title: t('Vehicle.vehicleNotFound') }));
            return;
        }

        if (!trip || !itinerary) {
            content.append(alert({ icon: 'Warning', color: 'warning', title: t('Vehicle.tripNotFound') }));
            return;
        }

        if (!stops) {
            content.append(loading({ height: '50vh' }));
            return;
        }

        const theme = generateDarkScheme(trip[2][6]);
        const color = [trip[2][6], theme.primary, theme.onPrimary];

        const list = el('div', { className: 'trip-stop-list' });

        itinerary[0].forEach((itineraryStop, index) => {
            const row = tripStopRow(trip, vehicle, itineraryStop, index, color, stops[index], sequence);
            if (row) list.append(row);
        });

        // Stopka z opisem kursu (port TripFooter.tsx)
        const description = trip[6];
        if (description?.length) {
            list.append(
                el(
                    'div',
                    { className: 'trip-footer' },
                    description.map(([key, value], index) =>
                        el(
                            'span',
                            {},
                            key === 'Vehicle.operatedBy'
                                ? t('Vehicle.operatedBy', { value })
                                : `${key}: ${value}`,
                            index < description.length - 1 ? ' · ' : '',
                        ),
                    ),
                ),
            );
        }

        content.append(list);

        // Przewijanie do aktualnego przystanku przy śledzeniu (port TripContent)
        if (followStore.isFollowing) {
            const stopsLength = itinerary[0].length;
            const stopScrollIndex =
                sequence === undefined || sequence < 1 || !stopsLength
                    ? 0
                    : sequence - (sequence + 1 === stopsLength ? 0 : 1);

            const row = list.children[stopScrollIndex];
            row?.scrollIntoView({
                behavior: 'smooth',
                block: stopScrollIndex + 1 === stopsLength ? 'end' : 'start',
            });
        }
    };

    /** Wiersz przystanku kursu (port TripStop.tsx). */
    function tripStopRow(trip, vehicle, stop, index, color, update, sequence) {
        const departure = update?.[1];
        if (!update || !stop || !departure) return null;

        const scheduled = departure[0] ?? 0;
        const delay = departure[1] ?? 0;
        const estimatedDeparture = scheduled + delay;
        const status = departure[2];

        const arrival = update[0] ?? departure;
        const arrScheduled = arrival[0] ?? 0;
        const arrDelay = arrival[1] ?? 0;
        const arrEstimated = arrScheduled + arrDelay;

        const shouldUseSeconds = index === 0 && estimatedDeparture - Date.now() < 100000;
        const hasDeparted =
            status === 3 ||
            (sequence === undefined ? estimatedDeparture < Date.now() : sequence > index);

        const platform = update[2] || stop[3];
        const track = update[3];
        const stopData = stop[0];
        const alight = stop[1];
        const isForbidden = (alight & AlightType.Forbidden) !== 0;
        const isOnDemand = (alight & AlightType.OnDemand) !== 0;
        const stopCode = stopData[3];
        const isTrain = trip[2][5] === 2;

        /* Port TripStopTimes.tsx — czasy przyjazdu/odjazdu z kolorami opóźnień.
         * Zgłoszenie użytkownika: przyciemniane (0.7 jak w oryginale) są
         * TYLKO czasy przystanków przejechanych — nazwy i kropki zostają
         * pełnym kontrastem. */
        const isLiveStatus = status !== 3 && status !== 0;
        const delayType = delay > 0 ? 'delayed' : 'early';
        const arrivalTimeStr = getTime(arrEstimated);
        const departureTimeStr = getTime(estimatedDeparture);
        const isSingleTime = arrivalTimeStr === departureTimeStr;
        const isSingleTimeButDelayed = !isTrain && isSingleTime && Math.abs(delay) >= 60000;

        const timesBox = el(
            'div',
            { className: 'trip-stop-times' + (hasDeparted ? ' departed' : '') },
        );

        if (isSingleTimeButDelayed) {
            timesBox.append(
                el('span', { className: 'trip-stop-time struck' }, getTime(scheduled)),
                el(
                    'span',
                    { className: `trip-stop-time delay delay-${isLiveStatus ? delayType : 'unknown'}` },
                    departureTimeStr,
                ),
            );
        } else {
            const times = isSingleTime ? [departure] : [arrival, departure];

            times.forEach((time) => {
                const timeScheduled = time[0] ?? 0;
                const timeDelay = time[1] ?? 0;
                const timeEstimated = timeScheduled + timeDelay;

                const isNumber = typeof timeDelay === 'number';
                const delayMinutes = isNumber && Math.floor(Math.abs(timeDelay) / 60000);
                const delayClass =
                    isLiveStatus && isNumber && delayMinutes
                        ? timeDelay > 0
                            ? 'delayed'
                            : 'early'
                        : 'unknown';

                timesBox.append(
                    el(
                        'span',
                        { className: `trip-stop-time delay delay-${delayClass}` },
                        getTime(timeEstimated),
                    ),
                );
            });
        }

        const row = el(
            'button',
            {
                className: 'trip-stop-row' + (hasDeparted ? ' departed' : ''),
                onClick: () => {
                    const map = getMap();
                    map?.flyTo({
                        center: stopData[4],
                        zoom: map.getZoom() > 15 ? map.getZoom() : 15,
                    });

                    /* Kliknięcie przystanku na liście otwiera jego arkusz
                     * (popup z dołu: odjazdy itp.) — zgłoszenie użytkownika.
                     * Przejście idzie przez router, więc strzałka wstecz /
                     * przycisk back telefonu wraca do kursu. */
                    const urlCity = segments()[0] || city;
                    navigate(
                        `/${urlCity}/stop/${encodeURIComponent(stopData[0])}` +
                            buildCitySuffix(stopData[1], city),
                        { state: -1 },
                    );
                },
            },
            el(
                'div',
                { className: 'trip-stop-icon-col' },
                timesBox,
                vehicleStopIcon(color, index, trip[2][5], sequence === index ? vehicle?.[8] : undefined),
            ),
            el(
                'div',
                { className: 'trip-stop-text' },
                el(
                    'span',
                    { className: 'trip-stop-name' },
                    isForbidden && renderIcon('RemoveCircleOutline', { size: 18 }),
                    isOnDemand && renderIcon('WavingHand', { size: 16 }),
                    `${stopData[2]}${stopCode ? ` ${stopCode}` : ''}`,
                ),
                el(
                    'span',
                    { className: 'trip-stop-secondary' },
                    vehicleDelay(delay, status),
                    platform && el('span', {}, ` · ${t('Vehicle.platform')} `, el('b', {}, platform)),
                    track && el('span', {}, ` · ${t('Vehicle.track')} `, el('b', {}, track)),
                ),
            ),
            !hasDeparted &&
                (() => {
                    const diff = shouldUseSeconds
                        ? Math.round((estimatedDeparture - Date.now()) / 1000)
                        : Math.round((estimatedDeparture - Date.now()) / 60000);
                    return el(
                        'div',
                        { className: 'trip-stop-countdown' },
                        el('span', {}, diff > 0 ? String(diff) : '<1'),
                        el('span', {}, t(shouldUseSeconds ? 'Vehicle.sec' : 'Vehicle.min')),
                    );
                })(),
        );

        if (sequence === index) row.classList.add('current');

        return row;
    }

    /** Ikona przystanku na osi (port TripStopIcon.tsx). */
    function vehicleStopIcon(color, index, type, percentTraveled, lineMargin) {
        const [routeColor, text, background] = color;

        const wrap = el('span', { className: 'trip-stop-icons' });

        const dot = el('span', {
            className: 'vehicleStopIcon',
            style: { border: `3px solid ${routeColor}` },
        });
        wrap.append(dot);

        if (index !== 0) {
            const line = el('span', {
                className: 'vehicleStopIconLine',
                style: {
                    backgroundColor: routeColor,
                    ...(lineMargin ? { marginLeft: `${lineMargin}px` } : {}),
                },
            });

            if (percentTraveled !== undefined) {
                const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                icon.setAttribute('viewBox', '0 0 24 24');
                icon.setAttribute('width', '26px');
                icon.setAttribute('height', '26px');
                icon.setAttribute('fill', 'currentColor');
                icon.style.cssText = `position:absolute;margin-left:-5px;margin-top:-14px;top:${percentTraveled}%;color:${text};background-color:${background};border-radius:50%;padding:3px;z-index:20;border:1px solid ${routeColor};transition:top 0.5s`;
                icon.innerHTML = vehicleTypeIcon(type);
                line.append(icon);
            }

            wrap.append(line);
        }

        return wrap;
    }

    /* -------------------------- Mapa ------------------------------ */

    let routeDrawn = false;

    /** Ścieżka trasy kursu (do przyczepiania pojazdu do linii — snap). */
    let tripRoutePath = null;

    const applyMap = () => {
        const trip = vehicleStore.trip;
        const itinerary = vehicleStore.itinerary;
        const vehicle = vehicleStore.vehicle;

        // Trasa na mapie (port TripRoute)
        if (trip && itinerary && !routeDrawn) {
            routeDrawn = true;

            const shape =
                typeof itinerary[1] === 'string' ? polylineToGeoJson(itinerary[1]) : itinerary[1];

            tripRoutePath = shape?.geometry?.coordinates ?? null;

            const stopsGeoJson = {
                type: 'FeatureCollection',
                features: itinerary[0].map((iStop) => {
                    const s = iStop[0];
                    const code = s[3];
                    const label = code ? `${s[2]} ${code}` : s[2];
                    return {
                        type: 'Feature',
                        geometry: { type: 'Point', coordinates: s[4] },
                        properties: { id: s[0], name: label, variant: false },
                    };
                }),
            };

            updateTripRoute(
                { type: 'FeatureCollection', features: [{ ...shape, properties: { variant: false } }] },
                stopsGeoJson,
                trip[2][6],
            );
        }

        // Pojazd (ikonka) zawsze jedzie PO LINII trasy — rzutujemy pozycję
        // GPS na łamaną trasy (nie może wisać poza linią).
        if (vehicle) updateTripVehicleMarker(vehicle, tripRoutePath || getTripRoutePaths()[0]);

        // Śledzenie: przesuń mapę do pojazdu albo dopasuj do początku trasy (port Trip/index.tsx)
        if (!vehicleStore.fresh && !followStore.isFollowing) return;

        if (vehicle?.[4]) {
            getMap()?.flyTo({
                center: vehicle[4],
                zoom: getMap().getZoom() > 15 ? getMap().getZoom() : 15,
            });
        } else if (trip && itinerary && vehicleStore.fresh) {
            const stops = itinerary[0];
            const now = Date.now();

            let startIndex;
            const sequence = vehicleStore.sequence;
            const stopUpdates = vehicleStore.stops;
            if (sequence !== undefined && sequence !== -1) {
                startIndex = sequence;
            } else if (stopUpdates?.length) {
                const upcoming = stopUpdates.findIndex((u) => {
                    const dep = u[1];
                    return dep[0] + dep[1] >= now;
                });
                startIndex = upcoming === -1 ? Math.max(0, stops.length - 3) : upcoming;
            } else {
                startIndex = 0;
            }

            const slice = stops.slice(startIndex, startIndex + 3);

            if (slice.length) {
                let minLng = Infinity,
                    minLat = Infinity,
                    maxLng = -Infinity,
                    maxLat = -Infinity;
                for (const s of slice) {
                    const [lng, lat] = s[0][4];
                    if (lng < minLng) minLng = lng;
                    if (lat < minLat) minLat = lat;
                    if (lng > maxLng) maxLng = lng;
                    if (lat > maxLat) maxLat = lat;
                }

                fitBounds(
                    [
                        [minLng, minLat],
                        [maxLng, maxLat],
                    ],
                    {
                        padding: { left: 30, right: 30, top: 30, bottom: getSheetHeight() },
                        maxZoom: 16,
                    },
                );
            }
        }

        vehicleStore.setFresh(false);
    };

    /* ------------------------ Strumień ----------------------------- */

    const endpoint =
        kind === 'trip'
            ? `trips/${encodeURIComponent(id)}/stream`
            : `positions/${encodeURIComponent(id)}/stream`;

    const stream = createEventQuery({
        city,
        endpoint,
        onInitial: (rawInitial) => {
            let itinerary = [...rawInitial.itinerary];
            if (itinerary[1] && typeof itinerary[1] === 'string') {
                // Dekodowanie polyline następuje przy rysowaniu (patrz applyMap)
            }
            vehicleStore.setItinerary(itinerary);
            vehicleStore.setTrip(rawInitial.trip);
            vehicleStore.setStops(undefined);
            vehicleStore.setSequence(undefined);
            if (vehicleStore.fresh === undefined) vehicleStore.setFresh(true);

            renderHeader();
            renderContent();
            applyMap();
        },
        onMessage: (rawData) => {
            if (rawData.position) {
                vehicleStore.setVehicle(rawData.position);
                vehicleStore.setLastPing(rawData.position[6]);
            }
            if (rawData.stops) {
                vehicleStore.setStops(rawData.stops.map((stop) => [stop[0], stop[1], '', '', []]));
            }
            if (rawData.sequence !== undefined) {
                vehicleStore.setSequence(rawData.sequence);
            }
            if (rawData.alerts) {
                vehicleStore.setAlerts(rawData.alerts);
            }

            renderHeader();
            renderContent();
            applyMap();
        },
        onState: ({ loading, error }) => {
            vehicleStore.setStreamStatus({ loading, error });
            renderContent();
        },
    });

    renderHeader();
    renderContent();

    return {
        sheet,
        destroy() {
            if (pingInterval) clearInterval(pingInterval);
            stream.destroy();
            sheet.close();
            removeTripRoute();
            updateTripVehicleMarker(null);

            // Koniec trybu SOLO — pojazdy, kropki i przystanki miasta
            // wracają na mapę (event -> odświeżenie strumienia markerów).
            setSoloVehicleMode(false);

            map?.off('movestart', onMoveStart);
            vehicleStore.reset();
            followStore.reset();
        },
    };
}

/* ------------------ Dialogi podrzędne kursu ------------------------- */

/** Informacje o pojeździe (port pages/Trip/VehicleInfo.tsx). */
export async function mountVehicleInfoDialog(city, vehicleId) {
    const d = dialog({ onClose: () => goBack() });

    d.content.append(el('h5', { className: 'dialog-title' }, t('Vehicle.vehicleInfo')));

    try {
        const data = await getFromAPI(city, `vehicles/vehicle/${encodeURIComponent(vehicleId)}`, {});

        if (!data) {
            d.content.append(el('p', { className: 'dialog-text' }, t('VehicleInfo.noData')));
        } else {
            const rows = [
                ['VehicleInfo.model', data[1]],
                ['VehicleInfo.prodYear', data[2]],
                ['VehicleInfo.carrier', data[3]],
            ];

            d.content.append(
                el(
                    'div',
                    { className: 'vehicle-info' },
                    rows.map(
                        ([key, value]) =>
                            value &&
                            el(
                                'div',
                                { className: 'vehicle-info-row' },
                                el('span', { className: 'vehicle-info-key' }, t(key)),
                                el('span', { className: 'vehicle-info-value' }, String(value)),
                            ),
                    ),
                ),
            );
        }
    } catch {
        d.content.append(el('p', { className: 'dialog-text' }, t('Shared.loadError')));
    }

    d.content.append(
        el(
            'button',
            { className: 'button contained dialog-close', onClick: () => d.close() },
            t('Time.cancel') === 'Anuluj' ? 'OK' : 'OK',
        ),
    );

    document.body.append(d);
}

/** Utrudnienia kursu (port pages/Trip/TripAlerts.tsx). */
export function mountTripAlertsDialog(alerts) {
    const d = dialog({ onClose: () => goBack() });

    d.content.append(el('h5', { className: 'dialog-title' }, t('Vehicle.alerts')));

    if (!alerts?.length) {
        d.content.append(
            alert({
                icon: 'Warning',
                color: 'warning',
                title: t('Vehicle.alertsEmpty'),
                description: t('Vehicle.alertsEmptyDescription'),
            }),
        );
    } else {
        d.content.append(
            el(
                'div',
                { className: 'alerts-list' },
                alerts.map((alertTuple) => {
                    const [title, description, url, publishedAt, activeFrom, activeUntil] = alertTuple;
                    return el(
                        'div',
                        { className: 'alert-card' },
                        el('h6', {}, title),
                        el('div', { className: 'alert-card-body', html: description }),
                        el(
                            'div',
                            { className: 'alert-card-meta' },
                            activeFrom && el('span', {}, t('Vehicle.alertsFrom', { moment: getTime(activeFrom) })),
                            activeUntil && el('span', {}, t('Vehicle.alertsUntil', { moment: getTime(activeUntil) })),
                            publishedAt && el('span', {}, t('Vehicle.alertsPublished', { moment: getTime(publishedAt) })),
                        ),
                        url && el('a', { href: url, target: '_blank', className: 'alert-card-link' }, t('Vehicle.alertsDetails')),
                    );
                }),
            ),
        );
    }

    document.body.append(d);
}
