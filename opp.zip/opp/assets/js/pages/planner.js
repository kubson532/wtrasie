/**
 * Planer tras — nowa zakładka oparta o silnik Transitous (MOTIS 2 API),
 * w stylu UI oryginalnego zbiorkom.live (te same chipy linii, oś czasu kursu
 * z trip.js, kolory typu pojazdu, przejścia piesze na szaro).
 *
 * Planer jest DOLNYM ARKUSZEM (popup z dołu) — tak jak widok linii
 * (linia + przystanki) i widok kursu: formularz i wyniki w jednym
 * arkuszu, podgląd wybranego wariantu w drugim (wróć = wyniki).
 *
 * Funkcje:
 *   - pola "skąd"/"dokąd" z PODPOWIEDZIAMI ROZWIJANÝMI OD POLA W DÓŁ,
 *     z rozmytym dopasowaniem (bez ogonków/cyfr/ukośników; spacja = filtry),
 *     z biasem geograficznym okolicy bieżącej mapy
 *   - "kiedy" (data) i "o której" (czas) + skrót "teraz"
 *   - obecna lokalizacja GPS jako punkt startowy
 *   - wybór punktu bezpośrednio z mapy (skąd/dokąd) + przycisk back
 *   - maksymalna liczba przesiadek
 *   - przełączniki wykluczeń przewoźników Z LOGOTYPAMI (wsiobusy/PKS/pociągi)
 *   - przycisk Szukaj
 *   - wyniki z opóźnieniami czasu rzeczywistego (realtime Transitous)
 *   - wybór wariantu → podgląd na mapie:
 *       • TRASA, KTÓRĄ MAM JECHAĆ = CZERWONA (pełna)
 *       • DOJAZD pojazdu — od jego bieżącej pozycji do mojego przystanku
 *         wsiadania = PÓŁPRZEZROCZYSTA (żywe pozycje, /api/v1/trip)
 *       • przejścia piesze na szaro (przerywane)
 *       • żywe pojazdy z moich linii są PRZYCZEPIANE do linii trasy (snap)
 *   - menu przystanków na trasie: pełna lista przystanków po drodze
 *     (lazy /api/v1/trip — plan zwraca tylko ucięte intermediateStops),
 *     kliknięcie przystanku otwiera arkusz z jego odjazdami (Transitous)
 *   - arkusz podglądu: strzałka wstecz / X + przycisk back telefonu
 */

import { el, bottomSheet, alert, loading } from '../ui.js';
import { renderIcon, defaultColors, vehicleTypeIcon } from '../icons.js';
import { t } from '../i18n.js';
import { goBack } from '../router.js';
import {
    geocode,
    plan,
    filterItineraries,
    decodePolyline,
    motisTime,
    legDelay,
    fetchLegStops,
    fetchStopTimes,
    fetchApproachPath,
} from '../transitous.js';
import { locationStore } from '../store.js';
import { getTime, getDelay, msToTime } from '../util.js';
import { PLANNER as BRAND } from '../branding.js';
import {
    getMap,
    updateTripRoute,
    removeTripRoute,
    fitBounds,
    setRoutePreview,
    setApproachPaths,
    setTripEndpoints,
    clearRoutePreview,
    clearVehicleMarkers,
    removeDotMarkers,
} from '../map.js';
import { vehicleDelay } from './widgets.js';

/* ------------------------------------------------------------------ */
/* Kolory linii wg typu pojazdu (branding.js — jeden plik do rebrandu)  */
/* ------------------------------------------------------------------ */

/** Kolor przejścia pieszego. */
const WALK_COLOR = BRAND.walkColor;

/** Kolor MOJEJ trasy na mapie — cała podróż na czerwono. */
const ROUTE_COLOR = BRAND.routeHighlight;

/** Mapowanie routeType (GTFS/MOTIS) → VehicleType zbiorkom. */
const GTFS_TYPE_TO_ZBIORKOM = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 6, 6: 6, 7: 7, 11: 8, 12: 9 };

/** Kolor nogi podróży: kolor linii GTFS → kolor typu pojazdu → szary. */
function legColor(leg, resolvedColors) {
    if (leg.mode === 'WALK') return WALK_COLOR;
    if (resolvedColors?.has(leg)) return resolvedColors.get(leg);
    if (leg.routeColor) return `#${String(leg.routeColor).replace('#', '')}`;
    const type = GTFS_TYPE_TO_ZBIORKOM[leg.routeType] ?? 3;
    return defaultColors[type] ?? defaultColors[3];
}

/** Kolor tekstu badge'a linii (GTFS routeTextColor albo biel). */
function legTextColor(leg) {
    if (leg.routeTextColor) return `#${String(leg.routeTextColor).replace('#', '')}`;
    return 'hsla(0, 0%, 100%, 0.8)';
}

/* ------------------------------------------------------------------ */
/* Rozwiązywanie kolizji kolorów linii                                 */
/* ------------------------------------------------------------------ */

/**
 * Rozwiązuje kolory nóg itinerarium: gdy DWIE linie mają TEN SAM kolor
 * (np. dwie linie autobusowe bez routeColor w GTFS — obie zielone),
 * kolejna noga dostaje kolor z palety awaryjnej (branding.js), żeby na
 * mapie dało się je odróżnić (zgłoszenie użytkownika).
 * Zwraca Map(leg → kolor).
 */
function resolveItineraryColors(itinerary) {
    const resolved = new Map();
    const used = [];
    let fallbackIndex = 0;

    for (const leg of itinerary.legs) {
        if (leg.mode === 'WALK') continue;

        const base = leg.routeColor
            ? `#${String(leg.routeColor).replace('#', '')}`
            : (defaultColors[GTFS_TYPE_TO_ZBIORKOM[leg.routeType] ?? 3] ?? defaultColors[3]);

        let color = base;
        // Czy kolor jest już zajęty przez inną nogę? (porównujemyHEX bez #)
        const isTaken = (candidate) =>
            used.some((usedColor) => normalizeHex(usedColor) === normalizeHex(candidate));

        if (isTaken(color)) {
            color =
                BRAND.collisionPalette[fallbackIndex % BRAND.collisionPalette.length];
            fallbackIndex++;
            // paleta też może się powtórzyć — wtedy przesuwaj aż znajdziesz wolny
            let guard = 0;
            while (isTaken(color) && guard++ < 16) {
                color = shiftHexHue(color, BRAND.collisionHueShift);
            }
        }

        used.push(color);
        resolved.set(leg, color);
    }

    return resolved;
}

/** Normalizuje zapis koloru do porównania (#RRGGBB, małe litery). */
function normalizeHex(color) {
    const hex = String(color).replace('#', '').toLowerCase();
    if (hex.length === 3) return hex.split('').map((c) => c + c).join('');
    return hex;
}

/** Przesuwa odcień koloru HEX o stopnie (HSL) — awaryjne rozdzielenie linii. */
function shiftHexHue(hex, degrees) {
    const clean = normalizeHex(hex);
    const r = parseInt(clean.slice(0, 2), 16) / 255;
    const g = parseInt(clean.slice(2, 4), 16) / 255;
    const b = parseInt(clean.slice(4, 6), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const l = (max + min) / 2;
    let h = 0;
    let s = 0;

    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        else if (max === g) h = ((b - r) / d + 2) / 6;
        else h = ((r - g) / d + 4) / 6;
    }

    h = (h + degrees / 360) % 1;
    if (h < 0) h += 1;

    // HSL → RGB
    const hueToRgb = (p, q, tt) => {
        if (tt < 0) tt += 1;
        if (tt > 1) tt -= 1;
        if (tt < 1 / 6) return p + (q - p) * 6 * tt;
        if (tt < 1 / 2) return q;
        if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
        return p;
    };

    let r2;
    let g2;
    let b2;
    if (s === 0) {
        r2 = g2 = b2 = l;
    } else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r2 = hueToRgb(p, q, h + 1 / 3);
        g2 = hueToRgb(p, q, h);
        b2 = hueToRgb(p, q, h - 1 / 3);
    }

    const toHex = (x) =>
        Math.round(Math.min(1, Math.max(0, x)) * 255)
            .toString(16)
            .padStart(2, '0');

    return `#${toHex(r2)}${toHex(g2)}${toHex(b2)}`;
}

/* ------------------------------------------------------------------ */
/* Logotypy kategorii przewoźników (SVG, własne — bez znaków firmowych) */
/* ------------------------------------------------------------------ */

const CARRIER_ICON_PATHS = {
    bus: 'M4 16c0 .88.39 1.67 1 2.22V20c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h8v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1.78c.61-.55 1-1.34 1-2.22V6c0-3.5-3.58-4-8-4s-8 .5-8 4v10zm3.5 1c-.83 0-1.5-.67-1.5-1.5S6.67 14 7.5 14s1.5.67 1.5 1.5S8.33 17 7.5 17zm9 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm1.5-6H6V6h12v5z',
    train:
        'M12 2c-4 0-8 .5-8 4v9.5C4 17.43 5.57 19 7.5 19L6 20.5v.5h2.23l2-2H14l2 2h2v-.5L16.5 19c1.93 0 3.5-1.57 3.5-3.5V6c0-3.5-3.58-4-8-4zM7.5 17c-.83 0-1.5-.67-1.5-1.5S6.67 14 7.5 14s1.5.67 1.5 1.5S8.33 17 7.5 17zm3.5-7H6V6h5v4zm2 0V6h5v4h-5zm3.5 7c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z',
};

/** Tworzy logotyp kategorii przewoźnika (plakietka SVG). */
function carrierLogo(kind, size = 34) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', size);
    svg.setAttribute('height', size);
    svg.setAttribute('viewBox', '0 0 48 48');
    svg.classList.add('carrier-logo');

    const style = BRAND.carriers[kind] ?? BRAND.carriers.wsiobus;

    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', '2');
    rect.setAttribute('y', '2');
    rect.setAttribute('width', '44');
    rect.setAttribute('height', '44');
    rect.setAttribute('rx', '10');
    rect.setAttribute('fill', style.bg);
    svg.append(rect);

    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', CARRIER_ICON_PATHS[style.icon]);
    path.setAttribute('fill', '#ffffff');
    path.setAttribute('transform', 'translate(12, 7) scale(1)');
    svg.append(path);

    if (style.label) {
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', '24');
        text.setAttribute('y', '43');
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('font-size', style.label.length > 4 ? '7' : '10');
        text.setAttribute('font-weight', 'bold');
        text.setAttribute('fill', style.labelColor);
        text.setAttribute('font-family', 'Roboto, sans-serif');
        text.textContent = style.label;
        svg.append(text);
    }

    return svg;
}

/* ------------------------------------------------------------------ */
/* Badge linii (chip nogi) — język routeChip zbiorkom, kolor wg typu    */
/* ------------------------------------------------------------------ */

function legBadge(leg, { small = false, resolvedColors } = {}) {
    if (leg.mode === 'WALK') {
        return el(
            'span',
            { className: 'planner-badge walk' + (small ? ' small' : '') },
            renderIcon('DirectionsWalk', { size: small ? 14 : 16 }),
        );
    }

    const color = legColor(leg, resolvedColors);

    const badge = el(
        'span',
        {
            className: 'planner-badge' + (small ? ' small' : ''),
            style: { backgroundColor: color, color: legTextColor(leg) },
        },
        (() => {
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('viewBox', '0 0 24 24');
            svg.setAttribute('width', '1em');
            svg.setAttribute('height', '1em');
            svg.setAttribute('fill', 'currentColor');
            const type = GTFS_TYPE_TO_ZBIORKOM[leg.routeType] ?? 3;
            svg.innerHTML = vehicleTypeIcon(type);
            return svg;
        })(),
        el('b', {}, leg.routeShortName || leg.mode),
    );

    return badge;
}

/* ------------------------------------------------------------------ */
/* Stan planera                                                         */
/* ------------------------------------------------------------------ */

const plannerState = {
    from: null, // { lat, lon, name }
    to: null,
    date: null, // YYYY-MM-DD
    time: null, // HH:MM
    maxTransfers: 3,
    excludeWsiobus: false,
    excludePks: false,
    excludeTrains: false,
    results: null,
    selectedItinerary: -1,
    picking: null, // 'from' | 'to' | null — tryb wyboru punktu z mapy
};

/** Domyślna data/godzina (teraz). */
function defaultDateTime() {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return {
        date: `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`,
        time: `${pad(now.getHours())}:${pad(now.getMinutes())}`,
    };
}

/** Czas odjazdu/przyjazdu przystanku nogi (realtime, ms). */
function placeTime(place, kind = 'departure') {
    return motisTime(place?.[kind] ?? place?.arrival ?? place?.departure);
}

/* ------------------------------------------------------------------ */
/* Widok planera                                                        */
/* ------------------------------------------------------------------ */

/**
 * Planer jako DOLNY ARKUSZ (popup z dołu) — jak widok linii i kursu:
 * formularz + wyniki przewijają się w arkuszu nad mapą. Podgląd wybranego
 * wariantu to drugi arkusz (back = powrót do wyników). sheetHost — wspólny
 * kontener arkuszy (#root .sheet-host). Zwraca obiekt z destroy().
 */
export function mountPlannerSheet(sheetHost) {
    const defaults = defaultDateTime();
    plannerState.date ??= defaults.date;
    plannerState.time ??= defaults.time;

    const plannerSheet = bottomSheet({
        snapPoints: [
            Math.round(window.innerHeight * 0.92),
            Math.round(window.innerHeight / 1.6),
            Math.round(window.innerHeight / 2.8),
        ],
        defaultSnap: 1,
        onDismiss: () => goBack(),
    });

    /* Nagłówek arkusza: strzałka wstecz + tytuł (przeciąganie za pasek
     * działa jak w innych arkuszach; przyciski nie blokują gestu). */
    plannerSheet.header.append(
        el(
            'div',
            { className: 'planner-sheet-header' },
            el(
                'button',
                {
                    className: 'icon-button',
                    onClick: () => goBack({ ignoreState: true }),
                },
                renderIcon('ArrowBack', { size: 20 }),
            ),
            el('h5', {}, t('Planner.title')),
        ),
    );

    const host = el('div', { className: 'planner-host' });
    plannerSheet.scroll.append(host);

    sheetHost.append(plannerSheet.root);
    requestAnimationFrame(() => plannerSheet.refresh());

    /* ---------------------- Pola skąd/dokąd ---------------------- */

    let activeField = null; // które pole ma otwartą listę podpowiedzi
    let activeFieldEl = null; // element pola, pod którym rozwija się lista
    let geocodeAbort = null;
    let geocodeTimer = null;

    const fromInput = el('input', {
        type: 'text',
        className: 'planner-input',
        placeholder: t('Planner.from'),
        value: plannerState.from?.name || '',
        autoComplete: 'off',
    });

    const toInput = el('input', {
        type: 'text',
        className: 'planner-input',
        placeholder: t('Planner.to'),
        value: plannerState.to?.name || '',
        autoComplete: 'off',
    });

    const suggestions = el('div', { className: 'planner-suggestions hidden' });

    /**
     * Umieszcza listę podpowiedzi BEZPOŚREDNIO POD AKTYWNYM POLEM
     * (rozwijana od pola w dół — zgłoszenie użytkownika), w obrębie
     * kontenera pól (position: relative).
     */
    function positionSuggestions(fieldEl) {
        if (!fieldEl) return;
        const fields = fieldEl.parentElement;
        const top = fieldEl.offsetTop + fieldEl.offsetHeight - 12;
        suggestions.style.top = `${top}px`;
        // szerokość wyrównana do pola (z lewej)
        suggestions.style.left = `${fieldEl.offsetLeft}px`;
        suggestions.style.right = 'auto';
        suggestions.style.maxWidth = '100%';
        void fields;
    }

    /** Podpowiedzi dla pola (geokodowanie Transitous, fuzzy, z debouncem). */
    const attachAutocomplete = (input, field, fieldEl) => {
        input.addEventListener('input', () => {
            activeField = field;
            activeFieldEl = fieldEl;
            plannerState[field] = null;
            clearTimeout(geocodeTimer);
            geocodeAbort?.abort();

            const query = input.value.trim();
            if (query.length < 2) {
                suggestions.classList.add('hidden');
                return;
            }

            geocodeTimer = setTimeout(async () => {
                geocodeAbort = new AbortController();
                try {
                    // Bias geograficzny podpowiedzi — wg środka bieżącej mapy
                    const map = getMap();
                    const center = map?.getCenter();

                    const results = await geocode(query, {
                        signal: geocodeAbort.signal,
                        nearLat: center?.lat,
                        nearLon: center?.lng,
                    });

                    if (activeField !== field) return;

                    suggestions.replaceChildren();
                    for (const result of results) {
                        suggestions.append(
                            el(
                                'button',
                                {
                                    className: 'planner-suggestion',
                                    onClick: () => {
                                        plannerState[field] = {
                                            lat: result.lat,
                                            lon: result.lon,
                                            name: result.name,
                                            stopId: result.id,
                                        };
                                        input.value = result.name;
                                        suggestions.classList.add('hidden');
                                    },
                                },
                                el(
                                    'span',
                                    { className: 'planner-suggestion-icon' },
                                    renderIcon(result.type === 'STOP' ? 'PinDrop' : 'Place', { size: 20 }),
                                ),
                                el(
                                    'div',
                                    { className: 'planner-suggestion-text' },
                                    el('span', { className: 'planner-suggestion-name' }, result.name),
                                    result.area &&
                                        el('span', { className: 'planner-suggestion-area' }, result.area),
                                ),
                            ),
                        );
                    }

                    if (results.length) {
                        positionSuggestions(fieldEl);
                        suggestions.classList.remove('hidden');
                    } else {
                        suggestions.classList.add('hidden');
                    }
                } catch {
                    /* przerwane żądanie — ignoruj */
                }
            }, 250);
        });

        input.addEventListener('focus', () => {
            activeField = field;
            activeFieldEl = fieldEl;
        });

        input.addEventListener('blur', () => {
            /* Ukryj podpowiedzi z opóźnieniem, by zadziałało kliknięcie */
            setTimeout(() => {
                if (activeField === field) suggestions.classList.add('hidden');
            }, 150);
        });
    };

    const fromField = el('div', { className: 'planner-field from' }, renderIcon('MyLocation', { size: 20 }), fromInput);
    const toField = el('div', { className: 'planner-field to' }, renderIcon('Place', { size: 20 }), toInput);
    attachAutocomplete(fromInput, 'from', fromField);
    attachAutocomplete(toInput, 'to', toField);

    /** Przyciski akcji przy polach (lokalizacja / mapa). */
    const fieldButtons = (field) =>
        el(
            'div',
            { className: 'planner-field-buttons' },
            field === 'from' &&
                el(
                    'button',
                    {
                        className: 'icon-button planner-mini-button',
                        title: t('Planner.useLocation'),
                        onClick: useCurrentLocation,
                    },
                    renderIcon('NearMe', { size: 20 }),
                ),
            el(
                'button',
                {
                    className: 'icon-button planner-mini-button',
                    title: t('Planner.pickOnMap'),
                    onClick: () => pickOnMap(field),
                },
                renderIcon('Place', { size: 20 }),
            ),
        );

    /** Użyj bieżącej lokalizacji jako punktu początkowego. */
    function useCurrentLocation() {
        if (!navigator.geolocation) {
            alert({ title: t('Planner.locationFailed'), icon: 'LocationDisabled' });
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                plannerState.from = {
                    lat: latitude,
                    lon: longitude,
                    name: t('Planner.myLocation'),
                };
                locationStore.setUserLocation([longitude, latitude]);
                fromInput.value = t('Planner.myLocation');
            },
            () => alert({ title: t('Planner.locationFailed'), icon: 'LocationDisabled' }),
            { enableHighAccuracy: true, timeout: 8000 },
        );
    }

    /* ---------- Wybór punktu kliknięciem na mapie ---------- */

    let pickingCleanup = null;
    let activePickBanner = null;
    let activePickHandler = null;

    /** Kończy wybór punktu z mapy (zawsze bezpieczna — idempotentna). */
    function stopPicking() {
        plannerState.picking = null;
        pickingCleanup = null;

        if (activePickHandler) {
            getMap()?.off('click', activePickHandler);
            activePickHandler = null;
        }

        window.removeEventListener('popstate', onPopStateWhilePicking);
        activePickBanner?.remove();
        activePickBanner = null;

        // Arkusz planera wraca (był tylko schowany, stan formularza żyje)
        plannerSheet.show();
    }

    /** Przycisk back telefonu / strzałka wstecz przerywa wybór z mapy. */
    function onPopStateWhilePicking() {
        if (plannerState.picking && window.history.state !== 'picking') {
            stopPicking();
        }
    }

    function pickOnMap(field) {
        plannerState.picking = field;

        // Schowaj arkusz — mapa ma być klikalna; baner podpowiada, co robić
        plannerSheet.hide();

        const banner = el(
            'div',
            { className: 'planner-pick-banner' },
            renderIcon('Place', { size: 20 }),
            el('span', {}, field === 'from' ? t('Planner.pickFrom') : t('Planner.pickTo')),
            el(
                'button',
                {
                    className: 'button text',
                    onClick: () => {
                        // wróć w historii (zdjąć stan 'picking'), co też
                        // zamknie wybór przez onPopStateWhilePicking
                        if (window.history.state === 'picking') window.history.back();
                        else stopPicking();
                    },
                },
                t('Planner.cancel'),
            ),
        );
        banner.id = 'planner-pick-banner';
        document.body.append(banner);
        activePickBanner = banner;

        // Wpis w historii: przycisk back telefonu = anulowanie wyboru
        window.history.pushState('picking', '');
        window.addEventListener('popstate', onPopStateWhilePicking);

        const map = getMap();
        const handler = (event) => {
            const { lng, lat } = event.lngLat;
            plannerState[field] = {
                lat,
                lon: lng,
                name: `${lat.toFixed(5)}, ${lng.toFixed(5)}`,
            };
            (field === 'from' ? fromInput : toInput).value = plannerState[field].name;

            // usuń wpis 'picking' z historii bez zmiany widoku:
            // back() wywoła onPopStateWhilePicking → stopPicking()
            if (window.history.state === 'picking') {
                window.history.back();
            } else {
                stopPicking();
            }
        };

        activePickHandler = handler;
        map?.once('click', handler);

        pickingCleanup = stopPicking;
    }
    /* --------------------------- Opcje ---------------------------- */

    const dateInput = el('input', { type: 'date', className: 'planner-input planner-date', value: plannerState.date });
    const timeInput = el('input', { type: 'time', className: 'planner-input planner-time', value: plannerState.time });

    dateInput.addEventListener('change', () => {
        plannerState.date = dateInput.value;
    });
    timeInput.addEventListener('change', () => {
        plannerState.time = timeInput.value;
    });

    /** Skrót "Teraz" — przywraca bieżącą datę i godzinę. */
    const nowButton = el(
        'button',
        {
            className: 'button text planner-now',
            onClick: () => {
                const now = defaultDateTime();
                plannerState.date = now.date;
                plannerState.time = now.time;
                dateInput.value = now.date;
                timeInput.value = now.time;
            },
        },
        t('Planner.now'),
    );

    const transfersSelect = el(
        'select',
        { className: 'planner-input planner-transfers' },
        [0, 1, 2, 3, 4, 5].map((n) =>
            el(
                'option',
                { value: String(n), selected: plannerState.maxTransfers === n },
                n === 0 ? t('Planner.noTransfers') : t('Planner.transfersN', { n }),
            ),
        ),
    );
    transfersSelect.addEventListener('change', () => {
        plannerState.maxTransfers = parseInt(transfersSelect.value, 10);
    });

    /* Przełączniki wykluczeń przewoźników z logotypami */
    const carrierSwitch = (kind, label, key) => {
        const checkbox = el('input', { type: 'checkbox' });
        checkbox.checked = plannerState[key];
        checkbox.addEventListener('change', () => {
            plannerState[key] = checkbox.checked;
        });

        return el(
            'label',
            { className: 'carrier-switch', title: `${t('Planner.exclude')}: ${label}` },
            el('div', { className: 'carrier-switch-left' }, carrierLogo(kind), el('span', {}, label)),
            checkbox,
        );
    };

    const carriers = el(
        'div',
        { className: 'planner-carriers' },
        carrierSwitch('wsiobus', t('Planner.wsiobus'), 'excludeWsiobus'),
        carrierSwitch('pks', t('Planner.pks'), 'excludePks'),
        carrierSwitch('trains', t('Planner.trains'), 'excludeTrains'),
    );

    /* --------------------------- Szukaj ---------------------------- */

    const searchButton = el(
        'button',
        { className: 'button contained planner-search-button', onClick: runSearch },
        renderIcon('Search', { size: 20 }),
        t('Planner.search'),
    );

    const resultsHost = el('div', { className: 'planner-results' });

    async function runSearch() {
        plannerState.results = null;
        plannerState.selectedItinerary = -1;
        renderResults();

        if (!plannerState.from || !plannerState.to) {
            resultsHost.replaceChildren(
                alert({ title: t('Planner.needPoints'), icon: 'Place' }),
            );
            return;
        }

        // Data + czas lokalne -> Date (czas lokalny przeglądarki)
        const [year, month, day] = plannerState.date.split('-').map(Number);
        const [hours, minutes] = plannerState.time.split(':').map(Number);
        const when = new Date(year, month - 1, day, hours, minutes);

        resultsHost.replaceChildren(loading({ height: 200 }));

        try {
            const response = await plan({
                from: plannerState.from,
                to: plannerState.to,
                time: when,
                maxTransfers: plannerState.maxTransfers,
                numOfResults: 8,
            });

            const filtered = filterItineraries(response.itineraries, {
                excludeWsiobus: plannerState.excludeWsiobus,
                excludePks: plannerState.excludePks,
                excludeTrains: plannerState.excludeTrains,
            });

            // Opcja „Pieszo” — MOTIS zwraca połączenia bezprzesiadkowe w `direct`;
            // gdy przejście piesze jest szybsze niż najlepsze połączenie
            // komunikacyjne, pokazujemy je jako pierwszy wariant (jak jakdojade).
            const directWalk = (response.direct || []).filter(
                (it) => it.legs?.length && it.legs.every((leg) => leg.mode === 'WALK'),
            );

            let combined;
            if (filtered.length && directWalk.length && directWalk[0].duration < filtered[0].duration) {
                combined = [...directWalk, ...filtered];
            } else if (filtered.length) {
                combined = [...filtered, ...directWalk];
            } else {
                combined = directWalk;
            }

            plannerState.results = { all: response.itineraries, filtered: combined };
            renderResults();

            // Wyniki są pod formularzem — rozwiń arkusz i przewiń do nich
            plannerSheet.snapTo(0);
            resultsHost.scrollIntoView?.({ behavior: 'smooth', block: 'start' });
        } catch (error) {
            resultsHost.replaceChildren(
                alert({ title: t('Planner.searchFailed'), description: String(error.message || error) }),
            );
        }
    }

    /* ------------------------ Renderowanie ------------------------- */

    function renderResults() {
        resultsHost.replaceChildren();

        const results = plannerState.results;
        if (!results) return;

        if (!results.filtered.length) {
            resultsHost.append(
                alert({
                    icon: 'SearchOff',
                    title: t('Planner.noConnections'),
                    description: t('Planner.noConnectionsHint'),
                }),
            );
            return;
        }

        results.filtered.forEach((itinerary, index) => {
            resultsHost.append(itineraryCard(itinerary, index));
        });

        // Atrybucja wymagana przez politykę Transitous
        resultsHost.append(
            el(
                'a',
                {
                    className: 'transitous-attribution',
                    href: 'https://transitous.org/sources/',
                    target: '_blank',
                    rel: 'noopener noreferrer',
                },
                t('Planner.attribution'),
            ),
        );
    }

    /** Czas odjazdu wariantu z opóźnieniem realtime (używany w karcie). */
    function itineraryStart(itinerary) {
        const firstTransit = itinerary.legs.find((l) => l.mode !== 'WALK');
        const first = firstTransit?.from ?? itinerary.legs[0]?.from;
        return placeTime(first) ?? motisTime(itinerary.startTime);
    }

    function itineraryEnd(itinerary) {
        const lastTransit = [...itinerary.legs].reverse().find((l) => l.mode !== 'WALK');
        const last = lastTransit?.to ?? itinerary.legs[itinerary.legs.length - 1]?.to;
        return placeTime(last, 'arrival') ?? motisTime(itinerary.endTime);
    }

    /**
     * Karta itinerarium — styl jakdojade w języku zbiorkom:
     * pasek czasów + opóźnienia, potem badge'y linii i przejścia piesze.
     * Kliknięcie otwiera podgląd na mapie (arkusz planera się chowa).
     */
    function itineraryCard(itinerary, index) {
        const start = itineraryStart(itinerary);
        const end = itineraryEnd(itinerary);

        const selected = plannerState.selectedItinerary === index;

        const isWalkOnly = itinerary.legs.every((l) => l.mode === 'WALK');

        const firstTransit = itinerary.legs.find((l) => l.mode !== 'WALK');
        const firstDelay = firstTransit ? legDelay(firstTransit.from) : null;
        const [, firstDelayText] = getDelay(firstDelay);

        const card = el(
            'button',
            {
                className: 'planner-itinerary' + (selected ? ' selected' : '') + (isWalkOnly ? ' walk-only' : ''),
                onClick: () => selectItinerary(index),
            },
            el(
                'div',
                { className: 'planner-itinerary-header' },
                el(
                    'div',
                    { className: 'planner-itinerary-times' },
                    isWalkOnly
                        ? el(
                              'span',
                              { className: 'planner-time-big' },
                              renderIcon('DirectionsWalk', { size: 18 }),
                              ' ',
                              t('Planner.walk'),
                          )
                        : (() => {
                              const time = el('span', { className: 'planner-time-big' }, getTime(start));
                              if (firstDelayText && firstDelay !== null && firstDelay > 0) {
                                  time.classList.add('delay', 'delay-delayed');
                              }
                              return time;
                          })(),
                    isWalkOnly
                        ? el('span', { className: 'planner-time-big' }, getTime(end))
                        : el('span', { className: 'planner-arrow' }, '→'),
                    !isWalkOnly && el('span', { className: 'planner-time-big' }, getTime(end)),
                ),
                el(
                    'div',
                    { className: 'planner-itinerary-meta' },
                    el('span', {}, msToTime(itinerary.duration * 1000)),
                    !isWalkOnly &&
                        el(
                            'span',
                            {},
                            ' · ',
                            itinerary.transfers === 0
                                ? t('Planner.direct')
                                : t('Planner.transfersN', { n: itinerary.transfers }),
                        ),
                ),
            ),
            !isWalkOnly &&
                el(
                    'div',
                    { className: 'planner-itinerary-legs' },
                    itinerary.legs.map((leg) => legChip(leg)),
                ),
        );

        return card;
    }

    /** Chip nogi (badge linii/marsz) z opóźnieniem realtime. */
    function legChip(leg) {
        if (leg.mode === 'WALK') {
            return el(
                'span',
                { className: 'planner-leg walk' },
                renderIcon('DirectionsWalk', { size: 14 }),
                leg.duration >= 60
                    ? `${Math.round(leg.duration / 60)} ${t('Planner.min')}`
                    : `${leg.duration} ${t('Planner.sec')}`,
            );
        }

        const delay = legDelay(leg.from);
        const [, delayTime] = getDelay(delay);

        const wrap = el('span', { className: 'planner-leg' }, legBadge(leg, { small: true }));

        // Opóźnienie czasu rzeczywistego (GTFS-RT przez Transitous)
        if (delay !== null && delayTime) {
            wrap.append(
                el(
                    'span',
                    { className: `delay delay-${delay > 0 ? 'delayed' : 'early'}` },
                    delay > 0 ? `+${delayTime}` : `-${delayTime}`,
                ),
            );
        }

        if (leg.cancelled) {
            wrap.append(el('span', { className: 'delay delay-delayed' }, t('Planner.cancelled')));
        }

        return wrap;
    }

    /* ------------------------------------------------------------------ */
    /* Wybór wariantu → podgląd trasy na mapie + arkusz szczegółów        */
    /* ------------------------------------------------------------------ */

    let previewSheet = null;
    let previewCleanupHistory = false; // czy w historii jest wpis podglądu
    let previewResolvedColors = null; // Map(leg → kolor) z rozwiązanymi kolizjami

    /** Przycisk back telefonu / strzałka zamyka podgląd (wraca do wyników). */
    function onPopStateWhilePreview() {
        if (previewSheet && window.history.state !== 'preview') {
            exitPreview();
        }
    }

    function selectItinerary(index) {
        plannerState.selectedItinerary = index;
        renderResults();

        const itinerary = plannerState.results.filtered[index];
        if (!itinerary) return;

        const transitLegs = itinerary.legs.filter((l) => l.mode !== 'WALK');

        /* ---------- Kolory z rozwiązanymi kolizjami ---------- */
        /* Używane w LISTACH arkusza podglądu (badge'y linii, kreski nóg).
         * Na MAPIE cała trasa, którą mam jechać, jest CZERWONA — dlatego
         * kolizje kolorów i kreskowanie wspólanych odcinków dotyczą
         * już tylko interfejsu listy. */
        previewResolvedColors = resolveItineraryColors(itinerary);

        /* ---------- Geometria nóg ---------- */

        const features = [];
        const stopFeatures = [];
        const previewPathsByLine = new Map(); // linia → [ścieżki] (do snapowania)

        // Krok 1: zdekoduj geometrie nóg.
        // Nogi transportowe = MOJA TRASA → CZERWONA, pełna. Przejścia
        // piesze = szare, przerywane (styl jakdojade).
        for (const leg of itinerary.legs) {
            const points = leg.legGeometry?.points
                ? decodePolyline(leg.legGeometry.points, leg.legGeometry.precision ?? 7)
                : null;
            if (!points) continue;

            const line = String(leg.routeShortName || '');
            if (leg.mode !== 'WALK' && line) {
                if (!previewPathsByLine.has(line)) previewPathsByLine.set(line, []);
                previewPathsByLine.get(line).push(points);
            }

            features.push({
                type: 'Feature',
                geometry: { type: 'LineString', coordinates: points },
                properties: {
                    variant: false,
                    walk: leg.mode === 'WALK',
                    color: leg.mode === 'WALK' ? WALK_COLOR : ROUTE_COLOR,
                },
            });
        }

        // Krok 2: przystanki na mapie (from/to + ucięte intermediateStops;
        // pełna lista doładuje się po rozwinięciu nogi w arkuszu).
        // Kropki moich linii = czerwone obwódki, końce spacerów = szare.
        for (const leg of itinerary.legs) {
            const stopColor = leg.mode === 'WALK' ? WALK_COLOR : ROUTE_COLOR;
            const legStops = [leg.from, ...(leg.intermediateStops || []), leg.to];
            legStops.forEach((place, stopIndex) => {
                if (place?.lat && place?.lon) {
                    stopFeatures.push({
                        type: 'Feature',
                        geometry: { type: 'Point', coordinates: [place.lon, place.lat] },
                        properties: {
                            id: place.stopId || `${leg.tripId}-${stopIndex}-${place.name}`,
                            name: place.name,
                            variant: false,
                            walk: leg.mode === 'WALK',
                            color: stopColor,
                        },
                    });
                }
            });
        }

        // Rysuj trasę: moja podróż na CZERWONO, przejścia piesze szare
        updateTripRoute(
            { type: 'FeatureCollection', features },
            { type: 'FeatureCollection', features: stopFeatures },
            ROUTE_COLOR,
        );

        // Markery A (start) i B (koniec) — widoczne punkty podróży na mapie
        // (zgłoszenie: „marker na mapie, jak wybiorę, żeby był widoczny
        // start i koniec”). Usuwane przy wyjściu z podglądu (removeTripRoute).
        setTripEndpoints(
            itinerary.legs[0]?.from ?? plannerState.from,
            itinerary.legs[itinerary.legs.length - 1]?.to ?? plannerState.to,
        );

        // Podgląd pojazdów: usuń pozostałe, zostaw tylko te z moich linii
        // (i PRZYCZEPIAJ je do linii trasy — patrz map.js setRoutePreview)
        clearVehicleMarkers();
        removeDotMarkers();
        setRoutePreview(
            new Set(transitLegs.map((leg) => String(leg.routeShortName)).filter(Boolean)),
            previewPathsByLine,
        );

        // Ścieżki DOJAZDU: od początku kursu do przystanku wsiadania
        // (async /api/v1/trip). map.js dorysuje je PÓŁPRZEZROCZYSTE od
        // bieżącej pozycji żywego pojazdu, gdy ten pojawi się na strumieniu.
        buildApproachPaths(transitLegs);

        // Dopasuj widok do całej trasy
        let minLng = Infinity,
            minLat = Infinity,
            maxLng = -Infinity,
            maxLat = -Infinity;
        for (const feature of features) {
            for (const [lng, lat] of feature.geometry.coordinates) {
                if (lng < minLng) minLng = lng;
                if (lat < minLat) minLat = lat;
                if (lng > maxLng) maxLng = lng;
                if (lat > maxLat) maxLat = lat;
            }
        }

        if (minLng !== Infinity) {
            fitBounds([[minLng, minLat], [maxLng, maxLat]], {
                padding: { top: 60, left: 30, right: 30, bottom: 200 },
                maxZoom: 15,
            });
        }

        /* ---------- Arkusz szczegółów wybranego wariantu ---------- */

        // Był już podgląd? Cicho podmień (historia i listenery żyją dalej)
        const wasInPreview = !!previewSheet;
        if (previewSheet) {
            const old = previewSheet;
            previewSheet = null;
            old.close();
        }

        // Arkusz planera (formularz + wyniki) chowa się — na ekranie
        // zostaje JEDEN arkusz: podgląd wariantu.
        plannerSheet.hide();

        // Wpis w historii: przycisk back telefonu / strzałka zamyka podgląd
        if (!wasInPreview) {
            window.history.pushState('preview', '');
            previewCleanupHistory = true;
            window.addEventListener('popstate', onPopStateWhilePreview);
        }

        previewSheet = buildPreviewSheet(itinerary);
    }

    /* ---------- Ścieżki DOJAZDU (nabieganie pojazdu do mnie) ---------- */

    let approachGeneration = 0;

    /**
     * Pobiera geometrie DOJAZDU dla nóg wariantu — od początku kursu do
     * mojego przystanku WSIADANIA (plan zna tylko geometrię NOGI) —
     * i rejestruje je w map.js. Warstwa półprzezroczysta dorysuje się
     * od bieżącej pozycji ŻYWEGO pojazdu, gdy pojawi się na strumieniu
     * (zgłoszenie: „trasa od jego pozycji do mnie półprzezroczysta”).
     */
    async function buildApproachPaths(legs) {
        const generation = ++approachGeneration;
        const pathsByLine = new Map();

        for (const leg of legs) {
            try {
                const path = await fetchApproachPath(leg);
                const line = String(leg.routeShortName || '');
                if (path?.length >= 2 && line) {
                    if (!pathsByLine.has(line)) pathsByLine.set(line, []);
                    pathsByLine.get(line).push(path);
                }
            } catch {
                /* brak danych dojazdu — pomiń nogę */
            }
        }

        // Podgląd mógł zostać zamknięty/zmieniony w trakcie pobierania
        if (generation !== approachGeneration || !previewSheet) return;
        setApproachPaths(pathsByLine);
    }

    /** Wyjście z podglądu: usuń trasę, przywróć wszystkie pojazdy. */
    function exitPreview() {
        if (previewSheet) {
            const sheet = previewSheet;
            previewSheet = null;
            sheet.close();
        }

        window.removeEventListener('popstate', onPopStateWhilePreview);

        // jeśli zamknięcie nastąpiło przez przycisk (a nie back), zdejmij
        // wpis 'preview' z historii
        if (previewCleanupHistory && window.history.state === 'preview') {
            previewCleanupHistory = false;
            window.history.back();
        } else {
            previewCleanupHistory = false;
        }

        plannerState.selectedItinerary = -1;
        previewResolvedColors = null;
        removeTripRoute();
        clearRoutePreview();
        clearVehicleMarkers();

        // Arkusz planera (formularz + wyniki) wraca na ekran
        plannerSheet.show();
        renderResults();
    }

    /** Arkusz dolny ze szczegółami wariantu (styl jak w widoku kursu). */
    function buildPreviewSheet(itinerary) {
        const sheet = bottomSheet({
            snapPoints: [window.innerHeight / 1.6, window.innerHeight / 2.4, window.innerHeight / 3.5],
            defaultSnap: 1,
            onDismiss: exitPreview,
        });

        /* Nagłówek: czasy + meta + przyciski (wstecz / zamknij — strzałka
         * i X działają; popup zamyka się też przyciskiem back telefonu). */
        const start = itineraryStart(itinerary);
        const end = itineraryEnd(itinerary);
        const hasRealtime = itinerary.legs.some((leg) => leg.mode !== 'WALK' && leg.realTime);

        sheet.header.append(
            el(
                'div',
                { className: 'planner-preview-header' },
                el(
                    'div',
                    { className: 'planner-preview-summary' },
                    el(
                        'span',
                        { className: 'planner-time-big' },
                        getTime(start),
                        ' → ',
                        getTime(end),
                        ' ',
                        hasRealtime
                            ? el(
                                  'span',
                                  { className: 'planner-rt-badge live' },
                                  renderIcon('GpsFixed', { size: 12 }),
                                  t('Planner.realtime'),
                              )
                            : el(
                                  'span',
                                  { className: 'planner-rt-badge' },
                                  renderIcon('GpsOff', { size: 12 }),
                                  t('Planner.scheduledOnly'),
                              ),
                    ),
                    el(
                        'span',
                        { className: 'planner-preview-meta' },
                        msToTime(itinerary.duration * 1000),
                        ' · ',
                        itinerary.transfers === 0
                            ? t('Planner.direct')
                            : t('Planner.transfersN', { n: itinerary.transfers }),
                    ),
                ),
                el(
                    'div',
                    { className: 'planner-preview-actions' },
                    el(
                        'button',
                        {
                            className: 'icon-button',
                            title: t('Planner.backToResults'),
                            onClick: () => exitPreview(),
                        },
                        renderIcon('ArrowBack', { size: 20 }),
                    ),
                    el(
                        'button',
                        {
                            className: 'icon-button',
                            title: t('Shared.close'),
                            onClick: () => exitPreview(),
                        },
                        renderIcon('Close', { size: 20 }),
                    ),
                ),
            ),
        );

        /* Lista nóg; każda noga transportowa rozwija się w menu przystanków
         * w stylu oryginalnego widoku kursu (trip-stop-row). Rozwinięcie
         * doładowuje PEWNĄ listę przystanków po drodze (/api/v1/trip —
         * plan zwraca tylko ucięte intermediateStops). */
        const legsHost = el('div', { className: 'planner-preview-legs' });

        const expanded = new Set();
        const fullStopsByLeg = new Map(); // noga → pełna lista przystanków

        const renderLegs = () => {
            legsHost.replaceChildren();
            let legIndex = 0;

            for (const leg of itinerary.legs) {
                const index = legIndex++;

                if (leg.mode === 'WALK') {
                    legsHost.append(
                        el(
                            'div',
                            { className: 'planner-walk-row' },
                            el('span', { className: 'planner-walk-icon' }, renderIcon('DirectionsWalk', { size: 18 })),
                            el(
                                'span',
                                { className: 'planner-walk-text' },
                                `${t('Planner.walk')} · `,
                                leg.duration >= 60
                                    ? `${Math.round(leg.duration / 60)} ${t('Planner.min')}`
                                    : `${leg.duration} ${t('Planner.sec')}`,
                            ),
                        ),
                    );
                    continue;
                }

                const isOpen = expanded.has(index);

                const legHeader = el(
                    'button',
                    {
                        className: 'planner-leg-header' + (isOpen ? ' open' : ''),
                        onClick: () => {
                            if (expanded.has(index)) expanded.delete(index);
                            else {
                                expanded.add(index);
                                loadFullStops(leg);
                            }
                            renderLegs();
                            sheet.refresh();
                        },
                    },
                    el('span', {
                        className: 'planner-leg-dash',
                        style: { backgroundColor: legColor(leg, previewResolvedColors) },
                    }),
                    legBadge(leg, { small: true, resolvedColors: previewResolvedColors }),
                    el(
                        'div',
                        { className: 'planner-leg-header-text' },
                        el('span', { className: 'planner-leg-headsign' }, leg.headsign || leg.routeLongName || ''),
                        el(
                            'span',
                            { className: 'planner-leg-times' },
                            getTime(placeTime(leg.from) ?? 0),
                            ' → ',
                            getTime(placeTime(leg.to, 'arrival') ?? 0),
                            leg.cancelled
                                ? el('span', { className: 'delay delay-delayed' }, ` · ${t('Planner.cancelled')}`)
                                : (() => {
                                      const delay = legDelay(leg.from);
                                      const [, delayTime] = getDelay(delay);
                                      return delay !== null && delayTime
                                          ? el(
                                                'span',
                                                { className: `delay delay-${delay > 0 ? 'delayed' : 'early'}` },
                                                ` · ${delay > 0 ? '+' : '-'}${delayTime}`,
                                            )
                                          : null;
                                  })(),
                        ),
                    ),
                    el(
                        'span',
                        { className: 'planner-leg-expand' },
                        renderIcon(isOpen ? 'ExpandLess' : 'ExpandMore', { size: 20 }),
                    ),
                );

                legsHost.append(legHeader);

                if (isOpen) {
                    legsHost.append(
                        buildStopsTimeline(leg, fullStopsByLeg.get(leg)) ??
                            el('div', { className: 'planner-stops' }, loading({ height: 120 })),
                    );
                }
            }
        };

        /** Doładuj PEWNĄ listę przystanków nogi (i dodaj je na mapę). */
        async function loadFullStops(leg) {
            const stops = await fetchLegStops(leg);
            if (!stops) return;
            fullStopsByLeg.set(leg, stops);

            if (!expanded.has(itinerary.legs.indexOf(leg))) return;

            // dodaj przystanki pośrednie na mapę (aktualizacja warstwy trip-stops)
            const map = getMap();
            const source = map?.getSource('trip-stops');
            if (source && previewSheet) {
                const data = source._data;
                const known = new Set(data.features.map((f) => f.properties.id));
                for (const place of stops) {
                    const id = place.stopId;
                    if (known.has(id) || !place.lat || !place.lon) continue;
                    data.features.push({
                        type: 'Feature',
                        geometry: { type: 'Point', coordinates: [place.lon, place.lat] },
                        properties: {
                            id,
                            name: place.name,
                            variant: false,
                            walk: false,
                            color: legColor(leg, previewResolvedColors),
                        },
                    });
                }
                source.setData(data);
            }

            renderLegs();
            sheet.refresh();
        }

        renderLegs();
        sheet.scroll.append(legsHost);

        const sheetHost = document.querySelector('.sheet-host');
        if (sheetHost) sheetHost.append(sheet.root);
        else document.body.append(sheet.root);

        return sheet;
    }

    /**
     * Menu przystanków nogi — dokładnie styl widoku kursu (trip.js):
     * czasy z kolorami opóźnień, kropki na linii w kolorze nogi (linia
     * łącząca przystanki względem wiersza — bez „kwadratów”), odliczanie,
     * przyciemniane TYLKO czasy przejechanych przystanków.
     * Kliknięcie przystanku otwiera arkusz z jego odjazdami.
     */
    function buildStopsTimeline(leg, fullStops) {
        const color = legColor(leg, previewResolvedColors);
        const list = el('div', { className: 'trip-stop-list planner-stops' });

        const stops = fullStops ?? [leg.from, ...(leg.intermediateStops || []), leg.to];

        stops.forEach((place, index) => {
            if (!place) return;

            const scheduled = motisTime(place.scheduledDeparture ?? place.scheduledArrival);
            const actual = motisTime(place.departure ?? place.arrival);
            const delay = scheduled !== null && actual !== null ? actual - scheduled : null;
            const [, delayText] = getDelay(delay);

            const isLiveStatus = !!leg.realTime && delay !== null;
            const hasDeparted = actual !== null && actual < Date.now();

            const timesBox = el(
                'div',
                { className: 'trip-stop-times' + (hasDeparted ? ' departed' : '') },
            );

            const isSingleDelayed = delay !== null && Math.abs(delay) >= 60000 && delayText;

            if (isSingleDelayed && scheduled !== null) {
                timesBox.append(
                    el('span', { className: 'trip-stop-time struck' }, getTime(scheduled)),
                    el(
                        'span',
                        {
                            className: `trip-stop-time delay delay-${isLiveStatus ? (delay > 0 ? 'delayed' : 'early') : 'unknown'}`,
                        },
                        getTime(actual ?? scheduled),
                    ),
                );
            } else {
                const time = actual ?? scheduled;
                if (time !== null) {
                    const delayClass =
                        isLiveStatus && delay !== null && delayText
                            ? delay > 0
                                ? 'delayed'
                                : 'early'
                            : 'unknown';
                    timesBox.append(
                        el('span', { className: `trip-stop-time delay delay-${delayClass}` }, getTime(time)),
                    );
                }
            }

            /* Kropka + linia w kolorze nogi (port TripStopIcon) */
            const icons = el('span', { className: 'trip-stop-icons' });
            const dot = el('span', {
                className: 'vehicleStopIcon',
                style: { border: `3px solid ${color}` },
            });
            icons.append(dot);

            if (index !== 0) {
                icons.append(
                    el('span', {
                        className: 'vehicleStopIconLine',
                        style: { backgroundColor: color },
                    }),
                );
            }

            const map = getMap();
            const row = el(
                'button',
                {
                    className: 'trip-stop-row' + (hasDeparted ? ' departed' : ''),
                    onClick: () => {
                        map?.flyTo({
                            center: [place.lon, place.lat],
                            zoom: map.getZoom() > 15 ? map.getZoom() : 15,
                        });

                        /* Kliknięcie przystanku pokazuje go w widoku:
                         * popup z dołu z jego odjazdami (Transitous). */
                        if (place.stopId) openTransitousStopSheet(place, leg);
                    },
                },
                el('div', { className: 'trip-stop-icon-col' }, timesBox, icons),
                el(
                    'div',
                    { className: 'trip-stop-text' },
                    el('span', { className: 'trip-stop-name' }, place.name),
                    el(
                        'span',
                        { className: 'trip-stop-secondary' },
                        vehicleDelay(delay, leg.realTime ? 2 : 0),
                    ),
                ),
                (() => {
                    /* Odliczanie dla przystanków, na których jeszcze nie byliśmy */
                    const time = actual ?? scheduled;
                    if (time === null || hasDeparted) return null;
                    const diff = Math.round((time - Date.now()) / 60000);
                    return el(
                        'div',
                        { className: 'trip-stop-countdown' },
                        el('span', {}, diff > 0 ? String(diff) : '<1'),
                        el('span', {}, t('Planner.min')),
                    );
                })(),
            );

            list.append(row);
        });

        return list;
    }

    /* ---------- Arkusz przystanku Transitous (odjazdy z dołu) ---------- */

    let transitousStopSheet = null;
    let stopSheetHistory = false;

    /** Przycisk back telefonu zamyka arkusz przystanku (wraca do podglądu). */
    function onPopStateWhileStopSheet() {
        if (transitousStopSheet && window.history.state !== 'stop-sheet') {
            closeTransitousStopSheet(false);
        }
    }

    function closeTransitousStopSheet(popHistory = true) {
        const sheet = transitousStopSheet;
        if (!sheet) return;
        transitousStopSheet = null;
        window.removeEventListener('popstate', onPopStateWhileStopSheet);

        // przywróć podgląd wariantu (był tylko schowany, nie zamknięty)
        previewSheet?.show();

        sheet.dismiss();

        if (popHistory && stopSheetHistory && window.history.state === 'stop-sheet') {
            window.history.back();
        }
        stopSheetHistory = false;
    }

    function openTransitousStopSheet(place, leg) {
        // Na ekranie widać TYLKO JEDEN arkusz: podgląd chowamy (wróci po
        // zamknięciu przystanku) — nowy arkusz i tak chowa pozostałe (ui.js).
        previewSheet?.hide();

        const sheet = bottomSheet({
            snapPoints: [window.innerHeight / 2, window.innerHeight / 3],
            defaultSnap: 1,
            onDismiss: () => {
                if (transitousStopSheet === sheet) {
                    transitousStopSheet = null;
                    window.removeEventListener('popstate', onPopStateWhileStopSheet);
                    previewSheet?.show();

                    // zamknięcie przez przeciągnięcie w dół — zdejmij wpis
                    if (stopSheetHistory && window.history.state === 'stop-sheet') {
                        window.history.back();
                    }
                    stopSheetHistory = false;
                }
            },
        });

        transitousStopSheet = sheet;

        // Wpis w historii: przycisk back telefonu zamyka arkusz przystanku
        window.history.pushState('stop-sheet', '');
        stopSheetHistory = true;
        window.addEventListener('popstate', onPopStateWhileStopSheet);

        const header = el(
            'div',
            { className: 'stop-header' },
            el(
                'div',
                { className: 'stop-header-left' },
                el(
                    'span',
                    {
                        className: 'stop-tag-icon',
                        style: {
                            backgroundColor: legColor(leg, previewResolvedColors),
                            width: '28.8px',
                            height: '28.8px',
                        },
                    },
                    (() => {
                        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                        svg.setAttribute('viewBox', '0 0 24 24');
                        svg.setAttribute('width', '1em');
                        svg.setAttribute('height', '1em');
                        svg.setAttribute('fill', 'currentColor');
                        svg.innerHTML = vehicleTypeIcon(GTFS_TYPE_TO_ZBIORKOM[leg.routeType] ?? 3);
                        return svg;
                    })(),
                ),
                el('b', { className: 'stopTag-name' }, place.name),
            ),
            el(
                'div',
                { className: 'sheet-header-buttons' },
                el(
                    'button',
                    {
                        className: 'icon-button',
                        title: t('Shared.close'),
                        onClick: () => closeTransitousStopSheet(),
                    },
                    renderIcon('Close', { size: 20 }),
                ),
            ),
        );

        const content = el('div', { className: 'stop-content' });

        sheet.header.append(header);
        sheet.scroll.append(content);

        const sheetHost = document.querySelector('.sheet-host');
        if (sheetHost) sheetHost.append(sheet.root);
        else document.body.append(sheet.root);

        transitousStopSheet = sheet;

        (async () => {
            content.append(loading({ height: 160 }));
            try {
                const departures = await fetchStopTimes(place.stopId);
                content.replaceChildren();

                if (!departures.length) {
                    content.append(
                        el(
                            'div',
                            { style: { padding: '16px' } },
                            alert({ title: t('Schedules.noDepartures'), icon: 'Bedtime' }),
                        ),
                    );
                    return;
                }

                const departuresList = el('div', { className: 'stop-departures' });

                departures.forEach((departure) => {
                    const color = departure.routeColor
                        ? `#${String(departure.routeColor).replace('#', '')}`
                        : (defaultColors[GTFS_TYPE_TO_ZBIORKOM[departure.routeType] ?? 3] ??
                          defaultColors[3]);

                    const [, delayText] = getDelay(departure.delay);

                    const timeBox = el(
                        'div',
                        { className: 'transitous-stop-departure-time' },
                        departure.delay !== null &&
                        delayText &&
                        Math.abs(departure.delay) >= 60000 &&
                        departure.scheduledTime !== null
                            ? el('span', { className: 'trip-stop-time struck' }, getTime(departure.scheduledTime))
                            : null,
                        el(
                            'span',
                            {
                                className: `trip-stop-time delay delay-${departure.realtime ? (departure.delay > 0 ? 'delayed' : 'early') : 'unknown'}`,
                            },
                            getTime(departure.time ?? departure.scheduledTime ?? 0),
                        ),
                    );

                    const diff =
                        departure.time !== null
                            ? Math.round((departure.time - Date.now()) / 60000)
                            : null;

                    departuresList.append(
                        el(
                            'div',
                            { className: 'transitous-stop-departure' },
                            timeBox,
                            el(
                                'span',
                                {
                                    className: 'planner-badge small',
                                    style: { backgroundColor: color, color: 'hsla(0, 0%, 100%, 0.8)' },
                                },
                                (() => {
                                    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                                    svg.setAttribute('viewBox', '0 0 24 24');
                                    svg.setAttribute('width', '1em');
                                    svg.setAttribute('height', '1em');
                                    svg.setAttribute('fill', 'currentColor');
                                    svg.innerHTML = vehicleTypeIcon(
                                        GTFS_TYPE_TO_ZBIORKOM[departure.routeType] ?? 3,
                                    );
                                    return svg;
                                })(),
                                el('b', {}, departure.routeShortName || departure.mode),
                            ),
                            el(
                                'div',
                                { className: 'transitous-stop-departure-text' },
                                el('span', { className: 'transitous-stop-departure-headsign' }, departure.headsign),
                                el(
                                    'span',
                                    { className: 'transitous-stop-departure-meta' },
                                    departure.agencyName || departure.routeLongName || '',
                                    departure.cancelled
                                        ? el('span', { className: 'delay delay-delayed' }, ` · ${t('Planner.cancelled')}`)
                                        : departure.delay !== null && delayText
                                          ? el(
                                                'span',
                                                {
                                                    className: `delay delay-${departure.delay > 0 ? 'delayed' : 'early'}`,
                                                },
                                                ` · ${departure.delay > 0 ? '+' : '-'}${delayText}`,
                                            )
                                          : null,
                                ),
                            ),
                            diff !== null && diff >= 0
                                ? el(
                                      'div',
                                      { className: 'transitous-stop-departure-countdown' },
                                      el('span', {}, diff > 0 ? String(diff) : '<1'),
                                      el('span', {}, t('Planner.min')),
                                  )
                                : null,
                        ),
                    );
                });

                content.append(
                    departuresList,
                    el(
                        'a',
                        {
                            className: 'transitous-attribution',
                            href: 'https://transitous.org/sources/',
                            target: '_blank',
                            rel: 'noopener noreferrer',
                        },
                        t('Planner.attribution'),
                    ),
                );
            } catch {
                content.replaceChildren(alert({ title: t('Shared.loadError') }));
            }
        })();
    }

    /* ------------------------- Składanie --------------------------- */

    const swapButton = el(
        'button',
        {
            className: 'icon-button planner-swap',
            title: t('Planner.swap'),
            onClick: () => {
                const { from, to } = plannerState;
                plannerState.from = to;
                plannerState.to = from;
                fromInput.value = to?.name || '';
                toInput.value = from?.name || '';
                renderResults();
            },
        },
        renderIcon('SwapVert', { size: 20 }),
    );

    /* Formularz w KARTACH-sekcjach MD3 (styl zbiorkom.live):
     * pola A/B, „kiedy” + przesiadki, wykluczenia przewoźników. */
    const form = el(
        'div',
        { className: 'planner-form' },
        el(
            'div',
            { className: 'planner-fields' },
            fromField,
            toField,
            swapButton,
            suggestions,
        ),
        el(
            'div',
            { className: 'planner-section' },
            el(
                'div',
                { className: 'planner-row' },
                el('label', { className: 'planner-label' }, el('span', {}, t('Planner.when')), dateInput),
                el('label', { className: 'planner-label' }, el('span', {}, t('Planner.atWhatTime')), timeInput),
                nowButton,
            ),
            el(
                'div',
                { className: 'planner-row' },
                el(
                    'label',
                    { className: 'planner-label' },
                    el('span', {}, t('Planner.maxTransfers')),
                    transfersSelect,
                ),
            ),
        ),
        el('div', { className: 'planner-section planner-section-carriers' }, carriers),
        searchButton,
    );

    // przyciski pól doklejamy po utworzeniu formularza (od świeżych pól)
    fromField.append(fieldButtons('from'));
    toField.append(fieldButtons('to'));

    host.append(form, resultsHost);

    if (plannerState.results) renderResults();

    return {
        destroy() {
            document.getElementById('planner-pick-banner')?.remove();
            clearTimeout(geocodeTimer);
            geocodeAbort?.abort();
            pickingCleanup?.();
            window.removeEventListener('popstate', onPopStateWhilePicking);
            window.removeEventListener('popstate', onPopStateWhilePreview);
            window.removeEventListener('popstate', onPopStateWhileStopSheet);

            if (previewCleanupHistory && window.history.state === 'preview') {
                window.history.back();
            }
            previewCleanupHistory = false;

            if (previewSheet) {
                const sheet = previewSheet;
                previewSheet = null;
                sheet.close();
            }
            stopSheetHistory = false;
            if (transitousStopSheet) {
                const sheet = transitousStopSheet;
                transitousStopSheet = null;
                sheet.close();
            }

            // zanimch trwające pobieranie ścieżek dojazdu
            approachGeneration++;

            removeTripRoute();
            clearRoutePreview();
            clearVehicleMarkers();
            plannerSheet.close();
        },
    };
}
