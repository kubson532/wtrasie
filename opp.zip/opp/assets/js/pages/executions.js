/**
 * "Co wyjechało?" — port pages/Executions:
 *   index.tsx       — dialog z filtrami i listą wykonanych kursów
 *   ExecutionsFilter — data + linia + brygada + pojazd
 *   Execution.tsx   — pojedynczy kurs z opóźnieniami i przystankami
 */

import { el, dialog, alert, loading } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, query as queryParams, replaceSearch } from '../router.js';
import { getFromAPI } from '../api.js';
import { getCityDate, getCityTimezone, getTime } from '../util.js';
import { vehicleHeadsign } from './widgets.js';

function setUrlParam(key, value) {
    const params = queryParams();
    if (value) params.set(key, value);
    else params.delete(key);
    replaceSearch(params);
}

export async function mountExecutionsDialog(city) {
    const d = dialog({
        onClose: () => navigate(`/${city}`),
        fullscreen: window.innerWidth <= 600,
    });

    const date = queryParams().get('date') || getCityDate(Date.now(), getCityTimezone(city));
    let route = queryParams().get('route') || '';
    let brigade = queryParams().get('brigade') || '';
    let vehicle = queryParams().get('vehicle') || '';

    const enabled = !!route || !!vehicle;

    const header = el(
        'div',
        { className: 'page-header space-between' },
        el(
            'div',
            { className: 'page-header-left' },
            el('button', { className: 'icon-button', onClick: () => navigate(`/${city}`) }, renderIcon('ArrowBack')),
            el('h5', {}, t('Executions.executions')),
        ),
    );

    const filterHost = el('div', { className: 'executions-filter' });
    const listHost = el('div', { className: 'executions-list' });

    d.content.append(header, filterHost, listHost);
    document.body.append(d);

    /* Filtry (port ExecutionsFilter.tsx) */
    const autocomplete = await getFromAPI(city, 'dispatches/autocomplete', {}).catch(() => null);
    const routesMap = new Map((autocomplete?.routes ?? []).map((r) => [r[0], r]));

    const dateInput = el('input', {
        type: 'date',
        value: date,
        className: 'executions-input',
    });
    dateInput.addEventListener('change', () => {
        setUrlParam('date', dateInput.value);
        loadExecutions();
    });

    const routeInput = el('input', {
        type: 'text',
        placeholder: t('Executions.route'),
        value: route,
        className: 'executions-input',
        list: 'executions-routes',
    });
    routeInput.addEventListener('change', () => {
        route = routeInput.value.trim();
        setUrlParam('route', route);
        brigade = '';
        brigadeInput.value = '';
        loadExecutions();
    });

    const routesDatalist = el(
        'datalist',
        { id: 'executions-routes' },
        (autocomplete?.routes ?? []).map((r) => el('option', { value: r[0] }, r[2])),
    );

    const brigadeInput = el('input', {
        type: 'text',
        placeholder: t('Executions.brigade'),
        value: brigade,
        className: 'executions-input',
    });
    brigadeInput.addEventListener('change', () => {
        brigade = brigadeInput.value.trim();
        setUrlParam('brigade', brigade);
        loadExecutions();
    });

    const vehicleInput = el('input', {
        type: 'text',
        placeholder: t('Executions.vehicle'),
        value: vehicle,
        className: 'executions-input',
        list: 'executions-vehicles',
    });
    vehicleInput.addEventListener('change', () => {
        vehicle = vehicleInput.value.trim();
        setUrlParam('vehicle', vehicle);
        loadExecutions();
    });

    const vehiclesDatalist = el(
        'datalist',
        { id: 'executions-vehicles' },
        (autocomplete?.vehicles ?? []).map((v) => el('option', { value: v })),
    );

    filterHost.append(
        dateInput,
        routeInput,
        brigadeInput,
        vehicleInput,
        routesDatalist,
        vehiclesDatalist,
    );

    /* Lista wykonanych kursów (port useQueryExecutions + Execution.tsx) */
    async function loadExecutions() {
        listHost.replaceChildren(loading({ height: 300 }));

        if (!route && !vehicle) {
            listHost.replaceChildren(alert({ icon: 'History', title: t('Executions.noFilter') }));
            return;
        }

        try {
            const executions = await getFromAPI(city, 'dispatches', {
                route,
                brigade,
                vehicle,
                date,
            });

            listHost.replaceChildren();

            if (!executions?.length) {
                listHost.append(
                    alert({
                        icon: 'Dangerous',
                        title: t('Executions.noResults'),
                        description: t('Executions.noResultsDescription'),
                    }),
                );
                return;
            }

            for (const execution of executions) {
                listHost.append(executionRow(execution, routesMap.get(execution[1])));
            }
        } catch (err) {
            listHost.replaceChildren(
                alert({ title: t('Shared.loadError'), description: String(err.message ?? err) }),
            );
        }
    }

    function executionRow(execution, routeTuple) {
        const [tripId, , brigadeId, vehicleId, , originName, , destName, scheduledStart, actualStart, startDelay, scheduledEnd, actualEnd, endDelay] = execution;

        const row = el(
            'button',
            { className: 'execution-row' },
            el(
                'div',
                { className: 'execution-row-header' },
                routeTuple && vehicleHeadsign(routeTuple, { brigade: brigadeId }),
                el(
                    'span',
                    { className: 'execution-vehicle' },
                    vehicleId ? `#${vehicleId}` : '',
                ),
            ),
            el(
                'div',
                { className: 'execution-row-body' },
                el(
                    'div',
                    { className: 'execution-leg' },
                    el('span', { className: 'execution-time' },
                        getTime(actualStart || scheduledStart),
                        ' ',
                        startDelay >= 60
                            ? el('b', { className: 'delay delay-delayed' }, `+${Math.round(startDelay / 60)}`)
                            : startDelay <= -60
                              ? el('b', { className: 'delay delay-early' }, `${Math.round(startDelay / 60)}`)
                              : ''),
                    el('span', { className: 'execution-stop' }, originName),
                ),
                el(
                    'div',
                    { className: 'execution-leg' },
                    el('span', { className: 'execution-time' },
                        getTime(actualEnd || scheduledEnd),
                        ' ',
                        endDelay >= 60
                            ? el('b', { className: 'delay delay-delayed' }, `+${Math.round(endDelay / 60)}`)
                            : endDelay <= -60
                              ? el('b', { className: 'delay delay-early' }, `${Math.round(endDelay / 60)}`)
                              : ''),
                    el('span', { className: 'execution-stop' }, destName),
                ),
            ),
        );

        // Rozwinięcie: przystanki kursu (port useQueryExecutionTrip)
        const details = el('div', { className: 'execution-stops hidden' });

        const expandButton = el(
            'button',
            { className: 'execution-expand' },
            t('Executions.expandStops'),
        );

        expandButton.addEventListener('click', async () => {
            if (details.classList.contains('hidden')) {
                details.classList.remove('hidden');
                expandButton.textContent = t('Executions.hideStops');

                if (!details.children.length) {
                    details.append(loading({ height: 80 }));
                    const trip = await getFromAPI(city, 'dispatches/trip', {
                        trip: tripId,
                        date,
                        vehicle: vehicleId,
                    }).catch(() => null);

                    details.replaceChildren();
                    for (const stop of trip?.stops ?? []) {
                        details.append(
                            el(
                                'div',
                                { className: 'execution-stop-row' },
                                el('span', { className: 'execution-time' }, getTime(stop[3] || stop[2])),
                                el('span', { className: 'execution-stop' }, stop[1]),
                            ),
                        );
                    }
                }
            } else {
                details.classList.add('hidden');
                expandButton.textContent = t('Executions.expandStops');
            }
        });

        const wrapper = el('div', { className: 'execution' }, row, details, expandButton);
        return wrapper;
    }

    loadExecutions();

    return {
        destroy() {
            d.remove();
        },
    };
}
