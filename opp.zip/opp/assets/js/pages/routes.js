/**
 * Rozkłady (lista linii) — port pages/Routes.tsx:
 * pełnoekranowy dialog z wyszukiwarką linii i siatką chipów.
 */

import { el, dialog, textField, loading } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { navigate, pathname } from '../router.js';
import { getFromAPI } from '../api.js';
import { buildCitySuffix } from '../util.js';
import { routeChip } from './widgets.js';

export async function mountRoutesDialog(city) {
    const d = dialog({ fullscreen: window.innerWidth <= 900, closeable: false });

    const header = el(
        'div',
        { className: 'page-header' },
        el(
            'button',
            {
                className: 'icon-button',
                onClick: () => navigate(pathname(), { state: 'menu' }),
            },
            renderIcon('Menu'),
        ),
        el('h5', {}, t('Schedules.schedules')),
    );

    const gridHost = el('div', { className: 'routes-grid-host' });

    d.content.append(header, gridHost);
    document.body.append(d);

    let search = '';

    const renderGrid = (routes) => {
        gridHost.replaceChildren();

        if (!routes) {
            gridHost.append(loading({ height: 300 }));
            return;
        }

        const filtered = routes.filter((route) =>
            route[2].toLowerCase().includes(search.toLowerCase()),
        );

        const input = textField({
            placeholder: t('Schedules.search'),
            value: search,
            adornment: 'Search',
            onChange: (value) => {
                search = value;
                renderGrid(routes);
            },
        });
        input.classList.add('routes-search');

        const grid = el(
            'div',
            { className: 'routes-grid' },
            filtered.map((route) =>
                routeChip(route, () =>
                    navigate(
                        `/${city}/route/${route[0]}` + buildCitySuffix(route[1], city),
                        { state: -3 },
                    ),
                ),
            ),
        );

        gridHost.append(input, grid);
    };

    renderGrid(null);

    try {
        const routes = await getFromAPI(city, 'routes', {});
        renderGrid(routes);
    } catch {
        renderGrid([]);
    }

    return {
        destroy() {
            d.remove();
        },
    };
}
