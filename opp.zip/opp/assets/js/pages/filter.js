/**
 * Filtrowanie — port komponentów sheet/Filter:
 *   FilterHeader      — pole wyszukiwania linii/modeli + reset
 *   FilterContent     — aktywne filtry, linie w pobliżu, instrukcja
 *   FilterActive      — chipy aktywnych filtrów
 *   FilterRoutesNearby — chipy linii w pobliżu
 *   FilterSearchResult — wyniki z checkboxami
 *   FilterHowToUse    — instrukcja
 */

import { el, bottomSheet, textField } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t } from '../i18n.js';
import { goBack, segments } from '../router.js';
import { createEventQuery, getFromAPI } from '../api.js';
import { filterStore, locationStore } from '../store.js';
import { routeChip, vehicleHeadsign } from './widgets.js';
import { getMap } from '../map.js';

export function mountFilterSheet(sheetHost) {
    const city = segments()[0];

    const map = getMap();

    // Otwarcie: zapamiętaj pozycję mapy i skopiuj aktywne filtry do tymczasowych
    // (port useEffect z pages/Filter.tsx)
    if (map) {
        filterStore.setInitialPosition([map.getZoom(), map.getCenter()]);
    }
    filterStore.useTemp();

    const header = el('div', { className: 'filter-header' });
    const content = el('div', { className: 'filter-content' });

    const sheet = bottomSheet({
        blocking: true,
        onDismiss: () => goBack(),
    });

    sheet.header.append(header);
    sheet.scroll.append(content);
    sheetHost.append(sheet.root);

    // Strumień przefiltrowanych pojazdów — dopasowanie widoku (port useQueryMarkers z Filter.tsx)
    let boundsStream = null;
    const connectBoundsStream = () => {
        boundsStream?.close();

        const filterRoutes = filterStore.tempRoutes.map((route) => route[0]).join(',');
        const filterModels = filterStore.tempModels.join(',');

        if (!filterRoutes && !filterModels) return;

        const params = new URLSearchParams();
        if (filterRoutes) params.set('filterRoutes', filterRoutes);
        if (filterModels) params.set('filterModels', filterModels);

        boundsStream = createEventQuery({
            city,
            endpoint: `mapFeatures/0/0,0,0,0/stream?${params.toString()}`,
            onMessage: (data) => {
                if (data.bbox && map) {
                    map.fitBounds(data.bbox, {
                        maxZoom: 15,
                        padding: { top: 50, left: 50, right: 50, bottom: 50 },
                        maxDuration: 1000,
                    });
                }
            },
        });
    };

    connectBoundsStream();

    let routesCache = null;
    let modelsCache = null;

    /* Nagłówek z wyszukiwarką i resetem (port FilterHeader.tsx) */
    const renderHeader = () => {
        header.replaceChildren();

        const input = textField({
            placeholder: t('Filter.searchRoutesOrModels'),
            value: filterStore.search,
            adornment: 'Search',
            onChange: (value) => {
                filterStore.setSearch(value);
                renderHeader();
                renderContent();
            },
            endAdornment: filterStore.search
                ? el(
                      'button',
                      {
                          className: 'icon-button',
                          onClick: () => {
                              filterStore.setSearch('');
                              renderHeader();
                              renderContent();
                          },
                      },
                      renderIcon('HighlightOff', { size: 20 }),
                  )
                : null,
        });
        input.classList.add('filter-input');

        const hasTemp = filterStore.tempRoutes.length || filterStore.tempModels.length;

        header.append(
            input,
            el(
                'button',
                {
                    className: 'icon-button filter-reset' + (hasTemp ? '' : ' disabled'),
                    title: 'Reset',
                    onClick: () => {
                        if (!hasTemp) return;
                        filterStore.reset();

                        if (filterStore.initialPosition && getMap()) {
                            getMap().easeTo({
                                zoom: filterStore.initialPosition[0],
                                center: filterStore.initialPosition[1],
                            });
                        }

                        renderHeader();
                        renderContent();
                        connectBoundsStream();
                        window.dispatchEvent(new CustomEvent('zbiorkom:filters-changed'));
                    },
                },
                renderIcon('RestartAlt', { size: 22 }),
            ),
        );
    };

    /* Treść (port FilterContent.tsx) */
    const renderContent = async () => {
        content.replaceChildren();

        // Wyszukiwane wyniki
        if (filterStore.search) {
            const box = el('div', { className: 'filter-search-results' });

            if (!routesCache) routesCache = await getFromAPI(city, 'routes', {});
            if (!modelsCache) modelsCache = await getFromAPI(city, 'vehicles/models', {});

            const q = filterStore.search.trim().toLowerCase();
            const matchedRoutes = (routesCache || []).filter(
                (route) =>
                    route[2].toLowerCase().includes(q) || route[3]?.toLowerCase().includes(q),
            );
            const matchedModels = (modelsCache || []).filter((model) => model.toLowerCase().includes(q));

            for (const result of [...matchedRoutes, ...matchedModels]) {
                const isModel = typeof result === 'string';
                const selected = isModel
                    ? filterStore.tempModels.includes(result)
                    : filterStore.tempRoutes.some((route) => route[0] === result[0]);

                const onClick = () => {
                    if (isModel) {
                        if (filterStore.tempModels.includes(result)) filterStore.removeModel(result);
                        else filterStore.addModel(result);
                    } else {
                        if (filterStore.tempRoutes.some((route) => route[0] === result[0])) {
                            filterStore.removeRoute(result);
                        } else {
                            filterStore.addRoute(result);
                        }
                    }
                    renderContent();
                    connectBoundsStream();
                    window.dispatchEvent(new CustomEvent('zbiorkom:filters-changed'));
                };

                box.append(
                    el(
                        'button',
                        { className: 'filter-search-row', onClick },
                        isModel
                            ? el('span', {}, result)
                            : vehicleHeadsign(result, { headsign: result[3] }),
                        el(
                            'span',
                            { className: 'filter-checkbox' + (selected ? ' checked' : '') },
                            selected ? renderIcon('Check', { size: 18 }) : '',
                        ),
                    ),
                );
            }

            content.append(box);
            return;
        }

        // Aktywne filtry (port FilterActive.tsx)
        if (filterStore.tempRoutes.length || filterStore.tempModels.length) {
            content.append(
                el(
                    'div',
                    { className: 'filter-section' },
                    el('h6', {}, renderIcon('AddCircle', { size: 20 }), ' ', t('Filter.activeFilters')),
                    el(
                        'div',
                        { className: 'filter-chips' },
                        filterStore.tempRoutes.map((route) =>
                            routeChip(route, () => {
                                filterStore.removeRoute(route);
                                renderContent();
                                connectBoundsStream();
                                window.dispatchEvent(new CustomEvent('zbiorkom:filters-changed'));
                            }),
                        ),
                        filterStore.tempModels.map((model) =>
                            el(
                                'div',
                                {
                                    className: 'routeChip model-chip',
                                    onClick: () => {
                                        filterStore.removeModel(model);
                                        renderContent();
                                        connectBoundsStream();
                                        window.dispatchEvent(new CustomEvent('zbiorkom:filters-changed'));
                                    },
                                },
                                model,
                            ),
                        ),
                    ),
                ),
            );
        }

        // Linie w pobliżu (port FilterRoutesNearby.tsx)
        const userLocation = locationStore.userLocation;
        if (userLocation) {
            try {
                const routesNearby = await getFromAPI(city, 'routes/nearby', {
                    lat: userLocation[1],
                    lon: userLocation[0],
                });

                if (routesNearby?.length) {
                    content.append(
                        el(
                            'div',
                            { className: 'filter-section' },
                            el('h6', {}, renderIcon('MyLocation', { size: 20 }), ' ', t('Filter.routesNearby')),
                            el(
                                'div',
                                { className: 'filter-chips' },
                                routesNearby.map((route) => {
                                    const selected = filterStore.tempRoutes.some(
                                        (r) => r[0] === route[0],
                                    );

                                    return routeChip(
                                        route,
                                        () => {
                                            if (selected) filterStore.removeRoute(route);
                                            else filterStore.addRoute(route);
                                            renderContent();
                                            connectBoundsStream();
                                            window.dispatchEvent(new CustomEvent('zbiorkom:filters-changed'));
                                        },
                                        {
                                            color: selected
                                                ? 'hsla(0, 0%, 100%, 0.8)'
                                                : route[6],
                                            backgroundColor: selected ? route[6] : 'transparent',
                                            border: selected ? 'none' : `1px solid ${route[6]}`,
                                        },
                                    );
                                }),
                            ),
                        ),
                    );
                }
            } catch {
                // ignoruj — sekcja jest opcjonalna
            }
        }

        // Instrukcja (port FilterHowToUse.tsx)
        content.append(
            el(
                'div',
                { className: 'filter-section' },
                el('h6', {}, renderIcon('Help', { size: 20 }), ' ', t('Filter.howToUseTitle')),
                el('p', {}, t('Filter.howToUseContent')),
            ),
        );
    };

    renderHeader();
    renderContent();

    return {
        sheet,
        destroy() {
            // Zamknięcie: zastosuj filtry, wyczyść wyszukiwanie (port cleanup z Filter.tsx)
            boundsStream?.close();
            filterStore.applyChanges();
            filterStore.setSearch('');
            map?.setPadding({ left: 0, top: 0, right: 0, bottom: 0 });
            sheet.close();
            window.dispatchEvent(new CustomEvent('zbiorkom:filters-changed'));
        },
    };
}
