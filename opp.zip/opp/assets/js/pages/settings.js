/**
 * Ustawienia — port komponentów:
 *   pages/Settings/index.tsx           — pełnoekranowy dialog
 *   pages/Settings/MarkerSettings.tsx  — znaczniki pojazdów (brygada/tabor)
 *   pages/Settings/BehaviorSettings.tsx — zachowanie aplikacji
 *   pages/Settings/LanguageSettings.tsx — język
 *   pages/Settings/CitySettings.tsx    — zmiana miasta
 *   pages/Settings/ThemeSettings.tsx   — zmiana motywu
 *   pages/Settings/ThemeDialog.tsx     — paleta kolorów motywu
 */

import { el, dialog, checkboxRow, radioRow } from '../ui.js';
import { renderIcon } from '../icons.js';
import { t, setLanguage, i18n, translations } from '../i18n.js';
import { navigate, pathname } from '../router.js';
import { settings, themeStore, applyTheme } from '../store.js';

import { THEME_COLORS } from '../branding.js';

export function mountSettingsDialog() {
    const d = dialog({ fullscreen: window.innerWidth <= 900, closeable: false, className: 'settings-dialog' });

    const header = el(
        'div',
        { className: 'page-header' },
        el(
            'button',
            {
                className: 'icon-button',
                onClick: () => navigate(pathname(), { state: 'menu' }),
            },
            renderIcon('Menu'),
        ),
        el('h5', {}, t('Settings.settings')),
    );

    /* Znaczniki pojazdów (port MarkerSettings.tsx) */
    const markerSettings = el(
        'div',
        { className: 'settings-card top-rounded' },
        el('h2', {}, t('Settings.vehicleMarker')),
        checkboxRow(t('Settings.brigade'), localStorage.getItem('brigade') === 'true', (value) => {
            settings.brigade = value;
        }),
        checkboxRow(t('Settings.fleet'), localStorage.getItem('fleet') === 'true', (value) => {
            settings.fleet = value;
        }),
    );

    /* Zachowanie (port BehaviorSettings.tsx) */
    const behaviorSettings = el(
        'div',
        { className: 'settings-card' },
        el('h2', {}, t('Settings.behavior')),
        checkboxRow(
            t('Settings.moveToLastLocation'),
            localStorage.getItem('moveToLastLocation') === 'true',
            (value) => {
                settings.moveToLastLocation = value;
            },
        ),
        checkboxRow(
            t('Settings.useLocationSorting'),
            localStorage.getItem('useLocationSorting') === 'true',
            (value) => {
                settings.useLocationSorting = value;
            },
        ),
        checkboxRow(
            t('Settings.useStopCodeAsIcon'),
            localStorage.getItem('useStopCodeAsIcon') === 'true',
            (value) => {
                settings.useStopCodeAsIcon = value;
            },
        ),
        checkboxRow(
            t('Settings.disableLiquidGlass'),
            localStorage.getItem('disableLiquidGlass') === 'true',
            (value) => {
                settings.disableLiquidGlass = value;
            },
        ),
    );

    /* Język (port LanguageSettings.tsx) */
    const languageSettings = el(
        'div',
        { className: 'settings-card' },
        el('h2', {}, t('Settings.language')),
        Object.keys(translations).map((language) =>
            radioRow(
                'language',
                t(`Languages.${language}`),
                i18n.language === language,
                () => {
                    setLanguage(language);
                    d.remove();
                    mountSettingsDialog();
                },
            ),
        ),
    );

    /* Miasto + motyw (port CitySettings.tsx + ThemeSettings.tsx) */
    const bottomRow = el(
        'div',
        { className: 'settings-bottom-row' },
        el(
            'button',
            { className: 'settings-half-button left', onClick: () => navigate('/cities') },
            renderIcon('LocationCity'),
            t('Settings.changeCity'),
        ),
        el(
            'button',
            { className: 'settings-half-button right', onClick: () => navigate(pathname() + '/theme') },
            renderIcon('ColorLens'),
            t('Settings.changeTheme'),
        ),
    );

    d.content.append(header, markerSettings, behaviorSettings, languageSettings, bottomRow);
    document.body.append(d);

    return {
        destroy() {
            d.remove();
        },
    };
}

/** Dialog wyboru koloru motywu (port ThemeDialog.tsx). */
export function mountThemeDialog() {
    const d = dialog({ onClose: () => window.history.back() });

    d.content.append(
        el(
            'div',
            { className: 'page-header' },
          el('button', { className: 'icon-button', onClick: () => window.history.back() }, renderIcon('Close')),
            el('h5', {}, t('Settings.changeTheme')),
        ),
    );

    const grid = el(
        'div',
        { className: 'theme-grid' },
        THEME_COLORS.map((color) =>
            el('button', {
                className: 'theme-color' + (themeStore.color === color ? ' selected' : ''),
                style: { backgroundColor: color },
                title: color,
                onClick: () => {
                    themeStore.setColor(color);
                    applyTheme();
                    d.remove();
                    mountThemeDialog();
                },
            }),
        ),
    );

    d.content.append(grid);
    document.body.append(d);

    return {
        destroy() {
            d.remove();
        },
    };
}
