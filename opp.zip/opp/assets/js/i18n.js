/**
 * Tłumaczenia aplikacji — dokładna kopia zasobów i18next z oryginału
 * (src/components/translations/pl.json i en.json).
 */

export const translations = {
    pl: {
    "Menu": {
        "welcome": "Witaj!",
        "installApp": "Zainstaluj aplikację",
        "installTitle": "Zainstaluj aplikację",
        "installAndroid": "Android / Chrome",
        "installAndroidHint": "Menu przeglądarki (⋮) → „Zainstaluj aplikację” lub „Dodaj do ekranu głównego”.",
        "installIos": "iPhone / iPad (Safari)",
        "installIosHint": "Przycisk udostępniania → „Dodaj do ekranu początkowego”.",
        "installDesktop": "Komputer",
        "installDesktopHint": "Kliknij ikonę instalacji w pasku adresu przeglądarki.",
        "map": "Mapa",
        "schedules": "Rozkłady",
        "blog": "Blog",
        "about": "O aplikacji",
        "settings": "Ustawienia",
        "executions": "Co wyjechało?",
        "privacyPolicy": "Polityka prywatności",
        "switchTo": "Przełączyć na",
        "yes": "Tak",
        "supportingRegulations": "Regulamin wspierania"
    },
    "Planner": {
        "title": "Planer tras",
        "from": "Skąd",
        "to": "Dokąd",
        "when": "Kiedy",
        "atWhatTime": "O której",
        "now": "Teraz",
        "maxTransfers": "Przesiadki",
        "noTransfers": "Bez przesiadek",
        "transfersN": "{{n}} przesiadek",
        "direct": "Bez przesiadek",
        "search": "Szukaj",
        "swap": "Zamień",
        "useLocation": "Użyj mojej lokalizacji",
        "pickOnMap": "Wskaż punkt na mapie",
        "pickFrom": "Kliknij punkt początkowy na mapie",
        "pickTo": "Kliknij punkt docelowy na mapie",
        "cancel": "Anuluj",
        "myLocation": "Moja lokalizacja",
        "locationFailed": "Nie można określić Twojej lokalizacji.",
        "needPoints": "Podaj punkt startowy i docelowy",
        "searchFailed": "Nie udało się wyszukać połączeń",
        "noConnections": "Brak połączeń",
        "noConnectionsHint": "Zmień kryteria wyszukiwania lub wykluczenia przewoźników.",
        "exclude": "Wyklucz",
        "wsiobus": "Wsiobusy",
        "pks": "PKS",
        "trains": "Pociągi",
        "min": "min",
        "sec": "s",
        "walk": "Przejście piesze",
        "cancelled": "odwołany",
        "showResults": "Pokaż listę połączeń",
        "attribution": "Dane planera: Transitous (transitous.org/sources)",
        "realtime": "na żywo",
        "scheduledOnly": "wg rozkładu",
        "backToResults": "Wróć do listy połączeń",
        "departures": "Odjazdy"
    },
    "Vehicle": {
        "onTime": "Planowo",
        "early": "{{time}} przed czasem",
        "delayed": "Opóźniony {{time}}",
        "departure": "Oczekiwanie na odjazd",
        "departed": "Odjechał",
        "cancelled": "Odwołany",
        "scheduled": "Brak danych o opóźnieniu",
        "tripNotFound": "Nie znaleźliśmy tej trasy...",
        "vehicleSchedule": "Rozkład jazdy pojazdu",
        "brigadeSchedule": "Rozkład brygady",
        "vehicleInfo": "Informacje o pojeździe",
        "platform": "Peron",
        "track": "Tor",
        "breakTime": "{{time}} przerwy",
        "noBreak": "Bez przerwy",
        "addFavoriteRoute": "Dodaj {{route}} do ulubionych",
        "removeFavoriteRoute": "Usuń {{route}} z ulubionych",
        "favoriteStops": "Ulubione przystanki",
        "selectRoutes": "Wybierz linie:",
        "frequency": "Co <0>{{time}}</0> min",
        "then": "Potem",
        "noMoreDepartures": "Brak dalszych odjazdów",
        "routeChange": "Zmiana linii na {{route}}",
        "terminus": "Przystanek krańcowy",
        "operatedBy": "Kurs obsługiwany przez {{value}}",
        "alerts": "Utrudnienia",
        "alertsFrom": "od {{moment}}",
        "alertsUntil": "do {{moment}}",
        "alertsPublished": "opublikowano {{moment}}",
        "alertsDetails": "Więcej informacji",
        "alertsEmpty": "Bez utrudnień",
        "alertsEmptyDescription": "Nie ma w tej chwili żadnych zgłoszonych utrudnień.",
        "sunPosition": "Gdzie usiąść?",
        "sec": "sek",
        "min": "min",
        "vehicleNotFound": "Nie znaleziono pojazdu.",
        "routeEmpty": "Ta linia nie ma przystanków",
        "showStops_one": "Pokaż {{count}} przystanek",
        "showStops_few": "Pokaż {{count}} przystanki",
        "showStops_many": "Pokaż {{count}} przystanków",
        "showStops_other": "Pokaż {{count}} przystanków"
    },
    "Brigades": {
        "selectBrigade": "Wybierz brygadę dla linii <0></0>",
        "brigadeSchedule": "Rozkład brygady <0></0>",
        "trips": "{{tripsLength}} kursów",
        "travelTime": "Czas przejazdu: {{time}}",
        "clickForTrip": "Kliknij, aby zobaczyć kurs",
        "operatedBy": "Realizowany przez pojazd #{{vehicle}}",
        "multilineAlert": "Brygada wieloliniowa, możliwe błędy w dopasowywaniu rozkładów pojazdów. Prosimy o użycie własnego rozsądku w celu weryfikacji poprawności dopasowań.",
        "noDuty": "Brak rozkładów brygadowych w wybranym dniu"
    },
    "Schedules": {
        "schedules": "Rozkłady",
        "search": "Wyszukaj linie",
        "anywhere": "Gdziekolwiek (kliknij, aby zmienić)",
        "noDepartures": "Brak nadchodzących odjazdów",
        "removeDestination": "Usuń kierunek",
        "stopNotServed": "Przystanek {{stop}} nie jest dzisiaj obsługiwany."
    },
    "Shared": {
        "share": "Udostępnij",
        "close": "Zamknij",
        "ago": "temu",
        "loadError": "Wystąpił błąd ładowania",
        "networkError": "Brak połączenia z serwerem",
        "retry": "Spróbuj ponownie"
    },
    "Favorites": {
        "selectDirection": "Wybierz kierunek",
        "addStopsHere": "Twoje ulubione przystanki",
        "howToAddStopsHere": "Aby dodać przystanek, kliknij gwiazdkę ⭐ na przystanku.",
        "thanksToDirection": "Pokazujemy tylko odjazdy do wybranych miejsc. Usuń wszystkie kierunki, aby wrócić do wszystkich odjazdów.",
        "allDirections": "Pokazujemy wszystkie odjazdy. Wybierając kierunek, pokażemy tylko odjazdy do wybranego miejsca.",
        "editDirections": "Filtruj kierunki"
    },
    "Search": {
        "bestResults": "✨ Najlepszy wynik",
        "stops": "Przystanki",
        "vehicles": "Pojazdy",
        "routes": "Linie",
        "stations": "Stacje",
        "howToUse": "Jak używać wyszukiwarki?",
        "howToVehicles": "Wyszukiwanie pojazdów",
        "vehiclesDescription": "Wyszukaj używając numeru taborowego (np. 5869), linii (np. 105) lub brygady (np. 105/1)",
        "howToStops": "Wyszukiwanie przystanków i stacji",
        "stopsDescription": "Wyszukaj używając nazwy, np. Dworzec Główny.",
        "howToRoutes": "Wyszukiwanie linii",
        "routesDescription": "Wyszukaj używając numeru linii, np. 105.",
        "howToHistory": "Historia wyszukiwania",
        "historyDescription": "Zapisujemy ostatnie wyszukiwania, abyś mógł szybko do nich wrócić.",
        "relations": "Relacje",
        "howToRelations": "Wyszukiwanie relacji pociągów",
        "relationsDescription": "Wyszukaj używając numeru relacji, np. 99267."
    },
    "Filter": {
        "filter": "Filtrowanie",
        "searchRoutesOrModels": "Wyszukaj linie lub modele",
        "routesNearby": "Linie w pobliżu",
        "activeFilters": "Aktywne filtry",
        "howToUseTitle": "Jak używać filtrowania?",
        "howToUseContent": "Aby filtrować pojazdy na mapie, wybierz interesujące Cię linie lub modele pojazdów poprzez wyszukiwarkę, następnie wróć do mapy klikając na nią."
    },
    "VehicleInfo": {
        "model": "Model",
        "depot": "Zajezdnia",
        "carrier": "Przewoźnik",
        "prodYear": "Rok produkcji",
        "lowFloor": "Niska podłoga",
        "airConditioned": "Klimatyzacja",
        "equipment": "Wyposażenie",
        "noData": "Brak danych o pojeździe"
    },
    "Updates": {
        "downloadingUpdate": "Pobieram aktualizację..."
    },
    "Blog": {
        "blog": "Blog"
    },
    "Settings": {
        "settings": "Ustawienia",
        "vehicleMarker": "Znaczniki pojazdów",
        "brigade": "Numer brygady",
        "fleet": "Numer taborowy",
        "language": "Język",
        "searchRoutes": "Wyszukaj linie",
        "changeCity": "Zmień miasto",
        "changeTheme": "Zmień motyw",
        "pickCity": "Wybierz obszar metropolitalny",
        "welcome": "Witaj na zbiorkom.live!",
        "selectCity": "Wybierz twoje lub najbliższe miasto.",
        "behavior": "Zachowanie aplikacji",
        "moveToLastLocation": "Użyj ostatniej lokalizacji przy otwarciu mapy",
        "useLocationSorting": "Sortuj przystanki według Twojej lokalizacji",
        "welcomeTo": "Witaj na",
        "welcomeText": "Wybierz miasto, aby zobaczyć komunikację miejską na żywo.",
        "searchCities": "Wyszukaj miasto",
        "containsAgencies": "Zawiera",
        "useStopCodeAsIcon": "Użyj numeru przystanku jako ikony",
        "disableLiquidGlass": "Wyłącz efekt rozmytego szkła"
    },
    "Languages": {
        "en": "Angielski",
        "pl": "Polski"
    },
    "Seo": {
        "blogPosts": {
            "title": "Blog",
            "description": "Przeczytaj najnowsze wpisy na naszym blogu poświęconym komunikacji miejskiej. Dowiedz się więcej o nowościach w aplikacji, planowanych funkcjach oraz ciekawostkach związanych z transportem publicznym."
        },
        "blogPost": {
            "title": "{{title}}",
            "description": "{{description}}"
        },
        "brigadeSelect": {
            "title": "Wybierz brygadę dla linii {{route}} w {{city}}"
        },
        "brigadeSchedule": {
            "title": "Rozkład brygady {{route}}/{{brigade}} w {{city}}",
            "description": "Sprawdź rozkład brygady {{brigade}} linii {{route}} w {{city}}. Zobacz wszystkie kursy, czasy przejazdu oraz informacje o pojeździe, który realizuje daną trasę."
        },
        "settings": {
            "title": "Ustawienia",
            "description": "Dostosuj aplikację do swoich potrzeb. Wybierz język, zmień ikonę aplikacji, a także wybierz miasto, w którym aktualnie się znajdujesz."
        },
        "cities": {
            "title": "Wybierz miasto",
            "description": "Sprawdź gdzie jest twój autobus, tramwaj lub pociąg w {{cities}}. Zobacz odjazdy z przystanków, rozkłady jazdy i brygady oraz informacje o pojazdach."
        },
        "city": {
            "title": "{{city}} - Mapa komunikacji miejskiej",
            "description": "Śledź w czasie rzeczywistym ruch autobusów, tramwajów i pociągów w {{city}}! Klikając na pojazd lub przystanek, uzyskaj szczegółowe informacje o trasie oraz najbliższych odjazdach. Dostosuj widok mapy, filtrując według interesujących Cię linii lub modelu pojazdu, by szybko i sprawnie planować swoją podróż."
        },
        "route": {
            "title": "{{city}} - Rozkład linii {{route}}",
            "description": "Sprawdź rozkład jazdy linii {{route}} w {{city}}. Zobacz wszystkie kursy, czasy przejazdu, rozkład brygad oraz informacje o pojeździe, który realizuje daną trasę."
        },
        "schedules": {
            "title": "{{city}} - Rozkłady jazdy",
            "description": "Sprawdź rozkłady jazdy autobusów, tramwajów i pociągów w {{city}}. Zobacz odjazdy z przystanków, rozkłady brygad oraz informacje o pojazdach."
        },
        "station": {
            "title": "Stacja {{station}}",
            "description": "Sprawdź odjazdy pociągów ze stacji {{station}}. Opóźnienia pociągów, informacje o peronach oraz lokalizacja pociągu na mapie."
        },
        "stop": {
            "title": "Przystanek {{stop}} w {{city}}",
            "description": "Sprawdź odjazdy komunikacji miejskiej z przystanku {{stop}} w {{city}}. Lokalizacja pojazdów na mapie, informacje o odjazdach oraz rozkład jazdy."
        },
        "trip": {
            "title": "Kurs linii {{route}} w kierunku {{headsign}}",
            "description": "Sprawdź trasę kursu linii {{route}} w kierunku {{headsign}}. Zobacz odjazdy z przystanków, lokalizację pojazdu na mapie oraz informacje o pojeździe."
        },
        "vehicle": {
            "title": "Pojazd {{vehicle}} na linii {{route}}"
        }
    },
    "Time": {
        "enterTime": "Wprowadź czas",
        "hour": "Godzina",
        "minute": "Minuty",
        "nextDay": "Zobaczysz rozkład na następny dzień od {{time}}",
        "cancel": "Anuluj",
        "save": "OK"
    },
    "Executions": {
        "executions": "Co wyjechało?",
        "vehicle": "Pojazd",
        "trip": "Kurs",
        "route": "Linia",
        "brigade": "Brygada",
        "expandStops": "Pokaż przystanki",
        "hideStops": "Ukryj przystanki",
        "noResults": "Brak wyników...",
        "noResultsDescription": "Spróbuj wyszukać coś innego.",
        "noFilter": "Wyszukaj coś..."
    },
    "Directions": {
        "noResultsFound": "Zgubiliśmy się!",
        "noResultsFoundDescription": "Nie wiemy jak tu dojechać...",
        "lastUpdated": "Ostatnio zaktualizowano",
        "leave": "Wyjdź o",
        "arrive": "Przyjazd o"
    },
    "Layers": {
        "layers": "Warstwy",
        "darkMode": "Ciemny motyw"
    },
    "Backend": {
        "error": {
            "retry": "Spróbuj ponownie",
            "network": {
                "title": "Brak połączenia z internetem",
                "message": "Sprawdź Wi-Fi lub dane komórkowe i spróbuj ponownie."
            },
            "server": {
                "title": "Coś poszło nie tak po naszej stronie",
                "message": "Serwery zbiorkom.live w tej chwili nie odpowiadają. Spróbuj ponownie za chwilę."
            },
            "unknown": {
                "title": "Coś poszło nie tak",
                "message": "Nie udało się załadować mapy. Spróbuj ponownie."
            }
        }
    }
},
    en: {
    "Menu": {
        "welcome": "Welcome",
        "installApp": "Install app",
        "installTitle": "Install app",
        "installAndroid": "Android / Chrome",
        "installAndroidHint": "Browser menu (⋮) → “Install app” / “Add to Home screen”.",
        "installIos": "iPhone / iPad (Safari)",
        "installIosHint": "Share button → “Add to Home Screen”.",
        "installDesktop": "Desktop",
        "installDesktopHint": "Click the install icon in the browser address bar.",
        "map": "Map",
        "schedules": "Schedules",
        "blog": "Blog",
        "about": "About the app",
        "settings": "Settings",
        "executions": "Dispatches",
        "privacyPolicy": "Privacy policy",
        "switchTo": "Switch to",
        "yes": "Yes",
        "supportingRegulations": "Supporting regulations"
    },
    "Planner": {
        "title": "Route planner",
        "from": "From",
        "to": "To",
        "when": "Date",
        "atWhatTime": "Time",
        "now": "Now",
        "maxTransfers": "Transfers",
        "noTransfers": "No transfers",
        "transfersN": "{{n}} transfers",
        "direct": "Direct",
        "search": "Search",
        "swap": "Swap",
        "useLocation": "Use my location",
        "pickOnMap": "Pick point on map",
        "pickFrom": "Click the starting point on the map",
        "pickTo": "Click the destination on the map",
        "cancel": "Cancel",
        "myLocation": "My location",
        "locationFailed": "Could not determine your location.",
        "needPoints": "Enter the start and destination points",
        "searchFailed": "Failed to search for connections",
        "noConnections": "No connections",
        "noConnectionsHint": "Change search criteria or carrier exclusions.",
        "exclude": "Exclude",
        "wsiobus": "Suburban buses",
        "pks": "PKS",
        "trains": "Trains",
        "min": "min",
        "sec": "s",
        "walk": "Walk",
        "cancelled": "cancelled",
        "showResults": "Show connection list",
        "attribution": "Planner data: Transitous (transitous.org/sources)",
        "realtime": "live",
        "scheduledOnly": "as scheduled",
        "backToResults": "Back to connections",
        "departures": "Departures"
    },
    "Vehicle": {
        "onTime": "On time",
        "early": "Early {{time}}",
        "delayed": "Delayed {{time}}",
        "departure": "Waiting for departure",
        "departed": "Departed",
        "cancelled": "Cancelled",
        "scheduled": "Scheduled",
        "tripNotFound": "We couldn't find this route...",
        "vehicleSchedule": "Vehicle schedule",
        "brigadeSchedule": "Brigade schedule",
        "vehicleInfo": "Vehicle info",
        "platform": "Platform",
        "track": "Track",
        "breakTime": "{{time}} break",
        "noBreak": "No break",
        "addFavoriteRoute": "Add {{route}} to favorites",
        "removeFavoriteRoute": "Remove {{route}} from favorites",
        "favoriteStops": "Favorite stops",
        "selectRoutes": "Select routes:",
        "frequency": "Every <0>{{time}}</0> min",
        "then": "Then",
        "noMoreDepartures": "No more departures",
        "routeChange": "Route change to {{route}}",
        "terminus": "Terminus",
        "operatedBy": "Trip operated by {{value}}",
        "alerts": "Impediments",
        "alertsFrom": "from {{moment}}",
        "alertsUntil": "until {{moment}}",
        "alertsPublished": "published {{moment}}",
        "alertsDetails": "More information",
        "alertsEmpty": "No impediments",
        "alertsEmptyDescription": "There are no reported disruptions right now.",
        "sunPosition": "Where to sit?",
        "sec": "sec",
        "min": "min",
        "vehicleNotFound": "Vehicle not found.",
        "routeEmpty": "This line has no stops",
        "showStops_one": "Show {{count}} stop",
        "showStops_other": "Show {{count}} stops"
    },
    "Brigades": {
        "selectBrigade": "Choose the brigade of route <0></0>",
        "brigadeSchedule": "Schedule of brigade <0></0>",
        "trips": "{{tripsLength}} trips",
        "travelTime": "Travel time: {{time}}",
        "clickForTrip": "Click to see the trip",
        "operatedBy": "Operated by vehicle #{{vehicle}}",
        "multilineAlert": "Multiline brigade, possible errors in matching vehicle schedules. Please use your own judgment to verify the correctness of the matches.",
        "noDuty": "No duty schedules are available on the selected day"
    },
    "Schedules": {
        "schedules": "Schedules",
        "search": "Search routes",
        "anywhere": "Anywhere (click to change)",
        "noDepartures": "No upcoming departures",
        "removeDestination": "Remove destination",
        "stopNotServed": "Stop {{stop}} is not served today."
    },
    "Shared": {
        "share": "Share",
        "close": "Close",
        "ago": "ago",
        "loadError": "Failed to load",
        "networkError": "No connection to the server",
        "retry": "Try again"
    },
    "Favorites": {
        "selectDirection": "Select direction",
        "addStopsHere": "Your favorite stops",
        "howToAddStopsHere": "To add a stop, click the star ⭐ on the stop.",
        "thanksToDirection": "We show only departures to the chosen places. Remove all directions to see every departure again.",
        "allDirections": "We show all departures. By selecting a direction, we'll show only departures to the chosen place.",
        "editDirections": "Filter directions"
    },
    "Search": {
        "bestResults": "✨ Best result",
        "stops": "Stops",
        "vehicles": "Vehicles",
        "routes": "Routes",
        "stations": "Stations",
        "howToUse": "How to use the search?",
        "howToVehicles": "Searching for vehicles",
        "vehiclesDescription": "Search using the fleet number (e.g., 5869), route (e.g., 105) or brigade (e.g., 105/1)",
        "howToStops": "Searching for stops and stations",
        "stopsDescription": "Search using the name, e.g., Main Station.",
        "howToRoutes": "Searching for routes",
        "routesDescription": "Search using the route number, e.g., 105.",
        "howToHistory": "Search history",
        "historyDescription": "We save recent searches so you can quickly return to them.",
        "relations": "Relations",
        "howToRelations": "Searching for train relations",
        "relationsDescription": "Search using the relation number, e.g., 99267."
    },
    "Filter": {
        "filter": "Filter",
        "searchRoutesOrModels": "Search routes or models",
        "routesNearby": "Routes nearby",
        "activeFilters": "Active filters",
        "howToUseTitle": "How to use filtering?",
        "howToUseContent": "To filter vehicles on the map, select the lines or vehicle models you are interested in through the search input, then return to the map by clicking on it."
    },
    "VehicleInfo": {
        "model": "Model",
        "depot": "Depot",
        "carrier": "Carrier",
        "prodYear": "Production year",
        "lowFloor": "Low floor",
        "airConditioned": "Air conditioned",
        "equipment": "Equipment",
        "noData": "No vehicle data available"
    },
    "Updates": {
        "downloadingUpdate": "Downloading update..."
    },
    "Blog": {
        "blog": "Blog"
    },
    "Settings": {
        "settings": "Settings",
        "vehicleMarker": "Vehicle marker",
        "brigade": "Brigade number",
        "fleet": "Fleet number",
        "language": "Language",
        "searchRoutes": "Search routes",
        "pickCity": "Select metropolitan area",
        "changeCity": "Change city",
        "changeTheme": "Change theme",
        "behavior": "Application behavior",
        "moveToLastLocation": "Use last location when opening the map",
        "useLocationSorting": "Sort stops according to your location",
        "welcomeTo": "Welcome to",
        "welcomeText": "Select a city to see live public transport on map.",
        "searchCities": "Search cities",
        "containsAgencies": "Contains",
        "useStopCodeAsIcon": "Use stop code as icon",
        "disableLiquidGlass": "Disable liquid glass effect"
    },
    "Languages": {
        "en": "English",
        "pl": "Polish"
    },
    "Seo": {
        "blogPosts": {
            "title": "Blog",
            "description": "Read the latest posts on our blog dedicated to public transportation. Learn more about new features in the app, planned functionalities, and interesting facts related to public transport."
        },
        "blogPost": {
            "title": "{{title}}",
            "description": "{{description}}"
        },
        "brigadeSelect": {
            "title": "Select brigade for route {{route}} in {{city}}"
        },
        "brigadeSchedule": {
            "title": "Brigade schedule {{route}}/{{brigade}} in {{city}}",
            "description": "Check the schedule of brigade {{brigade}} for route {{route}} in {{city}}. See all trips, travel times, and information about the vehicle operating the route."
        },
        "settings": {
            "title": "Settings",
            "description": "Customize the app to your needs. Choose the language, change the app icon, and select the city you are currently in."
        },
        "cities": {
            "title": "Select city",
            "description": "Check where your bus, tram, or train is in {{cities}}. See departures from stops, timetables, brigades, and vehicle information."
        },
        "city": {
            "title": "{{city}} - Public transport map",
            "description": "Track the real-time movement of buses, trams, and trains in {{city}}! By clicking on a vehicle or stop, get detailed information about the route and upcoming departures. Customize the map view by filtering according to the lines or vehicle models you are interested in to quickly and efficiently plan your journey."
        },
        "route": {
            "title": "{{city}} - Route {{route}} schedule",
            "description": "Check the schedule of route {{route}} in {{city}}. See all trips, travel times, brigade schedules, and information about the vehicle operating the route."
        },
        "schedules": {
            "title": "{{city}} - Timetables",
            "description": "Check the timetables of buses, trams, and trains in {{city}}. See departures from stops, brigade schedules, and vehicle information."
        },
        "station": {
            "title": "Station {{station}}",
            "description": "Check train departures from station {{station}}. Train delays, platform information, and train location on the map."
        },
        "stop": {
            "title": "Stop {{stop}} in {{city}}",
            "description": "Check public transport departures from stop {{stop}} in {{city}}. Vehicle location on the map, departure information, and timetable."
        },
        "trip": {
            "title": "Trip of route {{route}} towards {{headsign}}",
            "description": "Check the trip of route {{route}} towards {{headsign}}. See departures from stops, vehicle location on the map, and vehicle information."
        },
        "vehicle": {
            "title": "Vehicle {{vehicle}} on route {{route}}"
        }
    },
    "Time": {
        "enterTime": "Enter time",
        "hour": "Hour",
        "minute": "Minute",
        "nextDay": "You will see the schedule for the next day from {{time}}",
        "cancel": "Cancel",
        "save": "OK"
    },
    "Executions": {
        "executions": "Dispatches",
        "vehicle": "Vehicle",
        "trip": "Trip",
        "route": "Route",
        "brigade": "Brigade",
        "expandStops": "Show stops",
        "hideStops": "Hide stops",
        "noResults": "No results...",
        "noResultsDescription": "Try searching for something else.",
        "noFilter": "Search for something..."
    },
    "Directions": {
        "noResultsFound": "We're lost!",
        "noResultsFoundDescription": "We don't know how to get there...",
        "lastUpdated": "Last updated",
        "leave": "Leave at",
        "arrive": "Arrive by"
    },
    "Layers": {
        "layers": "Layers",
        "darkMode": "Dark mode"
    },
    "Backend": {
        "error": {
            "retry": "Try again",
            "network": {
                "title": "No internet connection",
                "message": "Check your Wi-Fi or mobile data and try again."
            },
            "server": {
                "title": "Something went wrong on our end",
                "message": "zbiorkom.live servers aren't responding right now. Please try again in a moment."
            },
            "unknown": {
                "title": "Something went wrong",
                "message": "We couldn't load the map. Please try again."
            }
        }
    }
},
};

/**
 * Aktywny język — identyczna logika jak w register.ts:
 * Googlebot dostaje polski, użytkownik język z localStorage,
 * a w przeciwnym razie język przeglądarki.
 */
const isGoogleBot = navigator.userAgent.includes('Googlebot');

export const i18n = {
    language: isGoogleBot ? 'pl' : localStorage.getItem('language') || navigator.language.split('-')[0],
    fallback: 'pl',
};

export function setLanguage(language) {
    i18n.language = language;
    localStorage.setItem('language', language);
}

/**
 * Tłumaczy klucz w formacie "namespace.klucz" z podstawieniami
 * {{zmienna}} — odpowiednik useTranslation / t() z react-i18next.
 */
export function t(key, replacements = {}) {
    const [ns, ...rest] = key.split('.');
    const path = rest.join('.');

    for (const lang of [i18n.language, i18n.fallback]) {
        const dict = translations[lang];
        if (!dict) continue;

        let node = dict[ns];
        if (node === undefined) continue;

        // Słownik może być zagnieżdżony (np. Backend.error.network.title)
        for (const part of path.split('.')) {
            node = node?.[part];
        }

        if (typeof node === 'string') {
            return node.replace(/\{\{(\w+)\}\}/g, (_, name) => replacements[name] ?? '');
        }
    }

    return key;
}
