/**
 * Konfiguracja po stronie klienta — wartości wstrzyknięte z PHP (config.php)
 * oraz stałe oryginalnej aplikacji.
 */

// window.Gay ustawia index.php (odpowiednik register.ts)
export const API_BASE = window.Gay.base;
export const CLOUD_BASE = window.Gay.cloudBase;
export const WELCOME_ALERT_URL = window.Gay.welcomeAlertUrl;
export const APP_VERSION = window.Gay.version;

// API planera tras Transitous (MOTIS 2) — https://transitous.org/api/
export const API_BASE_TRANSITOUS = 'https://api.transitous.org/api';

export const DEFAULT_TIMEZONE = 'Europe/Warsaw';
export const DEFAULT_LOCATION = [21.0122, 52.2297];

// Limit czasu żądań (odpowiednik cities.ts)
export const REQUEST_TIMEOUT = 10000;
export const CONNECTIVITY_TIMEOUT = 5000;
export const CONNECTIVITY_CHECK_URL = 'https://www.gstatic.com/generate_204';
