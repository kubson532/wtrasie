/**
 * Klient API Transitous (MOTIS 2) — silnik planera tras.
 *
 * Dokumentacja API: https://transitous.org/api/
 *  - geokodowanie: GET /api/v1/geocode?text=...
 *  - planowanie:   GET /api/v1/plan?fromPlace=lat,lon&toPlace=lat,lon&time=ISO
 *
 * Odpowiedź planu zawiera itineraria z nogami (WALK + środki transportu),
 * czasami rozkładowymi i rzeczywistymi (realtime) oraz geometriami polyline
 * o precyzji podanej w polu legGeometry.precision.
 *
 * Zgodnie z polityką użycia Transitous aplikacja wysyła nagłówek Referer
 * (przeglądarka) i prezentuje atrybucję w widoku planera.
 */

import { API_BASE_TRANSITOUS } from './config.js';
import { searchTokens, matchesTokens } from './util.js';

/** Pojedyncze zapytanie geokodujące do MOTIS. */
async function geocodeOnce(text, { signal, nearLat, nearLon } = {}) {
    const params = new URLSearchParams({ text });
    if (typeof nearLat === 'number' && typeof nearLon === 'number') {
        params.set('place', `${nearLat},${nearLon}`);
        params.set('placeBias', '2');
        params.set('numResults', '12');
    }

    const url = `${API_BASE_TRANSITOUS}/v1/geocode?${params.toString()}`;

    const response = await fetch(url, { signal });
    if (!response.ok) throw new Error('GEOCODE_ERROR');

    const results = await response.json();

    // Priorytet: przystanki przed miejscami (jak w aplikacji zbiorkom)
    const stops = results.filter((r) => r.type === 'STOP');
    const places = results.filter((r) => r.type === 'PLACE');

    const withPriority = [...stops, ...places].map((r) => ({
        type: r.type,
        id: r.id,
        name: r.name,
        area: r.areas?.find((a) => a.unique)?.name || r.areas?.[0]?.name,
        lat: r.lat,
        lon: r.lon,
        modes: r.modes,
    }));

    // Dodatkowe sortowanie wg odległości — wzmacnia bias serwera
    if (typeof nearLat === 'number' && typeof nearLon === 'number') {
        const distance = (r) => (r.lat - nearLat) ** 2 + (r.lon - nearLon) ** 2;
        withPriority.sort((a, b) => distance(a) - distance(b));
    }

    return withPriority.slice(0, 12);
}

/**
 * Geokodowanie miejsc i przystanków z ROZMYTYM dopasowaniem:
 *  - pomijamy znaki polskie, cyfry i ukośniki,
 *  - spacja oddziela FILTRY („Podkarpacka Politechnika 01” → „pod” + „pol”),
 *  - każdy wynik musi spełniać WSZYSTKIE filtry.
 * Gdy pełne zapytanie nie zwraca wystarczająco wyników, próbujemy
 * kolejno z najdłuższym tokenem (a potem każdym tokenem) i filtrujemy
 * wyniki całą listą filtrów — dzięki temu częściowo wpisane frazy
 * i literówki i tak znajdują przystanek.
 */
export async function geocode(text, { signal, nearLat, nearLon } = {}) {
    const trimmed = String(text ?? '').trim();
    if (trimmed.length < 2) return [];

    const tokens = searchTokens(trimmed);

    // Drabina zapytań: pełna fraza → najdłuższy token → pozostałe tokeny
    const ladder = [trimmed];
    if (tokens.length > 1) {
        const longest = [...tokens].sort((a, b) => b.length - a.length)[0];
        ladder.push(longest);
        for (const token of tokens) {
            if (token !== longest && token.length >= 3) ladder.push(token);
        }
    }

    const seen = new Set();
    const collected = [];

    for (const query of ladder.slice(0, 3)) {
        let results = [];
        try {
            results = await geocodeOnce(query, { signal, nearLat, nearLon });
        } catch {
            if (query === trimmed) throw new Error('GEOCODE_ERROR');
            continue;
        }

        for (const result of results) {
            if (!matchesTokens(result.name, result.area, tokens)) continue;
            const key = `${result.type}:${result.id}`;
            if (seen.has(key)) continue;
            seen.add(key);
            collected.push(result);
        }

        if (collected.length >= 6) break;
    }

    return collected.slice(0, 8);
}

/**
 * Planowanie podróży przez silnik Transitous.
 *
 * @param {object} options
 *   from, to        — { lat, lon, name } (współrzędne lub przystanek)
 *   time            — Date (moment odjazdu)
 *   arriveBy        — true = szukaj po czasie PRZYJAZDU
 *   maxTransfers    — maksymalna liczba przesiadek
 *   numOfResults    — liczba wyników (pobieramy więcej i filtrujemy przewoźników)
 */
export async function plan({
    from,
    to,
    time,
    arriveBy = false,
    maxTransfers = 3,
    numOfResults = 8,
    signal,
}) {
    const params = new URLSearchParams({
        fromPlace: `${from.lat},${from.lon}`,
        toPlace: `${to.lat},${to.lon}`,
        time: time.toISOString(),
        maxTransfers: String(maxTransfers),
        numOfResults: String(numOfResults),
        // Domyślny promień pieszy jest mały — zwiększamy, by dosięgnąć wsiobusów
        maxWalkTime: '30',
        maxTravelTime: '10800',
    });

    if (arriveBy) params.set('arriveBy', 'true');

    const url = `${API_BASE_TRANSITOUS}/v1/plan?${params.toString()}`;

    const response = await fetch(url, { signal });
    if (!response.ok) throw new Error('PLAN_ERROR');

    const data = await response.json();

    return {
        itineraries: data.itineraries || [],
        direct: data.direct || [],
    };
}

/* ------------------------------------------------------------------ */
/* Klasyfikacja przewoźników (przełączniki wykluczeń w planerze)        */
/* ------------------------------------------------------------------ */

/** Tryby oznaczające pociągi w MOTIS. */
const TRAIN_MODES = new Set([
    'RAIL',
    'LONG_DISTANCE',
    'REGIONAL_RAIL',
    'NIGHT_LONG_DISTANCE',
    'METRO',
    'SUBWAY',
]);

/** Nazwy przewoźników kolejowych. */
const TRAIN_AGENCIES = /pkp|polregio|koleje|skm|wkd|arriva|intercity/i;

/** Czy noga to pociąg. */
export function isTrainLeg(leg) {
    return TRAIN_MODES.has(leg.mode) || TRAIN_AGENCIES.test(leg.agencyName || '');
}

/** Czy noga to autobus PKS (dalekobieżny/lokalny przewoźnik PKS). */
export function isPksLeg(leg) {
    return /pks/i.test(leg.agencyName || '');
}

/**
 * Czy noga to "wsiobus" — podmiejska linia autobusowa.
 * W Kielcach linie podmiejskie mają numby 100+; dodatkowo sprawdzamy
 * nazwę przewoźnika/linii pod kątem "wsiobus".
 */
export function isWsiobusLeg(leg) {
    if (leg.mode !== 'BUS' || isTrainLeg(leg) || isPksLeg(leg)) return false;

    const routeName = String(leg.routeShortName || '');
    const haystack = `${leg.agencyName || ''} ${leg.routeLongName || ''}`;

    if (/wsiobus/i.test(haystack)) return true;

    // Numery 100+ w Kielcach to linie podmiejskie (wsiobusy)
    return /^\d{3,}$/.test(routeName) && parseInt(routeName, 10) >= 100;
}

/**
 * Filtruje itineraria według wykluczonych kategorii przewoźników.
 * Zwraca itineraria, które NIE korzystają z wykluczonych środków.
 */
export function filterItineraries(itineraries, { excludeWsiobus, excludePks, excludeTrains }) {
    if (!excludeWsiobus && !excludePks && !excludeTrains) return itineraries;

    const excluded = (leg) => {
        if (leg.mode === 'WALK') return false;
        if (excludeTrains && isTrainLeg(leg)) return true;
        if (excludePks && isPksLeg(leg)) return true;
        if (excludeWsiobus && isWsiobusLeg(leg)) return true;
        return false;
    };

    return itineraries.filter((itinerary) =>
        itinerary.legs.every((leg) => !excluded(leg)),
    );
}

/* ------------------------------------------------------------------ */
/* Pełna lista przystanków kursu + odjazdy z przystanku                */
/* ------------------------------------------------------------------ */

/* Cache pełnych list przystanków per noga (tripId+from+to). */
const legStopsCache = new Map();

/**
 * Pobiera KURS z MOTIS (/api/v1/trip) — pełną listę przystanków pojazdu
 * (setki przystanków; plan zwraca tylko UCIĘTE intermediateStops).
 * Używane przez planer, gdy użytkownik rozwija nogę — lista przystanków
 * po drodze zawiera wtedy WSZYSTKIE pośrednie przystanki.
 */
export async function fetchTrip(tripId, { signal } = {}) {
    const url = `${API_BASE_TRANSITOUS}/v1/trip?tripId=${encodeURIComponent(tripId)}`;
    const response = await fetch(url, { signal });
    if (!response.ok) throw new Error('TRIP_ERROR');
    return response.json();
}

/**
 * Pełna lista przystanków NOGI (od place.from do place.to włącznie)
 * na podstawie kursu z /api/v1/trip. Dopasowuje przystanki po stopId
 * (z wyborem wystąpienia najbliższego czasowo), zwraca null przy błędzie.
 */
export async function fetchLegStops(leg, { signal } = {}) {
    const cacheKey = `${leg.tripId}|${leg.from?.stopId}|${leg.to?.stopId}`;
    if (legStopsCache.has(cacheKey)) return legStopsCache.get(cacheKey);

    try {
        const trip = await fetchTrip(leg.tripId, { signal });

        // Wszystkie przystanki kursu (kurs może mieć wiele nóg — interlinia)
        const allStops = [];
        for (const tripLeg of trip.legs || []) {
            allStops.push(
                tripLeg.from,
                ...(tripLeg.intermediateStops || []),
                tripLeg.to,
            );
        }

        const fromTime = motisTime(leg.from?.departure ?? leg.from?.scheduledDeparture);
        const toTime = motisTime(leg.to?.arrival ?? leg.to?.scheduledArrival);

        // Znajdź indeksy przystanków granicznych: pierwsza para (from, to)
        // o zgodnych stopId i czasach najbliższych czasom nogi.
        let fromIndex = -1;
        let toIndex = -1;
        let bestScore = Infinity;

        for (let i = 0; i < allStops.length; i++) {
            if (!allStops[i] || allStops[i].stopId !== leg.from?.stopId) continue;
            const iTime = motisTime(allStops[i].departure ?? allStops[i].arrival);
            const iDelta = fromTime !== null && iTime !== null ? Math.abs(iTime - fromTime) : 0;

            for (let j = i + 1; j < allStops.length; j++) {
                if (!allStops[j] || allStops[j].stopId !== leg.to?.stopId) continue;
                const jTime = motisTime(allStops[j].arrival ?? allStops[j].departure);
                const jDelta = toTime !== null && jTime !== null ? Math.abs(jTime - toTime) : 0;

                const score = iDelta + jDelta;
                if (score < bestScore) {
                    bestScore = score;
                    fromIndex = i;
                    toIndex = j;
                }
                break; // pierwsza para od tego wystąpienia from wystarcza
            }
        }

        if (fromIndex === -1 || toIndex === -1) {
            legStopsCache.set(cacheKey, null);
            return null;
        }

        const stops = allStops.slice(fromIndex, toIndex + 1);
        legStopsCache.set(cacheKey, stops);
        return stops;
    } catch {
        legStopsCache.set(cacheKey, null);
        return null;
    }
}

/* Cache ścieżek dojazdu (nabiegania) per noga. */
const approachPathCache = new Map();

/**
 * Ścieżka DOJAZDU pojazdu do mojego przystanku WSIADANIA:
 * geometria pełnego kursu (/api/v1/trip) od POCZĄTKU kursu do przystanku
 * wsiadania nogi planera (plan zwraca geometrię tylko NOGI — od wsiadania).
 *
 * Planer przycina ją później od BIEŻĄCEJ POZYCJI żywego pojazdu do
 * przystanku wsiadania i rysuje półprzezroczyste (patrz map.js).
 *
 * Zwraca [[lng, lat], …] albo null (kurs zaczyna się od wsiadania / brak
 * danych). Klucz cache: tripId + stopId + czas odjazdu.
 */
export async function fetchApproachPath(leg, { signal } = {}) {
    const fromTime = motisTime(leg.from?.departure ?? leg.from?.scheduledDeparture);
    const cacheKey = `${leg.tripId}|${leg.from?.stopId}|${fromTime}`;
    if (approachPathCache.has(cacheKey)) return approachPathCache.get(cacheKey);

    try {
        const trip = await fetchTrip(leg.tripId, { signal });

        // Znajdź NOGĘ kursu zawierającą mój przystanek wsiadania
        // (stopId + czas najbliższy czasowi odjazdu z planu).
        let containing = null; // { legIndex, place, timeDelta }
        for (let legIndex = 0; legIndex < (trip.legs || []).length; legIndex++) {
            const places = [
                trip.legs[legIndex].from,
                ...(trip.legs[legIndex].intermediateStops || []),
                trip.legs[legIndex].to,
            ];

            for (const place of places) {
                if (!place || place.stopId !== leg.from?.stopId) continue;
                const placeTime = motisTime(place.departure ?? place.arrival);
                const delta =
                    fromTime !== null && placeTime !== null ? Math.abs(placeTime - fromTime) : 0;
                if (!containing || delta < containing.timeDelta) {
                    containing = { legIndex, place, timeDelta: delta };
                }
            }
        }

        if (!containing) {
            // Przystanku wsiadania nie ma w kursie — brak dojazdu.
            approachPathCache.set(cacheKey, null);
            return null;
        }

        // Sklej geometrie wszystkich nóg kursu PRZED nogą z wsiadaniem
        // (interlinia — kurs może zmieniać pojazd/linię bez przesiadki).
        const pathPieces = [];
        for (let legIndex = 0; legIndex < containing.legIndex; legIndex++) {
            const tripLeg = trip.legs[legIndex];
            const geometry = tripLeg?.legGeometry?.points;
            if (geometry) {
                pathPieces.push(
                    decodePolyline(geometry, tripLeg.legGeometry.precision ?? 7),
                );
            }
        }

        // Noga ZAWIERAJĄCA wsiadanie: utnij geometrię do wierzchołka
        // najbliższego przystankowi wsiadania.
        const containingLeg = trip.legs[containing.legIndex];
        const geometry = containingLeg?.legGeometry?.points;
        if (geometry && containing.place?.lat && containing.place?.lon) {
            const coords = decodePolyline(
                geometry,
                containingLeg.legGeometry.precision ?? 7,
            );
            const target = [containing.place.lon, containing.place.lat];

            let bestIndex = 0;
            let bestDistance = Infinity;
            for (let i = 0; i < coords.length; i++) {
                const distance = distSqDegrees(coords[i], target);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    bestIndex = i;
                }
            }

            const piece = coords.slice(0, bestIndex + 1);

            // Doklej DOKŁADNE współrzędne przystanku wsiadania na koniec
            // ścieżki — dojazd ma stykać się bez szpary z czerwoną nogą
            // (najbliższy wierzchołek może być kilka metrów obok).
            const last = piece[piece.length - 1];
            if (
                last &&
                distSqDegrees(last, target) < 0.001 ** 2 &&
                distSqDegrees(last, target) > 0
            ) {
                piece.push(target);
            }

            if (piece.length >= 2) pathPieces.push(piece);
        }

        const path = pathPieces.flat();
        const result = path.length >= 2 ? path : null;
        approachPathCache.set(cacheKey, result);
        return result;
    } catch {
        approachPathCache.set(cacheKey, null);
        return null;
    }
}

/** Kwadrat odległości stopni (szybkie porównanie punktów na mapie). */
function distSqDegrees([ax, ay], [bx, by]) {
    return (ax - bx) ** 2 + (ay - by) ** 2;
}

/* Cache odjazdów z przystanku. */
const stopTimesCache = new Map();

/**
 * Odjazdy z przystanku Transitous (/api/v1/stoptimes) — używane przez
 * arkusz przystanku otwierany z listy planera (kliknięcie przystanku).
 * Zwraca [{ time, delay, realtime, cancelled, headsign, routeShortName,
 *            routeLongName, routeColor, routeTextColor, routeType, agencyName,
 *            tripId }].
 */
export async function fetchStopTimes(stopId, { signal, limit = 20 } = {}) {
    const cacheKey = `${stopId}|${Math.floor(Date.now() / 60000)}`;
    if (stopTimesCache.has(cacheKey)) return stopTimesCache.get(cacheKey);

    const params = new URLSearchParams({
        stopId,
        n: String(limit),
    });

    const url = `${API_BASE_TRANSITOUS}/v1/stoptimes?${params.toString()}`;
    const response = await fetch(url, { signal });
    if (!response.ok) throw new Error('STOPTIMES_ERROR');

    const data = await response.json();
    const times = (data.stopTimes || []).map((event) => {
        const place = event.place || {};
        const time = motisTime(place.departure ?? place.arrival);
        const scheduledTime = motisTime(place.scheduledDeparture ?? place.scheduledArrival);
        return {
            time,
            scheduledTime,
            delay: time !== null && scheduledTime !== null ? time - scheduledTime : null,
            realtime: !!event.realTime,
            cancelled: !!event.cancelled || !!event.tripCancelled,
            headsign: event.headsign || event.tripTo?.name || '',
            routeShortName: event.routeShortName,
            routeLongName: event.routeLongName,
            routeColor: event.routeColor,
            routeTextColor: event.routeTextColor,
            routeType: event.routeType,
            agencyName: event.agencyName,
            tripId: event.tripId,
            mode: event.mode,
        };
    });

    stopTimesCache.set(cacheKey, times);
    return times;
}

/* ------------------------------------------------------------------ */
/* Dekodowanie polyline                                                */

/**
 * Dekoduje polyline MOTIS z uwzględnieniem precyzji (Transitous używa 1e7,
 * standard Google to 1e5 — dlatego czytamy pole precision).
 */
export function decodePolyline(points, precision = 7) {
    const factor = 10 ** precision;
    let index = 0;
    let lat = 0;
    let lng = 0;

    const coordinates = [];

    while (index < points.length) {
        let b;
        let shift = 0;
        let result = 0;

        do {
            b = points.charCodeAt(index++) - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);

        lat += (result >> 1) ^ -(result & 1);

        shift = 0;
        result = 0;

        do {
            b = points.charCodeAt(index++) - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);

        lng += (result >> 1) ^ -(result & 1);

        coordinates.push([lng / factor, lat / factor]);
    }

    return coordinates;
}

/** Parsuje czas ISO MOTIS na timestamp ms (null gdy brak). */
export function motisTime(value) {
    return value ? Date.parse(value) : null;
}

/**
 * Opóźnienie nogi/przystanku w milisekundach na podstawie czasów
 * rzeczywistego i rozkładowego (dane realtime Transitous/GTFS-RT).
 */
export function legDelay(point) {
    const actual = motisTime(point.departure ?? point.arrival);
    const scheduled = motisTime(point.scheduledDeparture ?? point.scheduledArrival);
    if (actual === null || scheduled === null) return null;
    return actual - scheduled;
}
