/**
 * Narzędzia wspólne — port funkcji z src/components/util/tools.ts
 * (bez zmian funkcjonalnych, czysty JavaScript bez TypeScript).
 */

import { DEFAULT_LOCATION, DEFAULT_TIMEZONE } from './config.js';
import { query } from './router.js';

/** Czas HH:MM w formacie pl (odpowiednik getTime z tools.ts). */
export function getTime(time) {
    return new Date(time).toLocaleTimeString('pl', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
    });
}

/** Wysokość arkusza dolnego (odpowiednik getSheetHeight). */
export function getSheetHeight() {
    return window.innerHeight / 3 + 24;
}

/** [klasa opóźnienia, tekst opóźnienia] — odpowiednik getDelay. */
export function getDelay(delay) {
    const isNumber = typeof delay === 'number';
    const delayTime = msToTime(isNumber ? Math.abs(delay) : 0);

    const kind = isNumber
        ? delayTime
            ? delay > 0
                ? 'delayed'
                : 'early'
            : 'none'
        : 'unknown';

    return [kind, delayTime];
}

/** Formatowanie czasu trwania ms -> "X h Y min [Z s]" — odpowiednik msToTime. */
export function msToTime(ms, withSeconds) {
    const formattedTime = [];

    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    const remainingMinutes = minutes % 60;
    const remainingSeconds = seconds % 60;

    if (hours > 0) formattedTime.push(`${hours} h`);
    if (remainingMinutes > 0) formattedTime.push(`${remainingMinutes} min`);
    if (withSeconds) formattedTime.push(`${remainingSeconds} s`);

    return formattedTime.join(' ');
}

/** Strefa czasowa miasta (odpowiednik getCityTimezone). */
export function getCityTimezone(city) {
    return window.cities?.[city]?.timezone || DEFAULT_TIMEZONE;
}

/** Data YYYY-MM-DD danego momentu w strefie czasowej miasta (odpowiednik getCityDate). */
export function getCityDate(timestamp, timezone) {
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: timezone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
    }).format(timestamp);
}

/** Liczba dni od 2020-01-01 w strefie miasta (odpowiednik getDaysSince2020). */
export function getDaysSince2020(timestamp, timezone) {
    const [year, month, day] = getCityDate(timestamp, timezone).split('-').map(Number);
    return Math.floor(Date.UTC(year, month - 1, day) / 86400000) - 18262;
}

/** Dekodowanie zakodowanej linii (polyline) do GeoJSON LineString — odpowiednik polylineToGeoJson. */
export function polylineToGeoJson(polyline) {
    const factor = 1e6;
    let index = 0;
    let lat = 0;
    let lng = 0;

    const geoJson = {
        type: 'Feature',
        geometry: {
            type: 'LineString',
            coordinates: [],
        },
        properties: {},
    };

    while (index < polyline.length) {
        let b;
        let shift = 0;
        let result = 0;

        do {
            b = polyline.charCodeAt(index++) - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);

        lat += (result >> 1) ^ -(result & 1);

        shift = 0;
        result = 0;

        do {
            b = polyline.charCodeAt(index++) - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);

        lng += (result >> 1) ^ -(result & 1);

        geoJson.geometry.coordinates.push([lng / factor, lat / factor]);
    }

    return geoJson;
}

/** Mieszanie koloru HEX z tłem (odpowiednik fadeColor). */
export function fadeColor(hex, ratio, background = '#ffffff') {
    const color = parseInt(hex.slice(1), 16);
    const bg = parseInt(background.slice(1), 16);

    const mix = (shift) => {
        const channel = (value) => (value >> shift) & 0xff;
        return Math.round(channel(color) * ratio + channel(bg) * (1 - ratio));
    };

    return `rgb(${mix(16)}, ${mix(8)}, ${mix(0)})`;
}

/** Parsowanie identyfikatora pojazdu (odpowiednik parseVehicleId). */
export function parseVehicleId(id) {
    const colonIdx = id.indexOf(':');
    const underscoreIdx = id.indexOf('_', colonIdx + 1);
    const vehicleType = id.slice(0, colonIdx);

    if (underscoreIdx === -1 || underscoreIdx === colonIdx + 1) {
        return {
            vehicleType,
            agency: 'default',
            vehicleNumber: id.slice(colonIdx + 1),
        };
    }

    return {
        vehicleType,
        agency: id.slice(colonIdx + 1, underscoreIdx),
        vehicleNumber: id.slice(underscoreIdx + 1),
    };
}

/** Flagi sposobu wysiadania (odpowiednik AlightType). */
export const AlightType = {
    Regular: 1 << 0,
    Forbidden: 1 << 1,
    OnDemand: 1 << 2,
    IsLastStop: 1 << 3,
};

/** Miasto z query stringa ?city= (odpowiednik getCityFromUrl). */
export function getCityFromUrl(routeCity) {
    const fromQuery = query().get('city');
    return fromQuery || routeCity || '';
}

/** Sufiks ?city= dla encji z innego miasta (odpowiednik buildCitySuffix). */
export function buildCitySuffix(entityCity, routeCity) {
    if (!entityCity || entityCity === routeCity) return '';
    return `?city=${encodeURIComponent(entityCity)}`;
}

/** Udostępnianie linku (odpowiednik share). */
export function share(url) {
    if (navigator.share !== undefined) {
        navigator.share({ url });
    } else {
        navigator.clipboard.writeText(url);
    }
}

const POLISH_FOLD = {
    ą: 'a',
    ć: 'c',
    ę: 'e',
    ł: 'l',
    ń: 'n',
    ó: 'o',
    ś: 's',
    ź: 'z',
    ż: 'z',
};

/** Normalizacja wyszukiwania (odpowiednik normalizeSearch). */
export function normalizeSearch(value) {
    return value.toLowerCase().replace(/[ąćęłńóśźż]/g, (char) => POLISH_FOLD[char] ?? char);
}

/* ------------------------------------------------------------------ */
/* WYSZUKIWANIE ROZMYTE (fuzzy) — zgłoszenie użytkownika:                */
/* „w szukaniu pomijaj znaki polskie, cyfry, ukosniki a spacja to        */
/* oddzielenie filtrow, np. Podkarpacka Politechnika 01 -> pod pol       */
/* znaczy: każdy SPACJĄ oddzielony fragment zapytania to osobny filtr     */
/* prefikssowy, porównany bez ogonków/cyfr/ukośników.                    */
/* ------------------------------------------------------------------ */

/**
 * Normalizuje tekst do porównań: małe litery, bez ogonków (ą→a, ł→l…),
 * bez cyfr i ukośników („Politechnika 01” ≡ „politechnika”).
 */
export function normalizeForSearch(value) {
    return String(value ?? '')
        .toLowerCase()
        .replace(/[łŁ]/g, 'l')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[0-9]/g, '')
        .replace(/[\/\\]/g, ' ')
        .replace(/[^a-z\s]/g, ' ')
        .trim();
}

/**
 * Filtry z zapytania: fragmenty rozdzielone spacją, po normalizacji.
 * „Podkarpacka Politechnika 01” → [„podkarpacka”, „politechnika”]
 * („01” znika — cyfry są ignorowane w dopasowaniu).
 */
export function searchTokens(query) {
    return normalizeForSearch(query).split(/\s+/).filter(Boolean);
}

/**
 * Czy nazwa (plus opcjonalny kontekst, np. miejscowość) spełnia WSZYSTKIE
 * filtry? Każdy token musi być prefiksem jakiegoś słowa („pod” → „podkarpacka”)
 * albo — gdy ma ≥ 4 znaki — jego częścią ("litechnika" → „politechnika").
 */
export function matchesTokens(name, context, tokens) {
    if (!tokens?.length) return true;
    const words = normalizeForSearch(`${name ?? ''} ${context ?? ''}`).split(/\s+/).filter(Boolean);
    return tokens.every((token) =>
        words.some(
            (word) => word.startsWith(token) || (token.length >= 4 && word.includes(token)),
        ),
    );
}

/* ------------------------------------------------------------------ */
/* Generowanie ciemnego motywu Material 3 — DOKŁADNY port biblioteki    */
/* material-color-lite v2.0.6 (Apache-2.0, DomeQdev), używanej przez   */
/* oryginalny zbiorkom.live w App.tsx (generateDarkScheme).             */
/* Implementacja w color.js — re-eksport dla zachowania importów.       */
/* ------------------------------------------------------------------ */

export { generateDarkScheme } from './color.js';
