/**
 * Komponenty UI na czystym DOM — odpowiedniki elementów MUI używanych
 * przez oryginał: Fab, Dialog, Drawer, BottomSheet (react-spring-bottom-sheet),
 * Alert, Loading, Menu itd. Wszystko czytelne, bez zależności zewnętrznych.
 */

import { renderIcon } from './icons.js';

/* ------------------------- Podstawowe DOM ------------------------- */

/**
 * Tworzy element z tagiem, klasą, atrybutami i dziećmi.
 * Krótki odpowiednik createElement z Reacta.
 */
export function el(tag, props = {}, ...children) {
    const node = document.createElement(tag);

    for (const [key, value] of Object.entries(props)) {
        if (value === undefined || value === null || value === false) continue;

        if (key === 'className') {
            node.className = value;
        } else if (key === 'style') {
            Object.assign(node.style, value);
        } else if (key === 'dataset') {
            Object.assign(node.dataset, value);
        } else if (key.startsWith('on') && typeof value === 'function') {
            node.addEventListener(key.slice(2).toLowerCase(), value);
        } else if (key === 'html') {
            node.innerHTML = value;
        } else if (value === true) {
            node.setAttribute(key, '');
        } else {
            node.setAttribute(key, value);
        }
    }

    for (const child of children.flat(Infinity)) {
        if (child === undefined || child === null || child === false) continue;
        node.append(child instanceof Node ? child : document.createTextNode(child));
    }

    return node;
}

/** Czyści kontener (odpowiednik root.removeChild / replaceChildren). */
export function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
}

/* ------------------------------ Fab ------------------------------- */

/** Pływający przycisk akcji (odpowiednik MuiFab). */
export function fab({ icon, onClick, position = {}, id, title }) {
    const button = el(
        'button',
        {
            className: 'fab',
            id,
            title,
            onClick,
            'aria-label': title,
        },
        typeof icon === 'string' ? renderIcon(icon) : icon,
    );

    Object.assign(button.style, position);
    return button;
}

/* ----------------------------- Dialog ----------------------------- */

/**
 * Okno dialogowe (odpowiednik MuiDialog).
 * Zwraca element z metodami .open() i .close().
 */
export function dialog({ className = '', closeable = true, onClose, fullscreen = false } = {}) {
    const content = el('div', { className: 'dialog-content' });
    const paper = el('div', { className: 'dialog-paper' + (fullscreen ? ' fullscreen' : '') }, content);

    const backdrop = el(
        'div',
        {
            className: 'dialog-backdrop',
            // Zamknięcie tylko przy kliknięciu samego tła (nie elementów dialogu)
            onClick: (event) => {
                if (event.target === backdrop && closeable) close();
            },
        },
        paper,
    );

    function close() {
        backdrop.remove();
        onClose?.();
    }

    backdrop.close = close;
    backdrop.content = content;
    if (className) backdrop.classList.add(className);

    return backdrop;
}

/* ---------------------------- Menu ------------------------------- */

/** Menu kontekstowe (odpowiednik MuiMenu). */
export function menu(anchorEl, items) {
    const rect = anchorEl.getBoundingClientRect();
    const list = el(
        'div',
        { className: 'menu-list' },
        items.map((item) =>
            item === null
                ? null
                : el(
                      'button',
                      {
                          className: 'menu-item' + (item.disabled ? ' disabled' : ''),
                          onClick: () => {
                              close();
                              item.onClick?.();
                          },
                      },
                      item.icon &&
                          el(
                              'span',
                              { className: 'menu-item-icon' },
                              renderIcon(item.icon, { size: 20 }),
                          ),
                      el('span', { className: 'menu-item-text' }, item.label),
                      item.trailing,
                  ),
        ),
    );

    const backdrop = el('div', { className: 'menu-backdrop' }, list);

    // Pozycjonowanie przy elemencie kotwiczącym (pod nim, wyrównane do prawej)
    Object.assign(list.style, {
        top: `${Math.min(rect.bottom + 4, window.innerHeight - list.offsetHeight - 8)}px`,
        left: `${Math.max(8, rect.right - 220)}px`,
    });

    function close() {
        backdrop.remove();
    }

    backdrop.addEventListener('click', (event) => {
        if (event.target === backdrop) close();
    });

    document.body.append(backdrop);
    return close;
}

/* ----------------------------- Alert ------------------------------ */

/** Alert z ikoną, tytułem i opisem (odpowiednik ui/Alert.tsx). */
export function alert({ title, description, icon = 'Report', color = 'error', height }) {
    return el(
        'div',
        { className: `alert alert-${color}`, style: height ? { height } : {} },
        el('div', { className: 'alert-icon' }, renderIcon(icon, { size: 48 })),
        el('div', { className: 'alert-text' }, el('h5', {}, title), description && el('p', {}, description)),
    );
}

/** Wskaźnik ładowania (odpowiednik ui/Loading.tsx). */
export function loading({ height = 120 } = {}) {
    return el(
        'div',
        { className: 'loading', style: { height } },
        el('div', { className: 'spinner' }),
    );
}

/** Szkielet ładowania (odpowiednik MuiSkeleton). */
export function skeleton({ width = 100, height = 20, radius = 4 }) {
    return el('div', { className: 'skeleton', style: { width, height, borderRadius: radius } });
}

/* ------------------------ Przełącznik ----------------------------- */

/** Checkbox z etykietą (odpowiednik FormControlLabel + Checkbox). */
export function checkboxRow(label, checked, onChange) {
    const box = el('input', { type: 'checkbox', checked: !!checked });
    box.addEventListener('change', () => onChange(box.checked));
    return el('label', { className: 'checkbox-row' }, box, el('span', {}, label));
}

/** Radio z etykietą (odpowiednik FormControlLabel + Radio). */
export function radioRow(name, label, checked, onChange) {
    const box = el('input', { type: 'radio', name, checked: !!checked });
    box.addEventListener('change', () => box.checked && onChange(box.value));
    return el('label', { className: 'checkbox-row' }, box, el('span', {}, label));
}

/* ------------------------ Pole tekstowe --------------------------- */

/** Pole tekstowe z ikoną na początku (odpowiednik MuiTextField). */
export function textField({ placeholder, value = '', onChange, adornment, endAdornment, autoFocus, type = 'text' }) {
    const input = el('input', { type, placeholder, value, autoComplete: 'off' });
    input.addEventListener('input', () => onChange?.(input.value));

    const field = el(
        'div',
        { className: 'text-field' },
        adornment && el('span', { className: 'text-field-adornment' }, renderIcon(adornment, { size: 20 })),
        input,
        endAdornment,
    );

    if (autoFocus) {
        requestAnimationFrame(() => input.focus());
    }

    field.input = input;
    return field;
}

/* ------------------------- Lista elementów ------------------------ */

/** Wiersz listy z tekstem głównym i dodatkowym (odpowiednik ListItemButton). */
export function listItem({ primary, secondary, onClick, className = '' }) {
    return el(
        'button',
        { className: `list-item ${className}`, onClick },
        el('div', { className: 'list-item-primary' }, primary),
        secondary && el('div', { className: 'list-item-secondary' }, secondary),
    );
}

/* --------------------------- Bottom sheet -------------------------- */

/* Rejestr otwartych arkuszy — tylko JEDEN arkusz dolny może być widoczny
 * naraz (zgłoszenie użytkownika: „nie pozwól kilku popupom z dołu naraz
 * się pokazać na ekranie"). Nowy arkusz zamyka poprzedni. */
const activeSheets = new Set();

/**
 * Dolny arkusz z punktami zaczepienia i przeciąganiem —
 * odpowiednik react-spring-bottom-sheet-updated.
 *
 * Oryginalne punkty: [maxHeight/1.5, maxHeight/2, maxHeight/3], defaultSnap=1
 * (arkusze blokujące: [maxHeight/1.8]).
 */
export function bottomSheet({ snapPoints, defaultSnap = 1, blocking = false, onDismiss }) {
    const maxHeight = window.innerHeight;

    const snaps = (snapPoints ?? [maxHeight / 1.5, maxHeight / 2, maxHeight / 3]).map(Math.round);
    let currentSnap = defaultSnap;

    const header = el('div', { className: 'sheet-header' });
    const scroll = el('div', { className: 'sheet-scroll' });
    const overlay = el('div', { className: 'sheet-overlay' }, header, scroll);
    const handle = el('div', { className: 'sheet-handle' });

    const backdrop = blocking ? el('div', { className: 'sheet-backdrop' }) : null;

    const root = el(
        'div',
        { className: 'sheet-root' + (blocking ? ' blocking' : '') },
        backdrop,
        overlay,
    );

    overlay.prepend(handle);

    let height = snaps[currentSnap];
    const apply = () => {
        overlay.style.setProperty('--sheet-h', `${height}px`);
        /* Uchwyt jest pozycjonowany absolutnie w nagłówku, więc odejmujemy
         * tylko faktyczną wysokość nagłówka. */
        scroll.style.height = `${Math.max(0, height - header.offsetHeight)}px`;
    };

    /** Przeskok do punktu zaczepienia z animacją. */
    const snapTo = (index) => {
        currentSnap = Math.max(0, Math.min(snaps.length - 1, index));
        height = snaps[currentSnap];
        overlay.classList.add('animated');
        apply();
    };

    if (backdrop) {
        backdrop.addEventListener('click', () => dismiss());
    }

    /** Zamknięcie arkusza (odpowiednik onDismiss). */
    let dismissed = false;
    function dismiss() {
        if (dismissed) return;
        dismissed = true;
        activeSheets.delete(sheet);
        overlay.classList.add('closing');
        backdrop?.classList.add('closing');
        setTimeout(() => {
            root.remove();
            onDismiss?.();
        }, 250);
    }

    /** Ciche usunięcie arkusza BEZ wywołania onDismiss (do niszczenia widoku
     * przy zmianie trasy — inaczej goBack() z onDismiss powodowałby pętlę). */
    function close() {
        if (dismissed) return;
        dismissed = true;
        activeSheets.delete(sheet);
        root.remove();
    }

    const sheet = {
        root,
        header,
        scroll,
        snapTo,
        dismiss,
        close,
        refresh: apply,
        /* Chowanie bez zamykania: pozwala otworzyć drugi arkusz NADEWRO
         * (np. odjazdy przystanku nad podglądem wariantu) i wrócić do
         * ukrytego arkusza bez utraty stanu — na ekranie widać tylko JEDEN
         * arkusz naraz. */
        hide() {
            root.style.display = 'none';
        },
        show() {
            root.style.display = '';
            apply();
        },
        get visible() {
            return root.style.display !== 'none' && !dismissed;
        },
        get height() {
            return height;
        },
    };

    // Tylko jeden arkusz dolny WIDOCZNY naraz — nowy arkusz chowa
    // poprzednie (zostają w pamięci; można je przywrócić przez show()).
    for (const other of activeSheets) {
        if (other !== sheet) other.hide();
    }
    activeSheets.add(sheet);

    // Przeciąganie za uchwyt/nagłówek — ALE NIE za przyciski: kliknięcia
    // w nagłówku (lokalizacja/śledź, menu „…”, zamknięcie X) muszą działać.
    // Wcześniejsze preventDefault na całym nagłówku blokowało kliknięcia
    // na telefonach (touchstart) — stąd „przyciski nic nie robiły”.
    const isInteractive = (target) =>
        target instanceof Element &&
        !!target.closest('button, a, input, select, textarea, label, [data-no-drag]');

    let dragging = null;
    const startY = (event) => {
        const point = event.touches?.[0] ?? event;
        if (isInteractive(point.target)) return; // przeciąganie nie zaczyna się od przycisku
        dragging = { startY: point.clientY, startHeight: height };
        overlay.classList.remove('animated');
        event.preventDefault();
    };

    const moveY = (event) => {
        if (!dragging) return;
        const point = event.touches?.[0] ?? event;
        height = Math.min(maxHeight, Math.max(60, dragging.startHeight - (point.clientY - dragging.startY)));
        apply();
    };

    const endY = () => {
        if (!dragging) return;
        dragging = null;
        // Wybierz najbliższy punkt zaczepienia
        let best = 0;
        let bestDistance = Infinity;
        snaps.forEach((snapHeight, index) => {
            const distance = Math.abs(snapHeight - height);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = index;
            }
        });

        // Przeciągnięcie bardzo nisko zamyka (odpowiednik minimalnego progu biblioteki)
        if (height < snaps[snaps.length - 1] * 0.6 && !blocking) {
            dismiss();
        } else {
            snapTo(best);
        }
    };

    handle.addEventListener('mousedown', startY);
    handle.addEventListener('touchstart', startY, { passive: false });
    header.addEventListener('mousedown', startY);
    header.addEventListener('touchstart', startY, { passive: false });

    window.addEventListener('mousemove', moveY);
    window.addEventListener('touchmove', moveY, { passive: false });
    window.addEventListener('mouseup', endY);
    window.addEventListener('touchend', endY);

    apply();
    requestAnimationFrame(apply);

    return sheet;
}

/* --------------------------- Menu boczne --------------------------- */

/**
 * Szuflada menu z lewej strony (odpowiednik SwipeableDrawer).
 * Zwraca element z metodami .open() / .close().
 */
export function drawer(content, { onClose } = {}) {
    const paper = el('div', { className: 'drawer-paper' }, content);
    const backdrop = el('div', { className: 'drawer-backdrop' }, paper);

    let openState = false;

    function open() {
        openState = true;
        backdrop.classList.add('open');
    }

    function close() {
        openState = false;
        backdrop.classList.remove('open');
    }

    backdrop.addEventListener('click', (event) => {
        if (event.target === backdrop) {
            close();
            // Zamknięcie przez użytkownika (backdrop) — jak Root.tsx:
            // setClose={() => goBack({ ignoreState: true })} — zdejmuje
            // wpis „menu” z historii. Zamknięcia programowe (close()) go
            // NIE wywołują (nawigacja już zmienia historię).
            onClose?.();
        }
    });

    backdrop.open = open;
    backdrop.close = close;
    backdrop.isOpen = () => openState;

    return backdrop;
}

/* ---------------------------- Toast -------------------------------- */

/** Krótki komunikat u dołu ekranu (odpowiednik alert()/snackbara). */
export function toast(message) {
    const node = el('div', { className: 'toast' }, message);
    document.body.append(node);
    setTimeout(() => node.classList.add('show'), 10);
    setTimeout(() => {
        node.classList.remove('show');
        setTimeout(() => node.remove(), 300);
    }, 2600);
}
