/**
 * Mapa i znaczniki — port komponentów z src/components/map:
 *   Map.tsx          — inicjalizacja maplibre, style, ciemny motyw
 *   VehicleMarker    — chip pojazdu z kolorem linii, ikoną i kierunkiem
 *   StopMarker       — okrągły znacznik przystanku / kwadrat stacji
 *   DotMarkers       — kropki pojazdów przy małym zbliżeniu (warstwa circle)
 *   LocationMarker   — lokalizacja użytkownika + przycisk GPS
 *   TripRoute        — rysowanie trasy kursu (linia + przystanki + etykiety)
 *   TripPlatforms    — perony (wielokąty)
 *
 * Biblioteka MapLibre GL jest ładowana jako klasyczny skrypt UMD
 * (index.php) i dostępna jako window.maplibregl.
 */

const maplibregl = window.maplibregl;
import { defaultColors, renderIcon, vehicleTypeIcon, material } from './icons.js';
import { fadeColor, parseVehicleId } from './util.js';
import { MAP as MAP_STYLE, PLANNER } from './branding.js';
import { settings } from './store.js';
import { segments, query } from './router.js';

/* --------------------------- Geometria ---------------------------- */

/** Odległość euklidesowa w przybliżeniu płaskim (wystarczająca w skali miasta). */
function dist2(ax, ay, bx, by) {
    return (ax - bx) ** 2 + (ay - by) ** 2;
}

/**
 * Rzutuje punkt na łamaną i zwraca { point, index, distSq } — najbliższy
 * punkt na linii, indeks odcinka startowego oraz kwadrat odległości.
 * Używane do „przyczepiania” ikony pojazdu do linii trasy (snap) oraz
 * do przycinania ścieżki DOJAZDU od pozycji pojazdu do przystanku wsiadania.
 * path — tablica [[lng, lat], …]
 */
function projectOnPath(path, lngLat) {
    if (!Array.isArray(path) || path.length < 2 || !lngLat) {
        return { point: lngLat, index: 0, distSq: Infinity };
    }

    const [px, py] = lngLat;
    let bestPoint = lngLat;
    let bestIndex = 0;
    let bestDist = Infinity;

    for (let i = 0; i < path.length - 1; i++) {
        const [ax, ay] = path[i];
        const [bx, by] = path[i + 1];

        const dx = bx - ax;
        const dy = by - ay;
        const lengthSq = dx * dx + dy * dy;
        if (lengthSq === 0) continue;

        // Parametr projekcji (0..1) zawężony do odcinka
        let t = ((px - ax) * dx + (py - ay) * dy) / lengthSq;
        t = Math.max(0, Math.min(1, t));

        const cx = ax + t * dx;
        const cy = ay + t * dy;
        const d = dist2(px, py, cx, cy);

        if (d < bestDist) {
            bestDist = d;
            bestPoint = [cx, cy];
            bestIndex = i;
        }
    }

    return { point: bestPoint, index: bestIndex, distSq: bestDist };
}

/**
 * Rzutuje punkt na łamaną i zwraca NAJBLIŻSZY punkt na linii trasy.
 * Używane do „przyczepiania” ikony pojazdu do linii trasy — pojazd
 * nie może wisieć poza trasą (zgłoszenie użytkownika).
 * path — tablica [[lng, lat], …]
 */
export function snapLngLatToPath(path, lngLat) {
    const { point, distSq } = projectOnPath(path, lngLat);

    // Poza ~550 m od trasy nie przyciągaj (1° ≈ 111 km; 0.005° ≈ 550 m)
    const maxSnapDistSq = 0.005 ** 2;
    if (distSq > maxSnapDistSq) return lngLat;

    return point;
}

/* --------------------------- Style mapy ---------------------------- */

/** Styl wektorowy OpenFreeMap serwowany lokalnie (odpowiednik mapStyle.ts). */
const rasterStyle = (tiles, { neutral = false } = {}) => ({
    version: 8,
    name: 'Raster Layer',
    sources: {
        raster: {
            type: 'raster',
            // tiles może być adresem albo tablicą adresów (multi-CDN)
            tiles: Array.isArray(tiles) ? tiles : [tiles],
            tileSize: 256,
        },
    },
    sprite: 'https://tiles.openfreemap.org/sprites/ofm_f384/ofm',
    glyphs: 'https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf',
    layers: [
        {
            id: 'raster-layer',
            type: 'raster',
            source: 'raster',
            paint: neutral
                ? {}
                : {
                      'raster-brightness-max': 0.85,
                      'raster-brightness-min': 0.15,
                      'raster-contrast': 0.2,
                      'raster-saturation': -0.2,
                  },
        },
    ],
});

/** Definicje stylów — odpowiednik mapStyles z mapStyle.ts. */
export const mapStyles = {
    basic: {
        name: 'Basic',
        style: ((window.Gay && window.Gay.basePath) || '') + '/style.json',
        attribution: [
            '<a href="https://openfreemap.org" target="_blank">OpenFreeMap</a>',
            '&copy; <a href="https://www.openmaptiles.org/" target="_blank">OpenMapTiles</a>',
            '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        ],
        supportsDark: true,
    },
    openStreetMap: {
        name: 'OpenStreetMap',
        style: rasterStyle('https://tile.openstreetmap.org/{z}/{x}/{y}.png'),
        attribution: [
            '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        ],
        supportsDark: true,
    },
    humanitarian: {
        name: 'Humanitarian',
        style: rasterStyle([
            'https://a.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
            'https://b.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
            'https://c.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
        ]),
        attribution: [
            '&copy; <a href="https://www.hotosm.org/" target="_blank">Humanitarian OSM Team</a>',
            '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        ],
        supportsDark: true,
    },
    positron: {
        name: 'Carto Light',
        style: rasterStyle('https://basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png'),
        attribution: [
            '&copy; <a href="https://carto.com/" target="_blank">CARTO</a>',
            '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        ],
        supportsDark: true,
    },
    darkMatter: {
        name: 'Carto Dark',
        // neutral=true: styl jest JUŻ ciemny — bez filtrów jasności/kontrastu
        style: rasterStyle('https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', { neutral: true }),
        attribution: [
            '&copy; <a href="https://carto.com/" target="_blank">CARTO</a>',
            '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        ],
        supportsDark: false,
    },
    voyager: {
        name: 'Carto Voyager',
        style: rasterStyle('https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png'),
        attribution: [
            '&copy; <a href="https://carto.com/" target="_blank">CARTO</a>',
            '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        ],
        supportsDark: true,
    },
    topo: {
        name: 'OpenTopoMap',
        style: rasterStyle('https://tile.opentopomap.org/{z}/{x}/{y}.png'),
        attribution: [
            '&copy; <a href="https://opentopomap.org" target="_blank">OpenTopoMap</a>',
            '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        ],
        supportsDark: true,
    },
    googleSatellite: {
        name: 'Esri Satellite',
        style: rasterStyle(
            'https://services.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}?blankTile=false',
        ),
        attribution: ['&copy; <a href="https://www.esri.com" target="_blank">Esri</a>'],
    },
};

/* ------------------------ Inicjalizacja mapy ----------------------- */

let map = null;

/** Bieżący styl mapy (do przełączania). */
let currentStyleId = null;

/* Kontrolka atrybucji bieżącego stylu — trzymana w referencji, żeby przy
 * zmianie stylu ZUSUWAĆ starą (kontrolki żyją poza stylem i bez tego
 * duplikowałyby się przy każdym przełączeniu stylu mapy). */
let attributionControl = null;

/**
 * Tworzy mapę (odpowiednik Map.tsx). Wyliczenie początkowego widoku:
 *  1. parametry ?lat=&lon=&zoom=,
 *  2. ostatnia lokalizacja użytkownika (gdy włączona opcja),
 *  3. lokalizacja miasta z URL, potem warsaw, potem domyślna.
 */
export function initMap({ onSelectCitySuggestion } = {}) {
    if (map) return map;

    const urlParams = query();
    let initial = { longitude: 21.0122, latitude: 52.2297, zoom: 16 };

    if (urlParams.has('lat') && urlParams.has('lon')) {
        initial = {
            longitude: +urlParams.get('lon'),
            latitude: +urlParams.get('lat'),
            zoom: urlParams.has('zoom') ? +urlParams.get('zoom') : 16,
        };
    } else {
        const lastUserLocation = JSON.parse(localStorage.getItem('userLocation') || '{}');
        const moveToLastLocation = localStorage.getItem('moveToLastLocation') === 'true';

        if (moveToLastLocation && lastUserLocation?.lastUpdate > Date.now() - 1000 * 60 * 60 * 8) {
            initial = {
                longitude: lastUserLocation.location[0],
                latitude: lastUserLocation.location[1],
                zoom: 16,
            };
        } else {
            const cityId = segments()[0];
            const location = window.cities?.[cityId]?.location || window.cities?.warsaw?.location || initial;
            initial = {
                longitude: location[0],
                latitude: location[1],
                zoom: window.cities?.[cityId]?.zoom || 16,
            };
        }
    }

    currentStyleId = localStorage.getItem('mapStyle') || 'basic';
    const basicAppearance = localStorage.getItem('mapStyleBasicVariant') || 'light';

    if (basicAppearance === 'dark') document.body.classList.add('map-dark');

    map = new maplibregl.Map({
        container: 'root',
        style: (mapStyles[currentStyleId] || mapStyles.basic).style,
        center: [initial.longitude, initial.latitude],
        zoom: initial.zoom,
        attributionControl: false,
        dragRotate: false,
        minZoom: 5,
        maxPitch: 0,
    });

    // Udostępnienie mapy dla goBack() (router.js: powrót do miasta przywraca
    // zbliżenie) oraz diagnostyki (diag.php / konsola).
    window.__zbiorkomMap = {
        getMap: () => map,
        /* Diagnostyka pipeline'u pojazdów (konsola / testy E2E): pozwala
         * sprawdzić kolorowanie pojazdów z palety i warstwy dojazdu bez
         * czekania na żywy strumień pozycji. */
        diag: {
            updateVehicleMarkers,
            vehiclePalette,
            setApproachPaths,
            previewVehicleColors: () => previewVehicleColors,
        },
    };

    map.on('load', () => {
        map.touchZoomRotate.disableRotation();

        map.getCanvas().addEventListener('webglcontextlost', () => {
            if (!document.hidden) {
                window.location.reload();
            } else {
                document.addEventListener('focus', () => window.location.reload(), { once: true });
            }
        });

        // Kontrolka atrybucji z linkami stylu (odpowiednik MapStyleContent)
        addAttribution();
    });

    map.on('movestart', () => document.getElementById('root')?.classList.add('moving'));
    map.on('moveend', () => document.getElementById('root')?.classList.remove('moving'));

    return map;
}

export function getMap() {
    return map;
}

/** Dopisuje kontrolkę atrybucji dla bieżącego stylu mapy
 * (najpierw zdejmuje poprzednią — patrz attributionControl). */
function addAttribution() {
    if (attributionControl) {
        try {
            map.removeControl(attributionControl);
        } catch {
            /* kontrolka mogła już odejść razem ze starą mapą */
        }
        attributionControl = null;
    }

    const definition = mapStyles[currentStyleId] || mapStyles.basic;
    attributionControl = new maplibregl.AttributionControl({
        customAttribution: definition.attribution.join(' '),
    });
    map.addControl(attributionControl, 'bottom-right');
}

/** Przełącza styl mapy (odpowiednik useMapStyleStore + Map). */
export function setMapStyle(styleId) {
    if (!map) return;

    const definition = mapStyles[styleId];
    if (!definition) return;

    currentStyleId = styleId;

    map.once('styledata', () => {
        // Po zmianie stylu warstwy znika — przywróć atrybucję
        // (warstwy trasy/dot przywrócą się same przy następnej klatce danych).
        addAttribution();
    });

    map.setStyle(definition.style);
}

/** Włącza/wyłącza ciemny filtr mapy (odpowiednik basicAppearance === "dark"). */
export function setMapAppearance(appearance) {
    document.body.classList.toggle('map-dark', appearance === 'dark');
}

/** Bieżący identyfikator stylu mapy. */
export function currentMapStyle() {
    return currentStyleId;
}

/* -------------------------- Markery DOM ---------------------------- */

const markerLayers = {
    vehicles: new Map(), // id -> { marker, element }
    stops: new Map(),
    userLocation: null,
    tripVehicle: null,
};

/** Czyści wszystkie markery pojazdów. */
export function clearVehicleMarkers() {
    for (const { marker } of markerLayers.vehicles.values()) marker.remove();
    markerLayers.vehicles.clear();
}

/* ---------------- Paleta kolorów pojazdów (podgląd) ----------------- */

/* Lista 15 kolorów zdefiniowana w CSS (:root, --vehicle-palette-1..15) —
 * JEDYNE źródło prawdy to arkusz stylów (zgłoszenie: „zdefiniuj listę 15
 * kolorów gdzieś w css”). JS czyta ją z getComputedStyle przy pierwszym
 * użyciu. W trybie podglądu trasy (planer) KAŻDY pojazd dostaje INNY kolor
 * — dwa autobusy albo trzy pociągi nachodzące na siebie są rozróżnialne. */
let paletteCache = null;

/** Zwraca listę kolorów z CSS (pamiętnikowana). */
export function vehiclePalette() {
    if (paletteCache) return paletteCache;

    const styles = getComputedStyle(document.documentElement);
    const palette = [];
    for (let i = 1; i <= 15; i++) {
        const value = styles.getPropertyValue(`--vehicle-palette-${i}`).trim();
        if (value) palette.push(value);
    }

    paletteCache = palette.length ? palette : ['#4477aa', '#228833', '#ccbb44'];
    return paletteCache;
}

/** Przesuwa odcień koloru HEX o stopnie (HSL) — awaryjne rozdzielenie
 * powyżej 15 pojazdów (paleta się skończyła). */
function shiftHue(hex, degrees) {
    const clean = String(hex).replace('#', '');
    const r = parseInt(clean.slice(0, 2), 16) / 255;
    const g = parseInt(clean.slice(2, 4), 16) / 255;
    const b = parseInt(clean.slice(4, 6), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const l = (max + min) / 2;
    let h = 0;
    let s = 0;

    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        else if (max === g) h = ((b - r) / d + 2) / 6;
        else h = ((r - g) / d + 4) / 6;
    }

    h = (h + degrees / 360) % 1;
    if (h < 0) h += 1;

    const hueToRgb = (p, q, tt) => {
        if (tt < 0) tt += 1;
        if (tt > 1) tt -= 1;
        if (tt < 1 / 6) return p + (q - p) * 6 * tt;
        if (tt < 1 / 2) return q;
        if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
        return p;
    };

    let r2;
    let g2;
    let b2;
    if (s === 0) {
        r2 = g2 = b2 = l;
    } else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r2 = hueToRgb(p, q, h + 1 / 3);
        g2 = hueToRgb(p, q, h);
        b2 = hueToRgb(p, q, h - 1 / 3);
    }

    const toHex = (x) =>
        Math.round(Math.min(1, Math.max(0, x)) * 255)
            .toString(16)
            .padStart(2, '0');

    return `#${toHex(r2)}${toHex(g2)}${toHex(b2)}`;
}

/* Przydział kolorów w BIEŻĄCYM podglądzie: pojazd → kolor z palety.
 * Kolory przydzielane KOLEJNO (pierwszy pojazd = kolor 1, drugi = kolor 2…)
 * z pominięciem już zajętych — gwarancja, że dwa pojazdy NIGDY nie mają
 * tego samego koloru (zgłoszenie: „2 autobusy albo 3 pociągi nachodzące
 * na siebie”). Czyszczone przy wejściu/wyjściu z podglądu. */
const previewVehicleColors = new Map();

/** Kolor pojazdu w podglądzie (poza podglądem = null → kolor linii). */
function previewVehicleColor(vehicleId) {
    const id = String(vehicleId);
    if (previewVehicleColors.has(id)) return previewVehicleColors.get(id);

    const palette = vehiclePalette();
    const used = new Set(previewVehicleColors.values());

    let color = palette.find((candidate) => !used.has(candidate));
    if (!color) {
        // więcej pojazdów niż kolorów (15+) — obróć odcień pierwszego wolnego
        color = shiftHue(palette[previewVehicleColors.size % palette.length], 24);
        let guard = 0;
        while (used.has(color) && guard++ < 15) color = shiftHue(color, 24);
    }

    previewVehicleColors.set(id, color);
    return color;
}

/* ----------------- Tryb podglądu trasy z planera ------------------ */

/* Gdy planer tras pokaże wybrany wariant, na mapie zostają TYLKO pojazdy
 * linii, którymi jedzie ten wariant (reszta jest ukryta). NULL = tryb
 * normalny — wszystkie pojazdy. PUSTY zbiór = tryb SOLO (widok kursu:
 * na mapie zostaje TYLKO wyświetlany pojazd — zgłoszenie użytkownika). */
let routePreviewLines = null;
let routePreviewPaths = new Map();

/* Ścieżki DOJAZDU wg linii (planer): od początku kursu do przystanku
 * WSIADANIA. Gdy żywy pojazd tej linii się pojawi, maplibre dorysowuje
 * odcinek od jego pozycji do przystanku półprzezroczysto (warstwa
 * trip-route-approach). */
let approachPathsByLine = new Map();

/** Włącza tryb podglądu: tylko pojazdy o podanych numerach linii.
 * pathsByLine — geometrie nóg wybranego wariantu (Map: linia → [ścieżki]),
 * używane do PRZYCZEPIANIA żywych pojazdów do linii trasy (snap).
 * Każdy pojazd dostaje w podglądzie WŁASNY kolor z palety (15 kolorów CSS). */
export function setRoutePreview(lines, pathsByLine) {
    routePreviewLines = lines instanceof Set && lines.size ? lines : new Set();
    routePreviewPaths = pathsByLine instanceof Map ? pathsByLine : new Map();
    previewVehicleColors.clear();
    clearVehicleMarkers();
}

/** Wyłącza tryb podglądu — przywraca wszystkie pojazdy. */
export function clearRoutePreview() {
    routePreviewLines = null;
    routePreviewPaths = new Map();
    previewVehicleColors.clear();
    clearApproachPaths();
    clearVehicleMarkers();
}

/* --------------------- Tryb SOLO (widok kursu) --------------------- */

/* W widoku konkretnego kursu na mapie ma być TYLKO ten pojazd — jego
 * trasa, jego przystanki i jego ikonka (zgłoszenie: „jak wyświetlam
 * autobus konkretną trasę, pokazuj TYLKO jego na mapie”). Pozostałe
 * pojazdy, kropki i przystanki miasta są ukrywane; strumień markera
 * miasta dalej pracuje, ale jego aktualizacje są blokowane. */
let soloMode = false;

/**
 * Włącza/wyłącza tryb SOLO.
 * Po wyłączeniu rozgłaszany jest event „zbiorkom:markers-restore” —
 * layout miasta (main.js) odświeża strumień markera, dzięki czemu
 * przystanki i pojazdy miasta wracają natychmiast (onInitial strumienia
 * odtwarza przystanki bez czekania na przesunięcie mapy).
 */
export function setSoloVehicleMode(on) {
    if (soloMode === on) return;
    soloMode = on;

    // Pusty zbiór linii = filtr, który nie przepuszcza żadnego pojazdu
    routePreviewLines = on ? new Set() : null;
    routePreviewPaths = new Map();

    clearVehicleMarkers();
    removeDotMarkers();
    clearStopMarkers();

    if (!on) {
        window.dispatchEvent(new Event('zbiorkom:markers-restore'));
    }
}

/* -------------------- Ścieżka DOJAZDU pojazdu --------------------- */

/**
 * Rejestruje ścieżki DOJAZDU wg linii (planer tras):
 * Map(linia → [ [[lng, lat], …] ]) — od początku kursu do przystanku
 * wsiadania. Warstwa dorysuje się (półprzezroczysta), gdy na strumieniu
 * pojawią się żywe pojazdy danej linii w pobliżu ścieżki — KAŻDY pojazd
 * w swoim kolorze z palety (wspólne ulice = kreskowane naprzemiennie).
 */
export function setApproachPaths(pathsByLine) {
    approachPathsByLine = pathsByLine instanceof Map ? pathsByLine : new Map();
    refreshApproachLayer([]); // wyczyść — pojazdy dopiszą od nowa
}

/** Czyści ścieżki dojazdu (zamknięcie podglądu wariantu). */
export function clearApproachPaths() {
    approachPathsByLine = new Map();
    refreshApproachLayer([]);
}

/* Klucz współrzędnej do wykrywania WSPÓLNYCH ulic (zaokrąglenie ~1 m). */
const coordKey = ([lng, lat]) => `${lng.toFixed(5)}|${lat.toFixed(5)}`;

/**
 * Buduje featury warstwy dojazdu ze ścieżek pojazdów:
 *  - unikalne odcinki: pełna linia w KOLORZE pojazdu (z palety 15 kolorów),
 *  - WSPÓLNE ulice (ta sama geometria ≥ 2 pojazdów): pary featurów
 *    dash 'a'/'b' — kreski naprzemienne dwóch kolorów (zgłoszenie: „jeśli
 *    ich trasa biegnie ta samą ulicą, pokaż przerywaną linię”).
 * segments — [{ vehicleId, color, coordinates }]
 */
function buildApproachFeatures(segments) {
    if (!segments.length) return [];

    // Indeks: współrzędna → segmenty, które przez nią przechodzą
    const byCoord = new Map();
    segments.forEach((segment, index) => {
        for (const coordinate of segment.coordinates) {
            const key = coordKey(coordinate);
            if (!byCoord.has(key)) byCoord.set(key, []);
            if (!byCoord.get(key).includes(index)) byCoord.get(key).push(index);
        }
    });

    const features = [];

    segments.forEach((segment, index) => {
        let run = [];
        let runShared = false; // czy bieżący odcinek jest współdzielony
        let partner = -1; // z którym segmentem dzielimy ulicę

        const flush = () => {
            if (run.length < 2) {
                run = [];
                return;
            }

            if (runShared) {
                // Kreski naprzemienne: kolor partnera 'a' + mój 'b'.
                const other = segments[partner];
                features.push(
                    {
                        type: 'Feature',
                        geometry: { type: 'LineString', coordinates: run },
                        properties: { color: other.color, dash: 'a' },
                    },
                    {
                        type: 'Feature',
                        geometry: { type: 'LineString', coordinates: run },
                        properties: { color: segment.color, dash: 'b' },
                    },
                );
            } else {
                features.push({
                    type: 'Feature',
                    geometry: { type: 'LineString', coordinates: run },
                    properties: { color: segment.color },
                });
            }

            run = [];
        };

        const coordinates = segment.coordinates;
        for (let i = 0; i < coordinates.length; i++) {
            const sharing = byCoord.get(coordKey(coordinates[i])) || [];
            const shared = sharing.length >= 2;
            const newPartner = shared ? sharing.find((other) => other !== index) ?? index : -1;

            if (i > 0 && (shared !== runShared || newPartner !== partner)) flush();

            runShared = shared;
            partner = newPartner;
            run.push(coordinates[i]);
        }

        flush();
    });

    return features;
}

/**
 * Przerywa ścieżki dojazdu od pozycji pojazdów do końca (przystanku
 * wsiadania) i aktualizuje warstwę trip-approach.
 * segments — [{ coordinates }] albo [{ vehicleId, color, coordinates }]
 */
function refreshApproachLayer(segments) {
    const source = map?.getSource('trip-approach');
    if (!source) return;

    const rich = segments.map((segment) => ({
        vehicleId: segment.vehicleId ?? null,
        color: segment.color ?? PLANNER.approachColor,
        coordinates: segment.coordinates,
    }));

    source.setData({
        type: 'FeatureCollection',
        features: buildApproachFeatures(rich),
    });
}

/**
 * Liczy odcinki DOJAZDU dla widocznych pojazdów (tryb podglądu planera):
 * dla KAŻDEJ linii ze ścieżką dojazdu bierzemy WSZYSTKIE jej żywe pojazdy
 * w pobliżu ścieżki (nie tylko najbliższy!) — każdy dostaje WŁASNY kolor
 * z palety 15 kolorów (CSS) i własny, przycięty odcinek dojazdu. Gdy ich
 * trasa biegnie TA SAMĄ ulicą, wspólne odcinki są kreskowane naprzemiennie
 * (buildApproachFeatures → warstwy trip-approach-shared-a/b).
 */
function updateApproachSegments(vehicles) {
    if (!routePreviewLines || !approachPathsByLine.size) {
        if (map?.getSource('trip-approach')) refreshApproachLayer([]);
        return;
    }

    const limitSq = (MAP_STYLE.approachSnapDist ?? 0.005) ** 2;
    const segmentsByVehicle = new Map(); // vehicleId → { coordinates, color, distSq }

    for (const vehicle of vehicles) {
        const line = String(vehicle[2]?.[2] ?? '');
        const paths = approachPathsByLine.get(line);
        if (!paths?.length) continue;

        // RZUT RAW POZYCJI (nie snappingowanej — snap dotyczy linii MOJEJ nogi)
        const raw = vehicle[4];
        if (!raw) continue;

        let best = null;
        for (const path of paths) {
            const projection = projectOnPath(path, raw);
            if (!best || projection.distSq < best.distSq) {
                best = { ...projection, path };
            }
        }

        if (!best || best.distSq > limitSq) continue;

        // Odcinek: punkt rzutu + reszta ścieżki do przystanku wsiadania.
        // Pojazd już na/po przystanku wsiadania → odcinek za krótki → pomijamy.
        const segment = [best.point, ...best.path.slice(best.index + 1)];
        if (segment.length < 2) continue;

        segmentsByVehicle.set(vehicle[0], {
            vehicleId: vehicle[0],
            color: previewVehicleColor(vehicle[0]),
            coordinates: segment,
            distSq: best.distSq,
        });
    }

    // Kolor przydzielony raz zostaje przy pojazdzie (stabilność między
    // ramkami strumienia); pula 15 kolorów + shiftHue przy >15 pojazdach.
    refreshApproachLayer([...segmentsByVehicle.values()]);
}

/** Czyści wszystkie markery przystanków. */
export function clearStopMarkers() {
    // Wartości przechowywane w markerLayers.stops to same obiekty markerów
    // (patrz updateStopMarkers: set(id, marker)) — nie opakowania { marker }.
    for (const marker of markerLayers.stops.values()) marker?.remove();
    markerLayers.stops.clear();
}

/**
 * Aktualizuje znaczniki pojazdów (odpowiednik Markers.tsx + VehicleMarker.tsx).
 * vehicles — tablica krotek Vehicle (patrz typings.ts).
 */
export function updateVehicleMarkers(vehicles, onClick) {
    const seen = new Set();

    // W trybie podglądu trasy planera pokazuj tylko pojazdy z moich linii
    if (routePreviewLines) {
        vehicles = vehicles.filter((vehicle) => routePreviewLines.has(String(vehicle[2]?.[2])));
    }

    // UWAGA: let — pojazd bywa podmieniany kopią po PRZYCZEPIENIU do linii
    // (snap); na const pętla wywalałaby się TypeError przy pierwszym snapie.
    for (let vehicle of vehicles) {
        const id = vehicle[0];
        seen.add(id);

        let location = vehicle[4];

        // W podglądzie KAŻDY pojazd ma WŁASNY kolor z palety (15 kolorów
        // w CSS) — nachodzące na siebie busy/pociągi są rozróżnialne.
        const previewColor = routePreviewLines ? previewVehicleColor(id) : null;

        // Przyczep pojazd do linii trasy planera — pojazd jedzie PO LINII,
        // nie obok niej (zgłoszenie: „ikonka busa niech zawsze jeździ po
        // linii trasy, nie może być poza nią").
        if (routePreviewLines && location) {
            const paths = routePreviewPaths.get(String(vehicle[2]?.[2]));
            if (paths?.length) {
                const snapped = snapLngLatToPath(paths.flat(), location);
                if (snapped !== location) {
                    location = snapped;
                    vehicle = [...vehicle];
                    vehicle[4] = location;
                    vehicle.snapped = true;
                }
            }
        }

        const existing = markerLayers.vehicles.get(id);
        if (existing) {
            // MapLibre używa naszego elementu BEZPOŚREDNIO jako znacznika,
            // więc aktualizujemy jego zawartość W MIEJSCU (klasy maplibre
            // muszą zostać), a pozycję przez setLngLat.
            existing.marker.setLngLat(location);

            const fresh = renderVehicleElement(vehicle, previewColor);
            existing.element.style.background = fresh.style.background;
            existing.element.replaceChildren(...fresh.childNodes);
            existing.element.classList.toggle('snapped', !!vehicle.snapped);
            existing.element.classList.toggle('preview', !!previewColor);
        } else {
            const element = renderVehicleElement(vehicle, previewColor);
            if (vehicle.snapped) element.classList.add('snapped');
            if (previewColor) element.classList.add('preview');
            const marker = new maplibregl.Marker({ element })
                .setLngLat(location)
                .addTo(map);
            marker.getElement().addEventListener('click', () => onClick?.(vehicle));
            markerLayers.vehicles.set(id, { marker, element });
        }
    }

    // Usuń znaczniki, których już nie ma
    for (const [id, entry] of markerLayers.vehicles) {
        if (!seen.has(id)) {
            entry.marker.remove();
            markerLayers.vehicles.delete(id);
        }
    }

    // Ścieżki DOJAZDU (planer): przyciągnij odcinek od pozycji żywego
    // pojazdu do przystanku wsiadania — półprzezroczysta czerwona linia.
    if (routePreviewLines && approachPathsByLine.size) {
        updateApproachSegments(vehicles);
    }
}

/**
 * Tworzy element chipa pojazdu (dokładny port VehicleMarker.tsx).
 * previewColor — kolor z palety 15 kolorów CSS: w podglądzie trasy planera
 * KAŻDY pojazd ma inny kolor (zamiast koloru linii), żeby nachodzące
 * na siebie pojazdy (2 autobusy / 3 pociągi) były rozróżnialne.
 */
function renderVehicleElement(vehicle, previewColor) {
    const [id, , route, brigade, , bearing] = vehicle;
    const { vehicleNumber } = parseVehicleId(id);

    const showBrigade = settings.brigade;
    const showFleet = settings.fleet;
    const showFleetId = showFleet && !vehicleNumber.startsWith('_');

    const node = document.createElement('div');
    node.className = 'vehicle marker';
    node.style.background = previewColor || route[6];

    if (bearing !== null && bearing !== undefined) {
        const arrow = renderIcon('ArrowUpward', { size: 16 });
        arrow.style.transition = 'transform 0.5s';
        arrow.style.transform = `rotate(${bearing}deg)`;
        node.append(arrow);
    }

    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.setAttribute('viewBox', '0 0 24 24');
    icon.setAttribute('width', '1em');
    icon.setAttribute('height', '1em');
    icon.setAttribute('fill', 'currentColor');
    icon.innerHTML = vehicleTypeIcon(route[5], route[1], route[4]);
    node.append(icon);

    const name = document.createElement('b');
    name.textContent = route[2];
    node.append(name);

    const extra = document.createElement('span');
    extra.textContent =
        (showBrigade && brigade ? `/${brigade}` : '') + (showFleetId ? `/${vehicleNumber}` : '');
    if (extra.textContent) node.append(extra);

    return node;
}

/**
 * Aktualizuje znaczniki przystanków (odpowiednik Markers.tsx + StopMarker.tsx).
 * stops — tablica krotek Stop.
 */
export function updateStopMarkers(stops, onClick) {
    // Tryb SOLO (widok kursu): na mapie zostaje tylko wyświetlany pojazd
    // wraz z własną trasą i przystankami (warstwa trip-stops) — markery
    // przystanków miasta są ukryte.
    if (soloMode) return;

    const seen = new Set();

    for (const stop of stops) {
        const id = stop[0];
        seen.add(id);

        if (markerLayers.stops.has(id)) continue;

        const element = renderStopElement(stop);
        // Ikony przystanków ZAWSZE PIONOWO — nie obracają się razem z mapą
        // (alignment "viewport" zamiast "map"; zgłoszenie użytkownika:
        // „ikony przystanków odwracane a tak nie powinno być”).
        const marker = new maplibregl.Marker({
            element,
            pitchAlignment: 'viewport',
            rotationAlignment: 'viewport',
        })
            .setLngLat(stop[4])
            .addTo(map);

        marker.getElement().style.zIndex = 2;
        marker.getElement().addEventListener('click', () => onClick?.(stop));
        markerLayers.stops.set(id, marker);
    }

    for (const [id, marker] of markerLayers.stops) {
        if (!seen.has(id)) {
            marker.remove();
            markerLayers.stops.delete(id);
        }
    }
}

/** Tworzy element znacznika przystanku (dokładny port StopMarker.tsx). */
function renderStopElement(stop) {
    const types = stop[5];
    const color = defaultColors[types[0]] ?? defaultColors[3];

    // Stacje metra/kolej — kwadratowa ikona (odpowiednik gałęzi [1, 2] w StopMarker)
    if ([1, 2].some((type) => types.includes(type))) {
        const wrapper = document.createElement('div');
        wrapper.className = 'stop-station';
        wrapper.style.backgroundColor = color;

        const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        icon.setAttribute('viewBox', '0 0 24 24');
        icon.setAttribute('width', '1em');
        icon.setAttribute('height', '1em');
        icon.setAttribute('fill', 'currentColor');
        icon.innerHTML = vehicleTypeIcon(types[0]);
        wrapper.append(icon);
        return wrapper;
    }

    const bearing = stop[6];
    const code = stop[3];
    const useStopCode = code && code.length <= 2 && settings.useStopCodeAsIcon;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '30');
    svg.setAttribute('height', '30');
    svg.setAttribute('viewBox', '0 0 -4 30 30');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    svg.style.cursor = 'pointer';
    svg.style.transform = `rotate(${bearing || 0}deg)`;

    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', '15');
    circle.setAttribute('cy', '15');
    circle.setAttribute('r', '11');
    circle.setAttribute('fill', color);
    svg.append(circle);

    const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    group.setAttribute('fill', 'hsla(0, 0%, 100%, 0.8)');
    group.setAttribute(
        'transform',
        `translate(6, 6) scale(0.75) rotate(${-bearing || 0} 12 12)`,
    );

    if (useStopCode) {
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', '12');
        text.setAttribute('y', '13.25');
        text.setAttribute('dominant-baseline', 'middle');
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('font-size', '16');
        text.setAttribute('font-weight', 'bold');
        text.textContent = code;
        group.append(text);
    } else {
        group.innerHTML = vehicleTypeIcon(types[0]);
    }
    svg.append(group);

    if (bearing !== null && bearing !== undefined) {
        const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.setAttribute('transform', 'translate(15, 15) rotate(45) translate(-30, -30)');
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', 'm10 19 5-5 5 5z');
        path.setAttribute('fill', color);
        path.setAttribute('transform', 'rotate(-45 19.5 13)');
        g.append(path);
        svg.append(g);
    }

    return svg;
}

/* --------------------------- Kropki (dots) ------------------------- */

let dotsSource = null;

/** Rysuje kropki pojazdów (odpowiednik DotMarkers.tsx — warstwa circle). */
export function updateDotMarkers(vehicles) {
    if (!map) return;

    // W trybie podglądu trasy planera kropki (zagregowane pojazdy przy
    // małym zoomie) również są „pozostałymi pojazdami” — ukrywamy je.
    if (routePreviewLines) {
        removeDotMarkers();
        return;
    }

    const geojsonData = {
        type: 'FeatureCollection',
        features: vehicles.map((vehicle) => ({
            type: 'Feature',
            geometry: {
                type: 'Point',
                coordinates: vehicle[1],
            },
            properties: {
                color: vehicle[0],
            },
        })),
    };

    if (dotsSource && map.getSource('dots')) {
        dotsSource.setData(geojsonData);
        return;
    }

    map.addSource('dots', { type: 'geojson', data: geojsonData });
    dotsSource = map.getSource('dots');

    map.addLayer({
        id: 'dots',
        type: 'circle',
        source: 'dots',
        paint: {
            'circle-radius': 4,
            'circle-color': ['get', 'color'],
        },
    });
}

/** Usuwa warstwę kropek. */
export function removeDotMarkers() {
    if (map?.getLayer('dots')) map.removeLayer('dots');
    if (map?.getSource('dots')) map.removeSource('dots');
    dotsSource = null;
}

/* --------------------- Lokalizacja użytkownika --------------------- */

let userMarker = null;

/** Aktualizuje znacznik lokalizacji (odpowiednik LocationMarker.tsx). */
export function updateUserMarker(location, bearing) {
    if (!map) return;

    if (!userMarker) {
        const element = document.createElement('div');
        element.className = 'user-location';
        if (bearing !== undefined) {
            const arrow = renderIcon('ArrowDropUp', { size: 30 });
            arrow.style.color = '#1da1f2';
            arrow.style.transform = 'translate(-5.5px, -20px)';
            arrow.style.position = 'absolute';
            element.append(arrow);
        }
        const dot = document.createElement('div');
        dot.className = 'user-location-dot';
        element.append(dot);

        userMarker = new maplibregl.Marker({
            element,
            rotation: bearing,
            pitchAlignment: 'map',
            rotationAlignment: 'map',
        })
            .setLngLat(location)
            .addTo(map);
        userMarker.getElement().style.zIndex = 1;
    } else {
        userMarker.setLngLat(location);
        if (bearing !== undefined) userMarker.setRotation(bearing);
    }
}

/* --------------------- Punkty A/B trasy (planer) -------------------- */

/* Markery STARTU i KOŃCA wybranej trasy (zgłoszenie: „marker na mapie,
 * jak wybiorę, żeby był widoczny start i koniec”). Klasyczny pin A/B:
 * A = kolor motywu (var(--primary)), B = kolor trasy (czerwony).
 * Znaczniki DOM — zawsze nad linią trasy, nie łapią kliknięć. */
let endpointMarkers = [];

/** Tworzy element pina A/B (kropka z ogonkiem + litera w środku). */
function renderEndpointElement(kind, label) {
    const node = document.createElement('div');
    node.className = `planner-endpoint planner-endpoint-${kind}`;

    const letter = document.createElement('span');
    letter.append(document.createTextNode(label));
    node.append(letter);

    return node;
}

/**
 * Rysuje markery początku (A) i końca (B) podróży.
 * from/to — { lat, lon } (dowolny może być null → tylko jeden marker).
 */
export function setTripEndpoints(from, to) {
    clearTripEndpoints();
    if (!map) return;

    if (from?.lat && from?.lon) {
        const marker = new maplibregl.Marker({
            element: renderEndpointElement('start', 'A'),
            pitchAlignment: 'viewport',
            rotationAlignment: 'viewport',
        })
            .setLngLat([from.lon, from.lat])
            .addTo(map);
        marker.getElement().style.zIndex = 3;
        marker.getElement().style.pointerEvents = 'none';
        endpointMarkers.push(marker);
    }

    if (to?.lat && to?.lon) {
        const marker = new maplibregl.Marker({
            element: renderEndpointElement('end', 'B'),
            pitchAlignment: 'viewport',
            rotationAlignment: 'viewport',
        })
            .setLngLat([to.lon, to.lat])
            .addTo(map);
        marker.getElement().style.zIndex = 3;
        marker.getElement().style.pointerEvents = 'none';
        endpointMarkers.push(marker);
    }
}

/** Usuwa markery A/B (wyjście z podglądu / zmiana wariantu). */
export function clearTripEndpoints() {
    for (const marker of endpointMarkers) marker.remove();
    endpointMarkers = [];
}

/* --------------------------- Trasa kursu --------------------------- */

let tripSourcesAdded = false;

/** Ścieżka ostatnio narysowanej trasy (do przyczepiania pojazdu do linii). */
let tripRoutePaths = [];

/**
 * Rysuje trasę kursu na mapie (odpowiednik TripRoute.tsx):
 * linia w kolorze trasy + kropki przystanków + etykiety od zoomu 13.5.
 *
 * Właściwości featurów (properties):
 *  - color     — kolor odcinka (planer: kolor linii nogi)
 *  - walk      — przejście piesze (szara przerywana)
 *  - upcoming  — true = odcinek, na który pojazd jeszcze NIE dojechał —
 *                rysowany PÓŁPRZEZROCZYSTE (zgłoszenie: „jeśli coś jest na
 *                trasie, ale nie zajechało na przystanek, pokaż tę trasę
 *                do przystanku w kolorze, ale półprzezroczystą”)
 *  - dash a/b  — wspólny odcinek dwóch linii: kreskowanie naprzemienne
 *                dwóch kolorów (kawałek jeden kolor, kawałek drugi)
 *  - variant   — gałąź zbiorkom (przygaszona)
 */
export function updateTripRoute(shapeGeoJson, stopsGeoJson, color) {
    if (!map) return;

    // Kolor wierzchołkowy: features mogą nieść własny kolor (planer:
    // nogi w kolorach linii, przejścia piesze na szaro).
    const colorByVariant = ['case', ['get', 'variant'], fadeColor(color, 0.5), color];
    const lineColor = ['coalesce', ['get', 'color'], colorByVariant];

    // Odcinki, na które pojazd jeszcze nie dojechał — półprzezroczyste
    const lineOpacity = ['case', ['==', ['get', 'upcoming'], true], MAP_STYLE.upcomingOpacity, 1];

    // Zachowaj ścieżki do przyczepiania pojazdu do trasy (snap)
    tripRoutePaths = [];
    for (const feature of shapeGeoJson.features || []) {
        if (feature.geometry?.type === 'LineString' && !feature.properties?.walk) {
            tripRoutePaths.push(feature.geometry.coordinates);
        }
    }

    if (!tripSourcesAdded) {
        map.addSource('trip-route', { type: 'geojson', data: shapeGeoJson });
        map.addSource('trip-stops', { type: 'geojson', data: stopsGeoJson });

        // Ścieżka DOJAZDU żywego pojazdu (planer): od jego bieżącej
        // pozycji do przystanku wsiadania — półprzezroczysta (0.45).
        // Osobne źródło: aktualizowane przy każdym pakiecie pozycji.
        map.addSource('trip-approach', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });

        map.addLayer({
            id: 'trip-route-walk',
            type: 'line',
            source: 'trip-route',
            filter: ['==', ['get', 'walk'], true],
            layout: {
                'line-join': 'round',
                'line-cap': 'round',
            },
            paint: {
                // Przejście piesze: szara linia przerywana
                'line-color': ['coalesce', ['get', 'color'], PLANNER.walkColor],
                'line-width': MAP_STYLE.walkWidth,
                'line-dasharray': MAP_STYLE.walkDash,
            },
        });

        // DOJAZD pojazdów po zmniejszonej przezroczystości — pod linią
        // mojej trasy (czerwona, pełna) i nad przejściami pieszymi.
        // KAŻDY pojazd w swoim kolorze z palety (feature.properties.color).
        // Featury z dash (wspólne ulice) rysują warstwy -shared-a/b poniżej.
        map.addLayer({
            id: 'trip-route-approach',
            type: 'line',
            source: 'trip-approach',
            filter: ['!', ['has', 'dash']],
            layout: {
                'line-join': 'round',
                'line-cap': 'round',
            },
            paint: {
                'line-color': ['coalesce', ['get', 'color'], PLANNER.approachColor],
                'line-width': MAP_STYLE.routeWidth,
                'line-opacity': MAP_STYLE.approachOpacity ?? 0.45,
            },
        });

        // WSPÓLNE ulice dróg dojazdu dwóch pojazdów — kreski naprzemienne
        // dwóch kolorów (zgłoszenie: „jak ich trasa biegnie ta samą ulicą,
        // pokaż przerywaną linię”). Warstwa A: kreski [3,3]; warstwa B jest
        // przesunięta w fazie (zero-kreska) i wypełnia przerwy warstwy A.
        map.addLayer({
            id: 'trip-approach-shared-a',
            type: 'line',
            source: 'trip-approach',
            filter: ['==', ['get', 'dash'], 'a'],
            layout: {
                'line-join': 'round',
                'line-cap': 'butt',
            },
            paint: {
                'line-color': ['coalesce', ['get', 'color'], PLANNER.approachColor],
                'line-width': MAP_STYLE.routeWidth,
                'line-opacity': MAP_STYLE.approachOpacity ?? 0.45,
                'line-dasharray': MAP_STYLE.sharedDash,
            },
        });

        map.addLayer({
            id: 'trip-approach-shared-b',
            type: 'line',
            source: 'trip-approach',
            filter: ['==', ['get', 'dash'], 'b'],
            layout: {
                'line-join': 'round',
                'line-cap': 'butt',
            },
            paint: {
                'line-color': ['coalesce', ['get', 'color'], PLANNER.approachColor],
                'line-width': MAP_STYLE.routeWidth,
                'line-opacity': MAP_STYLE.approachOpacity ?? 0.45,
                // Przesunięcie fazowe: kreska 0 + przerwa = kreski w przerwach A
                'line-dasharray': [0, MAP_STYLE.sharedDash[0], MAP_STYLE.sharedDash[1], MAP_STYLE.sharedDash[1]],
            },
        });

        // Wspólne odcinki dwóch linii — kreski naprzemienne dwóch kolorów:
        // warstwa A rysuje kreski [3,3], warstwa B jest przesunięta w fazie
        // (zero-kreska na początku) i wypełnia przerwy warstwy A.
        map.addLayer({
            id: 'trip-route-shared-a',
            type: 'line',
            source: 'trip-route',
            filter: ['==', ['get', 'dash'], 'a'],
            layout: {
                'line-join': 'round',
                'line-cap': 'butt',
            },
            paint: {
                'line-color': lineColor,
                'line-width': MAP_STYLE.routeWidth,
                'line-opacity': MAP_STYLE.sharedOpacity,
                'line-dasharray': MAP_STYLE.sharedDash,
            },
        });

        map.addLayer({
            id: 'trip-route-shared-b',
            type: 'line',
            source: 'trip-route',
            filter: ['==', ['get', 'dash'], 'b'],
            layout: {
                'line-join': 'round',
                'line-cap': 'butt',
            },
            paint: {
                'line-color': lineColor,
                'line-width': MAP_STYLE.routeWidth,
                'line-opacity': MAP_STYLE.sharedOpacity,
                // Przesunięcie fazowe: kreska 0 + przerwa = kreski w przerwach A
                'line-dasharray': [0, MAP_STYLE.sharedDash[0], MAP_STYLE.sharedDash[1], MAP_STYLE.sharedDash[1]],
            },
        });

        map.addLayer({
            id: 'trip-route',
            type: 'line',
            source: 'trip-route',
            // Filtr MUSI być odporny na brak właściwości: „!” z null
            // (brak pola „dash”) odrzucałby WSZYSTKIE featury — dlatego
            // sprawdzamy istnienie pola („has” zawsze zwraca boolean).
            filter: ['all', ['!', ['has', 'dash']], ['!=', ['get', 'walk'], true]],
            layout: {
                'line-join': 'round',
                'line-cap': 'round',
            },
            paint: {
                'line-color': lineColor,
                'line-width': MAP_STYLE.routeWidth,
                'line-opacity': lineOpacity,
            },
        });

        map.addLayer({
            id: 'trip-stops',
            type: 'circle',
            source: 'trip-stops',
            paint: {
                'circle-radius': 4.5,
                'circle-color': '#fff',
                'circle-stroke-width': 2.5,
                'circle-stroke-color': lineColor,
            },
        });

        map.addLayer({
            id: 'trip-stop-labels',
            type: 'symbol',
            source: 'trip-stops',
            minzoom: 13.5,
            layout: {
                'text-field': ['get', 'name'],
                'text-size': 12,
                'text-font': ['Noto Sans Bold'],
                'text-offset': [0, 1.2],
                'text-anchor': 'top',
            },
            paint: {
                'text-color': lineColor,
                'text-halo-color': '#fff',
                'text-halo-width': 1,
            },
        });

        tripSourcesAdded = true;
    } else {
        map.getSource('trip-route')?.setData(shapeGeoJson);
        map.getSource('trip-stops')?.setData(stopsGeoJson);
    }
}

/** Usuwa trasę kursu z mapy. */
export function removeTripRoute() {
    if (!map) return;

    for (const layer of [
        'trip-stop-labels',
        'trip-stops',
        'trip-route',
        'trip-route-shared-b',
        'trip-route-shared-a',
        'trip-approach-shared-b',
        'trip-approach-shared-a',
        'trip-route-approach',
        'trip-route-walk',
    ]) {
        if (map.getLayer(layer)) map.removeLayer(layer);
    }
    for (const source of ['trip-stops', 'trip-route', 'trip-approach']) {
        if (map.getSource(source)) map.removeSource(source);
    }
    tripSourcesAdded = false;
    tripRoutePaths = [];
    clearTripEndpoints();
}

/**
 * Znacznik pojazdu kursu (kliknięcie nie prowadzi nigdzie — jak w Trip).
 * path (opcjonalny) — ścieżka trasy: pojazd zostaje PRZYCZEPOWANY do linii
 * (rzutujemy pozycję GPS na łamaną trasy — pojazd jedzie PO linii, nigdy
 * obok niej; zgłoszenie użytkownika).
 */
export function updateTripVehicleMarker(vehicle, path) {
    if (!map) return;

    if (!vehicle) {
        markerLayers.tripVehicle?.remove();
        markerLayers.tripVehicle = null;
        return;
    }

    const snapped =
        path && path.length > 1 ? snapLngLatToPath(path, vehicle[4]) : vehicle[4];

    const element = renderVehicleElement(vehicle);

    if (markerLayers.tripVehicle) {
        markerLayers.tripVehicle.setLngLat(snapped);
        markerLayers.tripVehicle.getElement().replaceChildren();
        markerLayers.tripVehicle.getElement().append(...element.childNodes);
    } else {
        markerLayers.tripVehicle = new maplibregl.Marker({ element })
            .setLngLat(snapped)
            .addTo(map);
    }
}

/** Ścieżki aktualnej trasy kursu (dla widoku Trip do snapowania pojazdu). */
export function getTripRoutePaths() {
    return tripRoutePaths;
}

/* ---------------------- Kształty linii (graf) ---------------------- */

let routeShapesLayer = null;

/**
 * Rysuje kształty kierunku linii (pnie i gałęzie) na mapie —
 * używane przez stronę linii (Route.tsx rysuje shapes przez TripRoute).
 */
export function updateRouteShapes(shapes, color) {
    if (!map) return;

    const features = shapes
        .flat()
        .filter(Boolean)
        .map((shape) => ({
            ...shape,
            properties: { variant: shape.properties?.variant ?? false },
        }));

    const data = { type: 'FeatureCollection', features };

    if (routeShapesLayer && map.getSource('route-shapes')) {
        map.getSource('route-shapes').setData(data);
        return;
    }

    map.addSource('route-shapes', { type: 'geojson', data });
    map.addLayer({
        id: 'route-shapes',
        type: 'line',
        source: 'route-shapes',
        layout: {
            'line-join': 'round',
            'line-cap': 'round',
        },
        paint: {
            'line-color': ['case', ['get', 'variant'], fadeColor(color, 0.5), color],
            'line-width': 4,
        },
    });

    routeShapesLayer = true;
}

/** Usuwa kształty linii z mapy. */
export function removeRouteShapes() {
    if (!map) return;
    if (map.getLayer('route-shapes')) map.removeLayer('route-shapes');
    if (map.getSource('route-shapes')) map.removeSource('route-shapes');
    routeShapesLayer = null;
}

/* --------------------- Wyjścia przystanku (pkp) -------------------- */

/**
 * Dodaje ikony wyjść/wejść stacji (odpowiednik Stop.tsx — stop-exits).
 * exits — lista krotek StopExit [nazwa, lokalizacja].
 */
export function updateStopExits(exits) {
    if (!map) return;

    const data = exits?.length
        ? {
              type: 'FeatureCollection',
              features: exits.map((exit) => ({
                  type: 'Feature',
                  geometry: { type: 'Point', coordinates: exit[1] },
                  properties: { name: exit[0] },
              })),
          }
        : { type: 'FeatureCollection', features: [] };

    if (map.getSource('stop-exits')) {
        map.getSource('stop-exits').setData(data);
        return;
    }

    map.addSource('stop-exits', { type: 'geojson', data });

    map.addLayer({
        id: 'stop-exits',
        type: 'symbol',
        source: 'stop-exits',
        layout: {
            'icon-image': 'entrance',
            'icon-size': 1,
            'icon-allow-overlap': true,
        },
        filter: ['>=', ['zoom'], 16],
    });

    map.addLayer({
        id: 'stop-exit-labels',
        type: 'symbol',
        source: 'stop-exits',
        layout: {
            'text-field': ['get', 'name'],
            'text-size': 14,
            'text-font': ['Noto Sans Bold'],
            'text-anchor': 'top',
            'text-justify': 'center',
            'text-offset': [0, 0.8],
            'text-allow-overlap': false,
        },
        paint: {
            'text-color': '#fff',
            'text-halo-color': '#5373d4',
            'text-halo-width': 1.5,
        },
        filter: ['>=', ['zoom'], 16],
    });
}

/** Usuwa wyjścia stacji z mapy. */
export function removeStopExits() {
    if (!map) return;
    for (const layer of ['stop-exit-labels', 'stop-exits']) {
        if (map.getLayer(layer)) map.removeLayer(layer);
    }
    if (map.getSource('stop-exits')) map.removeSource('stop-exits');
}

/* ------------------------ Perony (TripPlatforms) ------------------- */

/** Rysuje wielokąty peronów (odpowiednik TripPlatforms.tsx). */
export function updatePlatforms(platforms, color) {
    if (!map || !platforms) return;

    if (map.getSource('platforms')) {
        map.getSource('platforms').setData(platforms);
        return;
    }

    map.addSource('platforms', { type: 'geojson', data: platforms });
    map.addLayer({
        id: 'platforms',
        type: 'fill',
        source: 'platforms',
        paint: {
            'fill-color': color,
            'fill-opacity': 0.25,
        },
    });
    map.addLayer({
        id: 'platforms-outline',
        type: 'line',
        source: 'platforms',
        paint: {
            'line-color': color,
            'line-width': 2,
        },
    });
}

/** Usuwa perony z mapy. */
export function removePlatforms() {
    if (!map) return;
    for (const layer of ['platforms-outline', 'platforms']) {
        if (map.getLayer(layer)) map.removeLayer(layer);
    }
    if (map.getSource('platforms')) map.removeSource('platforms');
}

/** Usuwa z mapy wszystkie warstwy dodane przez widoki szczegółów. */
export function clearDetailLayers() {
    removeTripRoute();
    removeRouteShapes();
    removeStopExits();
    removePlatforms();
    removeDotMarkers();
    markerLayers.tripVehicle?.remove();
    markerLayers.tripVehicle = null;
}

/* ------------------------- Narzędzia widoku ----------------------- */

/** Przesuwa mapę do lokalizacji (odpowiednik flyTo z komponentów). */
export function flyTo(center, { zoom, padding } = {}) {
    map?.flyTo({
        center,
        zoom: zoom ?? Math.max(map.getZoom(), 15),
        padding,
    });
}

/** Dopasowuje widok do granic (odpowiednik fitBounds z Trip/index.tsx). */
export function fitBounds(bounds, { padding, maxZoom, maxDuration } = {}) {
    // Nigdy nie przekazuj jawnie undefined — maplibre traktuje je błędnie
    const options = {};
    if (padding) options.padding = padding;
    if (maxZoom !== undefined) options.maxZoom = maxZoom;
    if (maxDuration !== undefined) options.maxDuration = maxDuration;

    map?.fitBounds(bounds, options);
}

/** Aktualne granice mapy jako "w,s,e,n" (odpowiednik useMarkers). */
export function getBoundsString() {
    if (!map) return null;
    const bounds = map.getBounds();
    if (!bounds) return null;
    return [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()].join(',');
}

export { maplibregl };