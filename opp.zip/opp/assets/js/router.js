/**
 * Router po stronie klienta — port createBrowserRouter z react-router-dom
 * oraz logiki useGoBack. Utrzymuje stan w history.state (jak oryginał:
 * "menu" otwiera szufladę, liczby ujemne oznaczają liczbę kroków wstecz
 * po zamknięciu widoku).
 */

// Długość historii w momencie startu (odpowiednik window.historyLength)
window.historyLength = window.history.length;
window.skipPadding = false;

// Ścieżka bazowa instalacji ("" dla domeny głównej, "/podkatalog" gdy
// aplikacja wgrana do podkatalogu) — ustawiana przez index.php.
const basePath = (window.Gay && window.Gay.basePath) || '';

/* --------------------------- Tryb routingu ---------------------------- */
// "path"  — czyste adresy (/kielce/trip/123); wymaga, by serwer serwował
//           powłokę pod dowolną ścieżką (mod_rewrite / .htaccess).
// "hash"  — adresy #/kielce/trip/123; działa na KAŻDYM serwerze bez żadnej
//           konfiguracji (tryb awaryjny). Aplikacja sama go włącza po
//           sondzie /rewrite-probe-… (patrz main.js), gdy serwer nie
//           przepisuje adresów — np. gdy .htaccess nie wgrał się na hosting.
let routingMode = localStorage.getItem('routingMode') === 'hash' ? 'hash' : 'path';

/** Ustawia tryb routingu (zapamiętywany w localStorage). */
export function setRoutingMode(mode) {
    routingMode = mode === 'hash' ? 'hash' : 'path';
    try {
        localStorage.setItem('routingMode', routingMode);
    } catch {
        /* tryb prywatny przeglądarki — po prostu nie cache'uj */
    }
}

/** Aktualny tryb routingu: "path" albo "hash". */
export function getRoutingMode() {
    return routingMode;
}

/* --------------------------- Klucze wpisów ---------------------------- */

/* Symulacja location.key z react-router v6 (potrzebna useGoBack): każdy wpis
 * dodany przez nawigację SPA dostaje własny klucz, wpis startowy
 * (deep-link / odświeżenie) ma klucz "default". Dzięki temu goBack wie,
 * czy pod bieżącym wpisem jest jeszcze wpis aplikacji (można cofnąć
 * history.go) czy nie (wtedy wracamy na /:city/).
 * Stan aplikacji pakujemy w obiekt { __key, __state } — surowe wpisy
 * planera ('preview'/'picking'/'stop-sheet') pozostają stringami, więc
 * wszystkie istniejące porównania window.history.state === 'preview'
 * dalej działają. */
let keySequence = 0;
let currentKey = 'default';

/** Buduje stan wpisu dla history.push/replaceState i zapamiętuje klucz. */
function entryState(state) {
    currentKey = `k-${++keySequence}`;
    return { __key: currentKey, __state: state ?? null };
}

/** Uaktualnia klucz bieżącego wpisu po cofnięciu/naprzód w przeglądarce. */
function syncCurrentKey() {
    const raw = window.history.state;
    if (raw && typeof raw === 'object' && typeof raw.__key === 'string') {
        currentKey = raw.__key;
    } else if (typeof raw !== 'string') {
        // null / nieznany wpis (np. z sesji sprzed aktualizacji) — jak startowy
        currentKey = 'default';
    }
    /* surowe stringi planera dziedziczą klucz wpisu pod spodem (react-router
     * również nie zmienia location przy surowym pushState) */
}

/** Odkrywa stan zapisany przy nawigacji (number / 'menu' / null). */
export function unwrapHistoryState(raw) {
    if (raw && typeof raw === 'object') return raw.__state ?? null;
    if (typeof raw === 'string') return null; // surowe wpisy planera
    return typeof raw === 'number' ? raw : null;
}

/** Dodaje ścieżkę bazową do wewnętrznego adresu (idempotentne). */
function withBase(to) {
    if (!basePath || typeof to !== 'string' || to.startsWith(basePath)) return to;
    return basePath + to;
}

/** Aktualna ścieżka aplikacji (bez bazy; w trybie hash — z #/…). */
export function pathname() {
    if (routingMode === 'hash') {
        let p = (window.location.hash || '').split('?')[0];
        if (p.startsWith('#')) p = p.slice(1);
        if (p && !p.startsWith('/')) p = '/' + p;
        return p || '/';
    }

    let p = window.location.pathname;
    if (basePath && p.startsWith(basePath)) {
        p = p.slice(basePath.length);
    }
    return p || '/';
}

/** Segmenty ścieżki (zdekodowane — jak useParams w react-router). */
export function segments() {
    return pathname()
        .split('/')
        .filter(Boolean)
        .map((part) => {
            try {
                return decodeURIComponent(part);
            } catch {
                return part;
            }
        });
}

/** Query string bieżącego adresu ("" albo "?param=…") — świadomy trybu hash. */
export function search() {
    if (routingMode === 'hash') {
        const qs = (window.location.hash || '').split('?')[1] || '';
        return qs ? '?' + qs : '';
    }
    return window.location.search;
}

/** Parametry ?city= (odpowiednik useParams + getCityFromUrl). */
export function query() {
    return new URLSearchParams(search().replace(/^\?/, ''));
}

/**
 * Rozpoznaje widok na podstawie ścieżki — dokładnie te same reguły,
 * co Router.tsx + Sheet.getType().
 */
export function resolveRoute() {
    const parts = segments();
    const qs = query();

    // Ścieżki shella traktuj jak root (zapas na serwery bez przepisywania)
    if (parts[0] === 'index.php' || parts[0] === 'index.html') {
        return { view: 'root' };
    }

    if (parts.length === 0) return { view: 'root' };
    if (parts[0] === 'cities') return { view: 'cities' };

    const city = parts[0];

    if (parts.length === 1) return { view: 'city', city };

    const [sub, param, child, grandChild] = parts.slice(1);

    switch (sub) {
        case 'search':
            return { view: 'search', city };
        case 'planner':
            return { view: 'planner', city };
        case 'favoriteStops':
            return { view: 'favoriteStops', city };
        case 'layers':
            return { view: 'layers', city };
        case 'executions':
            return { view: 'executions', city };
        case 'filter':
            return { view: 'filter', city };
        case 'routes':
            return { view: 'routes', city };
        case 'blog':
            return param
                ? { view: 'blogPost', city, id: param }
                : { view: 'blog', city };
        case 'settings':
            return param === 'theme'
                ? { view: 'settingsTheme', city }
                : { view: 'settings', city };
        case 'stop':
        case 'station':
            if (child === 'time') return { view: 'stopTime', city, stop: param };
            if (child === 'addToFav') return { view: 'addToFav', city, stop: param };
            return { view: 'stop', city, stop: param, isStation: sub === 'station' };
        case 'trip':
        case 'vehicle':
            if (child === 'info') return { view: 'vehicleInfo', city, id: param, kind: sub };
            if (child === 'brigade') return { view: 'brigadeFromVehicle', city, id: param, kind: sub };
            if (child === 'alerts') return { view: 'tripAlerts', city, id: param, kind: sub };
            return { view: 'trip', city, id: param, kind: sub };
        case 'route':
            if (child === 'brigades') {
                return grandChild
                    ? { view: 'brigade', city, route: param, brigade: grandChild }
                    : { view: 'brigades', city, route: param };
            }
            return { view: 'route', city, route: param };
        case 'stops':
            return { view: 'redirect', to: `/${city}/search` };
        case 'brigades': {
            // /:city/brigades/:brigade -> /:city/route/:route/brigades/:brigade
            const splitted = param?.split('.');
            if (!splitted || splitted.length !== 2) {
                return { view: 'redirect', to: `/${city}/routes` };
            }
            return {
                view: 'redirect',
                to: `/${city}/route/${splitted[0]}/brigades/${splitted[1]}`,
            };
        }
        default:
            return { view: 'city', city };
    }
}

/**
 * Nawigacja (odpowiednik navigate()). Stan liczbowy ujemny zapamiętuje,
 * o ile kroków wrócić po zamknięciu widoku; "menu" otwiera szufladę menu.
 */
export function navigate(to, { state, replace = false } = {}) {
    // Tryb hash: adres serwera nigdy się nie zmienia (aplikacja żyje pod #/…),
    // więc odświeżanie i linki działają bez wsparcia przepisywania adresów.
    const entry = entryState(state);
    if (routingMode === 'hash') {
        let target = typeof to === 'string' ? to : String(to);
        if (basePath && target.startsWith(basePath + '/')) target = target.slice(basePath.length);
        if (!target.startsWith('/')) target = '/' + target;
        if (replace) {
            window.history.replaceState(entry, '', '#' + target);
        } else {
            window.history.pushState(entry, '', '#' + target);
        }
        render();
        return;
    }

    const url = withBase(to);
    if (replace) {
        window.history.replaceState(entry, '', url);
    } else {
        window.history.pushState(entry, '', url);
    }
    render();
}

/** Zamiana ścieżki z zachowaniem query stringa (odpowiednik window.location.pathname + search). */
export function navigateAppend(suffix) {
    navigate(pathname() + suffix + search());
}

/**
 * Podmienia query string bieżącego adresu bez przeładowania strony,
 * zachowując stan history (odpowiednik history.replaceState z useSearchState).
 * Świadomy trybu hash — w nim parametry żyją wewnątrz #/…?param=….
 */
export function replaceSearch(params) {
    const qs = params instanceof URLSearchParams ? params.toString() : String(params ?? '');
    const url =
        routingMode === 'hash'
            ? '#' + pathname() + (qs ? '?' + qs : '')
            : withBase(pathname()) + (qs ? '?' + qs : '');
    window.history.replaceState(window.history.state, '', url);
}

/**
 * Zwraca do /:city/ albo cofa się o zapisaną liczbę kroków — port useGoBack
 * 1:1 z oryginałem. Klucz wpisu (location.key) mówi, czy bieżący wpis został
 * dodany przez nawigację SPA (pod nim jest wcześniejszy wpis aplikacji →
 * można cofnąć history.go); "default" = wpis startowy → wracamy na /:city/.
 *
 * Naprawia zgłoszenie: „kliknięcie Filtr / Zmiana stylu mapy zamyka planer
 * i nie wraca do niego” — arkusz filtra/warstw otwierany Z planera po
 * zamknięciu wraca TERAZ do planera (poprzedni wpis historii), a nie do
 * widoku miasta (stan planera — punkty, wyniki — przetrwał w module).
 */
export function goBack({ ignoreState = false } = {}) {
    const state = unwrapHistoryState(window.history.state);
    const key = currentKey;
    const currentHistory = window.history.length - window.historyLength;

    const parts = segments();
    const city = parts[0] || 'cities';

    if (!key || key === 'default' || (Math.abs(state) > currentHistory && !ignoreState)) {
        navigate(`/${city}/`);
        const { getMap } = window.__zbiorkomMap || {};
        if (getMap && window.__zbiorkomMap.getMap().getZoom() < 15) {
            window.__zbiorkomMap.getMap().flyTo({ zoom: 15 });
        }
    } else {
        // liczba ujemna = o ile kroków wrócić po zamknięciu widoku
        // (np. wynik wyszukiwania → kurs: state -2 pomija dialog wyszukiwania)
        const delta = ignoreState ? -1 : typeof state === 'number' ? state : -1;
        window.history.go(delta);
    }
}

/* ------------------------ Powiadomienia o zmianach ------------------ */

const listeners = new Set();

/** Rejestruje callback wywoływany po każdej zmianie trasy. */
export function onRouteChange(callback) {
    listeners.add(callback);
    return () => listeners.delete(callback);
}

/** Wywołuje listenery (popstate + navigate). */
export function render() {
    const route = resolveRoute();

    if (route.view === 'redirect') {
        navigate(route.to, { replace: true });
        return;
    }

    for (const listener of listeners) listener(route, window.history.state);
}

window.addEventListener('popstate', () => {
    syncCurrentKey();
    render();
});
// Uwaga: celowo NIE dodajemy osobnego listenera „hashchange” — cofanie i
// przechodzenie po wpisach #/… generuje w nowoczesnych przeglądarkach ZARÓWNO
// popstate, jak i hashchange, więc osobny listener powodowałby podwójne
// renderowanie tego samego adresu (popstate w pełni obejmuje nawigacje hash).

/** Stan menu: navigate(path, { state: "menu" }) otwiera szufladę (jak Root.tsx). */
export function isMenuState(state) {
    return state === 'menu' || (state && typeof state === 'object' && state.__state === 'menu');
}
