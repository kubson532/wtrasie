<?php
/**
 * zbiorkom.live — strona diagnostyczna dla hostingu.
 * ---------------------------------------------------------------------------
 * Otwórz w przeglądarce: https://twoja-domena/diag.php
 * Pokazuje w prosty sposób, czy pliki aplikacji wgrały się poprawnie
 * i czy konfiguracja serwera pozwala jej działać. Nie wymaga niczego
 * poza PHP — działa nawet gdy sama aplikacja jest zepsuta.
 */

error_reporting(0);
@ini_set('display_errors', '0');

header('Content-Type: text/html; charset=utf-8');

function row($label, $value, $ok = true, $hint = '')
{
    $color = $ok ? '#2e7d32' : '#c62828';
    $mark = $ok ? '&#10003;' : '&#10007;';
    echo '<tr><td style="padding:6px 12px;border-bottom:1px solid #303030;">' . htmlspecialchars($label) . '</td>';
    echo '<td style="padding:6px 12px;border-bottom:1px solid #303030;color:' . $color . ';font-weight:600;">' . $mark . ' ' . htmlspecialchars($value) . '</td>';
    if ($hint !== '') {
        echo '<td style="padding:6px 12px;border-bottom:1px solid #303030;color:#aaa;font-size:12px;">' . htmlspecialchars($hint) . '</td>';
    } else {
        echo '<td style="border-bottom:1px solid #303030;"></td>';
    }
    echo '</tr>';
}

// Spodziewane rozmiary kluczowych plików (bajty) — wgrywane wg ZIP-a.
// Różnica = plik uszkodzony/przycięty przy wgrywaniu.
$expected = [
    'index.php' => null, // wersja może się różnić — sprawdzamy tylko istnienie
    'assets/js/vendor/maplibre-gl.js' => 803086,
    'assets/js/main.js' => null, // wersja może się różnić — sprawdzamy tylko istnienie
    'assets/js/branding.js' => null, // kolory i logotypy do przemianowania
    'assets/js/transitous.js' => null, // klient API planera (tylko wersja z planerem)
    'assets/js/pages/planner.js' => null, // widok planera (tylko wersja z planerem)
    'assets/css/main.css' => null,
    'assets/css/maplibre-gl.css' => 65534,
    'style.json' => 41916,
    '.htaccess' => null,
    'inc/i18n.php' => null,
    'inc/seo.php' => null,
    'config.php' => null,
    'cache/cities.json' => null,
    'service-worker.js' => null,
];

$checks = [];
$problems = 0;

// 1. Wersja PHP
$phpOk = version_compare(PHP_VERSION, '8.0.0', '>=');
if (!$phpOk) $problems++;

// 2. Pliki
foreach ($expected as $file => $size) {
    $path = __DIR__ . '/' . $file;
    if (!is_file($path)) {
        $checks[] = [$file, 'BRAK PLIKU', false, 'Wgraj pliki z ZIP-a (folder docelowy: katalog główny strony)'];
        $problems++;
        continue;
    }
    $real = filesize($path);
    if ($size !== null && $real !== false && abs($real - $size) > 8) {
        $checks[] = [$file, 'Zły rozmiar: ' . $real . ' B (powinno być ~' . $size . ' B)', false, 'Plik uszkodzony przy wgrywaniu — wgraj ponownie (najlepiej FTP w trybie binarnym)'];
        $problems++;
        continue;
    }
    $checks[] = [$file, 'OK (' . $real . ' B)', true, ''];
}

// 3. .htaccess — obecność (zawartość diagnostujemy przez działanie przepisywania)
$htaccessOk = is_file(__DIR__ . '/.htaccess');

// 4. Rozszerzenia PHP
$curlOk = extension_loaded('curl');
$jsonOk = extension_loaded('json');

// 5. URL bazowy
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
if ($base === '.' || $base === '/') $base = '';
?>
<!doctype html>
<html lang="pl">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Diagnostyka — zbiorkom.live (port PHP)</title>
    <style>
        body { background:#121212; color:#e6e6e6; font-family:Roboto,Arial,sans-serif; margin:0; padding:24px; }
        .wrap { max-width:860px; margin:0 auto; }
        h1 { font-size:22px; margin:0 0 4px; }
        p.sub { color:#9e9e9e; margin:0 0 20px; font-size:14px; }
        table { width:100%; border-collapse:collapse; background:#1c1c1c; border-radius:10px; overflow:hidden; font-size:14px; }
        th { text-align:left; padding:10px 12px; background:#272727; font-size:13px; letter-spacing:.3px; }
        td { vertical-align:top; }
        .verdict { margin:22px 0; padding:16px 18px; border-radius:12px; font-size:15px; line-height:1.55; }
        .verdict.ok { background:#163116; border:1px solid #2e7d32; }
        .verdict.bad { background:#2f1212; border:1px solid #c62828; }
        a { color:#66bb6a; }
        .hintbox { background:#1c1c1c; border-radius:10px; padding:14px 16px; font-size:13px; color:#bdbdbd; line-height:1.6; margin-top:18px; }
        code { background:#2a2a2a; padding:1px 6px; border-radius:6px; font-size:12.5px; }
    </style>
</head>
<body>
<div class="wrap">
    <h1>Diagnostyka aplikacji zbiorkom.live</h1>
    <p class="sub">Adres bazowy: <code><?= htmlspecialchars($scheme . '://' . $host . $base) ?></code></p>

    <table>
        <tr><th>Sprawdzenie</th><th>Wynik</th><th>Uwagi</th></tr>
        <?php
        row('Wersja PHP', PHP_VERSION . ' (' . PHP_SAPI . ')', $phpOk,
            $phpOk ? 'Aplikacja wymaga PHP 8.0+ (zalecane 8.1+).' : 'Zbyt stara wersja PHP.');
        foreach ($checks as [$label, $value, $ok, $hint]) {
            row('Plik: ' . $label, $value, $ok, $hint);
        }
        row('Plik .htaccess', $htaccessOk ? 'obecny' : 'BRAK', $htaccessOk,
            $htaccessOk ? 'Test działania przepisywania adresów poniżej („Czyste adresy…”).' : 'To plik UKRYTY (zaczyna się od kropki) — klienty FTP i menedżery plików często go nie pokazują i nie wgrywają. Włącz pokazywanie ukrytych plików i wgraj go ręcznie z ZIP-a. UWAGA: aplikacja działa poprawnie także BEZ niego (tryb #/…).');
        row('Rozszerzenie curl', $curlOk ? 'aktywne' : 'nieaktywne', $curlOk,
            'Niewymagane — API odpytywane jest z przeglądarki.');
        row('Rozszerzenie json', $jsonOk ? 'aktywne' : 'nieaktywne', $jsonOk, '');
        ?>
    </table>

    <?php if ($problems === 0): ?>
        <div class="verdict ok">
            <strong>Wszystkie pliki są na miejscu.</strong><br />
            Jeśli mimo to strona główna jest biała:
            1) wyczyść cache przeglądarki (Ctrl+F5), 2) sprawdź, czy stary service worker
            nie serwuje starej wersji (DevTools &rarr; Application &rarr; Service Workers &rarr; Unregister),
            3) upewnij się, że wgrano zawartość ZIP-a do katalogu <code>htdocs</code> (nie do podfolderu).
        </div>
    <?php else: ?>
        <div class="verdict bad">
            <strong>Znaleziono <?= $problems ?> problem(y) — to najprawdopodobniej przyczyna białej strony.</strong><br />
            Popraw je zgodnie z uwagami w tabeli i odśwież tę stronę.
        </div>
    <?php endif; ?>

    <div id="rewrite-test" class="verdict" style="background:#1c1c1c;border:1px solid #444;">
        Sprawdzam wsparcie czystych adresów (mod_rewrite)&hellip;
    </div>
    <script>
        (function () {
            var base = <?= json_encode($base, JSON_UNESCAPED_SLASHES) ?>;
            fetch(base + '/rewrite-probe-diag', { cache: 'no-store' })
                .then(function (response) {
                    return response.ok ? response.text() : '';
                })
                .then(function (body) {
                    var box = document.getElementById('rewrite-test');
                    if (body.trim() === 'OK') {
                        box.className = 'verdict ok';
                        box.innerHTML =
                            '<strong>Czyste adresy działają (przepisywanie adresów OK).</strong><br />' +
                            'Odświeżanie głębokich linków (np. /kielce/route/4) działa bez błędów.';
                    } else {
                        box.className = 'verdict bad';
                        box.innerHTML =
                            '<strong>Serwer nie przepisuje adresów (brak .htaccess lub mod_rewrite).</strong><br />' +
                            'To NIE blokuje działania aplikacji — sama użyje trybu <code>#/\u2026</code>, ' +
                            'w którym odświeżanie, linki i wszystkie funkcje działają poprawnie.<br />' +
                            'Jeżeli chcesz czystych adresów: wgraj plik <code>.htaccess</code> z ZIP-a. ' +
                            'To plik UKRYTY — w kliencie FTP / menedżerze plików włącz pokazywanie ' +
                            'ukrytych plików (dotfiles) i wgraj go ręcznie.';
                    }
                })
                .catch(function () {
                    var box = document.getElementById('rewrite-test');
                    box.className = 'verdict bad';
                    box.textContent = 'Nie udało się sprawdzić wsparcia przepisywania adresów (błąd sieci).';
                });
        })();
    </script>

    <p style="margin-top:20px;">
        <a href="<?= htmlspecialchars($base) ?>/">&larr; Wróć do aplikacji</a> &nbsp;·&nbsp;
        <a href="<?= htmlspecialchars($base) ?>/kielce/route/4" target="_blank">Test przepisywania adresów (/kielce/route/4)</a>
    </p>

    <div class="hintbox">
        <strong>Jak wgrać aplikację (InfinityFree):</strong><br />
        1. Panel klienta &rarr; <em>File Manager</em> &rarr; wejdź do katalogu <code>htdocs</code>.<br />
        2. Wgraj ZIP i użyj opcji <em>Extract</em> bezpośrednio w <code>htdocs</code> (pliki muszą leżeć
        bezpośrednio w <code>htdocs</code>, a nie w <code>htdocs/nazwa-zipa/</code>).<br />
        3. Usuń ewentualny domyślny plik <code>index2.html</code> lub inny index Hostingera.<br />
        4. Otwórz tę stronę (<code>/diag.php</code>) ponownie — wszystkie wiersze powinny być zielone.<br />
        5. Wejdź na stronę główną. Gdyby dalej było białe: Ctrl+F5, a w DevTools zakładka
        <em>Application &rarr; Service Workers &rarr; Unregister</em> (zepsuty service worker potrafi
        „zamrozić” stary, pusty widok nawet po naprawie plików).
    </div>
</div>
</body>
</html>
