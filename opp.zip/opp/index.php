<?php
/**
 * zbiorkom.live — port na czysty PHP + HTML
 * ---------------------------------------------------------------------------
 * Front controller. Obsługuje WSZYSTKIE adresy aplikacji (patrz .htaccess):
 *  /                       -> przekierowanie do /cities lub /:city (klient)
 *  /cities                 -> wybór miasta
 *  /:city/                 -> mapa komunikacji miejskiej na żywo
 *  /:city/search           -> wyszukiwarka
 *  /:city/stop/:id         -> przystanek (odjazdy)
 *  /:city/station/:id      -> stacja
 *  /:city/trip/:id         -> kurs (szczegóły pojazdu)
 *  /:city/vehicle/:id      -> pojazd
 *  /:city/route/:id        -> linia (graf przystanków)
 *  /:city/route/:id/brigades/:brigade -> rozkład brygady
 *  /:city/routes           -> rozkłady (lista linii)
 *  /:city/blog             -> blog
 *  /:city/settings         -> ustawienia
 *  /:city/executions       -> "Co wyjechało?"
 *  /:city/favoriteStops    -> ulubione przystanki
 *  /:city/filter           -> filtrowanie
 *  /:city/layers           -> warstwy mapy
 *
 * Po stronie serwera PHP odpowiada wyłącznie za:
 *  1. Shell dokumentu (identyczny jak index.html w oryginale)
 *  2. Meta tagi SEO zależne od adresu (odpowiednik komponentu Helm)
 *  3. Statyczne pliki z katalogu assets/ (dla wbudowanego serwera PHP)
 *
 * Cała logika aplikacji (mapa, strumienie SSE, arkusz, menu) działa
 * w przeglądarce jako czytelny, nieobfuskowany JavaScript (ES modules).
 *
 * Powłoka jest odporna na problemy hostingu (np. InfinityFree):
 *  - statyczny ekran startowy zamiast pustej (białej) strony,
 *  - czytelny komunikat błędu, gdy pliki JS nie wczytają się poprawnie,
 *  - obsługa instalacji w podkatalogu domeny (basePath),
 *  - SEO w bloku try/catch — błąd meta tagów nie przerywa renderowania.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/inc/i18n.php';
require_once __DIR__ . '/inc/seo.php';

// --- Wbudowany serwer PHP (php -S localhost:8000) -> serwuj pliki statyczne ---
if (PHP_SAPI === 'cli-server') {
    $file = __DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (is_file($file)) {
        /* Lokalny serwer deweloperski: serwuj pliki statyczne z nagłówkiem
         * „no-store”, żeby przeglądarka nigdy nie trzymała starego JS podczas
         * testów (na hostingu produkcyjnym pliki serwuje Apache/Nginx —
         * świeżość gwarantuje wersjonowany service worker). */
        $mime = [
            'css' => 'text/css',
            'js' => 'text/javascript',
            'json' => 'application/json',
            'svg' => 'image/svg+xml',
            'png' => 'image/png',
            'woff2' => 'font/woff2',
            'ttf' => 'font/ttf',
        ];
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        header('Content-Type: ' . ($mime[$ext] ?? 'application/octet-stream'));
        header('Cache-Control: no-store');
        readfile($file);
        exit;
    }
}

// --- Ścieżka bazowa aplikacji ---
// "" gdy aplikacja leży w katalogu głównym domeny,
// "/podkatalog" gdy wgrano ją do podkatalogu (działa wtedy bez zmian).
$basePath = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
if ($basePath === '.' || $basePath === '/') {
    $basePath = '';
}

// --- Sonda wsparcia przepisywania adresów (mod_rewrite) -------------------
// /rewrite-probe-<wersja> nie istnieje jako plik. Gdy serwer przepisuje
// adresy (np. przez .htaccess z mod_rewrite), żądanie trafia tutaj i dostaje
// 200 "OK". Gdy serwer NIE przepisuje adresów, klient dostaje 404 — aplikacja
// wykrywa to przy starcie (main.js: detectRoutingMode) i sama przełącza się
// na tryb #/… (routing awaryjny, który działa na każdym serwerze bez żadnej
// konfiguracji — patrz assets/js/router.js).
{
    $probePath = parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    if (!is_string($probePath) || $probePath === '') {
        $probePath = '/';
    }
    if ($basePath !== '' && strpos($probePath, $basePath) === 0) {
        $probePath = substr($probePath, strlen($basePath));
        if ($probePath === '' || $probePath === false) {
            $probePath = '/';
        }
    }
    if (strpos($probePath, '/rewrite-probe-') === 0) {
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: no-store');
        http_response_code(200);
        echo 'OK';
        exit;
    }
}

// --- Język dokumentu (domyślnie polski, jak w oryginale) ---
$lang = 'pl';

// --- Meta tagi SEO dla bieżącego adresu (odpowiednik Helm) ---
// Obliczone w try/catch: nawet gdyby coś poszło nie tak w SEO,
// strona MUSI się wyrenderować (hosting z wyłączonym display_errors
// pokazałby w przeciwnym razie pustą, białą stronę).
$uriPath = parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
if (!is_string($uriPath) || $uriPath === '') {
    $uriPath = '/';
}
if ($basePath !== '' && strpos($uriPath, $basePath) === 0) {
    $uriPath = substr($uriPath, strlen($basePath));
    if ($uriPath === '' || $uriPath === false) {
        $uriPath = '/';
    }
}

$seoTitle = 'zbiorkom.live';
$seoDescription = null;
try {
    $seo = seo_for_request($uriPath, $lang);
    if (is_array($seo) && count($seo) >= 1) {
        $seoTitle = (string) $seo[0];
        $seoDescription = $seo[1] ?? null;
    }
} catch (Throwable $seoError) {
    // celowo pomijamy — shell renderuje się dalej
}

$ogTitle = $seoTitle;
$defaultDescription = 'Śledź w czasie rzeczywistym ruch autobusów, tramwajów i pociągów. Klikając na pojazd lub przystanek, uzyskaj szczegółowe informacje o trasie oraz najbliższych odjazdach. Dostosuj widok mapy, filtrując według interesujących Cię linii lub modelu pojazdu, by szybko i sprawnie planować swoją podróż.';
$description = $seoDescription ?? $defaultDescription;
$B = $basePath;
?>
<!doctype html>
<html lang="<?= htmlspecialchars($lang) ?>">
    <head>
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"
        />
        <meta property="og:title" content="<?= htmlspecialchars($ogTitle) ?>" />
        <meta property="og:image" content="<?= htmlspecialchars($B) ?>/logo512.png" />
        <link rel="icon" href="<?= htmlspecialchars($B) ?>/favicon.svg" />
        <link rel="manifest" href="<?= htmlspecialchars($B) ?>/manifest.json" />
        <meta property="og:description" content="<?= htmlspecialchars($description) ?>" />
        <meta name="description" content="<?= htmlspecialchars($description) ?>" />
        <meta name="theme-color" content="<?= DEFAULT_THEME_COLOR ?>" />
        <meta content="dark light" name="color-scheme" />
        <title><?= htmlspecialchars($seoTitle) ?></title>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link
            href="https://fonts.googleapis.com/css2?family=Roboto+Flex:opsz,wght@8..144,100..1000&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
            rel="stylesheet"
        />
        <link rel="stylesheet" href="<?= htmlspecialchars($B) ?>/assets/css/maplibre-gl.css?v=<?= rawurlencode(APP_VERSION) ?>" />
        <link rel="stylesheet" href="<?= htmlspecialchars($B) ?>/assets/css/main.css?v=<?= rawurlencode(APP_VERSION) ?>" />
        <style>
            /* Statyczny ekran startowy — widać go natychmiast, zanim JS
               zacznie działać. Gdyby pliki JS się nie wczytały, na ekranie
               pozostaje komunikat zamiast pustej, białej strony. */
            #boot-screen {
                position: fixed;
                inset: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 20px;
                background: #121212;
                color: #e6e6e6;
                font-family: Roboto, Arial, sans-serif;
                z-index: 9999;
            }
            @media (prefers-color-scheme: light) {
                #boot-screen {
                    background: #f5f5f5;
                    color: #1c1c1c;
                }
            }
            #boot-screen img {
                width: 96px;
                height: 96px;
                border-radius: 24px;
            }
            #boot-screen .boot-spinner {
                width: 34px;
                height: 34px;
                border: 3px solid rgba(128, 128, 128, 0.35);
                border-top-color: #4caf50;
                border-radius: 50%;
                animation: boot-rotate 0.9s linear infinite;
            }
            @keyframes boot-rotate {
                to {
                    transform: rotate(360deg);
                }
            }
            #boot-screen .boot-text {
                font-size: 15px;
                opacity: 0.85;
            }
        </style>
    </head>

    <body>
        <noscript><div data-nosnippet="true">Włącz JavaScript, aby uruchomić tę aplikację.</div></noscript>
        <div id="root">
            <div id="boot-screen">
                <img src="<?= htmlspecialchars($B) ?>/logo512.png" alt="" width="96" height="96" />
                <div class="boot-spinner"></div>
                <div class="boot-text">Wczytywanie aplikacji…</div>
            </div>
        </div>

        <script>
            // Identyczna logika startowa jak w oryginalnym index.html:
            // kolor motywu zapisany w localStorage + opcjonalne wyłączenie
            // efektu rozmytego szkła.
            document
                .querySelector("meta[name=theme-color]")
                .setAttribute("content", localStorage.getItem("themeColor") || "<?= DEFAULT_THEME_COLOR ?>");

            if (localStorage.getItem("disableLiquidGlass") === "true") {
                document.body.classList.add("disable-liquid-glass");
            }

            // Konfiguracja API (odpowiednik window.Gay z register.ts)
            window.Gay = {
                base: "<?= API_BASE ?>",
                cloudBase: "<?= CLOUD_BASE ?>",
                welcomeAlertUrl: "<?= WELCOME_ALERT_URL ?>",
                version: "<?= APP_VERSION ?>",
                basePath: <?= json_encode($B, JSON_UNESCAPED_SLASHES) ?>,
            };

            // --- Odporność powłoki na problemy hostingu ---------------------
            // Zamiast białej strony użytkownik widzi czytelny komunikat,
            // gdy JavaScript nie wczyta się lub nie uruchomi poprawnie.
            window.__appBooted = false;

            window.bootFail = function (message, hint) {
                var root = document.getElementById("root");
                if (window.__appBooted || !root) return;

                var card = document.createElement("div");
                card.setAttribute("style", [
                    "position:fixed", "inset:0", "display:flex", "flex-direction:column",
                    "align-items:center", "justify-content:center", "gap:12px", "padding:24px",
                    "background:#121212", "color:#e6e6e6", "font-family:Roboto,Arial,sans-serif",
                    "text-align:center", "z-index:99999", "box-sizing:border-box"
                ].join(";"));

                var logo = document.createElement("img");
                logo.src = <?= json_encode($B, JSON_UNESCAPED_SLASHES) ?> + "/logo512.png";
                logo.setAttribute("style", "width:80px;height:80px;border-radius:20px");

                var title = document.createElement("div");
                title.setAttribute("style", "font-size:17px;font-weight:700");
                title.textContent = "Aplikacja nie wystartowała";

                var msg = document.createElement("div");
                msg.setAttribute("style", "max-width:480px;font-size:14px;line-height:1.5;opacity:0.9");
                msg.textContent = message || "Nieznany błąd.";

                var hintEl = document.createElement("div");
                hintEl.setAttribute("style", "max-width:480px;font-size:13px;line-height:1.5;opacity:0.7");
                hintEl.textContent = hint || "Otwórz diag.php, aby sprawdzić stan plików.";

                var diagLink = document.createElement("a");
                diagLink.href = <?= json_encode($B, JSON_UNESCAPED_SLASHES) ?> + "/diag.php";
                diagLink.setAttribute("style", "color:#4caf50;font-size:14px;text-decoration:underline");
                diagLink.textContent = "Diagnostyka (diag.php)";

                var retry = document.createElement("button");
                retry.textContent = "Spróbuj ponownie";
                retry.setAttribute("style", [
                    "margin-top:8px", "padding:10px 22px", "border:none", "border-radius:24px",
                    "background:#276b2b", "color:#fff", "font-size:14px", "cursor:pointer"
                ].join(";"));
                retry.onclick = function () { window.location.reload(); };

                card.append(logo, title, msg, hintEl, diagLink, retry);
                root.replaceChildren(card);
            };

            window.addEventListener("error", function (e) {
                if (!window.__appBooted && document.getElementById("boot-screen")) {
                    bootFail(
                        "Błąd JavaScript podczas uruchamiania: " + ((e && e.message) || "nieznany"),
                        "To zwykle oznacza, że pliki aplikacji nie wgrały się w całości lub serwer zwraca je w uszkodzonej formie."
                    );
                }
            });

            window.addEventListener("unhandledrejection", function () {
                if (!window.__appBooted && document.getElementById("boot-screen")) {
                    bootFail(
                        "Operacja startowa aplikacji nie powiodła się.",
                        "Sprawdź diagnostykę (diag.php) i spróbuj ponownie."
                    );
                }
            });
        </script>

        <!-- MapLibre GL: lokalna, niezminifikowana kopia (UMD -> window.maplibregl) -->
        <script
            src="<?= htmlspecialchars($B) ?>/assets/js/vendor/maplibre-gl.js?v=<?= rawurlencode(APP_VERSION) ?>"
            onerror="bootFail('Nie udało się wczytać pliku maplibre-gl.js (803 KB). Najczęstsza przyczyna: plik uszkodzony lub niekompletny po wgrywaniu na hosting.', 'Porównaj rozmiar pliku na serwerze z instrukcją — otwórz diag.php.')"
        ></script>

        <!-- Aplikacja: natywne moduły ES (bez bundlera).
             ?v= gwarantuje, że po aktualizacji plików przeglądarka nie poda
             starej wersji main.js (podmoduły odświeża service worker). -->
        <script
            type="module"
            src="<?= htmlspecialchars($B) ?>/assets/js/main.js?v=<?= rawurlencode(APP_VERSION) ?>"
            onerror="bootFail('Nie udało się wczytać modułu main.js. Pliki aplikacji są niekompletne albo serwer nie serwuje ich poprawnie.', 'Otwórz diag.php i sprawdź kompletność plików.')"
        ></script>
    </body>
</html>
