# zbiorkom.live — wersja PHP z planerem tras Transitous

To wersja rozszerzona: pełny port aplikacji [zbiorkom.live](https://github.com/DomeQdev/zbiorkom.live)
na **czysty PHP + HTML + CSS + JavaScript** (bez Vite, bez Node.js, bez bundlerów)
**plus nowa zakładka „Planer tras"** oparta o silnik routingu [Transitous](https://transitous.org)
(MOTIS 2 API). Kod jest w pełni czytelny; jedyna dołączona biblioteka to lokalna,
niezminifikowana kopia MapLibre GL JS 4.7.1.

## Zmiany w wersji 4.10.0 (poprawki wg zgłoszeń użytkowników)

**Naprawione błędy:**
- „Wybierz z mapy" w planerze działa: dialog chowa się (klasa `.minimized`),
  mapa staje się klikalna, wybrany punkt wraca do pola; przycisk back
  telefonu przerywa wybór. Wcześniej klasa CSS `.minimized` nie istniała,
  więc kliknięcie nie dawało efektu.
- Kliknięcie wariantu na liście wyników pokazuje mapę i arkusz podglądu
  (wcześniej pełnoekranowy dialog zasłaniał wszystko).
- Oś czasu (widok kursu i planer): linia łącząca przystanki jest CIĄGŁA
  i pozycjonowana względem wiersza — tak jak w oryginale. Wcześniej
  rysowała się jako oderwane „kwadraty" (16×16 px).
- Przyciemniane są TYLKO czasy przejechanych przystanków (jak w oryginale:
  TripStopTimes.tsx, opacity 0.7); nazwy przystanków i kropki zostają
  pełnym kontrastem. Wcześniej przyciemniał się cały wiersz.
- Przyciski w nagłówku arkusza dolnego (śledź/lokalizacja, menu „…", X)
  działają — przeciąganie arkusza nie zaczyna się od przycisków, więc
  `preventDefault` nie blokuje już kliknięć (dotyczyło telefonów).
- Filtr warstwy `trip-route` w MapLibre: wyrażenie `["!", ["get","dash"]]`
  z brakiem własności odrzucało WSZYSTKIE featury (trasa się nie rysowała);
  zamienione na bezpieczne `["!", ["has","dash"]]`.
- Ikony przystanków na mapie są ZAWSZE PIONOWE (alignment `viewport` —
  nie obracają się razem z mapą).
- Ikona pojazdu (bus) jedzie PO LINII trasy — pozycja GPS jest rzutowana
  na łamaną trasy (widok kursu i podgląd planera).

**Nowe funkcje planera:**
- Podpowiedzi rozwijają się BEZPOŚREDNIO POD POLEM, z którego pochodzą.
- Wyszukiwanie rozmyte: ignorujemy znaki polskie (ogonki), cyfry i ukośniki;
  spacja rozdziela FILTRY — „Podkarpacka Politechnika 01" znajduje
  przystanek także po częściowym wpisie (drabina zapytań do MOTIS +
  filtracja po stronie klienta). To samo działa w wyszukiwarce miasta.
- Pełna lista przystanków po drodze: rozwinięcie nogi doładowuje
  WSZYSTKIE przystanki pośrednie z `/api/v1/trip` (plan zwraca tylko
  ucięte `intermediateStops`) i dodaje je na mapę.
- Kliknięcie przystanku na liście otwiera arkusz z jego odjazdami
  (popup z dołu): w widoku kursu — odjazdy zbiorkom; w planerze —
  odjazdy Transitous (z opóźnieniami czasu rzeczywistego).
- Odcinki, na które pojazd jeszcze nie dojechał, są rysowane
  PÓŁPRZEZROCZYSTE (przejechane — pełnym kolorem).
- Dwie linie o tym samym kolorze dostają różne kolory (paleta awaryjna),
  a WSPÓLNE odcinki dwóch linii są kreskowane naprzemiennie dwoma
  kolorami (kawałek jeden kolor, kawałek drugi).
- Oznaczenie danych: „na żywo" / „wg rozkładu" w podglądzie wariantu.
- Strzałka wstecz / przycisk back telefonu zamyka podgląd, wybór z mapy
  i arkusz przystanku (wpisy w historii).
- Tylko JEDEN popup z dołu naraz (poprzedni arkusz jest chowany
  i przywracany po zamknięciu).
- Wersja desktopowa: pełnoekranowe dialogi (planer, ustawienia, rozkłady,
  blog) stają się na dużym ekranie unoszącą kartą 600 px — mapa pozostaje
  widoczna. Strona pozostaje mobile-first.

**Menu:**
- Usunięto „Blog" z menu bocznego.
- Dodano „Zainstaluj aplikację" — instalacja jako aplikacja (PWA): natywny
  prompt przeglądarki (Chrome/Edge/Android), a gdy niedostępny — okno
  z instrukcją (Android/Chrome, iPhone/Safari, komputer).

**Dla dewelopera:**
- Nowy plik `assets/js/branding.js` — JEDNO MIEJSCE z kolorami i logotypami
  do przemianowania (rebrandingu): nazwa aplikacji, kolory typów pojazdów
  (autobus/pociąg/tramwaj/…), kolory planera (przejścia piesze, logotypy
  przewoźników, paleta kolizji, wzory kreskowania), kolory motywu.
- Cache-busting `?v=4.10.0` na głównych zasobach + service worker
  v4.10.0 (stare cache usuwane przy aktywacji) — po wgraniu aktualizacji
  na hosting klienci dostaną świeże pliki od razu.
- Wbudowany serwer PHP serwuje pliki statyczne z `Cache-Control: no-store`
  (wyłącznie lokalnie, w celach testowych).

## Bezpieczeństwo i prywatność

- API zbiorkom (`api.zbiorkom.live`) oraz planera (`api.transitous.org`)
  są wywoływane **wyłącznie z przeglądarki użytkownika** (JavaScript,
  nagłówki CORS) — PHP nie robi żadnego proxy ani nie widzi zapytań.

## Wymagania

- Hosting z PHP 7.4+ — działa nawet **bez mod_rewrite** (wbudowany tryb awaryjny `#/…`)
- **Nic więcej** — żadne narzędzia budowania nie są potrzebne

## Uruchomienie

### Apache (xampp, hosting współdzielony itp.)

1. Skopiuj zawartość katalogu do katalogu głównego serwera (np. `htdocs/zbiorkom`).
2. Plik `.htaccess` załatwia przepisywanie adresów — a nawet jeśli go
   nie wgrasz, aplikacja i tak zadziała (tryb awaryjny `#/…`).

### Adresy URL: czyste albo awaryjne `#/…`

Aplikacja sama sprawdza (sonda `/rewrite-probe-…`), czy serwer serwuje powłokę
pod dowolną ścieżką (mod_rewrite / try_files):

- **serwer z przepisywaniem adresów** → czyste adresy jak w oryginale
  (`/kielce/trip/123`, `/kielce/planner`), odświeżanie i linki działają;
- **serwer bez tej obsługi** (np. brak wgranego `.htaccess` — plik ukryty,
  często pomijany przy wgrywaniu) → automatyczny tryb awaryjny
  `#/kielce/trip/123` — wszystkie funkcje działają (w tym Planer tras),
  łącznie z odświeżaniem i udostępnianiem linków, bez ŻADNEJ konfiguracji
  serwera.

Wybór trybu jest zapamiętywany i weryfikowany raz na sesję; po naprawie
serwera (wgraniu `.htaccess`) aplikacja sama wraca do czystych adresów.
Bezpieczeństwo startu: nawigacja startowa (wybór miasta) używa `history`
API bez przeładowania strony, więc start nigdy nie kończy się 404.

### Hosting współdzielony (InfinityFree itp.)

Patrz plik **INFINITYFREE-INSTALACJA.txt** (krok po kroku) — po wgraniu
otwórz `/diag.php`, aby zweryfikować kompletność plików na serwerze.

### Wbudowany serwer PHP (test lokalnie)

```bash
cd zbiorkom
php -S localhost:8000
```

Otwórz http://localhost:8000 — wbudowany serwer obsłuży pliki statyczne przez `index.php`.

### nginx

```nginx
location / {
    try_files $uri $uri/ /index.php?$query_string;
}
```

## Struktura projektu

```
├── index.php               # Front controller: routing + SEO (odpowiednik Helm.tsx)
├── config.php              # Adresy API (odpowiednik window.Gay)
├── .htaccess               # Reguły Apache
├── inc/
│   ├── i18n.php            # Tłumaczenia pl/en (kopia zasobów i18next)
│   └── seo.php             # Meta tagi SEO per adres (kopia słownika Seo)
├── assets/
│   ├── css/
│   │   ├── main.css        # Motyw Material 3 (odpowiednik MUI + generateDarkScheme)
│   │   └── maplibre-gl.css # Style MapLibre (lokalna kopia)
│   ├── js/                 # Natywne moduły ES (bez bundlera!)
│   │   ├── main.js         # Start aplikacji (odpowiednik index.tsx + App.tsx)
│   │   ├── router.js       # Router klienta (odpowiednik react-router-dom)
│   │   ├── api.js          # SSE + REST (odpowiednik useEventQuery + fetchFunctions)
│   │   ├── map.js          # Mapa i znaczniki (odpowiednik components/map)
│   │   ├── store.js        # Magazyny localStorage (odpowiednik zustand)
│   │   ├── ui.js           # Arkusz, dialogi, FAB-y (odpowiednik MUI)
│   │   ├── i18n.js         # Tłumaczenia (odpowiednik i18next)
│   │   ├── icons.js        # Ikony SVG (ścieżki z @mui/icons-material + Icon.tsx)
│   │   ├── util.js         # Narzędzia (odpowiednik tools.ts + material-color-lite)
│   │   ├── config.js       # Konfiguracja klienta
│   │   └── pages/          # Widoki (odpowiednik components/pages + components/sheet)
│   │       ├── city.js         # Mapa miasta: strumień mapFeatures, FAB-y, menu
│   │       ├── cities.js       # Wybór miasta
│   │       ├── stop.js         # Przystanek: odjazdy (strumień SSE)
│   │       ├── trip.js         # Kurs/pojazd: oś czasu, opóźnienia na żywo
│   │       ├── route.js        # Linia: graf przystanków (pień + gałęzie + koraliki)
│   │       ├── search.js       # Wyszukiwarka
│   │       ├── routes.js       # Rozkłady (lista linii)
│   │       ├── brigades.js     # Brygady
│   │       ├── favorites.js    # Ulubione przystanki
│   │       ├── filter.js       # Filtrowanie linii/modeli
│   │       ├── layers.js       # Warstwy mapy
│   │       ├── settings.js     # Ustawienia + motyw
│   │       ├── blog.js         # Blog
│   │       ├── executions.js   # „Co wyjechało?”
│   │       ├── timepicker.js   # Wybór czasu odjazdów
│   │       └── widgets.js      # Wspólne widgety (chipy, tagi, opóźnienia)
│   └── img/                 # Miniatury stylów mapy
├── style.json              # Styl wektorowy OpenFreeMap (lokalna kopia)
├── manifest.json           # Manifest PWA
├── service-worker.js       # Service worker (czytelny odpowiednik workbox)
├── robots.txt, sitemap.xml, privacy-policy.pdf, logo*, favicon.svg
└── cache/                  # Cache listy miast dla SEO (tworzony automatycznie)
```

## Co zostało przeniesione (bez zmian funkcjonalnych)

- Mapa na żywo: strumień SSE `mapFeatures` (pojazdy, kropki przy małym zoomie, przystanki)
- Trzy style mapy (OpenFreeMap, OSM, Esri Satellite) + ciemny motyw mapy
- Klikalne znaczniki pojazdów/przystanków z numerami linii, brygadą i taborem
- Arkusz dolny z przeciąganiem i punktami zaczepienia (przystanek/kurs/linia)
- Odjazdy z przystanku z opóźnieniami na żywo, odliczaniem i peronami
- Kurs: oś czasu z opóźnieniami, pozycją pojazdu, śledzeniem na mapie, utrudnieniami
- Linia: graf przystanków z pniami, gałęziami i pojazdami (koraliki) + kształty na mapie
- Brygady z wyborem dnia, wyszukiwarka, rozkłady, ulubione przystanki z kierunkami
- Filtrowanie linii/modeli, „Co wyjechało?”, blog, ustawienia (motyw/język/zachowanie)
- Lokalizacja użytkownika z orientacją urządzenia, PWA z aktualizacjami
- Wszystkie klucze localStorage zgodne z oryginałem (ulubione, filtry, motyw itd.)

## Dane

Aplikacja korzysta z publicznego API zbiorkom.live (`api.zbiorkom.live/api6`), dokładnie
tak jak oryginał — żadne dane nie są przechowywane lokalnie poza cache przeglądarki.


## Planer tras (Transitous) — nowa funkcja

Nowa zakładka **„Planer tras"** w menu (ikonka kierunkowskazu) pod adresem `/:city/planner`:

- **Skąd / dokąd** — pola z podpowiedziami miejsc i przystanków (geokodowanie Transitous),
  z przyciskiem zamiany kierunków
- **Kiedy / o której** — data i czas wyszukiwania (domyślnie teraz)
- **Moja lokalizacja** — użycie bieżącej pozycji GPS jako punktu początkowego
- **Wskaż na mapie** — wybór punktu startowego/docelowego kliknięciem na mapie
- **Przesiadki** — maksymalna liczba przesiadek (0-5)
- **Przełączniki wykluczeń przewoźników z logotypami:**
  - Wsiobusy (podmiejskie linie autobusowe, numery 100+)
  - PKS (przewoźnicy z „PKS" w nazwie)
  - Pociągi (kolej: PKP, PolRegio, Koleje itd.)
- **Szukaj** — wyniki z silnika Transitous z **opóźnieniami czasu rzeczywistego**
  (odjazdy przewidywane vs rozkładowe, oznaczenia opóźnień i odwołań)
- **Wyświetlanie wybranego wariantu na mapie** — geometrie linii + przystanki,
  pasek szczegółów z czasami odjazdów i opóźnieniami realtime

### Dane planera

Planer korzysta z publicznego API [Transitous](https://transitous.org/api/)
(MOTIS 2): `geocode` (lokalizator) i `plan` (wyszukiwanie połączeń z danymi
realtime GTFS-RT). Zgodnie z polityką użycia Transitous aplikacja wyświetla
atrybucję danych w widoku planera.

## Zmiany w tej wersji (v4.9.0 — „style 1:1 + planer jakdojade")

**Style skopiowane z oryginału (bez własnych pomysłów):**
- Dokładny port biblioteki `material-color-lite` (autorstwa DomeQdev, tej samej,
  której używa zbiorkom.live) do `assets/js/color.js` — motywy kolorystyczne
  (domyślny `#276b2b` i każdy wybrany) są teraz BIT W BIT jak w oryginale
  (drawer `#065315`, aktywne pozycje `#003908`, FAB-y z cieniem MUI itd.).
- Menu boczne: szerokość 240, cień MuiDrawer, tło backdrop 0.5, pozycje
  44px / padding 6px 16px / 16px, hover i transition jak w oryginale.
- Pasek odjazdów: uchwyt arkusza 36x4 na środku (8px od góry), nagłówek
  20/16/8 z cieniem, wiersze odjazdów 8px 16px (MuiListItemButton).
- Strona opcji: sekcje 16/16/4.8/4.8 na `inverse-on-surface`, nagłówki
  24px/700, przyciski Miasto/Motyw 18px/500 wys. 56, checkbox/radio
  w stylu MUI (zaznaczone = `md3.primary`).
- FAB filtra wrócił na pozycję z oryginału (16*4 = 64px pod FABem szukania).
- Oś czasu kursu: pełny port TripStopTimes — dwa czasy (przyjazd/odjazd),
  przekreślony czas rozkładowy przy opóźnieniu, kolory opóźnień, tor/peron,
- Service worker: cache v4.9.0 — po wgraniu tej wersji na hosting wszystkie
  ZAKTUALIZOWANE pliki zastępują stare cache automatycznie.

**Planer tras (nowości w stylu jakdojade):**
- Podpowiedzi skąd/dokąd z geokodowania Transitous Z BIASEM GEOGRAFICZNYM
  (parametry `place`/`placeBias` MOTIS + sortowanie wg odległości od środka
  mapy) — najpierw miejsca z okolicy, jak w jakdojade.
- Kolory linii wg typu pojazdu (kolory GTFS linii → kolory typu z Icon.tsx
  oryginału), przejścia piesze zawsze NA SZARO.
- Wyniki: karty w stylu jakdojade — czasy, czas przejazdu, przesiadki,
  badge'y linii z opóźnieniami realtime, wariant „Pieszo" gdy szybszy.
- Podgląd wariantu na mapie: usuń wszystkie pozostałe pojazdy (także kropki),
  zostaw ONLY pojazdy linii, którymi jedziesz (jeśli wyjechały — na żywo),
  a gdy ich nie ma — same trasy; nogi w kolorach linii, przejścia piesze
  szare przerywane.
- Menu przystanków na trasie — DOKŁADNIE jak w widoku kursu aplikacji
  (trip-stop-row: czasy, kropki na linii w kolorze nogi, opóźnienia,
  odliczanie minut, przycisk „Pokaż listę połączeń").
- Bezpośredni link /:miasto/planner montuje mapę (FAB-y, strumień) —
  podgląd i wybór punktu na mapie działają też po wejściu z zewnątrz.

**Zmiany v4.12.0 (zgłoszenia użytkownika):**
- Markery A (start) i B (koniec) na mapie po wybraniu wariantu w planerze —
  widoczne punkty podróży: A = kolor motywu, B = czerwony jak trasa,
  biały pierścień czytelny na każdym tle.
- W podglądzie trasy KAŻDY pojazd ma INNY kolor z listy 15 kolorów
  zdefiniowanej w CSS (:root, --vehicle-palette-1..15). Dzięki temu dwa
  autobusy albo trzy pociągi nachodzące na siebie są rozróżnialne
  (chipy mają dodatkowo jasną obwódkę).
- Ścieżki DOJAZDU rysowane są dla WSZYSTKICH żywych pojazdów linii
  (każdy w swoim kolorze z palety). Gdy trasa pojazdów biegnie TA SAMĄ
  ulicą, wspólne odcinki są KRESKOWANE naprzemiennie (warstwy
  trip-approach-shared-a/b).
- Naprawiono: arkusze Filtrowanie / Styl mapy / Polubione przyciemniały
  ekran i blokowały klikanie w popup (backdrop przykrywał arkusz —
  z-index wewnątrz .sheet-root).
- Style mapy: było 3, jest 8 — Basic (wektor), OpenStreetMap, Humanitarian
  (HOT), Carto Light, Carto Dark, Carto Voyager, OpenTopoMap, Esri
  Satellite; nowe style mają miniaturki w oknie wyboru.
- Panel planera przeprojektowany w stylu zbiorkom.live (MD3): karty-sekcje
  #2e312d r16, pola A/B z ikonami w kolorach motywu, wypełnione pola
  „kiedy”, przełączniki wykluczeń jako chipy z obrysem koloru motywu,
  przycisk „Szukaj” = contained (primaryContainer).
- Naprawiono nawigację powrotu (useGoBack 1:1 z oryginałem): zamknięcie
  Filtrowania / Stylu mapy / Wyszukiwania / Polubionych otwartych Z planera
  wraca teraz DO PLANERA (poprzedni wpis historii) z zachowanymi punktami
  i wynikami; dotąd każde zamknięcie wracało do widoku miasta i gubiło
  planer. Symulacja location.key (react-router) w router.js — klucze
  wpisów SPA vs wpis startowy; liczby ujemne (-1/-2/-3) pomijają już
  właściwą liczbę kroków, a zamykanie szuflady menu zdjęło wpis „menu”.

**Zmiany v4.11.0 (zgłoszenia użytkownika):**
- Planer tras jest DOLNYM ARKUSZEM (popup z dołu) — jak widok linii i kursu.
  Formularz i wyniki przewijają się w arkuszu nad mapą; „Szukaj" rozwija
  arkusz na wyniki; wybór wariantu otwiera arkusz podglądu; strzałka
  wstecz / przycisk back telefonu wraca do wyników.
- Podgląd wariantu na mapie: TRASA, KTÓRĄ MASZ JECHAĆ = CZERWONA
  (kolor w branding.js: PLANNER.routeHighlight), przejścia piesze szare
  przerywane; DOJAZD pojazdu — od jego bieżącej pozycji do Twojego
  przystanku wsiadania — PÓŁPRZEZROCZYSTY (geometria pełnego kursu
  z /api/v1/trip, przycinana na żywo wg pozycji pojazdu).
- Widok konkretnego kursu: na mapie widać TYLKO ten pojazd — jego trasa,
  jego przystanki i jego ikonka. Pozostałe pojazdy/kropki/przystanki
  miasta wracają po wyjściu z kursu.
- Menu boczne ma JEDNOLITY kolor — naprawiono ciemnoszare tło listy
  pozycji (przenikały style menu kontekstowego); pozycja aktywna nie ma
  już ciemnej pastylki (aktywność pokazuje tylko wypełniona ikona).
