<?php
/**
 * Generowanie znaczników SEO (odpowiednik komponentu Helm.tsx).
 * Dla danego adresu URL wybiera tytuł i opis ze słownika „Seo”
 * (identycznie jak w oryginalnej aplikacji) i zwraca tablicę
 * [tytuł, opis] gotową do wstawienia w <head>.
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/i18n.php';

/**
 * Pobiera tłumaczenie z zagnieżdżonej tablicy po kropkowanej ścieżce,
 * np. "Seo.city.title". Zwraca null, gdy klucz nie istnieje.
 */
function seo_translate(array $dict, string $path): ?string
{
    $node = $dict;
    foreach (explode('.', $path) as $part) {
        if (!is_array($node) || !array_key_exists($part, $node)) {
            return null;
        }
        $node = $node[$part];
    }
    return is_string($node) ? $node : null;
}

/**
 * Podmienia placeholdery {{nazwa}} w szablonie tłumaczenia.
 */
function seo_interpolate(string $template, array $dictionary): string
{
    return preg_replace_callback(
        '/\{\{(\w+)\}\}/',
        fn($m) => $dictionary[$m[1]] ?? '',
        $template
    );
}

/**
 * Rozpoznaje typ strony na podstawie ścieżki URL i zwraca
 * [zmienną SEO, słownik podstawień] — dokładnie tak, jak robią
 * to komponenty stron w oryginale (Helm variable="...").
 */
function seo_resolve(string $path): array
{
    // Usuń query string i zbędne ukośniki
    $path = parse_url($path, PHP_URL_PATH) ?: '/';
    $path = rtrim($path, '/');
    if ($path === '') {
        $path = '/';
    }
    $segments = $path === '/' ? [] : explode('/', ltrim($path, '/'));

    // "/" lub "/cities" — wybór miasta (Cities pokazuje dialog, ale SEO jak strona główna)
    if (count($segments) === 0) {
        return ['cities', []];
    }
    if ($segments[0] === 'cities') {
        return ['cities', []];
    }

    $city = $segments[0];
    $sub = $segments[1] ?? '';

    switch ($sub) {
        case '':
            return ['city', ['city' => $city]];
        case 'routes':
            return ['schedules', ['city' => $city]];
        case 'route':
            if (isset($segments[2])) {
                return ['route', ['city' => $city, 'route' => $segments[2]]];
            }
            return ['schedules', ['city' => $city]];
        case 'stop':
        case 'station':
            $kind = $sub === 'station' ? 'station' : 'stop';
            return [$kind, [$kind => $segments[2] ?? '', 'city' => $city]];
        case 'trip':
            return ['trip', ['city' => $city, 'route' => '', 'headsign' => '']];
        case 'vehicle':
            return ['vehicle', ['city' => $city, 'route' => '', 'vehicle' => $segments[2] ?? '']];
        case 'blog':
            return ['blogPosts', []];
        case 'settings':
            return ['settings', []];
        default:
            // search, filter, favoriteStops, layers, executions, brigades…
            return ['city', ['city' => $city]];
    }
}

/**
 * Zwraca [title, description] dla danego żądania.
 * Nazwę miasta podstawia z listy miast pobranej z API (z krótką pamięcią
 * podręczną w pliku, żeby nie odpytywać API przy każdym wejściu bota).
 */
function seo_for_request(string $requestUri, string $lang = 'pl'): array
{
    global $I18N;
    $dict = $I18N[$lang] ?? $I18N['pl'];

    [$variable, $dictionary] = seo_resolve($requestUri);

    // Podstaw nazwę miasta (identyfikator -> nazwa z API, jeśli dostępna)
    if (!empty($dictionary['city'])) {
        $dictionary['city'] = seo_city_name($dictionary['city']);
    }

    $title = seo_translate($dict, "Seo.$variable.title");
    $description = seo_translate($dict, "Seo.$variable.description");

    if ($title === null) {
        return ['zbiorkom.live', null];
    }

    $title = seo_interpolate($title, $dictionary);
    $description = $description === null ? null : seo_interpolate($description, $dictionary);

    return ["zbiorkom.live - $title", $description];
}

/**
 * Zamienia identyfikator miasta na nazwę wyświetlaną.
 * Korzysta z listy miast dostarczonej wraz z aplikacją (cache/cities.json),
 * więc działa na KAŻDYM hostingu — bez wychodzących połączeń HTTP
 * (na wielu hostingach, m.in. InfinityFree, allow_url_fopen jest wyłączone).
 */
function seo_city_name(string $cityId): string
{
    static $cities = null;

    if ($cities === null) {
        $cities = [];
        $bundled = __DIR__ . '/../cache/cities.json';
        if (is_file($bundled)) {
            $cities = json_decode((string) file_get_contents($bundled), true) ?: [];
        }
    }

    return $cities[$cityId] ?? $cityId;
}
