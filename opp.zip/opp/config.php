<?php
/**
 * zbiorkom.live — wersja PHP (port 1:1 z repozytorium DomeQdev/zbiorkom.live)
 * ---------------------------------------------------------------------------
 * Konfiguracja aplikacji. Cała aplikacja działa na zwykłym hostingu PHP —
 * bez Vite, bez Node.js, bez narzędzi budowania. Jedyną zewnętrzną biblioteką
 * jest lokalna, NIEZMINIFIKOWANA kopia MapLibre GL JS (assets/js/vendor).
 */

// Wersja aplikacji (odpowiednik VITE_APP_VERSION z oryginału)
define('APP_VERSION', '4.12.0');

// Bazowy adres API backendu (odpowiednik window.Gay.base w oryginale)
define('API_BASE', 'https://api.zbiorkom.live');

// Bazowy adres API "chmury" (blog — odpowiednik window.Gay.cloudBase)
define('CLOUD_BASE', 'https://4.zbiorkom.live');

// Endpoint sprawdzania powiadomień powitalnych (odpowiednik WelcomeAlert)
define('WELCOME_ALERT_URL', 'https://re61.2137.workers.dev');

// Domyślny kolor motywu (tak jak w oryginale)
define('DEFAULT_THEME_COLOR', '#276b2b');

// Domyślna strefa czasowa
define('DEFAULT_TIMEZONE', 'Europe/Warsaw');

// Domyślna lokalizacja mapy (Warszawa — jak w oryginale)
define('DEFAULT_LOCATION', json_encode([21.0122, 52.2297]));
