'use strict';
/* app.js — ZESTAW 20260924l:
   – KARTA: numery linii NA GÓRZE, łańcuszek godzin/minut POD SPODEM
     (minuty pieszo → [LINIA HH:MM] → minuty jazdy ↔ … → [HH:MM] → minuty);
     duży napis = godzina odjazdu (odliczanie gdy <10 min); szare „wyjdź za X"
   – LISTA: planer zbiera do 12 linii; start 6 kart; przewijanie w dół
     DOKŁADA po 5 (auto-uzupełnianie, scroll nietknięty)
   – filtr racjonalności · monitoring „Jadę — monitoruj" · deep linki ·
     Valhalla szeregowa · sync wartości zamiast przebudowy
   Pamiętaj: w index.php zamień 20260924k → 20260924l (meta + scripty). */

const APP_VER = '20260924l';
(function versionCheck(){
  const m = document.querySelector('meta[name="app-ver"]');
  if (!m || m.getAttribute('content') !== APP_VER){
    document.body.innerHTML = '<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;background:#0b0d10;color:#eceae4;font:14px/1.6 system-ui;text-align:center">Niezgodne wersje plików.<br>Zmień w index.php: &lt;meta name="app-ver" content="20260924l"&gt; i odśwież.</div>';
    throw new Error('version mismatch');
  }
})();

const CFG = {
  RT: [
    { url: 'https://www.mpkrzeszow.pl/gtfs/rt/gtfsrt.pb', label: 'API — bezpośrednio' },
    { url: '?_rt=1', label: 'API — proxy PHP' },
    { url: '?_rt=1&cached=1', label: 'ostatnia dobra kopia', cache: true }
  ],
  GTFS_DIR: 'gtfs/',
  REFRESH_MS: 10000
};
const PERF = { mobile:false, animMs:900 };
(function(){
  try { PERF.mobile = matchMedia('(pointer: coarse)').matches || innerWidth <= 700; }
  catch (e){ PERF.mobile = innerWidth <= 700; }
  PERF.animMs = PERF.mobile ? 700 : 900;
})();
const QPB = (function(){ try { return new URLSearchParams(location.search).get('pb') === '1'; } catch (e){ return false; } })();

/* ===== narzędzia ===== */
function $(s){ return document.querySelector(s); }
function p2(n){ return String(n).padStart(2, '0'); }
function esc(s){
  s = (s == null) ? '' : String(s);
  return s.replace(/[&<>"']/g, function(c){
    return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]; });
}
function cssVar(name, fallback){
  try { const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim(); return v || fallback; }
  catch (e){ return fallback; }
}
function ic2(name, fbId, size){
  const s = size || 18;
  return '<span class="icw" style="width:'+s+'px;height:'+s+'px">' +
    '<img src="icons/' + esc(name) + '.svg" alt="" draggable="false" ' +
      'onload="this.parentNode.classList.add(\'ok\')" onerror="this.remove()">' +
    '<svg class="ic" style="width:'+s+'px;height:'+s+'px"><use href="#' + fbId + '"/></svg></span>';
}
function hmsToSec(s){
  if (!s) return null;
  const a = s.split(':');
  if (a.length < 3) return null;
  const h = +a[0], m = +a[1], x = +a[2];
  if (!isFinite(h)) return null;
  return h*3600 + m*60 + x;
}
function fmtSD(sec){ if (sec == null) return '–:–';
  return p2(Math.floor(sec/3600)%24) + ':' + p2(Math.floor(sec/60)%60); }
function fmtUnix(u){ if (!isFinite(u)) return '--:--';
  const d = new Date(u*1000); return p2(d.getHours()) + ':' + p2(d.getMinutes()); }
function fmtUnixS(u){ if (!isFinite(u)) return '--:--:--';
  const d = new Date(u*1000); return p2(d.getHours())+':'+p2(d.getMinutes())+':'+p2(d.getSeconds()); }
function fmtDist(m){ return m < 1000 ? Math.round(m) + ' m' : (m/1000).toFixed(1) + ' km'; }
function fmtDur(sec){ const m = Math.max(1, Math.floor(sec/60));
  if (m < 60) return m + ' min';
  return Math.floor(m/60) + ' h ' + (m%60) + ' min'; }
function fmtT(sec){
  const m = Math.floor(sec/60), h = Math.floor(m/60), day = Math.floor(h/24);
  const s = p2(h%24) + ':' + p2(m%60);
  return day > 0 ? s + ' (+1d)' : s;
}
function fmtMin(d){
  if (d <= 45) return '<1 min';
  if (d < 3600) return Math.ceil(d/60) + 'min';
  const mm = Math.ceil(d/60);
  return Math.floor(mm/60) + 'h' + p2(mm%60);
}
function delayText(sec){
  if (sec == null) return null;
  const m = Math.round(Math.abs(sec)/60);
  if (m === 0) return 'na czas';
  return sec > 0 ? ('opóźnienie ' + m + ' min') : ('przyspieszenie ' + m + ' min');
}
function dlyCls(sec){ return (sec != null && sec < 0) ? 'md-early' : 'md-late'; }
function dlyTag(sec){
  if (sec == null) return '';
  return '<span class="bdel ' + dlyCls(sec) + '">' + delayText(sec) + '</span>';
}
function baseName(s){ return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
function natCmp(a,b){ return String(a).localeCompare(String(b),'pl',{numeric:true}); }
function easeOut(t){ return 1 - Math.pow(1 - t, 3); }
function toast(msg, err){
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : '');
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(function(){ t.style.transition = 'opacity .4s'; t.style.opacity = '0';
    setTimeout(function(){ t.remove(); }, 420); }, 5000);
}
window.addEventListener('error', function(e){ if (e && e.message) toast('Błąd JS: ' + e.message, true); });
window.addEventListener('unhandledrejection', function(e){
  const r = e.reason;
  toast('Błąd asynchr.: ' + ((r && r.message) ? r.message : String(r)), true);
});
const CYCLE = ['#5b8def','#e8590c','#2f9e44','#9c36b5','#e03131','#0c8599','#f08c00','#6741d9','#20c997','#c2255c'];
function legColor(i){ return CYCLE[i % CYCLE.length]; }
function lineColor(key){
  let h = 0; const s = String(key);
  for (let i = 0; i < s.length; i++) h = (h*31 + s.charCodeAt(i)) >>> 0;
  const PAL = ['#F5C244','#F09C3F','#E9702E','#E2512C','#C94D38','#B8562F','#9BA846','#6FA46B','#4FA98E','#3E9AA6','#6E93AC','#8C8A56'];
  return PAL[h % PAL.length];
}
function toks(s){
  s = String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  s = s.replace(/\//g, ' ');
  const raw = s.split(/[^a-z0-9]+/);
  const out = [];
  for (let i = 0; i < raw.length; i++){
    const t = raw[i];
    if (!t || t === 'nz' || /^\d+$/.test(t)) continue;
    out.push(t);
  }
  return out;
}
function matchScore(qt, st){
  if (!qt.length) return 0;
  let sc = 0;
  for (let i = 0; i < qt.length; i++){
    const q = qt[i];
    let best = 0;
    for (let j = 0; j < st.length; j++){
      const t = st[j];
      if (t === q){ best = 3; break; }
      if (t.indexOf(q) === 0 && best < 2) best = 2;
      else if (t.indexOf(q) > 0 && best < 1) best = 1;
    }
    if (!best) return -1;
    sc += best;
  }
  return sc;
}

/* liczniki live */
const Live = { items: [] };
function registerLives(root){
  Live.items = [];
  root.querySelectorAll('[data-live]').forEach(function(el){
    Live.items.push({ el: el, t: +el.dataset.live });
  });
}
/* „<1 min" miga do odjazdu; po odjazdie wiersz tablicy/kafel ZNIKA (bez „teraz") */
function tickLive(){
  if (document.hidden) return;
  const now = clockNow();
  for (let i = 0; i < Live.items.length; i++){
    const it = Live.items[i];
    if (!it.el.isConnected) continue;
    const d = it.t - now;
    if (d <= 0){
      const row = it.el.closest('li');
      if (row && it.el.closest('.board')) row.style.display = 'none';
      else {
        const tile = it.el.closest('.tile');
        if (tile && it.el.closest('.tgrid')) tile.style.display = 'none';
        else it.el.textContent = fmtUnix(it.t);
      }
      it.el.classList.remove('arr-now');
    } else if (d < 60){
      it.el.textContent = '<1 min';
      it.el.classList.add('arr-now');
    } else {
      it.el.textContent = fmtMin(d);
      it.el.classList.remove('arr-now');
    }
  }
  const c = $('#clock'); if (c) c.textContent = fmtUnixS(now);
}
function timeCell(depL, schedAbs, delay, pfx){
  let h = '<span class="mcol">';
  if (depL != null){
    h += '<span class="mmain" data-live="' + depL + '"></span>';
    if (delay != null){
      if (delay >= 60) h += '<span class="mdelay md-late">+' + Math.round(delay/60) + ' min</span>';
      else if (delay <= -60) h += '<span class="mdelay md-early">−' + Math.round(-delay/60) + ' min</span>';
    }
  } else if (schedAbs != null){
    h += '<span class="mclock big">' + fmtUnix(schedAbs) + '</span>';
  }
  h += '</span>';
  return h;
}

/* ===== SYNC dzieci — podmieniaj wartości, nie przebudowuj bloku ===== */
function syncChildren(parent, entries){
  const map = parent._sk || (parent._sk = new Map());
  if (!entries.length){
    if (map.size || parent.children.length){ parent.innerHTML = ''; parent._sk = new Map(); }
    return;
  }
  const want = new Set();
  for (let i = 0; i < entries.length; i++) want.add(entries[i].k);
  map.forEach(function(el, k){
    if (!want.has(k)){
      if (el.parentNode === parent) parent.removeChild(el);
      map.delete(k);
    }
  });
  let ref = null;
  for (let i = 0; i < entries.length; i++){
    const ent = entries[i];
    let el = map.get(ent.k);
    if (el && el._h === ent.h){
      /* bez zmian — zostaje */
    } else {
      const t = document.createElement('div');
      t.innerHTML = ent.h;
      const nel = t.firstElementChild;
      if (nel){
        if (el && el.parentNode === parent) parent.replaceChild(nel, el);
        el = nel;
        map.set(ent.k, el);
      } else if (!el) continue;
    }
    if (!el) continue;
    el._h = ent.h;
    if (ent.sub) syncChildren(el, ent.sub);
    if (ref){ if (el.previousElementSibling !== ref) parent.insertBefore(el, ref.nextSibling); }
    else if (parent.firstElementChild !== el) parent.insertBefore(el, parent.firstChild);
    ref = el;
  }
  const live = new Set();
  map.forEach(function(el){ live.add(el); });
  for (let i = parent.children.length - 1; i >= 0; i--){
    const ch = parent.children[i];
    if (!live.has(ch)) parent.removeChild(ch);
  }
}

/* ===== GTFS ===== */
const G = { routes:new Map(), trips:new Map(), stops:new Map(), stopTimes:new Map(),
  stopIndex:new Map(), shapes:new Map(), calRows:[], calDates:new Map(), stopArea:new Map(), feedInfo:null };
let stopsArray = [];
function parseCSVLine(l){
  if (l.indexOf('"') < 0) return l.split(',');
  const out = []; let cur = '', q = false;
  for (let i = 0; i < l.length; i++){
    const c = l[i];
    if (q){ if (c === '"'){ if (l[i+1] === '"'){ cur += '"'; i++; } else q = false; } else cur += c; }
    else { if (c === '"') q = true; else if (c === ','){ out.push(cur); cur = ''; } else cur += c; }
  }
  out.push(cur); return out;
}
async function fetchGTFS(file, reqCol){
  const att = ['?_gf=' + encodeURIComponent(file) + '&v=' + Math.floor(Date.now()/3.6e6), CFG.GTFS_DIR + file];
  let lastErr = '';
  for (let i = 0; i < att.length; i++){
    try {
      const res = await fetch(att[i], { cache: 'force-cache' });
      if (!res.ok){ lastErr = 'HTTP ' + res.status; continue; }
      const text = await res.text();
      if (text.slice(0, 400).replace(/^\uFEFF/, '').indexOf(reqCol) < 0){ lastErr = 'to nie ' + file; continue; }
      return text;
    } catch (e){ lastErr = e.message; }
  }
  throw new Error('Nie udało się wczytać ' + file + ' (' + lastErr + ')');
}
function tableRows(text){
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  const lines = text.split('\n');
  while (lines.length && lines[lines.length-1].trim() === '') lines.pop();
  const cols = {};
  parseCSVLine(lines[0]).forEach(function(h, i){ cols[h.trim()] = i; });
  return { cols: cols, lines: lines };
}
function ldFile(name){ const li = document.createElement('li');
  li.innerHTML = esc(name) + ' <i>…</i>'; $('#ld-files').appendChild(li); return li; }
function ldOk(li, info){ li.classList.add('done'); li.querySelector('i').textContent = info; }
async function loadStatic(){
  const plan = [
    ['feed_info.txt','feed_publisher_name',false], ['routes.txt','route_id',false],
    ['trips.txt','trip_id',true], ['stops.txt','stop_id',true],
    ['stop_areas.txt','stop_id',false],
    ['calendar_dates.txt','service_id',false], ['calendar.txt','service_id',false],
    ['stop_times.txt','trip_id',true], ['shapes.txt','shape_id',false]
  ];
  let done = 0;
  for (let p = 0; p < plan.length; p++){
    const file = plan[p][0], req = plan[p][1], mand = plan[p][2];
    const li = ldFile(file);
    $('#ld-msg').textContent = 'Wczytywanie ' + file + '…';
    let text = null;
    try { text = await fetchGTFS(file, req); } catch (e){ if (mand) throw e; }
    if (text == null){ ldOk(li, 'pominięty'); done++;
      $('#ld-bar').style.width = (done/plan.length*100)+'%'; continue; }
    const t = tableRows(text), cols = t.cols, lines = t.lines;
    if (file === 'feed_info.txt'){
      const r = parseCSVLine(lines[1] || ''); G.feedInfo = {};
      for (const k in cols) G.feedInfo[k] = r[cols[k]];
    } else if (file === 'routes.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.route_id]) continue;
        G.routes.set(c[cols.route_id], { id:c[cols.route_id],
          short:c[cols.route_short_name] || c[cols.route_id], long:c[cols.route_long_name] || '' }); }
    } else if (file === 'trips.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.trip_id]; if (!id) continue;
        G.trips.set(id, { route_id:c[cols.route_id], service_id:c[cols.service_id],
          headsign:c[cols.trip_headsign] || '', shape_id:c[cols.shape_id] || '', brigade:c[cols.brigade] || '' }); }
    } else if (file === 'stops.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.stop_id]; if (!id) continue;
        const s = { id:id, code:c[cols.stop_code] || '', name:c[cols.stop_name] || id,
          lat:+c[cols.stop_lat], lon:+c[cols.stop_lon],
          street:c[cols.street_name] || '', town:c[cols.town_name] || '', zone:c[cols.zone_id] || '' };
        G.stops.set(id, s); stopsArray.push(s); }
    } else if (file === 'stop_areas.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const aid = c[cols.area_id], sid = c[cols.stop_id];
        if (!aid || !sid) continue;
        G.stopArea.set(sid, aid);
        const st = G.stops.get(sid);
        if (st && !st.zone) st.zone = aid;
      }
    } else if (file === 'calendar_dates.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.service_id]) continue;
        const d = c[cols.date];
        if (!G.calDates.has(d)) G.calDates.set(d, []);
        G.calDates.get(d).push([c[cols.service_id], c[cols.exception_type]]); }
    } else if (file === 'calendar.txt'){
      const dn = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.service_id]) continue;
        const mask = [];
        for (let d = 0; d < 7; d++) mask.push(c[cols[dn[d]]] === '1');
        G.calRows.push({ sid:c[cols.service_id], mask:mask, start:c[cols.start_date], end:c[cols.end_date] }); }
    } else if (file === 'stop_times.txt'){
      const iT=cols.trip_id, iA=cols.arrival_time, iD=cols.departure_time, iS=cols.stop_id,
            iQ=cols.stop_sequence, iP=(cols.pickup_type!==undefined)?cols.pickup_type:-1,
            iO=(cols.drop_off_type!==undefined)?cols.drop_off_type:-1;
      let t0 = performance.now();
      for (let i = 1; i < lines.length; i++){
        const l = lines[i]; if (l === '') continue;
        const c = (l.indexOf('"') < 0) ? l.split(',') : parseCSVLine(l);
        const tid = c[iT]; if (!tid) continue;
        const seq = +c[iQ] || 0, sid = c[iS]; if (!sid) continue;
        let arr = hmsToSec(c[iA]), dep = hmsToSec(c[iD]);
        if (arr == null) arr = dep; if (dep == null) dep = arr; if (dep == null) continue;
        const pu = (iP >= 0) ? ((c[iP] === '') ? 0 : +c[iP]) : 0;
        const dof = (iO >= 0) ? ((c[iO] === '') ? 0 : +c[iO]) : 0;
        let tt = G.stopTimes.get(tid); if (!tt){ tt = []; G.stopTimes.set(tid, tt); }
        tt.push([seq, sid, arr, dep, pu, dof]);
        let ss = G.stopIndex.get(sid); if (!ss){ ss = []; G.stopIndex.set(sid, ss); }
        ss.push([tid, seq, dep, pu]);
        if ((i & 65535) === 0 && performance.now() - t0 > 40){
          $('#ld-bar').style.width = ((done + i/lines.length)/plan.length*100)+'%';
          $('#ld-msg').textContent = 'stop_times… ' + ((i/lines.length*100)|0) + '%';
          await new Promise(function(r){ setTimeout(r); }); t0 = performance.now();
        }
      }
    } else if (file === 'shapes.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.shape_id]; if (!id) continue;
        let a = G.shapes.get(id); if (!a){ a = []; G.shapes.set(id, a); }
        a.push([+c[cols.shape_pt_sequence] || 0, +c[cols.shape_pt_lat], +c[cols.shape_pt_lon]]); }
    }
    ldOk(li, (text.length/1024).toFixed(0) + ' KB');
    done++; $('#ld-bar').style.width = (done/plan.length*100)+'%';
    await new Promise(function(r){ setTimeout(r, 10); });
  }
}
function tripStops(tid){
  const a = G.stopTimes.get(tid); if (!a) return null;
  if (!a._s){ a.sort(function(x,y){ return x[0]-y[0]; }); a._s = true; }
  return a;
}
function shapePoints(id){
  const a = G.shapes.get(id); if (!a || !a.length) return null;
  if (!a._s){ a.sort(function(x,y){ return x[0]-y[0]; }); a._s = true; }
  return a;
}

/* ===== stan ===== */
const S = { vehicles:new Map(), tu:new Map(), alerts:[], tripVeh:new Map(),
  feedBase: Math.floor(Date.now()/1000), feedReal: Date.now(),
  routeFilter:null, firstFit:false, refreshing:false,
  errToasted:false, activeCache:null, activeDate:null, pickHide:false };
const ROUTE = { stack:[] };
const PLUI = { a:null, b:null, last:null, timeTouched:false };
const BOARD = { limit:20, deps:[] };
const RES = { limit:6, step:5 };   /* wyniki: start 6 kart, +5 przy przewijaniu */
const STOPS = { q:'', limit:40, sorted:null };
const ALERTS = { sig:null, dismissed:null };
const REC = { routes:[], stops:[] };
const SDAY = { cur:'today', list:null };
const PENDING = { veh:null, tries:0, j:null };
const TRACK = { j:null, miss:null, alt:null };
function routeActive(){ return ROUTE.stack.length ? ROUTE.stack[ROUTE.stack.length-1] : null; }
function clockNow(){ return S.feedBase + (Date.now() - S.feedReal)/1000; }
function dayStartUnix(){ const d = new Date(S.feedBase*1000); d.setHours(0,0,0,0); return Math.floor(d.getTime()/1000); }
function feedDateStr(){ const d = new Date(S.feedBase*1000);
  return d.getFullYear() + '-' + p2(d.getMonth()+1) + '-' + p2(d.getDate()); }
function activeServices(ds){
  const set = new Set(); const g = ds.replace(/-/g, '');
  const dow = new Date(ds + 'T12:00:00').getDay();
  const idx = (dow === 0) ? 6 : dow - 1;
  for (let i = 0; i < G.calRows.length; i++){
    const c = G.calRows[i];
    if (g >= c.start && g <= c.end && c.mask[idx]) set.add(c.sid);
  }
  const ex = G.calDates.get(g);
  if (ex) for (let i = 0; i < ex.length; i++){
    if (ex[i][1] === '1') set.add(ex[i][0]); else set.delete(ex[i][0]);
  }
  return set.size ? set : null;
}
function ensureActive(){
  const ds = feedDateStr();
  if (S.activeDate !== ds){ S.activeCache = activeServices(ds); S.activeDate = ds; }
}
const STATUS_TXT = ['dojeżdża do przystanku','na przystanku','w trasie'];
const OCC_TXT = ['pusty','dużo miejsc','kilka miejsc','tylko stojące','ścisk','pełny','nie przyjmuje pasażerów'];

function tripRowsLive(tid){
  const rows = tripStops(tid);
  if (!rows) return null;
  const tu = S.tu.get(String(tid));
  const ds0 = dayStartUnix();
  const out = [];
  if (!tu){
    for (let i = 0; i < rows.length; i++)
      out.push({ sid:String(rows[i][1]), seq:rows[i][0], dep:rows[i][3], depL:null, delay:null });
    return out;
  }
  const stuBySeq = new Map();
  const stus = tu.stops || [];
  for (let i = 0; i < stus.length; i++)
    if (stus[i].seq != null) stuBySeq.set(stus[i].seq, stus[i]);
  let carry = (tu.delay != null) ? tu.delay : null;
  for (let i = 0; i < rows.length; i++){
    const r = rows[i];
    const stu = stuBySeq.get(r[0]);
    if (stu){
      if (stu.depDelay != null) carry = stu.depDelay;
      else if (stu.arrDelay != null) carry = stu.arrDelay;
    }
    let depL = null;
    if (stu){
      if (stu.depTime) depL = stu.depTime;
      else if (stu.arrTime) depL = stu.arrTime;
    }
    if (depL == null) depL = ds0 + r[3] + (carry != null ? carry : 0);
    out.push({ sid:String(r[1]), seq:r[0], dep:r[3], depL:depL, delay:carry });
  }
  return out;
}
function liveRowFor(tid, seq){
  const rows = tripRowsLive(tid);
  if (!rows) return null;
  for (let i = 0; i < rows.length; i++) if (rows[i].seq === seq) return rows[i];
  return null;
}
function liveRowBySeq(rows, seq){
  if (!rows) return null;
  for (let i = 0; i < rows.length; i++) if (rows[i].seq === seq) return rows[i];
  return null;
}
function lineShortOf(routeId){
  const r = G.routes.get(routeId);
  return r ? r.short : routeId;
}

/* ===== profile dnia ===== */
function buildDayProfiles(){
  const sat = new Set(), sun = new Set();
  const wdCount = new Map();
  G.calDates.forEach(function(list, date){
    const d8 = date.slice(0,4)+'-'+date.slice(4,6)+'-'+date.slice(6,8);
    const wd8 = new Date(d8 + 'T12:00:00').getDay();
    list.forEach(function(row){
      if (row[1] !== '1') return;
      if (wd8 === 6) sat.add(row[0]);
      else if (wd8 === 0) sun.add(row[0]);
      else wdCount.set(row[0], (wdCount.get(row[0])||0) + 1);
    });
  });
  G.calRows.forEach(function(c){
    if (c.mask[5]) sat.add(c.sid);
    if (c.mask[6]) sun.add(c.sid);
    for (let i = 0; i < 5; i++) if (c.mask[i]) wdCount.set(c.sid, (wdCount.get(c.sid)||0) + 1);
  });
  const out = [{ key:'today', label:'Dziś', services:null, live:true }];
  const wdIds = Array.from(wdCount.keys()).sort();
  const letters = ['A','B','C','D'];
  for (let i = 0; i < wdIds.length; i++){
    out.push({ key:'wd_' + wdIds[i],
      label: wdIds.length > 1 ? ('Dzień roboczy ' + letters[i]) : 'Dzień roboczy',
      sub: 's' + wdIds[i], services: new Set([wdIds[i]]), live:false });
  }
  if (sat.size) out.push({ key:'sat', label:'Sobota', services:sat, live:false });
  if (sun.size) out.push({ key:'sun', label:'Niedziela / święto', services:sun, live:false });
  return out;
}
function dayProfiles(){ if (!SDAY.list) SDAY.list = buildDayProfiles(); return SDAY.list; }
function curProfile(){
  const ps = dayProfiles();
  for (let i = 0; i < ps.length; i++) if (ps[i].key === SDAY.cur) return ps[i];
  return ps[0];
}
function daySelectorHtml(){
  const ps = dayProfiles();
  let h = '<div class="vchips" style="padding:0 0 8px">';
  for (let i = 0; i < ps.length; i++){
    h += '<button class="vchip' + (SDAY.cur === ps[i].key ? ' on' : '') + '" data-day="' + i + '">' +
      esc(ps[i].label) + (ps[i].sub ? '<small>' + esc(ps[i].sub) + '</small>' : '') + '</button>';
  }
  return h + '</div>';
}

/* ===== motyw + podkłady ===== */
let THEME_MODE = 'dark', THEME = 'dark';
const BASEMAPS = [
  { id:'dark', name:'Ciemna', desc:'OSM z ciemnym filtrem', filter:'invert(1) hue-rotate(185deg) brightness(.92) contrast(.85) saturate(.45)',
    make:function(){ return L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      { maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }); } },
  { id:'light', name:'Jasna', desc:'standardowy OpenStreetMap', filter:'',
    make:function(){ return L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      { maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }); } },
  { id:'sat', name:'Satelita', desc:'zdjęcia lotnicze (Esri)', filter:'brightness(.95) saturate(.85)',
    make:function(){ return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      { maxZoom:19, attribution:'Imagery &copy; Esri, Maxar, Earthstar Geographics' }); } },
  { id:'topo', name:'Topograficzna', desc:'teren i drogi (Esri Topo)', filter:'',
    make:function(){ return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
      { maxZoom:19, attribution:'&copy; Esri, OpenStreetMap contributors' }); } }
];
const BASE = { id:'dark', layer:null, manual:false };
function setBasemapById(id){
  const b = BASEMAPS.find(function(x){ return x.id === id; }) || BASEMAPS[0];
  BASE.id = b.id;
  if (BASE.layer) map.removeLayer(BASE.layer);
  BASE.layer = b.make().addTo(map);
  const c = BASE.layer.getContainer();
  if (c) c.style.filter = b.filter || 'none';
}
function saveBasemap(id){ try { localStorage.setItem('ztm-basemap', id); } catch (e){} }
function chooseBasemap(id){
  BASE.manual = true; saveBasemap(id);
  setBasemapById(id);
  map.invalidateSize();
  renderSettings();
  if (history.length > 1) history.back();
  else go('map');
}
function setTheme(t){
  THEME = t;
  document.documentElement.setAttribute('data-theme', t);
  $('#btn-theme').innerHTML = ic2(t === 'dark' ? 'sun' : 'moon', t === 'dark' ? 'i-sun' : 'i-moon');
  const mc = document.querySelector('meta[name=theme-color]');
  if (mc) mc.setAttribute('content', t === 'dark' ? '#0b0d10' : '#e8edf3');
  if (!BASE.manual) setBasemapById(t === 'light' ? 'light' : 'dark');
}
function applyThemeMode(mode){
  THEME_MODE = mode;
  try { localStorage.setItem('ztm-theme', mode); } catch (e){}
  let t = mode;
  if (mode === 'auto'){
    try { t = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'; }
    catch (e){ t = 'dark'; }
  }
  setTheme(t);
  renderSettings();
}
function renderSettings(){
  document.querySelectorAll('#set-theme [data-v]').forEach(function(b){
    b.classList.toggle('on', b.dataset.v === THEME_MODE);
  });
  $('#set-maps').innerHTML = BASEMAPS.map(function(m){
    return '<button class="set-map' + (BASE.id === m.id ? ' on' : '') + '" data-m="' + m.id + '">' +
      '<span class="sw sw-' + m.id + '"></span>' +
      '<span class="sm"><b>' + m.name + '</b><small>' + m.desc + '</small></span></button>';
  }).join('');
}
 $('#set-theme').addEventListener('click', function(e){
  const b = e.target.closest('[data-v]');
  if (b) applyThemeMode(b.dataset.v);
});
 $('#set-maps').addEventListener('click', function(e){
  const b = e.target.closest('[data-m]');
  if (b) chooseBasemap(b.dataset.m);
});
 $('#btn-theme').addEventListener('click', function(){ applyThemeMode(THEME === 'dark' ? 'light' : 'dark'); });
 $('#btn-settings').addEventListener('click', function(){ go('settings', true); });
 $('#btn-layers').addEventListener('click', function(){
  let i = 0;
  for (let k = 0; k < BASEMAPS.length; k++) if (BASEMAPS[k].id === BASE.id) i = k;
  const nb = BASEMAPS[(i + 1) % BASEMAPS.length];
  BASE.manual = true; saveBasemap(nb.id); setBasemapById(nb.id); map.invalidateSize();
  toast('Podkład: ' + nb.name);
});

/* ===== mapa ===== */
const map = L.map('map', { zoomControl:false, attributionControl:true, markerZoomAnimation:!PERF.mobile });
map.setView([50.0413, 21.9990], 13);
map.attributionControl.setPrefix('');
const focusLayer = L.layerGroup().addTo(map);
const dotLayer = L.layerGroup().addTo(map);
const pointLayer = L.layerGroup().addTo(map);
const gpsLayer = L.layerGroup().addTo(map);
const stopRenderer = L.canvas({ padding:.4 });
const svgRenderer = L.svg({ padding:.3 });
let stopLayerFull = null, stopLayerThin = null;
function mkStopPair(s, radius){
  const sid = s.id;
  const grp = L.layerGroup();
  const dot = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:radius,
    weight:2.5, color:'#98a2ad', fillColor:'#39404a', fillOpacity:1 });
  dot.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
  dot.addTo(grp);
  const hit = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:22,
    opacity:0, fillOpacity:0, fill:false, interactive:true });
  hit.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
  hit.addTo(grp);
  return grp;
}
function buildStopLayers(){
  stopLayerFull = L.layerGroup();
  stopLayerThin = L.layerGroup();
  let i = 0;
  const total = stopsArray.length;
  function chunk(){
    if (document.hidden){ requestAnimationFrame(chunk); return; }
    const end = Math.min(i + 500, total);
    for (; i < end; i++){
      const s = stopsArray[i];
      if (!isFinite(s.lat) || !isFinite(s.lon)) continue;
      mkStopPair(s, 6).addTo(stopLayerFull);
      mkStopPair(s, 5).addTo(stopLayerThin);
    }
    if (i < total) requestAnimationFrame(chunk); else updateStopsVis();
  }
  requestAnimationFrame(chunk);
}
function updateStopsVis(){
  if (!stopLayerFull) return;
  const z = map.getZoom();
  let layer = null;
  if (CUR === 'map' && !S.pickHide){
    if (z >= 16) layer = stopLayerFull;
    else if (z >= 14) layer = stopLayerThin;
  }
  if (stopLayerFull !== layer && map.hasLayer(stopLayerFull)) map.removeLayer(stopLayerFull);
  if (stopLayerThin !== layer && map.hasLayer(stopLayerThin)) map.removeLayer(stopLayerThin);
  if (layer && !map.hasLayer(layer)) layer.addTo(map);
}
function syncDotVis(){
  if (map.getZoom() >= 11){ if (!map.hasLayer(dotLayer)) dotLayer.addTo(map); }
  else if (map.hasLayer(dotLayer)) map.removeLayer(dotLayer);
}
let mvT = null;
map.on('moveend zoomend', function(){
  clearTimeout(mvT);
  mvT = setTimeout(function(){ refreshVisibility(); updateStopsVis(); syncDotVis(); syncDirVis(); }, 80);
});
map.on('dragstart', function(){ if (GPS.followCam) GPS.followCam = false; });
map.on('click', function(e){
  if (PICK){ setPlanPoint(PICK, e.latlng.lat, e.latlng.lng); return; }
});

/* ===== GPS ===== */
const GPS = { on:false, lat:null, lng:null, watch:null, marker:null, ring:null, followCam:false };
function setGpsFieldText(){
  const inp = $('#hp-a');
  const row = $('#hp-a-row');
  if (GPS.on){
    inp.value = 'Moja lokalizacja (aktywna)';
    row.classList.add('gps-on');
  } else {
    if (inp.value.indexOf('Moja lokalizacja') === 0) inp.value = '';
    row.classList.remove('gps-on');
  }
}
function toggleGps(){
  if (GPS.on){
    if (GPS.watch != null) navigator.geolocation.clearWatch(GPS.watch);
    GPS.on = false; GPS.followCam = false; GPS.watch = null;
    gpsLayer.clearLayers(); GPS.marker = null; GPS.ring = null;
    $('#btn-gps').classList.remove('on');
    setGpsFieldText();
    renderStopsList();
    return;
  }
  if (!navigator.geolocation){ toast('Geolokalizacja niedostępna (HTTPS lub localhost)', true); return; }
  GPS.on = true;
  $('#btn-gps').classList.add('on');
  setGpsFieldText();
  GPS.watch = navigator.geolocation.watchPosition(function(p){
    const first = (GPS.lat == null);
    GPS.lat = p.coords.latitude; GPS.lng = p.coords.longitude;
    if (GPS.marker) GPS.marker.setLatLng([GPS.lat, GPS.lng]);
    else {
      GPS.marker = L.marker([GPS.lat, GPS.lng], { zIndexOffset:900, interactive:false,
        icon: L.divIcon({ className:'', iconSize:[16,16], iconAnchor:[8,8], html:'<div class="gps-dot"></div>' }) }).addTo(gpsLayer);
      GPS.followCam = true;
      if (CUR === 'map') map.panTo([GPS.lat, GPS.lng]);
    }
    if (GPS.ring){ GPS.ring.setLatLng([GPS.lat, GPS.lng]); GPS.ring.setRadius(p.coords.accuracy || 25); }
    else GPS.ring = L.circle([GPS.lat, GPS.lng], { radius:p.coords.accuracy || 25, weight:1,
      color:'#2f8fff', opacity:.5, fillOpacity:.08, interactive:false }).addTo(gpsLayer);
    if (first) renderStopsList();
    if (GPS.followCam && (CUR === 'map')) map.panTo([GPS.lat, GPS.lng], { animate:true, duration:.6 });
  }, function(err){
    toast('Lokalizacja: ' + (err.message || 'brak zgody'), true);
    toggleGps();
  }, { enableHighAccuracy:true, maximumAge:3000, timeout:12000 });
}
 $('#btn-gps').addEventListener('click', toggleGps);

/* ===== SHAPE INDEX ===== */
const SHAPE_IDX = new Map();
function shapeIndex(shapeId){
  if (SHAPE_IDX.has(shapeId)) return SHAPE_IDX.get(shapeId);
  const pts = shapePoints(shapeId);
  if (!pts || pts.length < 2){ SHAPE_IDX.set(shapeId, null); return null; }
  const ll = pts.map(function(p){ return [p[1], p[2]]; });
  const cum = [0];
  for (let i = 1; i < ll.length; i++) cum.push(cum[i-1] + PLANNER.havM(ll[i-1], ll[i]));
  const idx = { pts: ll, cum: cum, total: cum[cum.length-1] };
  SHAPE_IDX.set(shapeId, idx);
  return idx;
}
function projectOnShape(idx, lat, lng){
  let bd = Infinity, bseg = 0, bt = 0, bx = lat, by = lng;
  for (let i = 0; i < idx.pts.length - 1; i++){
    const a = idx.pts[i], b = idx.pts[i+1];
    const dx = b[0]-a[0], dy = b[1]-a[1];
    const len2 = dx*dx + dy*dy;
    let t = 0;
    if (len2 > 0){
      t = ((lat-a[0])*dx + (lng-a[1])*dy) / len2;
      t = Math.max(0, Math.min(1, t));
    }
    const px = a[0] + t*dx, py = a[1] + t*dy;
    const d = PLANNER.havM([lat,lng],[px,py]);
    if (d < bd){ bd = d; bseg = i; bt = t; bx = px; by = py; }
  }
  const dAlong = idx.cum[bseg] + bt * ((idx.cum[bseg+1]-idx.cum[bseg]) || 0);
  return { lat: bx, lng: by, d: dAlong, dist: bd };
}
function pointAtDist(idx, d){
  const cum = idx.cum;
  if (d <= 0) return idx.pts[0];
  if (d >= idx.total) return idx.pts[idx.pts.length-1];
  let lo = 0, hi = cum.length - 1;
  while (lo < hi - 1){ const m = (lo+hi)>>1; if (cum[m] <= d) lo = m; else hi = m; }
  const t = (d - cum[lo]) / ((cum[lo+1]-cum[lo]) || 1);
  const a = idx.pts[lo], b = idx.pts[lo+1];
  return [a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t];
}

/* ===== pojazdy ===== */
function viewBoundsOrNull(){
  if (CUR !== 'map' && CUR !== 'route') return null;
  try { if (map._loaded) return map.getBounds().pad(0.25); } catch (e){}
  return null;
}
function vehVisible(v){
  if (S.pickHide) return false;
  if (CUR === 'route'){
    const f = routeActive();
    if (!f) return false;
    if (f.mode === 'vehicle') return v.id === f.vid;
    if (f.mode === 'line' || f.mode === 'linedeps') return v.routeId === f.lineId;
    if (f.mode === 'journey'){
      const legs = f.journey.legs;
      for (let i = 0; i < legs.length; i++)
        if (legs[i].type === 'ride' && v.n && String(v.n.tripId) === String(legs[i].tid)) return true;
      return false;
    }
    if (f.mode === 'trip'){
      const vid = S.tripVeh.get(String(f.tid));
      return !!vid && v.id === vid;
    }
    if (f.mode === 'stop'){
      if (!f._arr || !v.n || v.n.tripId == null) return false;
      const seq = f._arr.get(String(v.n.tripId));
      return seq != null && (v.n.seq || 0) <= seq;
    }
    return false;
  }
  if (S.routeFilter && v.routeId !== S.routeFilter) return false;
  const b = viewBoundsOrNull();
  if (b && !b.contains([v.to.lat, v.to.lng])) return false;
  return true;
}
function attachV(v){
  const el = v.marker.getElement();
  if (el){
    v.el = el;
    v.bodyEl = el.querySelector('.vm-body');
    v.dirEl = el.querySelector('.vm-dir');
    if (v.bodyEl) v.bodyEl.textContent = v.lineName;
    if (v.dirEl) v.dirEl.style.display = (map.getZoom() >= 15) ? '' : 'none';
  }
}
function syncDirVis(){
  const on = map.getZoom() >= 15;
  S.vehicles.forEach(function(v){
    if (v.dirEl && v.dirEl.style.display !== (on ? '' : 'none'))
      v.dirEl.style.display = on ? '' : 'none';
  });
}
function syncVehMarker(v){
  if (CUR !== 'map' && CUR !== 'route') return;
  const vis = vehVisible(v);
  if (vis && !v.onMap){ v.marker.addTo(map); v.onMap = true; attachV(v); }
  else if (!vis && v.onMap){ map.removeLayer(v.marker); v.onMap = false; v.el = v.bodyEl = v.dirEl = null; }
}
function makeBusMarker(line){
  const w = PERF.mobile ? 60 : 56, h = PERF.mobile ? 34 : 30;
  return L.marker([0,0], { zIndexOffset:600, riseOnHover:!PERF.mobile,
    icon: L.divIcon({ className:'vm-wrap', iconSize:[w,h], iconAnchor:[w/2,h/2],
      html:'<div class="vm"><div class="vm-dir"><svg viewBox="0 0 24 24"><path d="M12 3l7 18-7-5.4L5 21z" fill="currentColor" stroke="none"/></svg></div>' +
           '<div class="vm-body">' + esc(line) + '</div></div>' }) });
}
function computeBearing(a, b){
  const dy = b.lat - a.lat, dx = (b.lng - a.lng) * Math.cos(a.lat*Math.PI/180);
  const d = Math.sqrt(dx*dx + dy*dy);
  if (d < 0.00004) return null;
  return (Math.atan2(dx, dy)*180/Math.PI + 360) % 360;
}
function lerpAngle(a, b, k){
  let d = b - a;
  while (d > 180) d -= 360;
  while (d < -180) d += 360;
  return a + d*k;
}
function upsertVehicle(id, n){
  if (n.lat == null || n.lng == null || !isFinite(n.lat) || !isFinite(n.lng)) return null;
  const trip = (n.tripId != null) ? G.trips.get(String(n.tripId)) : null;
  const routeId = (trip && trip.route_id) || n.routeId || null;
  const route = routeId ? G.routes.get(routeId) : null;
  const lineName = (route && route.short) || routeId || '·';
  const now = performance.now();
  let v = S.vehicles.get(id);
  let shpIdx = null, toLat = n.lat, toLng = n.lng, toD = null;
  if (trip && trip.shape_id){
    shpIdx = shapeIndex(trip.shape_id);
    if (shpIdx){
      const pr = projectOnShape(shpIdx, n.lat, n.lng);
      if (pr.dist < 60){ toLat = pr.lat; toLng = pr.lng; toD = pr.d; }
    }
  }
  if (!v){
    v = { id:id, marker: makeBusMarker(lineName),
      from:{lat:toLat,lng:toLng}, to:{lat:toLat,lng:toLng},
      shapeIdx:shpIdx, fromD:toD, toD:toD,
      t0: now - PERF.animMs, cur:{lat:toLat,lng:toLng}, brgShown:null,
      done:true, onMap:false, el:null, bodyEl:null, dirEl:null, tip:lineName };
    v.marker.on('click', function(e){ L.DomEvent.stop(e); openRoute('vehicle', { vid:id, from:'map' }); });
    v.marker.bindTooltip('Linia ' + lineName, { direction:'top', offset:[0,-14] });
    v.marker.setLatLng([toLat, toLng]);
    S.vehicles.set(id, v);
    syncVehMarker(v);
  } else {
    const sameShape = (v.shapeIdx === shpIdx);
    v.shapeIdx = shpIdx;
    v.from = { lat: v.cur.lat, lng: v.cur.lng };
    v.to = { lat: toLat, lng: toLng };
    v.fromD = sameShape ? v.toD : null;
    v.toD = toD;
    let anim = v.onMap && map.getZoom() >= 14;
    if (anim){
      try {
        const p1 = map.latLngToContainerPoint([v.cur.lat, v.cur.lng]);
        const p2 = map.latLngToContainerPoint([toLat, toLng]);
        const dx = p1.x - p2.x, dy = p1.y - p2.y;
        if (dx*dx + dy*dy < 9) anim = false;
        else {
          const vb = viewBoundsOrNull();
          if (vb && !vb.contains([toLat, toLng])) anim = false;
        }
      } catch (e){ anim = false; }
    }
    if (anim){ v.t0 = now; v.done = false; }
    else {
      v.cur = { lat: toLat, lng: toLng };
      v.marker.setLatLng([toLat, toLng]);
      v.t0 = now - PERF.animMs; v.done = true;
    }
    if (v.tip !== lineName){ v.tip = lineName; v.marker.setTooltipContent('Linia ' + lineName); }
    if (v.bodyEl && v.bodyEl.textContent !== lineName) v.bodyEl.textContent = lineName;
    syncVehMarker(v);
  }
  v.n = n; v.trip = trip; v.route = route; v.routeId = routeId;
  v.lineName = lineName;
  return v;
}
function removeVehicle(id){
  const v = S.vehicles.get(id);
  if (!v) return;
  if (v.onMap) map.removeLayer(v.marker);
  S.vehicles.delete(id);
  const f = routeActive();
  if (f && f.mode === 'vehicle' && f.vid === id){
    ROUTE.stack.pop();
    if (!routeActive()) go('map', true);
    else refreshRoute();
    return;
  }
  if (f && f.mode === 'trip' && S.tripVeh.get(String(f.tid)) === id) refreshRoute();
}
function refreshRoute(){
  const f = routeActive();
  if (!f) return;
  renderRoute();
  drawRouteMap(f, false);
}
function refreshVisibility(){ S.vehicles.forEach(syncVehMarker); }
function animTick(){
  requestAnimationFrame(animTick);
  if (document.hidden) return;
  animTick._f = !animTick._f;
  if (S.vehicles.size > 40 && animTick._f) return;
  const nowMs = performance.now();
  S.vehicles.forEach(function(v){
    if (!v.onMap || v.done) return;
    let t = (nowMs - v.t0) / PERF.animMs;
    if (!(t > 0)) t = 0;
    if (t >= 1) t = 1;
    const k = easeOut(t);
    if (v.shapeIdx && v.fromD != null && v.toD != null){
      const d = v.fromD + (v.toD - v.fromD) * k;
      const p = pointAtDist(v.shapeIdx, d);
      v.cur.lat = p[0]; v.cur.lng = p[1];
      if (map.getZoom() >= 15){
        const p2 = pointAtDist(v.shapeIdx, Math.min(v.shapeIdx.total, d + 20));
        const brg = computeBearing({lat:p[0],lng:p[1]},{lat:p2[0],lng:p2[1]});
        if (brg != null && v.dirEl) v.dirEl.style.transform = 'rotate(' + brg.toFixed(1) + 'deg)';
      }
    } else {
      v.cur.lat = v.from.lat + (v.to.lat - v.from.lat) * k;
      v.cur.lng = v.from.lng + (v.to.lng - v.from.lng) * k;
    }
    v.marker.setLatLng([v.cur.lat, v.cur.lng]);
    if (t >= 1) v.done = true;
  });
}
requestAnimationFrame(animTick);
const UPQ = { list:[], t:null };
function queueUpserts(list){
  for (let i = 0; i < list.length; i++) UPQ.list.push(list[i]);
  if (!UPQ.t) UPQ.t = setTimeout(processUpserts, 0);
}
function processUpserts(){
  const t0 = performance.now();
  while (UPQ.list.length && performance.now() - t0 < 8){
    const n = UPQ.list.shift();
    upsertVehicle(n.id, n);
  }
  if (UPQ.list.length) UPQ.t = setTimeout(processUpserts, 30);
  else UPQ.t = null;
}

/* ===== pomocnicze trasy ===== */
const BUS_LINE_C = cssVar('--bus-line-c', '#d95f14');
const BUS_GRAY_C = cssVar('--bus-gray-c', '#8b95a0');
function stopPos(sid){ const s = G.stops.get(sid); return s ? [s.lat, s.lon] : null; }
function stopName(sid){ const s = G.stops.get(sid); return s ? s.name : ('#' + sid); }
function railSvg(o){
  const col = (o.passed || o.gray) ? 'var(--bus-gray-c)' : 'var(--bus-line-c)';
  let s = '<svg class="rail" viewBox="0 0 12 44" style="color:' + col + '">';
  s += o.first
    ? '<circle cx="6" cy="7.5" r="5" fill="currentColor"/><path d="M6 7.5V22" stroke="currentColor" stroke-width="3"/>'
    : '<path d="M6 0V22" stroke="currentColor" stroke-width="3"/>';
  s += o.last
    ? '<path d="M6 22V36.5" stroke="currentColor" stroke-width="3"/><circle cx="6" cy="36.5" r="5" fill="currentColor"/>'
    : '<path d="M6 22V44" stroke="currentColor" stroke-width="3"/>';
  s += o.now
    ? '<circle cx="6" cy="22" r="6" fill="var(--accent)" stroke="#fff" stroke-width="2.5"/>'
    : (o.end
        ? '<circle cx="6" cy="22" r="5.5" fill="#fff" stroke="currentColor" stroke-width="3.5"/>'
        : '<circle cx="6" cy="22" r="4.2" fill="var(--panel2)" stroke="currentColor" stroke-width="3"/>');
  return s + '</svg>';
}
function pinIcon(letter, cls){
  return L.divIcon({ className:'pp-wrap', iconSize:[26,38], iconAnchor:[13,36],
    html:'<div class="pp ' + cls + '"><b>' + letter + '</b></div>' });
}
const shapeSliceCache = new Map();
function shapeSlice(shapeId, fromPt, toPt){
  const key = shapeId + '|' + fromPt[0].toFixed(5) + ',' + fromPt[1].toFixed(5) + '|' + toPt[0].toFixed(5) + ',' + toPt[1].toFixed(5);
  if (shapeSliceCache.has(key)) return shapeSliceCache.get(key);
  let out = null;
  const pts = shapePoints(shapeId);
  if (pts && pts.length >= 2){
    let bi = -1, bd = Infinity, ai = -1, ad = Infinity;
    for (let i = 0; i < pts.length; i++){
      const p = [pts[i][1], pts[i][2]];
      const d1 = PLANNER.havM(p, fromPt); if (d1 < bd){ bd = d1; bi = i; }
      const d2 = PLANNER.havM(p, toPt);   if (d2 < ad){ ad = d2; ai = i; }
    }
    if (bi >= 0 && ai >= 0 && bi !== ai && bd < 300 && ad < 300){
      out = [];
      const lo = Math.min(bi, ai), hi = Math.max(bi, ai);
      for (let i = lo; i <= hi; i++) out.push([pts[i][1], pts[i][2]]);
    }
  }
  shapeSliceCache.set(key, out);
  return out;
}
const LNC = { key:null, map:new Map() };
function lineInfo(lineId){
  const ds = feedDateStr();
  if (LNC.key !== ds){ LNC.key = ds; LNC.map = new Map(); }
  if (LNC.map.has(lineId)) return LNC.map.get(lineId);
  ensureActive();
  const act = S.activeCache;
  const groups = new Map();
  G.trips.forEach(function(tr, tid){
    if (tr.route_id !== lineId) return;
    if (act && !act.has(tr.service_id)) return;
    const st = tripStops(tid);
    if (!st || st.length < 2) return;
    const key = tr.headsign || ('Kierunek ' + lineId);
    let g = groups.get(key);
    if (!g){ g = { headsign: tr.headsign || ('Kierunek ' + lineId), tids: [], repStops: 0, rep: null, shapeId: tr.shape_id }; groups.set(key, g); }
    g.tids.push(tid);
    if (st.length > g.repStops){ g.repStops = st.length; g.rep = tid; g.shapeId = tr.shape_id; }
  });
  const out = Array.from(groups.values());
  out.sort(function(a,b){ return a.headsign.localeCompare(b.headsign, 'pl'); });
  LNC.map.set(lineId, out);
  return out;
}
function variantIdxForTrip(lineId, tid){
  if (tid == null) return 0;
  const vs = lineInfo(lineId);
  for (let i = 0; i < vs.length; i++)
    if (vs[i].tids.indexOf(String(tid)) >= 0) return i;
  return 0;
}

/* ===== bąbelek ===== */
let stopPopup = null;
function showStopPop(sid){
  const s = G.stops.get(sid);
  if (!s) return;
  if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  const html = '<div class="spb"><span class="spb-n">' + esc(s.name) + '</span>' +
    '<button class="spb-go" data-sid="' + esc(sid) + '" title="Otwórz przystanek"><svg class="ic"><use href="#i-arrow"/></svg></button></div>';
  stopPopup = L.popup({ closeButton:false, className:'stop-bubble', offset:[0,-8], autoPan:false })
    .setLatLng([s.lat, s.lon]).setContent(html).openOn(map);
}
document.addEventListener('click', function(e){
  const g = e.target.closest('.spb-go');
  if (g && g.dataset.sid){
    if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
    openRoute('stop', { stopId: g.dataset.sid, from: 'map' });
  }
});

/* ===== EKRAN TRASY ===== */
function openRoute(mode, opts){
  opts = opts || {};
  if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  focusLayer.clearLayers();
  dotLayer.clearLayers();
  if (mode === 'journey' && opts.journey === 'walk') mode = 'walk';
  const f = { mode: mode, from: (CUR === 'route' ? 'map' : CUR), tab: null,
    journey: (mode === 'journey') ? opts.journey : null,
    lineId: opts.lineId || null,
    varIdx: (opts.varIdx != null) ? opts.varIdx : 0,
    fromStop: opts.fromStop || null,
    stopId: opts.stopId || null,
    services: opts.services || null,
    tid: opts.tid || null,
    vid: opts.vid || null, _sc:false };
  if (mode === 'line') f.tab = opts.fromStop ? 'deps' : 'stops';
  if (mode === 'stop'){
    f.tab = 'dep';
    SDAY.cur = 'today';
    f._arr = new Map();
    (G.stopIndex.get(String(f.stopId)) || []).forEach(function(r){
      if (!f._arr.has(r[0])) f._arr.set(r[0], r[1]);
    });
  }
  ROUTE.stack.push(f);
  const rc = $('#route-content');
  if (rc){ rc._sk = new Map(); rc.innerHTML = ''; }
  renderRoute();
  go('route', true);
  drawRouteMap(f, true);
  refreshVisibility();
  if (ROUTE_SHEET && (mode === 'stop' || mode === 'vehicle')) ROUTE_SHEET.force(2);
  if (mode === 'journey' || mode === 'walk') setTimeout(refineWalksValhalla, 60);
}
function routeTitle(f){
  const t = $('#route-title');
  if (f.mode === 'journey'){
    const xt = f.journey.transfers === 0 ? 'bezpośrednio' : (f.journey.transfers + ' przesiadki');
    t.innerHTML = '<b>Połączenie</b><small>' + xt + ' · na miejscu ' + fmtT(f.journey.arrive) + '</small>';
  } else if (f.mode === 'walk'){
    t.innerHTML = '<b>Pieszo</b><small>' + fmtDist(PLUI.last ? PLANNER.havM([PLUI.last.a.lat, PLUI.last.a.lng], [PLUI.last.b.lat, PLUI.last.b.lng]) : 0) + '</small>';
  } else if (f.mode === 'line'){
    const r = G.routes.get(f.lineId);
    t.innerHTML = '<b>Linia ' + esc(r ? r.short : f.lineId) + '</b><small>' + esc(r ? r.long : '') + '</small>';
  } else if (f.mode === 'linedeps'){
    const r = G.routes.get(f.lineId);
    t.innerHTML = '<b>Linia ' + esc(r ? r.short : f.lineId) + ' · odjazdy</b><small>' + esc(stopName(f.stopId)) + '</small>';
  } else if (f.mode === 'trip'){
    const tr = G.trips.get(String(f.tid));
    const r = tr && G.routes.get(tr.route_id);
    t.innerHTML = '<b>Kurs ' + esc(r ? r.short : (tr ? tr.route_id : '?')) + '</b><small>' + esc(tr ? tr.headsign : '') + '</small>';
  } else if (f.mode === 'stop'){
    const s = G.stops.get(f.stopId);
    t.innerHTML = s ? '<b>' + esc(s.name) + '</b><small>przystanek ' + esc(s.code || s.id) + (s.zone ? ' · strefa ' + esc(s.zone) : '') + '</small>' : '<b>Przystanek</b>';
  } else {
    const v = S.vehicles.get(f.vid);
    t.innerHTML = v ? '<b>Linia ' + esc(v.lineName) + '</b><small>' + esc(v.trip ? v.trip.headsign : '') + '</small>' : '<b>Pojazd</b>';
  }
}
function renderRoute(){
  const f = routeActive();
  if (!f) return;
  routeTitle(f);
  const tabs = $('#route-tabs'), vars = $('#route-variants'), content = $('#route-content');
  let tabsHtml = '';
  if (f.mode === 'line'){
    if (f.fromStop) tabsHtml += '<button class="rtab' + (f.tab === 'deps' ? ' on' : '') + '" data-tab="deps">' + ic2('clock','i-clock',14) + 'Odjazdy</button>';
    tabsHtml += '<button class="rtab' + (f.tab === 'stops' ? ' on' : '') + '" data-tab="stops">' + ic2('pin','i-pin',14) + 'Przystanki</button>';
  } else if (f.mode === 'stop'){
    tabsHtml = '<button class="rtab' + (f.tab === 'dep' ? ' on' : '') + '" data-tab="dep">' + ic2('clock','i-clock',14) + 'Odjazdy</button>' +
               '<button class="rtab' + (f.tab === 'sch' ? ' on' : '') + '" data-tab="sch">' + ic2('bus','i-bus',14) + 'Linie</button>';
  }
  if (tabs._h !== tabsHtml){ tabs._h = tabsHtml; tabs.innerHTML = tabsHtml; }
  tabs.hidden = !tabsHtml;
  let varsHtml = '';
  let varsHidden = true;
  if (f.mode === 'line'){
    const vs = lineInfo(f.lineId);
    for (let i = 0; i < vs.length; i++){
      varsHtml += '<button class="vchip' + (i === f.varIdx ? ' on' : '') + '" data-var="' + i + '">' + esc(vs[i].headsign) + '<small>' + vs[i].tids.length + ' kurs.</small></button>';
    }
    varsHidden = !vs.length;
  }
  if (vars._h !== varsHtml){ vars._h = varsHtml; vars.innerHTML = varsHtml; }
  vars.hidden = varsHidden;
  syncChildren(content, contentEntries(f));
  registerLives(content);
  tickLive();
  if (f.mode === 'vehicle' && !f._sc){
    f._sc = true;
    requestAnimationFrame(function(){
      const nowEl = content.querySelector('li.now') || content.querySelector('li.end');
      if (nowEl) content.scrollTop = nowEl.offsetTop - content.clientHeight/2 + nowEl.offsetHeight/2;
    });
  }
}
function contentEntries(f){
  if (f.mode === 'journey') return journeyTimelineEntries(f);
  if (f.mode === 'walk') return walkTimelineEntries();
  if (f.mode === 'line') return (f.tab === 'deps') ? lineDepsEntries(f) : lineStopsEntries(f);
  if (f.mode === 'linedeps') return lineDepsOnlyEntries(f);
  if (f.mode === 'trip') return tripEntries(f);
  if (f.mode === 'stop'){
    const out = [];
    const showDaySel = (f.tab === 'sch') || (SDAY.cur !== 'today');
    if (showDaySel) out.push({ k:'day', h:daySelectorHtml() });
    return out.concat(stopContentEntries(f));
  }
  return vehicleEntries(f);
}
function walkTimelineEntries(){
  const PP = PLUI.last;
  if (!PP) return [{ k:'e', h:'<div class="empty">Brak danych.</div>' }];
  if (!PP.walk) PP.walk = {};
  const d = PLANNER.havM([PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]);
  const dur = (PP.walk.vDur != null) ? PP.walk.vDur : PLANNER.walkSec(d);
  const dist = (PP.walk.vDist != null) ? PP.walk.vDist : d;
  const foot = PP.walk.vCoords ? ' · chodniki' : '';
  return [{ k:'tl', h:'<div class="tl"></div>', sub: [
    { k:'a', h:'<div class="tl-row">' +
      '<div class="tl-rail"><span class="tl-dot" style="background:var(--ok);border-color:var(--ok)">' + ic2('target','i-target',17) + '</span></div>' +
      '<div class="tl-main"><b>Start</b><small>' + esc(PP.a.label || '') + '</small></div></div>' },
    { k:'w', h:'<div class="tl-row"><div class="tl-rail"><span class="tl-dot">' + ic2('walk','i-walk',17) + '</span></div>' +
      '<div class="tl-main"><b>Pieszo · ' + fmtDist(dist) + '</b><small id="walk-dur">~' + fmtDur(dur) + foot + '</small></div></div>' },
    { k:'b', h:'<div class="tl-row"><div class="tl-rail"><span class="tl-dot" style="background:var(--accent);border-color:var(--accent)">' + ic2('target','i-target',17) + '</span></div>' +
      '<div class="tl-main"><b>Cel</b><small>' + esc(PP.b.label || '') + '</small></div></div>' }
  ] }];
}
function journeyTimelineEntries(f){
  const j = f.journey;
  const ds0 = dayStartUnix();
  let rideNo = 0;
  const rows = [];
  const PP = PLUI.last;
  const out = [];
  if (TRACK.j === j){
    if (TRACK.miss){
      let ah = '';
      if (TRACK.alt){
        const names = [];
        for (let q = 0; q < TRACK.alt.legs.length; q++)
          if (TRACK.alt.legs[q].type === 'ride') names.push(lineShortOf(TRACK.alt.legs[q].routeId));
        ah = '<div class="jr-alt"><span>najszybsza alternatywa: <b>' + esc(names.join(' → ')) +
             '</b> · na miejscu ' + fmtT(TRACK.alt.arrive) + '</span><button data-alt="1">szczegóły</button></div>';
      } else ah = '<div class="jr-alt"><span>szukam alternatywy…</span></div>';
      out.push({ k:'trk', h:'<div class="jr-warn"><b>⚠ ' + esc(TRACK.miss) + '</b>' + ah + '</div>' });
    } else {
      out.push({ k:'trk', h:'<div class="jr-ok"><i></i>Monitoruję tę podróż na żywo — dam znać, gdy coś się zestka</div>' });
    }
  }
  function row(k, rail, main, time, sub){
    return { k:k, h:'<div class="tl-row' + (sub ? ' tl-sub' : '') + '"' + (sub ? ' data-sid="' + sub + '"' : '') + '">' +
      '<div class="tl-rail">' + rail + '</div>' +
      '<div class="tl-main">' + main + '</div>' +
      '<div class="tl-time">' + time + '</div></div>' };
  }
  rows.push(row('a',
    '<span class="tl-dot" style="background:var(--ok);border-color:var(--ok)">' + ic2('target','i-target',17) + '</span>',
    '<b>Start</b>' + (PP && PP.a && PP.a.label ? '<small>' + esc(PP.a.label) + '</small>' : ''),
    '<b>' + fmtT(PP ? PP.depSec : 0) + '</b>'
  ));
  for (let i = 0; i < j.legs.length; i++){
    const leg = j.legs[i];
    if (leg.type === 'walk'){
      rows.push(row('w' + i,
        '<span class="tl-dot">' + ic2('walk','i-walk',17) + '</span>',
        '<b>Przejdź · ' + fmtDist(leg.vDist != null ? leg.vDist : leg.dist) + '</b><small>~' + fmtDur(leg.vDur || leg.sec) + (leg.vCoords ? ' · chodniki' : '') + '</small>',
        '<b>~' + fmtDur(leg.vDur || leg.sec) + '</b>'
      ));
    } else {
      const r = G.routes.get(leg.routeId);
      const lineShort = r ? r.short : leg.routeId;
      const color = legColor(rideNo); rideNo++;
      rows.push(row('b' + i,
        '<span class="tl-dot" style="background:' + color + ';border-color:' + color + '"><b>' + esc(lineShort) + '</b></span>',
        '<b>Wsiądź · linia ' + esc(lineShort) + '</b><small>' + esc(leg.headsign || '') + '</small>',
        timeCell(null, ds0 + leg.depS, null, '')
      ));
      const tRows = tripRowsLive(leg.tid) || [];
      for (let k = leg.boardIdx + 1; k < leg.alightIdx && k < tRows.length; k++){
        const w = tRows[k];
        if (!w) continue;
        rows.push(row('m' + i + '_' + w.seq, '<span class="tl-sdot"></span>',
          '<b>' + esc(stopName(w.sid)) + '</b>',
          timeCell(w.depL, ds0 + w.dep, w.delay, ''), w.sid));
      }
      const al = tRows[leg.alightIdx];
      rows.push(row('e' + i,
        '<span class="tl-dot">' + ic2('pin','i-pin',17) + '</span>',
        '<b>Wysiądź · ' + esc(stopName(leg.alightSid)) + '</b>',
        al ? timeCell(al.depL, ds0 + al.dep, al.delay, '') : '<b>' + fmtT(leg.arr) + '</b>'
      ));
      const nx = j.legs[i + 1];
      if (nx && nx.type === 'ride'){
        const wait = Math.max(0, nx.dep - leg.arr);
        rows.push(row('t' + i,
          '<span class="tl-dot">' + ic2('refresh','i-refresh',17) + '</span>',
          '<b>Przesiadka</b><small>oczekiwanie ' + fmtDur(wait) + '</small>',
          '<b>' + fmtDur(wait) + '</b>'
        ));
      }
    }
  }
  rows.push(row('z',
    '<span class="tl-dot" style="background:var(--accent);border-color:var(--accent)">' + ic2('target','i-target',17) + '</span>',
    '<b>Cel</b>' + (PP && PP.b && PP.b.label ? '<small>' + esc(PP.b.label) + '</small>' : ''),
    '<b>' + fmtT(j.arrive) + '</b>'
  ));
  out.push({ k:'tl', h:'<div class="tl"></div>', sub: rows });
  out.push({ k:'acts', h:'<div class="rs-acts"><button id="rt-ride"' + (TRACK.j === j ? ' class="on"' : '') + '>' +
    ic2('gps','i-gps') + (TRACK.j === j ? 'Monitorowanie aktywne' : 'Jadę — monitoruj') + '</button></div>' });
  return out;
}
function depListRow(d, pfx, useLive){
  const route = d.trip ? G.routes.get(d.trip.route_id) : null;
  const line = route ? route.short : (d.trip ? d.trip.route_id : '·');
  const head = d.trip ? (d.trip.headsign || '—') : '—';
  const vid = (useLive && d.rt) ? (S.tripVeh.get(d.tid) || null) : null;
  return '<li data-trip="' + esc(d.tid) + '"' + (vid ? ' data-veh="' + esc(vid) + '"' : '') + '>' +
    '<span class="bl">' + esc(line) + '</span>' +
    '<span class="bd">' + esc(head) + '</span>' +
    '<span class="sep"></span>' +
    timeCell((useLive && d.rt) ? d.est : null, d.depUnix, (useLive && d.rt) ? d.delay : null, pfx) + '</li>';
}
function stopDepartures(stopId, services, useLive){
  const act = services || activeServices(feedDateStr());
  const ds0 = dayStartUnix();
  const now = clockNow();
  const deps = [];
  const list = G.stopIndex.get(String(stopId)) || [];
  for (let i = 0; i < list.length; i++){
    const tid = list[i][0], seq = list[i][1], dep = list[i][2], pu = list[i][3];
    if (pu === 1) continue;
    const trip = G.trips.get(tid);
    if (!trip) continue;
    if (act && !act.has(trip.service_id)) continue;
    const depUnix = ds0 + dep;
    let est = depUnix, rt = false, delay = null;
    if (useLive){
      if (depUnix < now - 150) continue;
      const tu = S.tu.get(tid);
      if (tu){
        rt = true;
        const lr = liveRowFor(tid, seq);
        if (lr){ if (lr.depL != null) est = lr.depL; delay = lr.delay; }
        else if (tu.delay != null){ est = depUnix + tu.delay; delay = tu.delay; }
      }
      if (est < now - 150) continue;
    }
    deps.push({ tid: tid, depUnix: depUnix, est: est, rt: rt, delay: delay, trip: trip });
  }
  deps.sort(function(a,b){ return a.est - b.est; });
  return deps;
}
function stopContentEntries(f){
  return (f.tab === 'sch') ? stopLinesTilesEntries(f.stopId) : stopDepsEntries(f.stopId);
}
function stopDepsEntries(sid){
  const p = curProfile();
  const all = stopDepartures(sid, p.services, p.live);
  BOARD.deps = all;
  const deps = all.slice(0, BOARD.limit);
  if (!deps.length) return [{ k:'e', h:'<div class="empty">Brak odjazdów dla tego dnia.</div>' }];
  const out = [{ k:'board', h:'<ul class="board"></ul>',
    sub: deps.map(function(d){ return { k:'d' + d.tid, h:depListRow(d, 'bd' + d.tid + '_', p.live) }; }) }];
  if (BOARD.limit < all.length)
    out.push({ k:'more', h:'<div class="loadmore">przewiń — więcej (' + (all.length - BOARD.limit) + ')</div>' });
  return out;
}
function stopLinesTilesEntries(sid){
  const p = curProfile();
  const all = stopDepartures(sid, p.services, p.live);
  const byRoute = new Map();
  for (let i = 0; i < all.length; i++){
    const d = all[i];
    const rid = d.trip ? d.trip.route_id : '?';
    let o = byRoute.get(rid);
    if (!o) byRoute.set(rid, { routeId: rid, next: d.est, delay: d.delay, tid: d.tid, rt: d.rt });
    else if (d.est < o.next){ o.next = d.est; o.delay = d.delay; o.tid = d.tid; o.rt = d.rt; }
  }
  const arr = Array.from(byRoute.values());
  arr.sort(function(a,b){
    const ra = G.routes.get(a.routeId), rb = G.routes.get(b.routeId);
    return natCmp(ra ? ra.short : a.routeId, rb ? rb.short : b.routeId);
  });
  if (!arr.length) return [{ k:'e', h:'<div class="empty">Brak linii dla tego dnia.</div>' }];
  return [{ k:'grid', h:'<div class="tgrid"></div>',
    sub: arr.map(function(o){
      const r = G.routes.get(o.routeId);
      return { k:'t' + o.routeId,
        h:'<div class="tile" data-line="' + esc(o.routeId) + '" data-trip="' + esc(o.tid || '') + '">' +
        '<div class="tile-ln">' + esc(r ? r.short : o.routeId) + '</div>' +
        '<div class="tile-t">' + timeCell((p.live && o.rt) ? o.next : null, o.next, (p.live && o.rt) ? o.delay : null, 'sl' + o.routeId + '_') + '</div></div>' };
    }) }];
}
function lineDepsEntries(f){
  const now = clockNow(), ds0 = dayStartUnix();
  const out = [];
  const list = G.stopIndex.get(String(f.fromStop)) || [];
  ensureActive();
  for (let i = 0; i < list.length; i++){
    const tid = list[i][0], seq = list[i][1], dep = list[i][2], pu = list[i][3];
    if (pu === 1) continue;
    const tr = G.trips.get(tid);
    if (!tr || tr.route_id !== f.lineId) continue;
    if (S.activeCache && !S.activeCache.has(tr.service_id)) continue;
    let est = ds0 + dep, rt = false, delay = null;
    const tu = S.tu.get(tid);
    if (tu){
      rt = true;
      const lr = liveRowFor(tid, seq);
      if (lr){ if (lr.depL != null) est = lr.depL; delay = lr.delay; }
      else if (tu.delay != null){ est = ds0 + dep + tu.delay; delay = tu.delay; }
    }
    if (est < now - 150) continue;
    out.push({ tid: tid, est: est, depUnix: ds0 + dep, rt: rt, delay: delay, trip: tr });
  }
  out.sort(function(a,b){ return a.est - b.est; });
  if (!out.length) return [{ k:'e', h:'<div class="empty">Brak odjazdów.</div>' }];
  return [{ k:'board', h:'<ul class="board"></ul>',
    sub: out.map(function(d){ return { k:'d' + d.tid, h:depListRow(d, 'ld' + d.tid + '_', true) }; }) }];
}
function lineDepsOnlyEntries(f){
  const all = stopDepartures(f.stopId, f.services, false)
    .filter(function(d){ return d.trip && d.trip.route_id === f.lineId; });
  if (!all.length) return [{ k:'e', h:'<div class="empty">Brak odjazdów tej linii w wybranym dniu.</div>' }];
  return [{ k:'board', h:'<ul class="board"></ul>',
    sub: all.map(function(d){ return { k:'d' + d.tid, h:depListRow(d, 'lo' + d.tid + '_', false) }; }) }];
}
function lineStopsEntries(f){
  const vs = lineInfo(f.lineId);
  const v = vs[f.varIdx];
  if (!v) return [{ k:'e', h:'<div class="empty">Brak wariantów dziś.</div>' }];
  const rows = tripRowsLive(v.rep) || [];
  const ds0 = dayStartUnix();
  return [{ k:'stops', h:'<ol class="rs-stops"></ol>',
    sub: rows.map(function(w, i){
      return { k:'s' + w.seq, h:'<li data-sid="' + esc(w.sid) + '">' +
        railSvg({ first: i===0, last: i===rows.length-1, end: false }) +
        '<span class="n">' + esc(stopName(w.sid)) + '</span>' +
        timeCell(w.depL, ds0 + w.dep, w.delay, 'ls' + w.seq + '_') + '</li>' };
    }) }];
}
function vehicleEntries(f){
  const v = S.vehicles.get(f.vid);
  if (!v) return [{ k:'e', h:'<div class="empty">Pojazd już niedostępny.</div>' }];
  const n = v.n;
  const rows = (n.tripId != null) ? tripRowsLive(String(n.tripId)) : null;
  const curSeq = n.seq || 0;
  let delay = null;
  if (rows){
    for (let i = 0; i < rows.length; i++) if (rows[i].seq >= curSeq){ delay = rows[i].delay; break; }
    if (delay == null && rows.length) delay = rows[rows.length-1].delay;
  }
  const spd = (n.speed != null) ? Math.round(n.speed * 3.6) : null;
  const occ = (n.occupancy != null && OCC_TXT[n.occupancy]) ? OCC_TXT[n.occupancy] : null;
  const stTxt = (n.status != null && STATUS_TXT[n.status]) ? STATUS_TXT[n.status] : '';
  const out = [];
  out.push({ k:'card', h:'<div class="rs-card"><span class="ln-sm">' + esc(v.lineName) + '</span>' +
    '<div><b>' + esc(v.trip ? v.trip.headsign : 'Kurs') + '</b>' +
    '<small>' + esc([n.plate ? 'tab. ' + n.plate : '', n.label ? 'tabor ' + n.label : ''].filter(Boolean).join(' · ') || '—') + '</small>' +
    '<small>' + esc([stTxt, spd != null ? '~' + spd + ' km/h' : '', occ].filter(Boolean).join(' · ')) + '</small></div></div>' });
  if (delay != null) out.push({ k:'dly', h:'<div style="padding:0 2px 8px">' + dlyTag(delay) + '</div>' });
  if (rows){
    const ds0 = dayStartUnix();
    out.push({ k:'stops', h:'<ol class="rs-stops"></ol>',
      sub: rows.map(function(w, i){
        const passed = (curSeq > 0 && w.seq < curSeq);
        return { k:'s' + w.seq,
          h:'<li class="' + (w.seq === curSeq ? 'now' : '') + (passed ? ' passed' : '') + '" data-sid="' + esc(w.sid) + '">' +
          railSvg({ first: i===0, last: i===rows.length-1, now: w.seq === curSeq, passed: passed }) +
          '<span class="n">' + esc(stopName(w.sid)) + '</span>' +
          (!passed ? timeCell(w.depL, ds0 + w.dep, w.delay, 'vs' + w.seq + '_')
                   : '<span class="mcol"><span class="mclock">' + fmtUnix(w.depL != null ? w.depL : ds0 + w.dep) + '</span></span>') + '</li>' };
      }) });
  } else {
    out.push({ k:'nor', h:'<div class="empty">Brak kursu w GTFS — tylko dane live.</div>' });
  }
  out.push({ k:'acts', h:'<div class="rs-acts"><button id="rt-line">' + ic2('bus','i-bus') + 'Pokaż linię</button></div>' });
  return out;
}
function tripEntries(f){
  const tr = G.trips.get(String(f.tid));
  if (!tr) return [{ k:'e', h:'<div class="empty">Nieznany kurs.</div>' }];
  const raw = tripStops(String(f.tid));
  const rows = tripRowsLive(String(f.tid)) || [];
  const r = G.routes.get(tr.route_id);
  const lineShort = r ? r.short : tr.route_id;
  const vid = S.tripVeh.get(String(f.tid)) || null;
  const v = vid ? S.vehicles.get(vid) : null;
  let tIdx = -1;
  if (raw) for (let i = 0; i < raw.length; i++) if (String(raw[i][1]) === String(f.fromStop)) { tIdx = i; break; }
  const tRow = tIdx >= 0 ? rows[tIdx] : null;
  const ds0 = dayStartUnix();
  const delay = tRow ? tRow.delay : null;
  const curSeq = v ? (v.n.seq || 0) : 0;
  const out = [];
  out.push({ k:'card', h:'<div class="rs-card"><span class="ln-sm">' + esc(lineShort) + '</span>' +
    '<div><b>' + esc(tr.headsign || lineShort) + '</b>' +
    '<small>' + (tRow ? esc(stopName(f.fromStop)) : '') + '</small></div></div>' });
  if (delay != null) out.push({ k:'dly', h:'<div style="padding:0 2px 8px">' + dlyTag(delay) + '</div>' });
  out.push({ k:'stops', h:'<ol class="rs-stops"></ol>',
    sub: rows.map(function(w, i){
      const passed = v && w.seq < curSeq;
      const isTarget = (i === tIdx);
      return { k:'s' + w.seq,
        h:'<li class="' + (isTarget ? 'end' : '') + (v && w.seq === curSeq ? ' now' : '') + (passed ? ' passed' : '') + '" data-sid="' + esc(w.sid) + '">' +
        railSvg({ first: i===0, last: i===rows.length-1, now: v && w.seq === curSeq, passed: passed, end: isTarget }) +
        '<span class="n">' + esc(stopName(w.sid)) + (isTarget ? ' · Twój przystanek' : '') + '</span>' +
        (!passed ? timeCell(w.depL, ds0 + w.dep, w.delay, 'tp' + w.seq + '_')
                 : '<span class="mcol"><span class="mclock">' + fmtUnix(w.depL != null ? w.depL : ds0 + w.dep) + '</span></span>') + '</li>' };
    }) });
  out.push({ k:'acts', h:'<div class="rs-acts"><button id="rt-line">' + ic2('bus','i-bus') + 'Pokaż linię</button></div>' });
  return out;
}

/* ===== rysowanie mapy ===== */
function sheetH(){
  const sh = $('#route-sheet');
  return sh ? sh.getBoundingClientRect().height + 16 : 56;
}
function fitVisible(bounds, keepZoom){
  if (!bounds || !bounds.isValid()) return;
  if (keepZoom && map.getZoom() >= 13){ map.panTo(bounds.getCenter()); return; }
  map.fitBounds(bounds, { paddingTopLeft:[40,56], paddingBottomRight:[40, sheetH()], maxZoom: 14 });
}
function drawRouteMap(f, fit){
  focusLayer.clearLayers();
  dotLayer.clearLayers();
  let bounds = null;
  function addPt(p){ if (!bounds) bounds = L.latLngBounds([p]); else bounds.extend(p); }
  if (f.mode === 'walk'){
    const PP = PLUI.last;
    if (PP){
      if (!PP.walk) PP.walk = {};
      focusLayer.addLayer(L.marker([PP.a.lat, PP.a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
      focusLayer.addLayer(L.marker([PP.b.lat, PP.b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
      const coords = (PP.walk.vCoords && PP.walk.vCoords.length > 1) ? PP.walk.vCoords : [[PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]];
      focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color:'#98a2ad', weight:4, dashArray:'2 8' }));
      addPt([PP.a.lat, PP.a.lng]); addPt([PP.b.lat, PP.b.lng]);
      if (!PP.walk._v){
        PP.walk._v = true;
        PLANNER.valhallaWalk([[PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]]).then(function(v){
          if (v && v.coords && v.coords.length > 1 && routeActive() === f){
            PP.walk.vCoords = v.coords;
            PP.walk.vDist = v.dist;
            PP.walk.vDur = PLANNER.walkSec(v.dist || 0);
            drawRouteMap(f, false);
            renderRoute();
          }
        });
      }
    }
  } else if (f.mode === 'journey'){
    const PP = PLUI.last;
    if (PP){
      focusLayer.addLayer(L.marker([PP.a.lat, PP.a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
      focusLayer.addLayer(L.marker([PP.b.lat, PP.b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
      addPt([PP.a.lat, PP.a.lng]); addPt([PP.b.lat, PP.b.lng]);
    }
    const legs = f.journey.legs;
    let rideNo = 0;
    for (let i = 0; i < legs.length; i++){
      const leg = legs[i];
      if (leg.type === 'walk'){
        const fp = leg.fromPt ? [leg.fromPt.lat, leg.fromPt.lng] : stopPos(leg.fromSid);
        const tp = leg.toPt ? [leg.toPt.lat, leg.toPt.lng] : stopPos(leg.toSid);
        if (fp && tp){
          const coords = leg.vCoords && leg.vCoords.length > 1 ? leg.vCoords : [fp, tp];
          focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color:'#98a2ad', weight:4, dashArray:'2 8' }));
          addPt(fp); addPt(tp);
        }
      } else {
        const color = legColor(rideNo); rideNo++;
        const coords = rideCoordsOf(leg);
        if (coords && coords.length > 1){
          focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color: color, weight: 5, opacity:.95 }));
          for (let c = 0; c < coords.length; c += 2) addPt(coords[c]);
        }
        const tr = G.trips.get(leg.tid);
        const bvid = tr && S.tripVeh.get(String(leg.tid));
        const bv = bvid ? S.vehicles.get(bvid) : null;
        const boardPt = stopPos(leg.boardSid);
        if (bv && boardPt && (bv.n.seq || 0) <= leg.boardIdx){
          let gcoords = null;
          if (tr && tr.shape_id) gcoords = shapeSlice(tr.shape_id, boardPt, [bv.cur.lat, bv.cur.lng]);
          if (!gcoords){
            gcoords = [[bv.cur.lat, bv.cur.lng]];
            const raw = tripStops(leg.tid) || [];
            let cIdx = 0;
            for (let k = 0; k < raw.length; k++) if (raw[k][0] <= (bv.n.seq || 0)) cIdx = k;
            for (let k = cIdx; k <= leg.boardIdx && k < raw.length; k++){
              const p = stopPos(raw[k][1]); if (p) gcoords.push(p);
            }
            gcoords.push(boardPt);
          }
          if (gcoords && gcoords.length > 1)
            focusLayer.addLayer(L.polyline(gcoords, { renderer: svgRenderer, color: BUS_GRAY_C, weight: 4, opacity: .9 }));
          const raw = tripStops(leg.tid) || [];
          let cIdx = 0;
          for (let k = 0; k < raw.length; k++) if (raw[k][0] <= (bv.n.seq || 0)) cIdx = k;
          for (let k = cIdx; k <= leg.boardIdx && k < raw.length; k++){
            const p = stopPos(raw[k][1]);
            if (p){
              const g = L.circleMarker(p, { renderer: svgRenderer, radius: 6, weight: 4,
                color: BUS_GRAY_C, fillColor: '#fff', fillOpacity: 1 });
              g.on('click', (function(sid){ return function(e){ L.DomEvent.stop(e); showStopPop(sid); }; })(String(raw[k][1])));
              dotLayer.addLayer(g); addPt(p);
            }
          }
        }
        const rows = tripStops(leg.tid);
        if (rows){
          for (let k = leg.boardIdx; k <= leg.alightIdx && k < rows.length; k++){
            const p = stopPos(rows[k][1]);
            if (p){
              const g = L.circleMarker(p, { renderer: svgRenderer, radius: 6, weight: 4,
                color: color, fillColor: '#fff', fillOpacity: 1 });
              g.on('click', (function(sid){ return function(e){ L.DomEvent.stop(e); showStopPop(sid); }; })(String(rows[k][1])));
              dotLayer.addLayer(g); addPt(p);
            }
          }
        }
      }
    }
  } else if (f.mode === 'line' || f.mode === 'linedeps'){
    const vs = lineInfo(f.lineId);
    const vr = vs[f.varIdx || 0];
    if (vr){
      const shp = shapePoints(vr.shapeId);
      if (shp){
        const ll = shp.map(function(p){ return [p[1], p[2]]; });
        focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .92 }));
        for (let i = 0; i < ll.length; i += 2) addPt(ll[i]);
      }
      const rows = tripStops(vr.rep);
      if (rows){
        for (let i = 0; i < rows.length; i++){
          const p = stopPos(rows[i][1]);
          if (p){
            const g = L.circleMarker(p, { renderer: svgRenderer, radius: 6, weight: 4,
              color: BUS_LINE_C, fillColor: '#fff', fillOpacity: 1 });
            g.on('click', (function(sid){ return function(e){ L.DomEvent.stop(e); showStopPop(sid); }; })(String(rows[i][1])));
            dotLayer.addLayer(g); addPt(p);
          }
        }
      }
    }
    if (f.stopId){
      const p = stopPos(f.stopId);
      if (p) focusLayer.addLayer(L.circleMarker(p, { renderer: svgRenderer,
        radius: 9, weight: 4, color: '#fff', fillColor: '#ff5c1a', fillOpacity: 1, interactive: false }));
    }
  } else if (f.mode === 'vehicle'){
    const v = S.vehicles.get(f.vid);
    if (v){
      const shp = shapePoints(v.trip && v.trip.shape_id);
      if (shp){
        const ll = shp.map(function(p){ return [p[1], p[2]]; });
        focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .9 }));
      }
      const rows = (v.n.tripId != null) ? tripStops(String(v.n.tripId)) : null;
      if (rows){
        for (let i = 0; i < rows.length; i++){
          const p = stopPos(rows[i][1]);
          if (p){
            const g = L.circleMarker(p, { renderer: svgRenderer, radius: 6, weight: 4,
              color: BUS_LINE_C, fillColor: '#fff', fillOpacity: 1 });
            g.on('click', (function(sid){ return function(e){ L.DomEvent.stop(e); showStopPop(sid); }; })(String(rows[i][1])));
            dotLayer.addLayer(g);
          }
        }
      }
      if (fit) map.setView([v.to.lat, v.to.lng], Math.max(map.getZoom(), 13));
    }
  } else if (f.mode === 'trip'){
    const tr = G.trips.get(String(f.tid));
    const raw = tripStops(String(f.tid)) || [];
    const shp = shapePoints(tr && tr.shape_id);
    if (shp){
      const ll = shp.map(function(p){ return [p[1], p[2]]; });
      focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .9 }));
      for (let i = 0; i < ll.length; i += 2) addPt(ll[i]);
    }
    let tIdx = -1;
    for (let i = 0; i < raw.length; i++) if (String(raw[i][1]) === String(f.fromStop)) { tIdx = i; break; }
    for (let i = 0; i < raw.length; i++){
      const p = stopPos(raw[i][1]);
      if (p){
        const g = L.circleMarker(p, { renderer: svgRenderer,
          radius: (i === tIdx) ? 8 : 6, weight: (i === tIdx) ? 4.5 : 4,
          color: (i === tIdx) ? '#ff5c1a' : BUS_LINE_C, fillColor: '#fff', fillOpacity: 1 });
        g.on('click', (function(sid){ return function(e){ L.DomEvent.stop(e); showStopPop(sid); }; })(String(raw[i][1])));
        dotLayer.addLayer(g); addPt(p);
      }
    }
  } else if (f.mode === 'stop'){
    const s = G.stops.get(f.stopId);
    if (s){
      focusLayer.addLayer(L.circleMarker([s.lat, s.lon], { renderer: svgRenderer,
        radius: 9, weight: 4, color: '#fff', fillColor: '#ff5c1a', fillOpacity: 1, interactive: false }));
      if (fit) map.setView([s.lat, s.lon], Math.max(map.getZoom(), 15));
    }
  }
  syncDotVis();
  if (fit && bounds && bounds.isValid()){
    if ((f.mode === 'journey' || f.mode === 'walk') && f.from === 'results'){
      map.fitBounds(bounds, { paddingTopLeft:[40,56], paddingBottomRight:[40, sheetH()], maxZoom: 15 });
    } else {
      fitVisible(bounds, true);
    }
  }
}
function rideCoordsOf(leg){
  const b = stopPos(leg.boardSid), a = stopPos(leg.alightSid);
  if (b && a){
    const trip = G.trips.get(leg.tid);
    if (trip && trip.shape_id){
      const s = shapeSlice(trip.shape_id, b, a);
      if (s) return s;
    }
  }
  const rows = tripStops(leg.tid);
  if (rows){
    const out = [];
    for (let i = leg.boardIdx; i <= leg.alightIdx; i++){
      const p = stopPos(rows[i][1]); if (p) out.push(p);
    }
    if (out.length > 1) return out;
  }
  return (b && a) ? [b, a] : null;
}
 $('#route-fitbtn').addEventListener('click', function(){
  const f = routeActive();
  if (f) drawRouteMap(f, true);
});
 $('#route-tabs').addEventListener('click', function(e){
  const b = e.target.closest('[data-tab]');
  const f = routeActive();
  if (b && f){ f.tab = b.dataset.tab; renderRoute(); refreshRouteHash(); }
});
 $('#route-variants').addEventListener('click', function(e){
  const b = e.target.closest('[data-var]');
  const f = routeActive();
  if (b && f){ f.varIdx = +b.dataset.var; renderRoute(); drawRouteMap(f, true); refreshRouteHash(); }
});
 $('#route-content').addEventListener('click', function(e){
  const f = routeActive();
  if (!f) return;
  const altBtn = e.target.closest('[data-alt]');
  if (altBtn && TRACK.alt){ openRoute('journey', { journey: TRACK.alt, from: 'route' }); return; }
  const dayBtn = e.target.closest('[data-day]');
  if (dayBtn){
    SDAY.cur = dayProfiles()[+dayBtn.dataset.day].key;
    BOARD.limit = 20;
    renderRoute();
    refreshRouteHash();
    return;
  }
  const tile = e.target.closest('.tile');
  if (tile){
    if (tile.dataset.trip && !tile.dataset.line){
      const tr = G.trips.get(tile.dataset.trip);
      if (tr) openRoute('trip', { tid: tile.dataset.trip, lineId: tr.route_id,
        fromStop: (f.fromStop || f.stopId) || null });
      return;
    }
    if (tile.dataset.line){
      const p = curProfile();
      if (p.live) openRoute('line', { lineId: tile.dataset.line,
        varIdx: variantIdxForTrip(tile.dataset.line, tile.dataset.trip || null),
        fromStop: f.stopId || f.fromStop || null, from: 'stop' });
      else openRoute('linedeps', { lineId: tile.dataset.line, stopId: f.stopId,
        services: p.services, from: 'stop' });
      return;
    }
  }
  const vehRow = e.target.closest('.veh-row');
  if (vehRow && vehRow.dataset.veh){ openRoute('vehicle', { vid: vehRow.dataset.veh }); return; }
  const li = e.target.closest('li[data-trip]');
  if (li){
    if (li.dataset.veh && S.vehicles.has(li.dataset.veh)){
      openRoute('vehicle', { vid: li.dataset.veh, from: 'route' });
      return;
    }
    const tr = G.trips.get(li.dataset.trip);
    if (tr) openRoute('trip', { tid: li.dataset.trip, lineId: tr.route_id,
      fromStop: (f.fromStop || f.stopId) || null });
    return;
  }
  const stopRow = e.target.closest('[data-sid]');
  if (stopRow){
    const p = stopPos(stopRow.dataset.sid);
    if (p) map.setView(p, Math.max(map.getZoom(), 15));
    showStopPop(stopRow.dataset.sid);
    return;
  }
  if (e.target.closest('#rt-ride')){
    if (f.mode === 'journey' && f.journey) toggleTripTrack(f.journey);
    return;
  }
  if (e.target.closest('#rt-line')){
    let lineId = null, tid = null;
    if (f.mode === 'vehicle'){ const v = S.vehicles.get(f.vid); lineId = v && v.routeId; tid = v && v.n.tripId; }
    else if (f.mode === 'trip'){ const tr = G.trips.get(String(f.tid)); lineId = tr && tr.route_id; tid = f.tid; }
    if (lineId) openRoute('line', { lineId: lineId, varIdx: variantIdxForTrip(lineId, tid), from: 'route' });
  }
});
 $('#route-content').addEventListener('scroll', function(){
  const f = routeActive();
  const el = $('#route-content');
  if (!f || f.mode !== 'stop' || f.tab !== 'dep') return;
  if (el.scrollTop + el.clientHeight > el.scrollHeight - 140){
    if (BOARD.limit < BOARD.deps.length){
      BOARD.limit += 20;
      renderRoute();
    }
  }
});

/* ===== sheety ===== */
function makeSheetDrag(sheet, grip, heightsFn, storeKey, onTap){
  function saveIdx(i){ try { localStorage.setItem(storeKey, String(i)); } catch (e){} }
  function apply(i, anim){
    idx = Math.max(0, Math.min(heightsFn().length - 1, i));
    if (!anim) sheet.classList.add('noanim');
    sheet.style.height = heightsFn()[idx] + 'px';
    if (!anim) requestAnimationFrame(function(){ sheet.classList.remove('noanim'); });
    saveIdx(idx);
  }
  let idx = 1;
  try { idx = Math.max(0, Math.min(heightsFn().length - 1, +(localStorage.getItem(storeKey) || 1))); } catch (e){}
  apply(idx, false);
  let sy = 0, sh = 0, drag = false, vy = 0, lastY = 0, lastT = 0, moved = false;
  grip.addEventListener('touchstart', function(e){
    drag = true; moved = false;
    sy = e.touches[0].clientY;
    sh = sheet.getBoundingClientRect().height;
    vy = 0; lastY = sy; lastT = Date.now();
    sheet.classList.add('noanim');
  }, { passive: true });
  grip.addEventListener('touchmove', function(e){
    if (!drag) return;
    const y = e.touches[0].clientY;
    if (Math.abs(y - sy) > 4) moved = true;
    let h = sh + (sy - y);
    const H = heightsFn();
    if (h < H[0]) h = H[0];
    if (h > H[H.length - 1]) h = H[H.length - 1];
    sheet.style.height = h + 'px';
    const t = Date.now();
    if (t > lastT) vy = (y - lastY) / (t - lastT);
    lastY = y; lastT = t;
  }, { passive: true });
  function end(){
    if (!drag) return;
    drag = false;
    sheet.classList.remove('noanim');
    const H = heightsFn();
    const cur = sheet.getBoundingClientRect().height;
    let ni = 0;
    if (vy > 0.7){ ni = 0; for (let i = 0; i < H.length; i++) if (H[i] < cur - 2) ni = i; }
    else if (vy < -0.7){ ni = H.length - 1; for (let i = H.length - 1; i >= 0; i--) if (H[i] > cur + 2) ni = i; }
    else { let bd = 1e9; for (let i = 0; i < H.length; i++){ const d = Math.abs(H[i] - cur); if (d < bd){ bd = d; ni = i; } } }
    apply(ni, true);
  }
  grip.addEventListener('touchend', end);
  grip.addEventListener('touchcancel', end);
  grip.addEventListener('click', function(){ if (!moved && onTap) onTap(apply, idx); });
  window.addEventListener('resize', function(){ apply(idx, false); });
  return {
    apply: apply,
    force: function(i){
      const H = heightsFn();
      const h = H[Math.max(0, Math.min(H.length - 1, i))];
      sheet.classList.add('noanim');
      sheet.style.height = h + 'px';
      requestAnimationFrame(function(){ sheet.classList.remove('noanim'); });
    },
    getIdx: function(){ return idx; }
  };
}
let routeLastOpen = 1;
const ROUTE_SHEET = makeSheetDrag($('#route-sheet'), $('#rs-grip'),
  function(){ return [44, Math.round(innerHeight * .20), Math.round(innerHeight * .45), Math.min(Math.round(innerHeight * .85), innerHeight - 60)]; },
  'ztm-sheet-route',
  function(apply, idx){
    if (idx === 0) apply(Math.max(1, routeLastOpen), true);
    else { routeLastOpen = idx; apply(0, true); }
  });
makeSheetDrag($('#home-sheet'), $('#hs-grip'),
  function(){ return [44, Math.round(innerHeight * .42)]; },
  'ztm-sheet-home',
  function(apply, idx){ apply(idx === 0 ? 1 : 0, true); });
makeSheetDrag($('#lines-sheet'), $('#ls-grip'),
  function(){ return [44, Math.round(innerHeight * .40)]; },
  'ztm-sheet-lines',
  function(apply, idx){ apply(idx === 0 ? 1 : 0, true); });

/* ===== nawigacja ===== */
const SCREENS = {};
['home','stops','results','settings'].forEach(function(n){
  const el = document.getElementById('scr-' + n);
  if (el) SCREENS[n] = el;
});
let CUR = 'home', PICK = null;
function go(name, keepSel, noPush){
  const prev = CUR;
  if (!keepSel){
    pointLayer.clearLayers();
    PICK = null; S.pickHide = false; $('#pick-banner').hidden = true;
  }
  if (prev === 'route' && name !== 'route'){
    ROUTE.stack.length = 0;
    focusLayer.clearLayers(); dotLayer.clearLayers();
    if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
    setTimeout(refreshVisibility, 60);
  }
  const isMap = (name === 'map' || name === 'route');
  document.body.classList.toggle('show-map', isMap);
  document.body.classList.toggle('on-route', name === 'route');
  for (const k in SCREENS) SCREENS[k].classList.toggle('on', k === name);
  CUR = name;
  closeAc();
  syncNav();
  if (isMap) setTimeout(function(){
    map.invalidateSize();
    refreshVisibility(); updateStopsVis();
    if (name === 'route') syncDotVis();
    firstFitMaybe();
  }, 60);
  if (name === 'stops') renderStopsList();
  if (!noPush){
    let hash = '#' + name;
    if (name === 'route'){ const q = routeHash(routeActive()); if (q) hash += '?' + q; }
    else if (name === 'results' && PLUI.last){ const q = resultsHash(); if (q) hash += '?' + q; }
    try { history.pushState((name === 'route') ? { ztm:'route', d: ROUTE.stack.length } : { ztm:name }, '', hash); } catch (e){}
  }
}
window.addEventListener('popstate', function(e){
  const st = e.state; const name = st && st.ztm;
  if (name === 'route'){
    if (CUR === 'route' && st.d != null){
      while (ROUTE.stack.length > Math.max(1, st.d)) ROUTE.stack.pop();
    }
    const f = routeActive();
    if (f){ go('route', true, true); renderRoute(); drawRouteMap(f, false); return; }
    go('map', true, true);
    return;
  }
  if (name && SCREENS[name]) go(name, true, true);
  else go('map', true, true);
});
function routeBack(){
  if (history.length > 1){ history.back(); return; }
  if (ROUTE.stack.length > 1){ ROUTE.stack.pop(); renderRoute(); drawRouteMap(routeActive(), true); return; }
  const f = ROUTE.stack[0];
  ROUTE.stack.length = 0;
  focusLayer.clearLayers(); dotLayer.clearLayers();
  go(f && f.from && SCREENS[f.from] ? f.from : 'map', true);
}
 $('#route-back').addEventListener('click', routeBack);
document.querySelectorAll('[data-back]').forEach(function(b){
  b.addEventListener('click', function(){
    if (history.length > 1) history.back();
    else go('map');
  });
});
function syncNav(){
  let active = null;
  if (CUR === 'home' || CUR === 'results' || CUR === 'settings') active = 'home';
  else if (CUR === 'map' || CUR === 'route') active = 'buses';
  else active = 'stops';
  document.querySelectorAll('#bottomnav [data-nav]').forEach(function(b){
    b.classList.toggle('on', b.dataset.nav === active);
  });
}
document.querySelectorAll('#bottomnav [data-nav]').forEach(function(b){
  b.addEventListener('click', function(){
    const w = b.dataset.nav;
    if (w === 'home') go('home');
    else if (w === 'buses') go('map');
    else go('stops');
  });
});
function firstFitMaybe(){
  if (S.firstFit || !S.vehicles.size || CUR !== 'map') return;
  S.firstFit = true;
  const pts = [];
  S.vehicles.forEach(function(v){ pts.push([v.to.lat, v.to.lng]); });
  const b = L.latLngBounds(pts);
  if (b.isValid()) map.fitBounds(b, { padding:[50,50], maxZoom:13 });
}
 $('#btn-fit').addEventListener('click', function(){
  const pts = [];
  S.vehicles.forEach(function(v){ if (v.onMap) pts.push([v.to.lat, v.to.lng]); });
  if (pts.length){ const b = L.latLngBounds(pts); if (b.isValid()) map.fitBounds(b, { padding:[50,50], maxZoom:13 }); }
  else map.setView([50.0413, 21.999], 13);
});

/* X-iki */
document.querySelectorAll('.clr-x').forEach(function(btn){
  btn.addEventListener('click', function(){
    const inp = document.getElementById(btn.dataset.clear);
    if (!inp) return;
    inp.value = '';
    inp.dispatchEvent(new Event('input', { bubbles:true }));
    inp.focus();
  });
});
['hp-a','hp-b','stops-q','map-search'].forEach(function(id){
  const inp = document.getElementById(id);
  if (!inp) return;
  const btn = document.querySelector('.clr-x[data-clear="' + id + '"]');
  if (!btn) return;
  function upd(){ btn.hidden = !((document.activeElement === inp) || !!inp.value); }
  inp.addEventListener('input', upd);
  inp.addEventListener('focus', upd);
  inp.addEventListener('blur', function(){ setTimeout(upd, 120); });
  upd();
});

/* autouzupełnianie */
function buildAC(){
  const seen = new Set();
  STOPS.sorted = [];
  for (let i = 0; i < stopsArray.length; i++){
    const s = stopsArray[i];
    if (seen.has(s.name)) continue;
    seen.add(s.name);
    STOPS.sorted.push({ name:s.name, tt:toks(s.name), sid:s.id, code:s.code });
  }
  STOPS.sorted.sort(function(a,b){ return a.name.localeCompare(b.name, 'pl'); });
}
function acQuery(q, limit){
  const qt = toks(q);
  if (!qt.length || !STOPS.sorted) return [];
  const out = [];
  for (let i = 0; i < STOPS.sorted.length; i++){
    const s = STOPS.sorted[i];
    const sc = matchScore(qt, s.tt);
    if (sc >= 0) out.push({ s: s, sc: sc });
    if (out.length >= 120) break;
  }
  out.sort(function(a,b){ return b.sc - a.sc || a.s.name.localeCompare(b.s.name, 'pl'); });
  return out.slice(0, limit).map(function(o){ return o.s; });
}
function closeAc(){
  ['#ac-a','#ac-b','#map-ac'].forEach(function(s){ const el = $(s); if (el) el.hidden = true; });
}
function attachAC(inputSel, panelSel, onPick, topHtmlFn){
  const inp = $(inputSel), panel = $(panelSel);
  if (!inp || !panel) return;
  function render(){
    const q = inp.value.trim();
    let html = '';
    if (!q && topHtmlFn) html = topHtmlFn();
    else if (q){
      const res = acQuery(q, 8);
      html = res.map(function(rr){
        return '<button class="ac-item" data-sid="' + esc(rr.sid) + '">' + ic2('pin','i-pin',15) + '<span>' + esc(rr.name) + '</span><small>' + esc(rr.code || '') + '</small></button>';
      }).join('') || '<div class="ac-empty">Brak przystanków</div>';
    }
    panel.innerHTML = html;
    panel.hidden = !html;
  }
  inp.addEventListener('input', render);
  inp.addEventListener('focus', render);
  panel.addEventListener('click', function(e){
    const b = e.target.closest('[data-sid]');
    if (!b) return;
    if (onPick(b.dataset.sid) !== false) panel.hidden = true;
  });
  document.addEventListener('click', function(e){
    if (e.target !== inp && !panel.contains(e.target)) panel.hidden = true;
  });
}

/* historia */
function recLoad(){
  try { const r = JSON.parse(localStorage.getItem('ztm-rec') || '{}');
    REC.routes = Array.isArray(r.routes) ? r.routes : [];
    REC.stops = Array.isArray(r.stops) ? r.stops : [];
  } catch (e){}
}
function recSave(){ try { localStorage.setItem('ztm-rec', JSON.stringify(REC)); } catch (e){} }
function recRouteAdd(a, b){
  const A = { l: a.label || 'start', sid: a.sid || null, lat: a.sid ? null : a.lat, lng: a.sid ? null : a.lng, gps: (!a.sid && a.lat == null) };
  const B = { l: b.label || 'cel', sid: b.sid || null, lat: b.sid ? null : b.lat, lng: b.sid ? null : b.lng };
  REC.routes = REC.routes.filter(function(rr){ return !(rr.a.l === A.l && rr.b.l === B.l); });
  REC.routes.unshift({ a: A, b: B });
  REC.routes = REC.routes.slice(0, 6);
  recSave();
  renderHomeHist();
}
function recStopAdd(sid){
  REC.stops = REC.stops.filter(function(s){ return s !== sid; });
  REC.stops.unshift(sid);
  REC.stops = REC.stops.slice(0, 6);
  recSave();
}
function renderHomeHist(){
  const b = $('#home-hist-body');
  if (!b) return;
  let h = '';
  if (REC.routes.length){
    h += '<div class="hs-sec">Trasy</div>';
    for (let i = 0; i < REC.routes.length; i++){
      const rr = REC.routes[i];
      h += '<button class="hs-route" data-r="' + i + '">' + ic2('arrow','i-arrow',15) + '<span><b>' + esc(rr.a.l) + '</b> → <b>' + esc(rr.b.l) + '</b></span></button>';
    }
  }
  const st = REC.stops.slice(0, 6).map(function(sid){ return G.stops.get(sid); }).filter(Boolean);
  if (st.length){
    h += '<div class="hs-sec">Przystanki</div><div class="hs-chips">';
    for (let i = 0; i < st.length; i++)
      h += '<button class="hchip" data-sid="' + esc(st[i].id) + '">' + esc(st[i].name) + '</button>';
    h += '</div>';
  }
  if (!h) h = '<div class="hs-empty">Historia pojawi się tutaj</div>';
  b.innerHTML = h;
}
function applyRecPoint(p, which){
  const inp = $(which === 'a' ? '#hp-a' : '#hp-b');
  if (p.gps){ PLUI[which] = null; inp.value = 'Moja lokalizacja'; return; }
  if (p.sid){
    const s = G.stops.get(p.sid);
    if (s){ PLUI[which] = null; inp.value = s.name; return; }
  }
  if (p.lat != null && p.lng != null){ PLUI[which] = { lat: p.lat, lng: p.lng }; inp.value = p.l; return; }
  inp.value = p.l || '';
}
document.addEventListener('click', function(e){
  const r = e.target.closest('#home-hist-body [data-r]');
  if (r){
    const rr = REC.routes[+r.dataset.r];
    if (rr){ applyRecPoint(rr.a, 'a'); applyRecPoint(rr.b, 'b'); }
    return;
  }
  const s = e.target.closest('#home-hist-body [data-sid]');
  if (s) openRoute('stop', { stopId: s.dataset.sid, from: 'stops' });
});

/* home / planer */
function setPick(which){
  PICK = which;
  S.pickHide = !!which;
  $('#pick-banner').hidden = !which;
  $('#pick-txt').textContent = which === 'a' ? 'Kliknij punkt STARTOWY (A)' : 'Kliknij punkt CELU (B)';
  refreshVisibility();
  updateStopsVis();
  if (which) go('map', true);
}
function setPlanPoint(which, lat, lng){
  PLUI[which] = { lat: lat, lng: lng };
  $(which === 'a' ? '#hp-a' : '#hp-b').value = 'Punkt z mapy (' + lat.toFixed(4) + ', ' + lng.toFixed(4) + ')';
  PICK = null; S.pickHide = false;
  $('#pick-banner').hidden = true;
  refreshVisibility();
  updateStopsVis();
  go('home', true);
}
 $('#pick-cancel').addEventListener('click', function(){
  PICK = null; S.pickHide = false;
  $('#pick-banner').hidden = true;
  refreshVisibility(); updateStopsVis();
  go('home', true);
});
 $('#hp-a-map').addEventListener('click', function(){ setPick('a'); });
 $('#hp-b-map').addEventListener('click', function(){ setPick('b'); });
 $('#hp-a-gps').addEventListener('click', function(){
  if (!GPS.on) toggleGps();
  else { PLUI.a = null; setGpsFieldText(); }
});
 $('#sp-walk').addEventListener('click', function(){
  PLANNER.setSpeed(5);
  $('#sp-walk').classList.add('on'); $('#sp-run').classList.remove('on');
});
 $('#sp-run').addEventListener('click', function(){
  PLANNER.setSpeed(10);
  $('#sp-run').classList.add('on'); $('#sp-walk').classList.remove('on');
});
(function(){
  const inp = $('#pl-time');
  if (!inp) return;
  ['change','input'].forEach(function(ev){
    inp.addEventListener(ev, function(){ PLUI.timeTouched = (inp.value !== ''); });
  });
})();
function resolvePoint(which){
  const inp = $(which === 'a' ? '#hp-a' : '#hp-b');
  const txt = (inp.value || '').trim();
  if (txt && txt.indexOf('Punkt z mapy') !== 0 && txt.indexOf('Moja lokalizacja') !== 0){
    const res = acQuery(txt, 1);
    if (res.length){
      const s = G.stops.get(res[0].sid);
      if (s) return { lat: s.lat, lng: s.lon, label: s.name, sid: s.id };
    }
  }
  if (PLUI[which]) return PLUI[which];
  if (which === 'a' && GPS.on && GPS.lat != null) return { lat: GPS.lat, lng: GPS.lng, label: 'moja lokalizacja' };
  return null;
}
 $('#hp-go').addEventListener('click', function(){
  const a = resolvePoint('a'), b = resolvePoint('b');
  if (!b){ toast('Ustaw cel (B)', true); return; }
  if (!a){ toast('Ustaw start: przystanek, mapa lub lokalizacja', true); return; }
  if (PLANNER.havM([a.lat, a.lng], [b.lat, b.lng]) < 30){ toast('A i B to to samo miejsce', true); return; }
  recRouteAdd(a, b);
  const dateStr = $('#pl-date').value || feedDateStr();
  const tv = ($('#pl-time').value || fmtUnix(Math.floor(clockNow()))).split(':');
  const depSec = ((+tv[0]) || 0) * 3600 + ((+tv[1]) || 0) * 60;
  const xfers = +$('#pl-xfer').value;
  PLUI.last = { a: a, b: b, depSec: depSec, dateStr: dateStr, xfers: xfers, res: null, busy: false, depUsed: depSec, timeTouched: PLUI.timeTouched };
  RES.limit = 6;
  go('results');
  const rb = $('#res-body');
  rb._sk = new Map(); rb.innerHTML = '<div class="empty">Szukam połączeń…</div>';
  runSearch(true);
});
function runSearch(forceNow){
  const L = PLUI.last;
  if (!L || L.busy) return;
  L.busy = true;
  setTimeout(function(){
    let dep = L.depSec;
    if (forceNow && !L.timeTouched && dep < clockNow() - dayStartUnix() - 60) dep = Math.floor(clockNow() - dayStartUnix());
    const nowDay = (dep >= clockNow() - dayStartUnix() - 60) ? Math.floor(clockNow() - dayStartUnix()) : null;
    try {
      const prevJ = (L.res && L.res.journeys) ? L.res.journeys : null;
      const res = PLANNER.plan(L.a.lat, L.a.lng, L.b.lat, L.b.lng, dep, L.dateStr, L.xfers, nowDay);
      L.res = res;
      L.depUsed = dep;
      renderResults();
      if (PENDING.j && CUR === 'results'){
        const want = PENDING.j; PENDING.j = null;
        if (want === 'walk'){ if (res.walk) openRoute('walk', { from: 'results' }); }
        else {
          const live = filterLiveJourneys();
          for (let i = 0; i < live.length; i++)
            if (live[i].sig === want){ openRoute('journey', { journey: live[i], from: 'results' }); break; }
        }
      }
      const fr = routeActive();
      if (fr && fr.mode === 'journey' && fr.journey && res.journeys){
        const key = journeyKeyOf(fr.journey);
        let nj = null, oj = null;
        for (let i = 0; i < res.journeys.length; i++) if (journeyKeyOf(res.journeys[i]) === key){ nj = res.journeys[i]; break; }
        if (prevJ) for (let i = 0; i < prevJ.length; i++) if (journeyKeyOf(prevJ[i]) === key){ oj = prevJ[i]; break; }
        if (oj && nj) oj.legs.forEach(function(ol){
          if (ol.type !== 'walk' || !ol.vCoords) return;
          nj.legs.forEach(function(nl){
            if (nl.type === 'walk' && nl.fromSid === ol.fromSid && nl.toSid === ol.toSid && !nl.vCoords){
              nl.vCoords = ol.vCoords; nl.vDur = ol.vDur; nl.vDist = ol.vDist;
            }
          });
        });
        if (nj){ fr.journey = nj; renderRoute(); }
      }
      if (TRACK.j && res.journeys){
        for (let i = 0; i < res.journeys.length; i++)
          if (res.journeys[i].sig === TRACK.j.sig){ TRACK.j = res.journeys[i]; break; }
      }
      refineWalksValhalla();
    } catch (err){
      PENDING.j = null;
      if (CUR === 'results' && !L.res) $('#res-body').innerHTML = '<div class="empty">Błąd planera: ' + esc((err && err.message) || err) + '</div>';
    }
    L.busy = false;
  }, 30);
}
setInterval(function(){
  if (CUR === 'results' && PLUI.last && PLUI.last.res && !PLUI.last.busy) runSearch(true);
}, 10000);

/* ===== VALHALLA ===== */
const VALC = new Map();
const VALH = { q:[], busy:false, fails:0, deadUntil:0, lastAt:0, GAP:1200, warned:false };
function decodeValhallaPolyline(str){
  let index = 0, lat = 0, lon = 0;
  const coordinates = [];
  while (index < str.length){
    let result = 0, shift = 0, byte;
    do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
    lat += (result & 1) ? ~(result >> 1) : (result >> 1);
    result = 0; shift = 0;
    do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
    lon += (result & 1) ? ~(result >> 1) : (result >> 1);
    coordinates.push([lat / 1000000, lon / 1000000]);
  }
  return coordinates;
}
function valhallaPush(job){ VALH.q.push(job); valhallaPump(); }
function valhallaPump(){
  if (VALH.busy || !VALH.q.length) return;
  const wait = Math.max(0, VALH.lastAt + VALH.GAP - Date.now());
  setTimeout(function(){
    if (!VALH.q.length) return;
    if (Date.now() < VALH.deadUntil){
      while (VALH.q.length) VALH.q.shift().resolve(null);
      return;
    }
    VALH.busy = true;
    valhallaRun(VALH.q.shift());
  }, wait);
}
async function valhallaRun(job){
  VALH.lastAt = Date.now();
  const urls = ['https://valhalla1.openstreetmap.de/route', 'https://valhalla2.openstreetmap.de/route'];
  let out = null;
  for (let u = 0; u < urls.length && !out; u++){
    try {
      const ctl = new AbortController();
      const to = setTimeout(function(){ ctl.abort(); }, 8000);
      let res;
      try { res = await fetch(urls[u], { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(job.body), signal: ctl.signal }); }
      finally { clearTimeout(to); }
      if (!res.ok) continue;
      const data = await res.json();
      if (data.trip && data.trip.legs && data.trip.legs.length){
        const coords = decodeValhallaPolyline(data.trip.legs[0].shape);
        if (coords && coords.length > 1){
          const distKm = (data.trip.summary && data.trip.summary.length) ? data.trip.summary.length : 0;
          out = { coords: coords, dist: distKm * 1000, dur: PLANNER.walkSec(distKm * 1000) };
        }
      }
    } catch (e){}
  }
  if (out){ VALH.fails = 0; VALH.warned = false; }
  else {
    VALH.fails++;
    if (VALH.fails >= 3){
      VALH.deadUntil = Date.now() + 600000;
      if (!VALH.warned){ VALH.warned = true; toast('Valhalla (trasy piesze) chwilowo niedostępne — przez 10 min liczę w linii prostej', true); }
    }
  }
  VALC.set(job.key, out);
  job.resolve(out);
  VALH.busy = false;
  valhallaPump();
}
PLANNER.valhallaWalk = function(pts){
  return new Promise(function(resolve){
    if (!pts || pts.length < 2 || !pts[0] || !pts[1]) { resolve(null); return; }
    const key = pts[0][0].toFixed(5) + ',' + pts[0][1].toFixed(5) + '|' + pts[1][0].toFixed(5) + ',' + pts[1][1].toFixed(5);
    if (VALC.has(key)){ resolve(VALC.get(key)); return; }
    if (Date.now() < VALH.deadUntil){ VALC.set(key, null); resolve(null); return; }
    valhallaPush({
      key: key,
      body: { locations: [ { lat: pts[0][0], lon: pts[0][1], type: 'break' },
                           { lat: pts[1][0], lon: pts[1][1], type: 'break' } ],
              costing: 'pedestrian', units: 'kilometers',
              directions_options: { units: 'kilometers' } },
      resolve: resolve
    });
  });
};
let VALH_GEN = 0;
function refineWalksValhalla(){
  const L = PLUI.last;
  if (!L || !L.res) return;
  const f = routeActive();
  const jobs = [];
  if (f && f.mode === 'walk' && L.res.walk && !L.res.walk.vCoords) jobs.push({ walkMain: true });
  else if (f && f.mode === 'journey' && f.journey){
    f.journey.legs.forEach(function(leg){
      if (leg.type === 'walk' && !leg.vCoords) jobs.push({ leg: leg });
    });
  }
  if (!jobs.length) return;
  const gen = ++VALH_GEN;
  let done = 0;
  jobs.forEach(function(job){
    const fp = job.walkMain ? [L.a.lat, L.a.lng] : (job.leg.fromPt ? [job.leg.fromPt.lat, job.leg.fromPt.lng] : stopPos(job.leg.fromSid));
    const tp = job.walkMain ? [L.b.lat, L.b.lng] : (job.leg.toPt ? [job.leg.toPt.lat, job.leg.toPt.lng] : stopPos(job.leg.toSid));
    if (!fp || !tp){ finish(); return; }
    PLANNER.valhallaWalk([fp, tp]).then(function(v){
      if (gen === VALH_GEN && v && v.coords && v.dist != null){
        if (job.walkMain){ L.res.walk.vCoords = v.coords; L.res.walk.vDist = v.dist; L.res.walk.vDur = PLANNER.walkSec(v.dist); }
        else { job.leg.vCoords = v.coords; job.leg.vDur = PLANNER.walkSec(v.dist); job.leg.vDist = v.dist; }
      }
      finish();
    });
  });
  function finish(){
    done++;
    if (done >= jobs.length && gen === VALH_GEN){
      if (CUR === 'results') renderResults();
      const fr = routeActive();
      if (fr && (fr.mode === 'journey' || fr.mode === 'walk')){ renderRoute(); drawRouteMap(fr, false); }
    }
  }
}

/* ===== MONITORING PODRÓŻY ===== */
function toggleTripTrack(j){
  if (TRACK.j === j){ TRACK.j = null; TRACK.miss = null; TRACK.alt = null; renderRoute(); return; }
  TRACK.j = j; TRACK.miss = null; TRACK.alt = null;
  toast('Monitoruję podróż — sprawdzam kursy i przesiadki na żywo');
  tripTick();
  renderRoute();
}
function trackEffDep(leg){
  const rows = tripRowsLive(String(leg.tid));
  const lr = liveRowBySeq(rows, leg.boardIdx);
  return (lr && lr.depL != null) ? lr.depL : (dayStartUnix() + leg.depS);
}
function trackEffArr(leg){
  const rows = tripRowsLive(String(leg.tid));
  const lr = liveRowBySeq(rows, leg.alightIdx);
  return (lr && lr.depL != null) ? lr.depL : (dayStartUnix() + leg.arrS);
}
function tripTick(){
  if (!TRACK.j || !PLUI.last) return;
  const j = TRACK.j;
  const now = clockNow();
  const rides = [];
  for (let i = 0; i < j.legs.length; i++) if (j.legs[i].type === 'ride') rides.push(j.legs[i]);
  if (!rides.length){ TRACK.j = null; return; }
  let miss = null;
  const r0 = rides[0];
  const vid0 = S.tripVeh.get(String(r0.tid));
  const v0 = vid0 ? S.vehicles.get(vid0) : null;
  if (v0 && (v0.n.seq || 0) > r0.boardIdx + 1){
    const near = (GPS.lat != null) &&
      (PLANNER.havM([GPS.lat, GPS.lng], [v0.cur.lat, v0.cur.lng]) < 150);
    if (!near) miss = 'Kurs linii ' + lineShortOf(r0.routeId) + ' odjechał bez Ciebie';
  } else if (GPS.lat != null && GPS.lng != null){
    const bp = stopPos(r0.boardSid);
    if (bp){
      const walkS = PLANNER.walkSec(PLANNER.havM([GPS.lat, GPS.lng], bp));
      const depEff = trackEffDep(r0);
      if (now + walkS > depEff + 90)
        miss = 'Nie zdążysz na kurs ' + lineShortOf(r0.routeId) + ' (odj. ' + fmtUnix(depEff) + ')';
    }
  }
  if (!miss){
    for (let i = 1; i < rides.length && !miss; i++){
      const a = trackEffArr(rides[i-1]);
      const b = trackEffDep(rides[i]);
      if (b < a + 45)
        miss = 'Przesiadka na ' + lineShortOf(rides[i].routeId) + ' odpada (odj. ' + fmtUnix(b) + ')';
    }
  }
  if (miss && TRACK.miss !== miss){
    TRACK.miss = miss;
    toast('⚠ ' + miss + ' — szukam alternatywy…', true);
    findTrackAlternative();
    renderRoute();
  } else if (!miss && TRACK.miss){
    TRACK.miss = null; TRACK.alt = null; renderRoute();
  }
}
function findTrackAlternative(){
  const L = PLUI.last;
  if (!L) return;
  let from = null;
  if (GPS.lat != null && GPS.lng != null) from = { lat: GPS.lat, lng: GPS.lng };
  else {
    let sid = null;
    if (TRACK.j){
      for (let i = 0; i < TRACK.j.legs.length; i++)
        if (TRACK.j.legs[i].type === 'ride'){ sid = TRACK.j.legs[i].boardSid; break; }
    }
    const p = sid ? stopPos(sid) : null;
    if (p) from = { lat: p[0], lng: p[1] };
    else from = { lat: L.a.lat, lng: L.a.lng };
  }
  const nowDay = Math.floor(clockNow() - dayStartUnix());
  try {
    const res = PLANNER.plan(from.lat, from.lng, L.b.lat, L.b.lng, nowDay, L.dateStr, L.xfers, nowDay);
    TRACK.alt = (res && res.journeys && res.journeys[0]) || null;
    if (TRACK.alt) toast('Alternatywa: ' + (function(){
      const n = [];
      for (let i = 0; i < TRACK.alt.legs.length; i++)
        if (TRACK.alt.legs[i].type === 'ride') n.push(lineShortOf(TRACK.alt.legs[i].routeId));
      return n.join(' → ') + ' · na miejscu ' + fmtT(TRACK.alt.arrive);
    })());
  } catch (e){ TRACK.alt = null; }
  renderRoute();
}

/* ===== DEEP LINKI ===== */
function encPoint(p){
  if (!p) return '';
  if (p.gps || (p.lat == null && p.lng == null)) return 'gps';
  if (p.sid) return 's:' + encodeURIComponent(p.sid);
  return p.lat.toFixed(6) + ',' + p.lng.toFixed(6) + ',' + encodeURIComponent(p.label || '');
}
function decPoint(v){
  if (!v) return null;
  if (v === 'gps') return { gps: true };
  if (v.indexOf('s:') === 0){
    const s = G.stops.get(decodeURIComponent(v.slice(2)));
    return s ? { lat:s.lat, lng:s.lon, label:s.name, sid:s.id } : null;
  }
  const g = v.split(',');
  if (g.length >= 2){
    const la = +g[0], lo = +g[1];
    if (isFinite(la) && isFinite(lo)){
      const lab = decodeURIComponent(g.slice(2).join(','));
      return { lat:la, lng:lo, label:lab || ('Punkt (' + la.toFixed(4) + ', ' + lo.toFixed(4) + ')') };
    }
  }
  return null;
}
function resultsHash(){
  const L = PLUI.last;
  if (!L) return '';
  return 'a=' + encPoint(L.a) + '&b=' + encPoint(L.b) +
    '&t=' + Math.floor(L.depSec/60) +
    '&d=' + encodeURIComponent(L.dateStr) +
    '&x=' + L.xfers +
    '&sp=' + (PLANNER.PL.speedKmh === 10 ? 10 : 5);
}
function routeHash(f){
  if (!f) return '';
  if (f.mode === 'stop') return 'stop=' + encodeURIComponent(f.stopId) +
    (SDAY.cur !== 'today' ? '&day=' + encodeURIComponent(SDAY.cur) : '') +
    (f.tab === 'sch' ? '&tab=sch' : '');
  if (f.mode === 'vehicle') return 'veh=' + encodeURIComponent(f.vid);
  if (f.mode === 'line') return 'line=' + encodeURIComponent(f.lineId) + '&var=' + f.varIdx +
    (f.tab === 'deps' ? '&tab=deps' : '') + (f.fromStop ? '&fstop=' + encodeURIComponent(f.fromStop) : '');
  if (f.mode === 'trip') return 'trip=' + encodeURIComponent(f.tid) +
    (f.fromStop ? '&fstop=' + encodeURIComponent(f.fromStop) : '');
  if (f.mode === 'linedeps') return 'line=' + encodeURIComponent(f.lineId) + '&stop=' + encodeURIComponent(f.stopId) +
    (SDAY.cur !== 'today' ? '&day=' + encodeURIComponent(SDAY.cur) : '');
  if (f.mode === 'journey') return 'j=' + encodeURIComponent(f.journey.sig) + '&' + resultsHash();
  if (f.mode === 'walk') return 'j=walk&' + resultsHash();
  return '';
}
function refreshRouteHash(){
  const q = routeHash(routeActive());
  try { history.replaceState(history.state, '', '#route' + (q ? '?' + q : '')); } catch (e){}
}
function dayKeyOf(str){
  const ps = dayProfiles();
  for (let i = 0; i < ps.length; i++) if (ps[i].key === str) return str;
  return (ps.length > 1) ? ps[1].key : 'today';
}
function parseRestore(){
  const h = location.hash || '';
  const qi = h.indexOf('?');
  if (qi < 0) return null;
  const name = h.slice(1, qi);
  if (name !== 'route' && name !== 'results') return null;
  try { return { name:name, ps:new URLSearchParams(h.slice(qi + 1)) }; } catch (e){ return null; }
}
function restoreResults(ps, jSig){
  const a = decPoint(ps.get('a')), b = decPoint(ps.get('b'));
  if (!a || !b){ toast('Link niekompletny — brak punktu A/B', true); go('home', true, true); return; }
  if (a.gps){
    if (GPS.on && GPS.lat != null){ a.lat = GPS.lat; a.lng = GPS.lng; a.label = 'moja lokalizacja'; }
    else { toast('Włącz lokalizację albo wskaż start', true); go('home', true, true); return; }
  }
  const tm = ps.get('t');
  const depSec = (tm != null && isFinite(+tm)) ? Math.max(0, Math.round(+tm)) * 60 : Math.floor(clockNow() - dayStartUnix());
  const dateStr = ps.get('d') || feedDateStr();
  const xfers = Math.max(0, Math.min(3, +(ps.get('x') || 2) || 0));
  const sp = (+(ps.get('sp') || 5) === 10) ? 10 : 5;
  PLANNER.setSpeed(sp);
  $('#sp-walk').classList.toggle('on', sp === 5);
  $('#sp-run').classList.toggle('on', sp === 10);
  $('#pl-date').value = dateStr;
  $('#pl-time').value = p2(Math.floor(depSec/3600)%24) + ':' + p2(Math.floor(depSec/60)%60);
  PLUI.timeTouched = true;
  PLUI.last = { a:a, b:b, depSec:depSec, dateStr:dateStr, xfers:xfers, res:null, busy:false, depUsed:depSec, timeTouched:true };
  RES.limit = 6;
  PENDING.j = jSig || null;
  go('results');
  const rb = $('#res-body');
  rb._sk = new Map(); rb.innerHTML = '<div class="empty">Szukam połączeń…</div>';
  runSearch(true);
}
function restoreRoute(ps){
  const j = ps.get('j');
  if (j){ restoreResults(ps, j); return; }
  const veh = ps.get('veh'), stop = ps.get('stop'), line = ps.get('line'), trip = ps.get('trip');
  const day = ps.get('day'), tab = ps.get('tab'), fstop = ps.get('fstop');
  if (veh){
    if (S.vehicles.has(veh)) openRoute('vehicle', { vid:veh, from:'map' });
    else { PENDING.veh = veh; PENDING.tries = 0; go('map', true, true); }
    return;
  }
  if (trip && G.trips.has(trip)){
    const tr = G.trips.get(trip);
    openRoute('trip', { tid:trip, lineId:tr.route_id, fromStop:fstop || null, from:'map' });
    return;
  }
  if (stop && G.stops.has(stop)){
    openRoute('stop', { stopId:stop, from:'map' });
    const f = routeActive();
    if (f){
      if (day) SDAY.cur = dayKeyOf(day);
      if (tab) f.tab = tab;
      renderRoute();
    }
    return;
  }
  if (line && G.routes.has(line)){
    if (stop && G.stops.has(stop)){
      SDAY.cur = dayKeyOf(day || 'sat');
      openRoute('linedeps', { lineId:line, stopId:stop, services:curProfile().services, from:'map' });
    } else {
      openRoute('line', { lineId:line, varIdx:Math.max(0, +(ps.get('var') || 0) || 0), fromStop:fstop || null, from:'map' });
      const f = routeActive();
      if (f && tab === 'deps'){ f.tab = 'deps'; renderRoute(); }
    }
    return;
  }
  go('map', true, true);
}

/* ===== WYNIKI ===== */
function filterLiveJourneys(){
  const res = PLUI.last.res;
  if (!res || !res.journeys) return [];
  const ds0 = dayStartUnix();
  const now = clockNow();
  let live = res.journeys.filter(function(j){
    return j.firstDep == null || (ds0 + j.firstDep) > now - 900;
  });
  if (!live.length) live = res.journeys;
  return live;
}
function journeyKeyOf(j){
  let fr = null;
  for (let i = 0; i < j.legs.length; i++){ if (j.legs[i].type === 'ride'){ fr = j.legs[i]; break; } }
  return j.sig + '@' + (fr ? fr.boardSid : 'w');
}
/* KARTA: numery linii NA GÓRZE (obok dużego odjazdu), łańcuszek POD SPODEM */
function journeyCard(j, idx){
  const legs = j.legs;
  const rides = [];
  let firstRideIdx = -1, lastRideIdx = -1;
  for (let i = 0; i < legs.length; i++){
    if (legs[i].type === 'ride'){
      rides.push(legs[i]);
      if (firstRideIdx < 0) firstRideIdx = i;
      lastRideIdx = i;
    }
  }
  let accWalk = 0, egrWalk = 0;
  for (let i = 0; i < legs.length; i++){
    if (legs[i].type !== 'walk') continue;
    const s = (legs[i].vDur || legs[i].sec);
    if (firstRideIdx < 0 || i < firstRideIdx) accWalk += s;
    else if (i > lastRideIdx) egrWalk += s;
  }
  const firstRide = rides[0] || null;
  const ds0 = dayStartUnix();
  const depDay = firstRide ? firstRide.depS : (PLUI.last.depUsed || PLUI.last.depSec);
  const depUnix = ds0 + depDay;
  const now = clockNow();
  const past = (depUnix < now - 60);
  /* duży napis: godzina odjazdu; odliczanie, gdy odjazd < 10 min */
  let etaHtml;
  if (past || depUnix - now > 600) etaHtml = '<span class="jr-eta">' + fmtT(firstRide ? firstRide.dep : depDay) + '</span>';
  else etaHtml = '<span class="jr-eta" data-live="' + depUnix + '"></span>';
  /* szare „wyjdź za X min" — nad liniami */
  let leaveHtml = '';
  if (!past){
    const leaveSec = depUnix - accWalk - now;
    leaveHtml = '<span class="jr-leave">' +
      (leaveSec <= 60 ? 'wyjdź teraz' : 'wyjdź za ' + fmtDur(leaveSec)) + '</span>';
  }
  const linesHtml = rides.map(function(Rg){
    return '<span class="bl">' + esc(lineShortOf(Rg.routeId)) + '</span>';
  }).join('');
  /* łańcuszek POD SPODEM */
  const chain = [];
  if (accWalk > 45) chain.push('<span class="jc-w">' + fmtDur(accWalk) + '</span>');
  for (let i = 0; i < rides.length; i++){
    const Rg = rides[i];
    const col = lineColor(Rg.routeId);
    chain.push('<span class="jc-l" style="background:' + col + '"><b>' + esc(lineShortOf(Rg.routeId)) + '</b>' + fmtT(Rg.dep) + '</span>');
    chain.push('<span class="jc-r">' + fmtDur(Math.max(60, Rg.arr - Rg.dep)) + '</span>');
    const nx = rides[i + 1];
    if (nx) chain.push('<span class="jc-x">↔ ' + fmtDur(Math.max(60, nx.dep - Rg.arr)) + '</span>');
  }
  if (rides.length){
    const last = rides[rides.length - 1];
    chain.push('<span class="jc-l" style="background:' + lineColor(last.routeId) + '">' + fmtT(last.arr) + '</span>');
  }
  if (egrWalk > 45) chain.push('<span class="jc-w">' + fmtDur(egrWalk) + '</span>');
  const isTop = (idx === 0);
  const badges = (isTop ? '<span class="jr-badge">najlepsza</span>' : '') +
    (j.transfers === 0 ? '<span class="jr-badge dir">bezpośrednia</span>' : '');
  return '<div class="jr' + (isTop ? ' best' : '') + '" data-j="' + idx + '">' +
    '<div class="jr-row">' + etaHtml +
      '<div class="jr-mid">' + leaveHtml + '<div class="jr-lines">' + linesHtml + '</div></div>' +
      '<span class="jr-badges">' + badges + '</span>' +
    '</div>' +
    '<div class="jc-chain">' + chain.join('') + '</div>' +
  '</div>';
}
function renderResults(){
  const PP = PLUI.last;
  if (!PP || !PP.res) return;
  const res = PP.res;
  const body = $('#res-body');
  if (res.error){
    body._sk = new Map();
    body.innerHTML = '<div class="empty">' + esc(res.error) + '</div>';
    return;
  }
  const live = filterLiveJourneys();
  let minArr = Infinity;
  for (let i = 0; i < live.length; i++) if (live[i].arrive < minArr) minArr = live[i].arrive;
  const entries = [];
  if (res.walk && res.walk.sec < 2700){
    const wArr = (PP.depUsed || PP.depSec) + res.walk.sec;
    const best = (wArr <= minArr);
    entries.push({ k:'walk', h:'<div class="jr' + (best ? ' best' : '') + '" data-j="walk">' +
      '<div class="jr-row">' +
        '<span class="jr-eta">~' + fmtDur(res.walk.sec) + '</span>' +
        '<span class="jr-lines">' + ic2('walk','i-walk',24) + '</span>' +
        '<span class="jr-badges">' + (best ? '<span class="jr-badge">najszybciej</span>' : '') + '</span>' +
      '</div>' +
      '<div class="jr-sub">' + fmtDist(res.walk.dist) + (res.walk.vCoords ? ' · chodniki' : ' · w linii prostej') + '</div></div>' });
  }
  const shown = live.slice(0, RES.limit);
  for (let i = 0; i < shown.length; i++)
    entries.push({ k:'j' + journeyKeyOf(shown[i]), h:journeyCard(shown[i], i) });
  if (shown.length && RES.limit < live.length)
    entries.push({ k:'more', h:'<div class="loadmore">przewiń — więcej (' + (live.length - RES.limit) + ')</div>' });
  if (!entries.length) entries.push({ k:'e', h:'<div class="empty">Brak połączeń.</div>' });
  syncChildren(body, entries);
  registerLives(body);
  tickLive();
}
 $('#res-body').addEventListener('click', function(e){
  const card = e.target.closest('.jr');
  if (!card) return;
  if (card.dataset.j === 'walk'){ openRoute('walk', { from: 'results' }); return; }
  const live = filterLiveJourneys();
  const j = live[+card.dataset.j];
  if (j) openRoute('journey', { journey: j, from: 'results' });
});
/* AUTO-UZUPEŁNIANIE: przewiń na dół → dołóż kolejne karty (scroll nietknięty) */
 $('#res-body').addEventListener('scroll', function(){
  const el = $('#res-body');
  if (el.scrollTop + el.clientHeight > el.scrollHeight - 220){
    const live = (PLUI.last && PLUI.last.res) ? filterLiveJourneys() : [];
    if (RES.limit < live.length){
      RES.limit += RES.step;
      renderResults();
    }
  }
});

/* ===== przystanki ===== */
function stopsMatches(){
  if (!STOPS.sorted) return [];
  const q = STOPS.q.trim();
  if (!q) return STOPS.sorted;
  const qt = toks(q);
  if (!qt.length) return STOPS.sorted;
  const out = [];
  for (let i = 0; i < STOPS.sorted.length; i++){
    if (matchScore(qt, STOPS.sorted[i].tt) >= 0) out.push(STOPS.sorted[i]);
    if (out.length >= 400) break;
  }
  out.sort(function(a,b){ return matchScore(qt,b.tt) - matchScore(qt,a.tt); });
  return out;
}
function stopsItemHtml(r){
  let dist = '';
  if (GPS.on && GPS.lat != null){
    const s = G.stops.get(r.sid);
    if (s) dist = '<span class="sdst">' + fmtDist(PLANNER.havM([GPS.lat, GPS.lng], [s.lat, s.lon])) + '</span>';
  }
  const s2 = G.stops.get(r.sid);
  const zone = (s2 && s2.zone) ? s2.zone : '';
  return '<button class="stop-item" data-sid="' + esc(r.sid) + '">' +
    '<span class="stop-main"><span class="stop-nrow">' +
    '<span class="stop-nm">' + esc(r.name) + '</span>' +
    (r.code ? '<span class="stop-code">' + esc(r.code) + '</span>' : '') +
    '</span></span>' + dist +
    (zone ? '<span class="zone-sq z' + esc(zone.toLowerCase()) + '" title="Strefa ' + esc(zone) + '">' + esc(zone) + '</span>' : '') +
    '</button>';
}
function renderStopsList(){
  if (CUR !== 'stops' || !STOPS.sorted) return;
  const box = $('#stops-list');
  const q = STOPS.q.trim();
  const gpsOn = GPS.on && GPS.lat != null;
  const entries = [];
  if (!q){
    const rec = REC.stops.slice(0, 3).map(function(sid){ return G.stops.get(sid); }).filter(Boolean);
    if (rec.length){
      entries.push({ k:'h-rec', h:'<div class="stops-sec">Ostatnie</div>' });
      for (let i = 0; i < rec.length; i++)
        entries.push({ k:'r' + rec[i].id, h:stopsItemHtml({ sid: rec[i].id, name: rec[i].name, code: rec[i].code }) });
    }
    if (gpsOn){
      const near = [];
      for (let i = 0; i < STOPS.sorted.length; i++){
        const s = G.stops.get(STOPS.sorted[i].sid);
        if (s) near.push({ r: STOPS.sorted[i], d: PLANNER.havM([GPS.lat, GPS.lng], [s.lat, s.lon]) });
      }
      near.sort(function(a,b){ return a.d - b.d; });
      entries.push({ k:'h-near', h:'<div class="stops-sec">Najbliżej</div>' });
      for (let i = 0; i < Math.min(10, near.length); i++) entries.push({ k:'n' + near[i].r.sid, h:stopsItemHtml(near[i].r) });
    }
  }
  const all = stopsMatches();
  entries.push({ k:'h-all', h:'<div class="stops-sec">' + (q ? 'Wyniki (' + all.length + ')' : 'Wszystkie') + '</div>' });
  const shown = all.slice(0, STOPS.limit);
  for (let i = 0; i < shown.length; i++) entries.push({ k:'a' + shown[i].sid, h:stopsItemHtml(shown[i]) });
  if (!shown.length) entries.push({ k:'e', h:'<div class="empty">Brak wyników.</div>' });
  else if (STOPS.limit < all.length) entries.push({ k:'more', h:'<div class="loadmore">przewiń — więcej (' + (all.length - STOPS.limit) + ')</div>' });
  syncChildren(box, entries);
}
 $('#stops-q').addEventListener('input', function(){
  STOPS.q = $('#stops-q').value;
  STOPS.limit = 40;
  renderStopsList();
});
 $('#stops-list').addEventListener('click', function(e){
  const b = e.target.closest('[data-sid]');
  if (b){
    recStopAdd(b.dataset.sid);
    openRoute('stop', { stopId: b.dataset.sid, from: 'stops' });
  }
});
 $('#stops-list').addEventListener('touchstart', function(e){
  const b = e.target.closest('.stop-item');
  if (b){
    const nm = b.querySelector('.stop-nm');
    if (nm && nm.scrollWidth > nm.clientWidth + 2) b.classList.add('expanded');
  }
}, { passive: true });
 $('#stops-list').addEventListener('scroll', function(){
  const box = $('#stops-list');
  if (box.scrollTop + box.clientHeight > box.scrollHeight - 160){
    const all = stopsMatches();
    if (STOPS.limit < all.length){
      STOPS.limit += 40;
      renderStopsList();
    }
  }
});

/* kafle linii */
function renderLinesSheet(){
  const box = $('#lines-body');
  if (!box) return;
  const ids = new Set();
  S.vehicles.forEach(function(v){ if (v.routeId) ids.add(v.routeId); });
  const arr = Array.from(ids).sort(function(a,b){
    const ra = G.routes.get(a), rb = G.routes.get(b);
    return natCmp((ra && ra.short) || a, (rb && rb.short) || b);
  });
  if (!arr.length){
    box._sk = new Map();
    box.innerHTML = '<div class="empty">Brak pojazdów na żywo.</div>';
    return;
  }
  syncChildren(box, [{ k:'grid', h:'<div class="tgrid"></div>',
    sub: arr.map(function(id){
      const r = G.routes.get(id);
      return { k:'t' + id, h:'<div class="tile" data-line="' + esc(id) + '">' +
        '<div class="tile-ln">' + esc((r && r.short) || id) + '</div></div>' };
    }) }]);
}
 $('#lines-body').addEventListener('click', function(e){
  const b = e.target.closest('[data-line]');
  if (b) openRoute('line', { lineId: b.dataset.line, from: 'map' });
});

/* szukajka */
function mapAcRender(){
  const inp = $('#map-search'), panel = $('#map-ac');
  const q = inp.value.trim();
  if (!q){ panel.hidden = true; return; }
  const qU = q.toUpperCase();
  const qn = baseName(q).replace(/\s+/g, '');
  const lineExact = [], lineStarts = [], lineHas = [];
  const rl = Array.from(G.routes.values());
  for (let i = 0; i < rl.length; i++){
    const r = rl[i];
    const sU = String(r.short).toUpperCase();
    if (sU === qU) lineExact.push(r);
    else if (sU.indexOf(qU) === 0) lineStarts.push(r);
    else if (sU.indexOf(qU) > 0 || baseName(r.long || '').indexOf(baseName(q)) >= 0) lineHas.push(r);
  }
  const tabor = [], plates = [];
  S.vehicles.forEach(function(v){
    const lab = String(v.n.label || '').toUpperCase();
    const plate = String(v.n.plate || '').toLowerCase().replace(/\s+/g, '');
    if (tabor.length < 4 && lab && lab.indexOf(qU) >= 0) tabor.push(v);
    else if (plates.length < 3 && plate && qn && plate.indexOf(qn) >= 0) plates.push(v);
  });
  const rows = [];
  const linePick = lineExact.concat(lineStarts, lineHas).slice(0, 4);
  for (let i = 0; i < linePick.length; i++){
    const r = linePick[i];
    rows.push('<button class="ac-item" data-line="' + esc(r.id) + '">' + ic2('bus','i-bus',15) + '<span><b>' + esc(r.short) + '</b> · ' + esc(r.long || '') + '</span></button>');
  }
  for (let i = 0; i < tabor.length; i++){
    const v = tabor[i];
    rows.push('<button class="ac-item" data-veh="' + esc(v.id) + '">' + ic2('bus','i-bus',15) + '<span><b>' + esc(v.n.label) + '</b> · tabor · linia ' + esc(v.lineName) + (v.n.plate ? ' · ' + esc(v.n.plate) : '') + '</span></button>');
  }
  for (let i = 0; i < plates.length; i++){
    const v = plates[i];
    rows.push('<button class="ac-item" data-veh="' + esc(v.id) + '">' + ic2('bus','i-bus',15) + '<span><b>' + esc(v.n.plate) + '</b> · rejestracja · linia ' + esc(v.lineName) + '</span></button>');
  }
  const stops = acQuery(q, 6);
  for (let i = 0; i < stops.length; i++)
    rows.push('<button class="ac-item" data-sid="' + esc(stops[i].sid) + '">' + ic2('pin','i-pin',15) + '<span>' + esc(stops[i].name) + '</span><small>' + esc(stops[i].code || '') + '</small></button>');
  panel.innerHTML = rows.join('') || '<div class="ac-empty">Brak wyników</div>';
  panel.hidden = false;
}
 $('#map-search').addEventListener('input', mapAcRender);
 $('#map-search').addEventListener('focus', mapAcRender);
 $('#map-ac').addEventListener('click', function(e){
  const vh = e.target.closest('[data-veh]');
  if (vh){ $('#map-ac').hidden = true; $('#map-search').value = ''; openRoute('vehicle', { vid: vh.dataset.veh, from: 'map' }); return; }
  const b = e.target.closest('[data-sid]');
  if (b){ $('#map-ac').hidden = true; $('#map-search').value = ''; showStopPop(b.dataset.sid); return; }
  const l = e.target.closest('[data-line]');
  if (l){ $('#map-ac').hidden = true; $('#map-search').value = ''; openRoute('line', { lineId: l.dataset.line, from: 'map' }); }
});
document.addEventListener('click', function(e){
  if (e.target !== $('#map-search') && !$('#map-ac').contains(e.target)) $('#map-ac').hidden = true;
});

/* ===== feed ===== */
async function fetchRT(){
  const errs = [];
  for (let i = 0; i < CFG.RT.length; i++){
    const src = CFG.RT[i];
    try {
      const res = await fetch(src.url, { cache:'no-store' });
      if (!res.ok){
        let t = '';
        try { t = (await res.text()).replace(/\s+/g,' ').slice(0, 90); } catch (e){}
        throw new Error('HTTP ' + res.status + (t ? ' — ' + t : ''));
      }
      const ab = await res.arrayBuffer();
      const gz = await PB.gunzip(new Uint8Array(ab));
      if (gz.warning && !gz.gunzipped) throw new Error(gz.warning);
      const kind = classify(gz.bytes);
      if (kind !== 'pb') throw new Error('serwer zwrócił: ' + kind);
      const F = parseGTFSRT(gz.bytes);
      F._src = src.label;
      F._cache = !!src.cache;
      return F;
    } catch (e){ errs.push(src.label + ': ' + ((e && e.message) ? e.message : String(e))); }
  }
  throw new Error(errs.join(' | '));
}
let DBG_TU = false;
function applyFeed(F){
  S.feedBase = F.timestamp; S.feedReal = Date.now();
  S.tu = F.updates; S.alerts = F.alerts;
  S.tripVeh = new Map();
  const seen = new Set();
  const list = [];
  for (let i = 0; i < F.vehicles.length; i++){
    const n = F.vehicles[i];
    seen.add(n.id);
    if (n.tripId != null) S.tripVeh.set(String(n.tripId), n.id);
    list.push(n);
  }
  const rm = [];
  S.vehicles.forEach(function(v, id){ if (!seen.has(id)) rm.push(id); });
  for (let i = 0; i < rm.length; i++) removeVehicle(rm[i]);
  queueUpserts(list);
  if (PENDING.veh){
    if (S.vehicles.has(PENDING.veh)){ const pv = PENDING.veh; PENDING.veh = null; openRoute('vehicle', { vid:pv, from:'map' }); }
    else if (++PENDING.tries >= 8){ PENDING.veh = null; toast('Pojazd z linku już nie kursuje', true); }
  }
  if (!DBG_TU){
    DBG_TU = true;
    let nTU = 0;
    F.updates.forEach(function(v){ nTU++; });
    console.log('[GTFS-RT] pojazdy: ' + F.vehicles.length + ' · TripUpdates: ' + nTU);
  }
  try { PLANNER.applyLive(S.tu, feedDateStr()); } catch (e){}
  LNC.key = null;
  renderLinesSheet();
  if (routeActive()) refreshRoute();
  renderAlerts();
  tripTick();
}
function renderAlerts(){
  const bar = $('#alertbar'), list = $('#alerts-list');
  if (!S.alerts.length){ bar.hidden = true; list.hidden = true; ALERTS.sig = null; return; }
  ALERTS.sig = S.alerts.map(function(a){ return (a.header || '') + '|' + (a.desc || ''); }).join(';;');
  if (ALERTS.sig === ALERTS.dismissed){ bar.hidden = true; list.hidden = true; return; }
  bar.hidden = false;
  $('#alerts-sum').textContent = (S.alerts.length === 1)
    ? (S.alerts[0].header || 'komunikat przewoźnika')
    : S.alerts.length + ' komunikatów przewoźnika';
  list.innerHTML = S.alerts.map(function(a){
    return '<div class="alr"><h4>' + esc(a.header || 'Komunikat') + '</h4>' +
      (a.desc ? '<p>' + esc(a.desc) + '</p>' : '') + '</div>';
  }).join('');
}
 $('#btn-alerts').addEventListener('click', function(){ const l = $('#alerts-list'); l.hidden = !l.hidden; });
 $('#alert-close').addEventListener('click', function(){
  ALERTS.dismissed = ALERTS.sig;
  $('#alertbar').hidden = true;
  $('#alerts-list').hidden = true;
});
async function refresh(force){
  if (S.refreshing) return;
  if (document.hidden && !force) return;
  S.refreshing = true;
  try {
    const F = await fetchRT();
    applyFeed(F);
    $('#feed-dot').className = 'dot ' + (F._cache ? 'file' : 'ok');
    $('#stat-feed-txt').textContent = (F._cache ? 'cache · ' : 'live · ') + fmtUnix(S.feedBase);
    S.errToasted = false;
  } catch (e){
    $('#feed-dot').className = 'dot err';
    $('#stat-feed-txt').textContent = 'błąd';
    if (!S.errToasted){ S.errToasted = true; toast('Feed nieudany: ' + ((e && e.message) || e), true); }
  } finally { S.refreshing = false; }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) refresh(true); });
let lastManual = 0;
 $('#feed-chip').addEventListener('click', function(){
  const now = Date.now();
  if (now - lastManual < 5000){ toast('Odświeżanie możliwe raz na 5 s'); return; }
  lastManual = now;
  const chip = $('#feed-chip');
  chip.classList.add('cool');
  setTimeout(function(){ chip.classList.remove('cool'); }, 5000);
  refresh(true);
});
async function loadPBFile(file){
  try {
    const ab = await file.arrayBuffer();
    const gz = await PB.gunzip(new Uint8Array(ab));
    const kind = classify(gz.bytes);
    if (kind !== 'pb') throw new Error('plik to: ' + kind);
    const F = parseGTFSRT(gz.bytes);
    F._src = 'plik'; F._cache = true;
    applyFeed(F);
    $('#feed-dot').className = 'dot file';
    $('#stat-feed-txt').textContent = 'plik · ' + fmtUnix(S.feedBase);
  } catch (e){ toast('Nie udało się wczytać .pb: ' + ((e && e.message) || e), true); }
}
 $('#btn-pbfile').addEventListener('click', function(){ $('#pbfile').click(); });
 $('#pbfile').addEventListener('change', function(e){
  const f = e.target.files && e.target.files[0];
  if (f) loadPBFile(f);
  e.target.value = '';
});
window.addEventListener('dragover', function(e){ e.preventDefault(); });
window.addEventListener('drop', function(e){
  e.preventDefault();
  const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (f && /\.(pb|gz)$/i.test(f.name)) loadPBFile(f);
});
let rzT = null;
window.addEventListener('resize', function(){
  clearTimeout(rzT);
  rzT = setTimeout(function(){ map.invalidateSize(); }, 200);
});

/* ?pb=1 */
async function dumpPB(){
  const st = document.createElement('style');
  st.textContent = 'html,body{height:auto;overflow:auto;background:#fff;color:#111}body{margin:0;padding:16px;font:12px/1.5 ui-monospace,Menlo,monospace}pre{white-space:pre-wrap;word-break:break-all;margin:0}';
  document.head.appendChild(st);
  document.body.innerHTML = '';
  const pre = document.createElement('pre');
  document.body.appendChild(pre);
  document.title = 'GTFS-RT — raw dump';
  pre.textContent = 'Pobieram feed…\n';
  try {
    const F = await fetchRT();
    const tuObj = {};
    F.updates.forEach(function(v, k){ tuObj[k] = v; });
    pre.textContent = JSON.stringify({
      _source: F._src,
      header: { timestamp: F.timestamp, iso: new Date(F.timestamp * 1000).toISOString() },
      vehiclesCount: F.vehicles.length, vehicles: F.vehicles,
      tripUpdatesCount: Object.keys(tuObj).length, tripUpdates: tuObj, alerts: F.alerts
    }, null, 2);
  } catch (e){ pre.textContent = 'BŁĄD: ' + ((e && e.message) || e); }
}

/* ===== start ===== */
(async function init(){
  if (QPB){ await dumpPB(); return; }
  const RP = parseRestore();
  try { history.replaceState({ ztm:'home' }, '', '#home'); } catch (e){}
  let mode = 'auto';
  try { mode = localStorage.getItem('ztm-theme') || 'auto'; } catch (e){}
  applyThemeMode(mode);
  try {
    const bm = localStorage.getItem('ztm-basemap');
    if (bm){ BASE.manual = true; setBasemapById(bm); }
  } catch (e){}
  recLoad();
  $('#btn-layers').innerHTML = ic2('layers','i-layers');
  $('#btn-gps').innerHTML = ic2('gps','i-gps');
  $('#btn-fit').innerHTML = ic2('fit','i-fit');
  $('#btn-pbfile').innerHTML = ic2('upload','i-upload');
  $('#sp-walk').innerHTML = ic2('walk','i-walk',16) + 'Marsz';
  $('#sp-run').innerHTML = ic2('run','i-run',16) + 'Bieg';
  ldOk(ldFile('css/app.css'), 'liquid glass');
  ldOk(ldFile('js/pb-parser.js'), 'dekoder .pb');
  ldOk(ldFile('js/planner.js'), 'silnik live');
  ldOk(ldFile('js/app.js'), 'interfejs');
  try {
    await loadStatic();
    buildAC();
    buildStopLayers();
    renderHomeHist();
    $('#pl-date').value = feedDateStr();
    $('#pl-time').value = fmtUnix(Math.floor(clockNow()));
    attachAC('#hp-b', '#ac-b', function(sid){
      const s = G.stops.get(sid);
      if (s) $('#hp-b').value = s.name;
      return true;
    });
    attachAC('#hp-a', '#ac-a', function(sid){
      if (sid === '__gps'){ if (!GPS.on) toggleGps(); else { PLUI.a = null; setGpsFieldText(); } return true; }
      if (sid === '__map'){ $('#ac-a').hidden = true; setPick('a'); return true; }
      const s = G.stops.get(sid);
      if (s) $('#hp-a').value = s.name;
      return true;
    }, function(){
      return '<button class="ac-item" data-sid="__gps">' + ic2('gps','i-gps',15) + '<span>Moja lokalizacja' + (GPS.on ? ' (aktywna)' : '') + '</span></button>' +
             '<button class="ac-item" data-sid="__map">' + ic2('target','i-target',15) + '<span>Wskaż na mapie</span></button>';
    });
  } catch (e){
    $('#ld-msg').classList.add('err');
    $('#ld-msg').innerHTML = 'Nie udało się wczytać GTFS:<br><b>' + esc((e && e.message) || e) + '</b><br><br>Sprawdź <b>?_sync=1</b> i <b>?_diag=1</b>.';
    return;
  }
  $('#ld-msg').textContent = 'Łączenie z API…';
  await refresh(true);
  $('#loading').classList.add('off');
  setTimeout(function(){ const l = $('#loading'); if (l) l.remove(); }, 500);
  setInterval(function(){ refresh(false); }, CFG.REFRESH_MS);
  setInterval(tickLive, 1000);
  setInterval(tripTick, 10000);
  renderStopsList();
  renderLinesSheet();
  if (RP){
    if (RP.name === 'route') restoreRoute(RP.ps);
    else restoreResults(RP.ps, null);
  }
})();
window.TRACKER = { PB: PB, PBRT: window.PBRT, PLANNER: window.PLANNER, G: G, S: S, ROUTE: ROUTE, PLUI: PLUI, GPS: GPS, REC: REC, SDAY: SDAY, TRACK: TRACK };