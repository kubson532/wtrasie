'use strict';
/* pb-parser.js — dekoder protobuf (.pb) + interpretacja GTFS-RT.
   KLUCZOWA POPRAWKA: TripUpdate oficjalnie ma trip=1, stop_time_update=2,
   vehicle=3, timestamp=4, delay=5. Wcześniejsza wersja czytała STU z pola 3
   → lista przystanków TU zawsze pusta → „brak danych" opóźnień. */

const PB = (function(){
  function readVarint(dv, pos){
    let value = 0n, shift = 0n;
    for (let i = 0; i < 10; i++){
      if (pos >= dv.byteLength) throw new Error('obcięty varint @' + pos);
      const b = dv.getUint8(pos); pos++;
      value |= BigInt(b & 0x7f) << shift;
      if (!(b & 0x80)) return { value: value, offset: pos };
      shift += 7n;
    }
    throw new Error('varint za długi @' + pos);
  }
  function twos(v){ return v >= 0x8000000000000000n ? v - 0x10000000000000000n : v; }
  function zigzag(v){ return (v >> 1n) ^ -(v & 1n); }
  function fltStr(v){
    if (Number.isNaN(v)) return 'NaN';
    if (v === Infinity) return 'Infinity';
    if (v === -Infinity) return '-Infinity';
    return String(v);
  }
  function toHex(u8){
    let s = '';
    for (let i = 0; i < u8.length; i++) s += u8[i].toString(16).padStart(2, '0');
    return s;
  }
  function tryString(u8){
    if (u8.length === 0) return '';
    try {
      const s = new TextDecoder('utf-8', { fatal: true }).decode(u8);
      let p = 0;
      for (let i = 0; i < s.length; i++){
        const c = s.charCodeAt(i);
        if (c >= 32 || c === 9 || c === 10 || c === 13) p++;
      }
      if (s.length > 0 && p / s.length < 0.85) return null;
      return s;
    } catch (e){ return null; }
  }
  function tryPacked(u8){
    try {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const vals = []; let pos = 0;
      while (pos < u8.length){
        const r = readVarint(dv, pos);
        vals.push(r.value.toString()); pos = r.offset;
      }
      if (vals.length >= 2 && pos === u8.length) return { type: 'varint', values: vals };
    } catch (e){}
    return null;
  }
  function readField(dv, u8, pos, field, wt, off, depth, maxDepth){
    let value = '';
    const interps = [];
    let children = null, bytesHex = null, next = pos;
    if (wt === 0){
      const r = readVarint(dv, pos); next = r.offset;
      const s = r.value; value = s.toString();
      interps.push({ label:'uint64', value:s.toString() });
      interps.push({ label:'int64',  value:twos(s).toString() });
      interps.push({ label:'sint64', value:zigzag(s).toString() });
      if (s === 0n || s === 1n) interps.push({ label:'bool', value:(s === 1n) ? 'true' : 'false' });
    } else if (wt === 1){
      if (pos + 8 > u8.length) throw new Error('obcięta wartość 64-bit @' + pos);
      const lo = dv.getUint32(pos, true), hi = dv.getUint32(pos + 4, true);
      const v = (BigInt(hi) << 32n) | BigInt(lo);
      next = pos + 8; value = v.toString();
      interps.push({ label:'fixed64',  value:v.toString() });
      interps.push({ label:'sfixed64', value:twos(v).toString() });
      interps.push({ label:'double',   value:fltStr(dv.getFloat64(pos, true)) });
    } else if (wt === 5){
      if (pos + 4 > u8.length) throw new Error('obcięta wartość 32-bit @' + pos);
      next = pos + 4;
      const u = dv.getUint32(pos, true) >>> 0;
      value = String(u);
      interps.push({ label:'fixed32',  value:String(u) });
      interps.push({ label:'sfixed32', value:String(dv.getInt32(pos, true)) });
      interps.push({ label:'float',    value:fltStr(dv.getFloat32(pos, true)) });
    } else if (wt === 2){
      const r = readVarint(dv, pos);
      const len = Number(r.value);
      if (len < 0 || len > 64 * 1024 * 1024) throw new Error('nierealna długość @' + pos);
      const start = r.offset;
      if (start + len > u8.length) throw new Error('obcięte pole @' + pos);
      const sub = u8.subarray(start, start + len);
      next = start + len;
      bytesHex = toHex(sub);
      let isMsg = false;
      if (len > 0){
        try {
          const n = decode(sub, { depth: depth + 1, maxDepth: maxDepth });
          if (n.fields.length > 0 && n.bytesRead === len && n.warnings.length === 0){
            children = n.fields; isMsg = true;
            value = '{ ' + n.fields.length + ' pól }';
            interps.push({ label:'message', value:value });
          }
        } catch (e){}
      } else value = '(puste)';
      const str = tryString(sub);
      if (str !== null){
        if (!isMsg) value = JSON.stringify(str);
        interps.push({ label:'string', value:JSON.stringify(str) });
      }
      if (!isMsg && str === null && len > 0){
        const pk = tryPacked(sub);
        if (pk){ interps.push({ label:'packed ' + pk.type, value:pk.values.join(', ') }); value = '[' + pk.values.join(', ') + ']'; }
      }
      if (!isMsg && str === null) value = '0x' + (bytesHex.length > 64 ? bytesHex.slice(0, 64) + '…' : bytesHex);
      interps.push({ label:'bytes', value:'0x' + bytesHex.slice(0, 96) + ' (' + len + ' B)' });
    }
    return { nextOffset: next, record: { field:field, wireType:wt, offset:off, length:next-off,
      value:value, interpretations:interps, children:children, bytesHex:bytesHex } };
  }
  function decode(u8, opts){
    if (!(u8 instanceof Uint8Array)) throw new TypeError('decode oczekuje Uint8Array');
    opts = opts || {};
    const depth = opts.depth || 0;
    const maxDepth = (opts.maxDepth == null) ? 32 : opts.maxDepth;
    if (depth > maxDepth) throw new Error('zagnieżdżenie > ' + maxDepth);
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let pos = 0;
    const fields = [], warnings = [];
    while (pos < u8.length){
      const fs = pos; let tag;
      try { const r = readVarint(dv, pos); tag = r.value; pos = r.offset; }
      catch (e){
        if (fields.length > 0){ warnings.push('stop @' + fs + ': ' + e.message); pos = fs; break; }
        throw e;
      }
      if (tag === 0n){
        if (fields.length > 0){ warnings.push('tag 0 @' + fs); pos = fs; break; }
        throw new Error('nieprawidłowy protobuf: tag = 0');
      }
      const field = Number(tag >> 3n), wt = Number(tag & 7n);
      if (field === 0){
        if (fields.length > 0){ warnings.push('pole 0 @' + fs); pos = fs; break; }
        throw new Error('nieprawidłowy protobuf: pole = 0');
      }
      if (wt === 3 || wt === 4){
        fields.push({ field:field, wireType:wt, offset:fs, length:0, value:'(grupy)', interpretations:[], children:null, bytesHex:null });
        continue;
      }
      if (wt !== 0 && wt !== 1 && wt !== 2 && wt !== 5) throw new Error('nieznany wire type ' + wt + ' @' + fs);
      const r = readField(dv, u8, pos, field, wt, fs, depth, maxDepth);
      pos = r.nextOffset;
      fields.push(r.record);
    }
    return { fields: fields, bytesRead: pos, warnings: warnings };
  }
  async function gunzip(u8){
    if (!u8 || u8.length < 2 || u8[0] !== 31 || u8[1] !== 139) return { bytes: u8, gunzipped: false };
    if (typeof DecompressionStream === 'undefined')
      return { bytes: u8, gunzipped: false, warning: 'gzip bez wsparcia DecompressionStream' };
    try {
      const st = new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'));
      const buf = await new Response(st).arrayBuffer();
      return { bytes: new Uint8Array(buf), gunzipped: true };
    } catch (e){ return { bytes: u8, gunzipped: false, warning: 'gzip: ' + ((e && e.message) || 'błąd') }; }
  }
  return { decode: decode, gunzip: gunzip };
})();

function hexToBytes(h){
  const out = new Uint8Array(h.length >> 1);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(h.substr(i * 2, 2), 16);
  return out;
}
/* pole, które ze schematu JEST wiadomością — dekoduj nawet gdy heurystyka nie rozpoznała */
function subRecs(rec){
  if (!rec) return null;
  if (rec.children) return rec.children;
  if (rec.wireType === 2 && rec.bytesHex && rec.bytesHex.length >= 2){
    try { return PB.decode(hexToBytes(rec.bytesHex)).fields; } catch (e){ return null; }
  }
  return null;
}
function interpOf(rec, label){
  const l = rec.interpretations || [];
  for (let i = 0; i < l.length; i++) if (l[i].label === label) return l[i];
  return null;
}
function rString(rec){
  const i = interpOf(rec, 'string');
  if (!i) return null;
  try { return JSON.parse(i.value); } catch (e){ return i.value; }
}
function rInt(rec){
  let i = interpOf(rec, 'int64');
  if (!i) i = interpOf(rec, 'uint64');
  if (i){ const n = Number(i.value); if (isFinite(n)) return n; }
  return null;
}
function rFloat(rec){
  let i = interpOf(rec, 'float');
  if (!i) i = interpOf(rec, 'double');
  if (i){ const n = Number(i.value); if (isFinite(n)) return n; }
  return rInt(rec);
}
function pick(recs, n){
  const out = [];
  for (let i = 0; i < recs.length; i++) if (recs[i].field === n) out.push(recs[i]);
  return out;
}
function one(recs, n){ const l = pick(recs, n); return l.length ? l[0] : null; }

function parseTripDescriptor(recs){
  const t = { tripId:null, startTime:null, startDate:null, routeId:null, direction:null, rel:null };
  let r = one(recs, 1); if (r) t.tripId = rString(r);
  r = one(recs, 2); if (r) t.startTime = rString(r);
  r = one(recs, 3); if (r) t.startDate = rString(r);
  r = one(recs, 4); if (r) t.rel = rInt(r);
  r = one(recs, 5); if (r) t.routeId = rString(r);
  r = one(recs, 6); if (r) t.direction = rInt(r);
  return t;
}
function parseVehicleDescriptor(recs){
  const d = { id:null, label:null, plate:null, wheelchair:null };
  let r = one(recs, 1); if (r) d.id = rString(r);
  r = one(recs, 2); if (r) d.label = rString(r);
  r = one(recs, 3); if (r) d.plate = rString(r);
  r = one(recs, 4); if (r) d.wheelchair = rInt(r);
  return d;
}
function parseVP(recs, id){
  const v = { id:id, tripId:null, routeId:null, startTime:null, lat:null, lng:null, bearing:null, speed:null,
    seq:null, status:null, stopId:null, occupancy:null, vehId:null, label:null, plate:null, wheelchair:null, ts:null };
  const tr = one(recs, 1);
  if (tr){ const rs = subRecs(tr); if (rs){ const td = parseTripDescriptor(rs);
    v.tripId = td.tripId; v.routeId = td.routeId; v.startTime = td.startTime; } }
  const pr = one(recs, 2);
  if (pr){ const rs = subRecs(pr); if (rs){
    let r = one(rs, 1); if (r) v.lat = rFloat(r);
    r = one(rs, 2); if (r) v.lng = rFloat(r);
    r = one(rs, 3); if (r) v.bearing = rFloat(r);
    r = one(rs, 5); if (r) v.speed = rFloat(r); } }
  let r = one(recs, 3); if (r) v.seq = rInt(r);
  r = one(recs, 4); if (r) v.status = rInt(r);
  r = one(recs, 5); if (r) v.ts = rInt(r);
  const f7 = one(recs, 7);
  if (f7){
    if (f7.wireType === 2){ const s = rString(f7); if (s != null) v.stopId = s; }
    else if (v.occupancy == null) v.occupancy = rInt(f7);
  }
  const f9 = one(recs, 9);
  if (f9 && v.occupancy == null) v.occupancy = rInt(f9);
  const vd = one(recs, 8);
  if (vd){ const rs = subRecs(vd); if (rs){ const d = parseVehicleDescriptor(rs);
    v.vehId = d.id; v.label = d.label; v.plate = d.plate; v.wheelchair = d.wheelchair; } }
  return v;
}
function parseSTE(rs, kind, stu){
  if (!rs) return;
  let y = one(rs, 1);
  if (y && y.wireType === 0){ const n = rInt(y); if (n != null) stu[kind + 'Delay'] = n; }
  y = one(rs, 2);
  if (y && y.wireType === 0){ const n = rInt(y); if (n != null && n > 0) stu[kind + 'Time'] = n; }
}
function parseSTU(rec){
  const rs = subRecs(rec);
  if (!rs) return null;
  const stu = { seq:null, stopId:null, arrTime:null, arrDelay:null, depTime:null, depDelay:null };
  let x = one(rs, 1);
  if (x && x.wireType === 0) stu.seq = rInt(x);
  x = one(rs, 4);                                  // oficjalnie stop_id = 4
  if (!x || x.wireType !== 2) x = one(rs, 5);      // warianty: stop_id = 5
  if (x && x.wireType === 2){ const s = rString(x); if (s != null) stu.stopId = s; }
  const arr = one(rs, 2); if (arr) parseSTE(subRecs(arr), 'arr', stu);
  const dep = one(rs, 3); if (dep) parseSTE(subRecs(dep), 'dep', stu);
  if (stu.seq == null && stu.stopId == null && stu.arrTime == null && stu.arrDelay == null &&
      stu.depTime == null && stu.depDelay == null) return null;
  return stu;
}
function parseTU(recs, feed){
  function asTrip(rec){
    if (!rec) return null;
    const rs = subRecs(rec);
    if (!rs) return null;
    const td = parseTripDescriptor(rs);
    return td.tripId ? td : null;
  }
  const tdA = asTrip(one(recs, 1));   // oficjalnie trip = 1
  const tdB = asTrip(one(recs, 2));   // warianty producentów
  let td = null;
  if (tdA && tdB){
    if (G.trips.size){
      if (G.trips.has(tdB.tripId)) td = tdB;
      else if (G.trips.has(tdA.tripId)) td = tdA;
      else td = tdB;
    } else td = tdB;
  } else td = tdB || tdA;
  if (!td) return;

  const tu = { tripId: td.tripId, delay: null, stops: [] };
  const d5 = one(recs, 5);            // trip-level delay (pole 5)
  if (d5 && d5.wireType === 0){
    const n = rInt(d5);
    if (n != null && n > -86400 && n < 86400) tu.delay = n;
  }
  /* >>> POPRAWKA <<< : stop_time_update = pole 2 (oficjalnie).
     Pole 3 to vehicle — parseSTU zwróci dla niego null, więc skanowanie
     obu pól jest bezpieczne i obejmuje też nietypowe producentów. */
  const stuCands = pick(recs, 2).concat(pick(recs, 3));
  for (let i = 0; i < stuCands.length; i++){
    const stu = parseSTU(stuCands[i]);
    if (stu) tu.stops.push(stu);
  }
  tu.stops.sort(function(a, b){ return (a.seq || 0) - (b.seq || 0); });
  feed.updates.set(String(td.tripId), tu);
}
function parseTranslatedString(recs){
  const trs = pick(recs, 1);
  for (let i = 0; i < trs.length; i++){
    const rs = subRecs(trs[i]);
    if (!rs) continue;
    const t = one(rs, 1);
    if (t){ const s = rString(t); if (s != null && s !== '') return s; }
  }
  return '';
}
function parseAlert(recs){
  const a = { header:'', desc:'', cause:null, effect:null };
  let r = one(recs, 6); if (r) a.cause = rInt(r);
  r = one(recs, 7); if (r) a.effect = rInt(r);
  r = one(recs, 10); if (r) a.header = parseTranslatedString(subRecs(r) || []);
  r = one(recs, 11); if (r) a.desc = parseTranslatedString(subRecs(r) || []);
  return a;
}
function parseGTFSRT(u8){
  const root = PB.decode(u8);
  if (!root.fields.length) throw new Error('feed bez pól');
  let timestamp = Math.floor(Date.now() / 1000);
  const hr = one(root.fields, 1);
  if (hr){ const rs = subRecs(hr); if (rs){ const t = one(rs, 3);
    if (t){ const n = rInt(t); if (n) timestamp = n; } } }
  const feed = { timestamp: timestamp, vehicles: [], updates: new Map(), alerts: [] };
  const ents = pick(root.fields, 2);
  for (let i = 0; i < ents.length; i++){
    const er = subRecs(ents[i]);
    if (!er) continue;
    const idRec = one(er, 1);
    const id = (idRec ? rString(idRec) : null) || ('e' + ents[i].offset);
    const del = one(er, 2);
    if (del && del.wireType === 0 && rInt(del) === 1) continue;
    const vp = one(er, 4);
    if (vp){ const rs = subRecs(vp); if (rs) feed.vehicles.push(parseVP(rs, id)); }
    const tu = one(er, 3);
    if (tu){ const rs = subRecs(tu); if (rs) parseTU(rs, feed); }
    const al = one(er, 5);
    if (al){ const rs = subRecs(al); if (rs) feed.alerts.push(parseAlert(rs)); }
  }
  return feed;
}
function classify(u8){
  if (!u8 || !u8.length) return 'pustą odpowiedź';
  if (u8[0] === 0x1f && u8[1] === 0x8b) return 'dane gzip (nie rozpakowane)';
  if (u8[0] === 0x50 && u8[1] === 0x4b) return 'archiwum ZIP zamiast .pb';
  const n = Math.min(u8.length, 600);
  let p = 0;
  for (let i = 0; i < n; i++){ const b = u8[i]; if (b===9||b===10||b===13||(b>=32&&b<127)) p++; }
  if (p / n > 0.97){
    let t = '';
    for (let i = 0; i < Math.min(400, u8.length); i++) t += String.fromCharCode(u8[i]);
    t = t.replace(/^\uFEFF/, '').trimStart();
    if (t.charAt(0) === '<' || /^<!doctype/i.test(t)) return 'HTML zamiast .pb';
    if (t.charAt(0) === '{' || t.charAt(0) === '[') return 'JSON zamiast .pb';
    if (u8[0] !== 0x0a) return 'tekst zamiast .pb: "' + t.slice(0, 80) + '"';
  }
  return 'pb';
}
window.PBRT = { PB: PB, parseGTFSRT: parseGTFSRT, classify: classify, subRecs: subRecs };