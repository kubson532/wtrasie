'use strict';
/* planner.js — silnik połączeń (RAPTOR + Dijkstra) z danymi NA ŻYWO. ZESTAW 20260924l:
   – ZAPEŁNIANIE LISTY: szukaj aż zbierzesz FILL_TARGET=12 różnych linii (do 3 h
     w przyszłość) — UI pokazuje 6 kart i dokłada po 5 przy przewijaniu (lazy)
   – FILTR RACJONALNOŚCI: chodzenie dłuższe niż jazda → śmieć; kurs, na który
     już nie zdążysz → śmieć; bezpiecznik: zostaje 1 najlepsza gdy nic nie ma
   – JEDNA KARTA NA LINIĘ finalną · przesiadka na pierwszym wspólnym przystanku
     (≤200 m) · Pareto z wymianą czas↔chodzenie (1 min przyjazdu = max 4 min chodzenia)
   – czasy efektywne: plan + opóźnienie z TripUpdate; przesiadka ≥ 120 s
     od EFEKTYWNEGO przyjazdu; tempo 5/10 km/h */

const PLCFG = {
  DETOUR: 1.3, TRANSFER_BUF: 120, ACCESS_M: 1500, ADJ_M: 400,
  WALK_CAP_M: 1500, MAX_WAIT: 3600, XFER_PENALTY: 420,
  FILL_HORIZON: 10800,   /* uzupełnianie: jak daleko patrzeć w przyszłość [s] */
  FILL_ROUNDS: 10,       /* uzupełnianie: maks. liczba rund szukania */
  FILL_TARGET: 12,       /* szukaj aż tyle RÓŻNYCH linii (dla lazy-scroll) */
  LIST_CAP: 16,          /* twardy limit zwracanych (pamięć/DOM) */
  WALK_EXCH: 0.25,       /* 1 min przyjazdu = max 4 min chodzenia */
  WALK_EXCH_CAP: 600,    /* max „tolerancji" późniejszego przyjazdu: 10 min */
  IRR_GRACE: 45          /* luz [s] przy „już nie zdążysz na kurs" */
};
const PL = { ready:false, dateKey:null, speedKmh:5, trips:null, stopSrv:null,
             stopsPos:null, adj:null, liveTids:new Set(), liveSlack:0 };

function havM(a, b){
  const R = 6371000;
  const la1 = a[0]*Math.PI/180, la2 = b[0]*Math.PI/180;
  const dLa = la2-la1, dLo = (b[1]-a[1])*Math.PI/180;
  const h = Math.sin(dLa/2)*Math.sin(dLa/2) + Math.cos(la1)*Math.cos(la2)*Math.sin(dLo/2)*Math.sin(dLo/2);
  return 2*R*Math.asin(Math.min(1, Math.sqrt(h)));
}
function walkSec(m){ return (m * PLCFG.DETOUR) / (PL.speedKmh * 1000 / 3600); }
function dayStartOf(dateStr){ return Math.floor(new Date(dateStr + 'T00:00:00').getTime() / 1000); }

class MinHeap {
  constructor(){ this.a = []; }
  push(p, v){
    const a = this.a; a.push([p, v]);
    let i = a.length - 1;
    while (i > 0){ const par = (i-1)>>1; if (a[par][0] <= a[i][0]) break;
      const t = a[par]; a[par] = a[i]; a[i] = t; i = par; }
  }
  pop(){
    const a = this.a;
    if (!a.length) return null;
    const top = a[0], last = a.pop();
    if (a.length){ a[0] = last; let i = 0;
      for(;;){ const l = 2*i+1, r = l+1; let m = i;
        if (l < a.length && a[l][0] < a[m][0]) m = l;
        if (r < a.length && a[r][0] < a[m][0]) m = r;
        if (m === i) break;
        const t = a[m]; a[m] = a[i]; a[i] = t; i = m; } }
    return top;
  }
}

function plannerInit(dateStr){
  const act = activeServices(dateStr);
  PL.trips = new Map(); PL.stopSrv = new Map(); PL.stopsPos = new Map();
  PL.liveTids = new Set(); PL.liveSlack = 0;
  for (let i = 0; i < stopsArray.length; i++){
    const s = stopsArray[i];
    if (isFinite(s.lat) && isFinite(s.lon)) PL.stopsPos.set(s.id, [s.lat, s.lon]);
  }
  G.trips.forEach(function(trip, tid){
    if (act && !act.has(trip.service_id)) return;
    const st = tripStops(tid);
    if (!st || st.length < 2) return;
    const stops = [];
    for (let i = 0; i < st.length; i++)
      stops.push({ sid:String(st[i][1]), seq:st[i][0], arr:st[i][2], dep:st[i][3], pu:st[i][4], dof:st[i][5] });
    const t = { stops:stops, routeId:trip.route_id, headsign:trip.headsign || '', live:null,
                effDep:stops.map(function(s){ return s.dep; }),
                effArr:stops.map(function(s){ return s.arr; }) };
    PL.trips.set(tid, t);
    for (let i = 0; i < stops.length; i++){
      if (stops[i].pu === 1) continue;
      let a = PL.stopSrv.get(stops[i].sid);
      if (!a){ a = []; PL.stopSrv.set(stops[i].sid, a); }
      a.push({ tid:tid, idx:i, dep:stops[i].dep });
    }
  });
  PL.stopSrv.forEach(function(l){ l.sort(function(a,b){ return a.dep - b.dep; }); });
  buildAdjacency();
  PL.dateKey = dateStr;
  PL.ready = true;
}
function buildAdjacency(){
  const CELL = 0.005, grid = new Map();
  PL.stopsPos.forEach(function(p, sid){
    const k = Math.floor(p[0]/CELL) + '_' + Math.floor(p[1]/CELL);
    let b = grid.get(k); if (!b){ b = []; grid.set(k, b); }
    b.push(sid);
  });
  PL.adj = new Map();
  PL.stopsPos.forEach(function(p, sid){
    const out = [];
    const cx = Math.floor(p[0]/CELL), cy = Math.floor(p[1]/CELL);
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++){
      const b = grid.get((cx+dx) + '_' + (cy+dy));
      if (!b) continue;
      for (let i = 0; i < b.length; i++){
        if (b[i] === sid) continue;
        const d = havM(p, PL.stopsPos.get(b[i]));
        if (d <= PLCFG.ADJ_M) out.push({ sid:b[i], dist:d });
      }
    }
    PL.adj.set(sid, out);
  });
}
function plFindStu(tu, s){
  const l = tu.stops || [];
  for (let i = 0; i < l.length; i++){
    if (l[i].seq != null && l[i].seq === s.seq) return l[i];
    if (l[i].stopId != null && String(l[i].stopId) === String(s.sid)) return l[i];
  }
  return null;
}
function plannerApplyLive(tuMap, dateStr){
  if (!PL.ready) return;
  PL.liveTids.forEach(function(tid){
    const t = PL.trips.get(tid);
    if (!t) return;
    for (let i = 0; i < t.stops.length; i++){
      t.effDep[i] = t.stops[i].dep;
      t.effArr[i] = t.stops[i].arr;
    }
    t.live = null;
  });
  PL.liveTids = new Set();
  if (PL.dateKey !== dateStr) return;
  const ds0 = dayStartOf(dateStr);
  let slack = 0;
  tuMap.forEach(function(tu, tid){
    const t = PL.trips.get(tid);
    if (!t) return;
    t.live = tu;
    PL.liveTids.add(tid);
    for (let i = 0; i < t.stops.length; i++){
      const s = t.stops[i];
      let ed = s.dep, ea = s.arr;
      const stu = plFindStu(tu, s);
      if (stu){
        if (stu.depTime) ed = stu.depTime - ds0;
        else if (stu.depDelay != null) ed = s.dep + stu.depDelay;
        else if (tu.delay != null) ed = s.dep + tu.delay;
        if (stu.arrTime) ea = stu.arrTime - ds0;
        else if (stu.arrDelay != null) ea = s.arr + stu.arrDelay;
        else if (tu.delay != null) ea = s.arr + tu.delay;
      } else if (tu.delay != null){
        ed = s.dep + tu.delay; ea = s.arr + tu.delay;
      }
      if (ed - s.dep > 3600 || s.dep - ed > 1500) ed = s.dep;
      if (ea - s.arr > 3600 || s.arr - ea > 1500) ea = s.arr;
      t.effDep[i] = ed; t.effArr[i] = ea;
      const d = Math.abs(ed - s.dep);
      if (d > slack) slack = d;
    }
  });
  PL.liveSlack = Math.min(1800, slack);
}
function nearStops(p, maxM){
  const out = [];
  PL.stopsPos.forEach(function(q, sid){
    const d = havM(p, q);
    if (d <= maxM) out.push({ sid:sid, dist:d, sec:walkSec(d) });
  });
  out.sort(function(a,b){ return a.sec - b.sec; });
  return out;
}
function mkWalk(parent, fromSid, toSid, sec, dist, kind, fromPt, toPt){
  return { type:'walk', kind:kind, fromSid:fromSid || null, toSid:toSid || null,
    fromPt:fromPt || null, toPt:toPt || null, sec:sec, dist:dist || 0, parent:parent };
}
function pathHasTrip(node, tid){
  for (; node; node = node.parent) if (node.type === 'ride' && node.tid === tid) return true;
  return false;
}
function flattenLegs(node){
  const a = [];
  for (let n = node; n; n = n.parent) a.push(n);
  a.reverse();
  return a;
}
function relaxWalk(map){
  const heap = new MinHeap();
  map.forEach(function(lab, sid){ heap.push(lab.t, sid); });
  for (;;){
    const top = heap.pop();
    if (!top) break;
    const t = top[0], sid = top[1];
    const lab = map.get(sid);
    if (!lab || lab.t < t) continue;
    const adj = PL.adj.get(sid) || [];
    for (let j = 0; j < adj.length; j++){
      const a = adj[j];
      const nwm = (lab.wm || 0) + a.dist;
      if (nwm > PLCFG.WALK_CAP_M) continue;
      const nt = t + walkSec(a.dist);
      const ex = map.get(a.sid);
      if (!ex || nt < ex.t - 0.001){
        map.set(a.sid, { t:nt, wm:nwm, node:mkWalk(lab.node, sid, a.sid, walkSec(a.dist), a.dist, 'transfer', null, null) });
        heap.push(nt, a.sid);
      }
    }
  }
}
function lbDep(list, t){
  let lo = 0, hi = list.length;
  while (lo < hi){ const m = (lo+hi)>>1; if (list[m].dep < t) lo = m+1; else hi = m; }
  return lo;
}

/* przesiadka na PIERWSZYM WSPÓLNYM przystanku (≤200 m) */
function normalizeTransfers(j){
  const legs = j.legs.map(function(l){ return Object.assign({}, l); });
  for (let i = 0; i < legs.length; i++){
    if (legs[i].type !== 'ride') continue;
    let ni = i + 1;
    while (ni < legs.length && legs[ni].type !== 'ride') ni++;
    if (ni >= legs.length) break;
    const A = legs[i], B = legs[ni];
    const tA = PL.trips.get(A.tid), tB = PL.trips.get(B.tid);
    if (!tA || !tB){ i = ni - 1; continue; }
    let bi = -1, bj = -1, bdist = 0, bsec = 0;
    for (let ii = A.boardIdx; ii < A.alightIdx && ii < tA.stops.length; ii++){
      if (tA.stops[ii].dof === 1) continue;
      const pa = PL.stopsPos.get(tA.stops[ii].sid);
      if (!pa) continue;
      for (let jj = 0; jj < B.boardIdx; jj++){
        if (tB.stops[jj].pu === 1) continue;
        const pb = PL.stopsPos.get(tB.stops[jj].sid);
        if (!pb) continue;
        const dd = havM(pa, pb);
        if (dd > 200) continue;
        const wsec = walkSec(dd);
        if (tB.effDep[jj] >= tA.effArr[ii] + PLCFG.TRANSFER_BUF + wsec){
          bi = ii; bj = jj; bdist = dd; bsec = wsec;
          break;
        }
      }
      if (bi >= 0) break;
    }
    if (bi >= 0){
      A.alightIdx = bi; A.alightSid = tA.stops[bi].sid; A.arr = tA.effArr[bi]; A.arrS = tA.stops[bi].arr;
      B.boardIdx = bj; B.boardSid = tB.stops[bj].sid; B.dep = tB.effDep[bj]; B.depS = tB.stops[bj].dep;
      const nWalk = ni - i - 1;
      if (nWalk > 0) legs.splice(i + 1, nWalk);
      let bIdx;
      if (bsec > 30){
        legs.splice(i + 1, 0, mkWalk(null, A.alightSid, B.boardSid, bsec, bdist, 'transfer', null, null));
        bIdx = i + 2;
      } else bIdx = i + 1;
      i = bIdx - 1;
      continue;
    }
    i = ni - 1;
  }
  j.legs = legs;
  return j;
}

/* Pareto + wymiana czas↔chodzenie */
function dominates(x, y){
  const walkSave = y.walkSec - x.walkSec;
  const arrAllow = Math.min(PLCFG.WALK_EXCH_CAP, Math.max(0, walkSave) * PLCFG.WALK_EXCH);
  if (x.arrive > y.arrive + arrAllow) return false;
  if (x.transfers > y.transfers) return false;
  if (x.walkSec > y.walkSec + 60) return false;
  if (x.firstDep < y.firstDep - 60) return false;
  return (x.arrive < y.arrive) || (x.transfers < y.transfers) ||
         (x.walkSec + 60 < y.walkSec) || (x.firstDep + 60 > y.firstDep);
}
function paretoKeep(list){
  for (let i = 0; i < list.length; i++){
    const c = list[i];
    let w = 0, fd = null, ride = 0, accW = 0, rideSeen = false;
    for (let k = 0; k < c.legs.length; k++){
      const Lg = c.legs[k];
      if (Lg.type === 'walk'){
        w += Lg.sec;
        if (!rideSeen) accW += Lg.sec;
      } else {
        rideSeen = true;
        if (fd == null) fd = Lg.dep;
        ride += (Lg.arr - Lg.dep);
      }
    }
    c.walkSec = w; c.firstDep = fd;
    c.rideSec = ride; c.accWalk = accW;
    c.score = c.arrive + PLCFG.XFER_PENALTY * c.transfers + Math.round(w * PLCFG.WALK_EXCH);
  }
  list.sort(function(a,b){
    if (a.score !== b.score) return a.score - b.score;
    if (a.walkSec !== b.walkSec) return a.walkSec - b.walkSec;
    return b.firstDep - a.firstDep;
  });
  const kept = [];
  for (let i = 0; i < list.length; i++){
    let dominated = false;
    for (let j = 0; j < kept.length; j++)
      if (dominates(kept[j], list[i])){ dominated = true; break; }
    if (!dominated) kept.push(list[i]);
    if (kept.length >= 60) break;
  }
  return kept;
}

/* FILTR RACJONALNOŚCI */
function rationalKeep(list, nowDay){
  const out = [];
  for (let i = 0; i < list.length; i++){
    const c = list[i];
    if (c.rideSec > 0 && c.walkSec > c.rideSec) continue;
    if (nowDay != null && c.firstDep != null && c.accWalk != null &&
        c.firstDep - c.accWalk < nowDay - PLCFG.IRR_GRACE) continue;
    out.push(c);
  }
  if (!out.length && list.length) return list.slice(0, 1);
  return out;
}

function lastRideOf(j){
  for (let i = j.legs.length - 1; i >= 0; i--)
    if (j.legs[i].type === 'ride') return j.legs[i];
  return null;
}
function dedupeFinalLine(list){
  const seen = new Set();
  const out = [];
  for (let i = 0; i < list.length; i++){
    const fin = lastRideOf(list[i]);
    if (fin && fin.routeId != null){
      if (seen.has(fin.routeId)) continue;
      seen.add(fin.routeId);
    }
    out.push(list[i]);
  }
  return out;
}

function searchRound(oLat, oLng, dLat, dLng, acc, egrMap, dep, maxTransfers){
  const ridesMax = Math.max(1, Math.min(3, (maxTransfers|0)) + 1);
  const reach = [];
  for (let k = 0; k <= ridesMax; k++) reach.push(new Map());
  for (let i = 0; i < acc.length; i++){
    const a = acc[i];
    reach[0].set(a.sid, { t: dep + a.sec, wm: a.dist,
      node: mkWalk(null, null, a.sid, a.sec, a.dist, 'access', { lat:oLat, lng:oLng }, null) });
  }
  relaxWalk(reach[0]);

  const cands = [];
  function addCand(stopId, t, node){
    if (cands.length > 30000) return;
    const e = egrMap.get(stopId);
    if (!e) return;
    const fn = mkWalk(node, stopId, null, e.sec, e.dist, 'egress', null, { lat:dLat, lng:dLng });
    const legs = flattenLegs(fn);
    let rides = 0; const tids = []; let firstDep = null;
    for (let i = 0; i < legs.length; i++)
      if (legs[i].type === 'ride'){ rides++; tids.push(legs[i].tid); if (firstDep == null) firstDep = legs[i].dep; }
    if (!rides) return;
    cands.push({ arrive: t + e.sec, legs: legs, transfers: rides - 1, sig: tids.join('>'), firstDep: firstDep });
  }
  for (let k = 1; k <= ridesMax; k++){
    const prev = reach[k-1], cur = reach[k];
    prev.forEach(function(lab, sid){
      const boardFrom = lab.t + ((k === 1) ? 0 : PLCFG.TRANSFER_BUF);
      const list = PL.stopSrv.get(sid);
      if (!list) return;
      let i = lbDep(list, boardFrom - PL.liveSlack);
      for (; i < list.length; i++){
        const srv = list[i];
        if (srv.dep > boardFrom + PLCFG.MAX_WAIT + PL.liveSlack) break;
        if (pathHasTrip(lab.node, srv.tid)) continue;
        const td = PL.trips.get(srv.tid);
        if (!td) continue;
        const ed = td.effDep[srv.idx];
        if (ed < boardFrom) continue;
        for (let j = srv.idx + 1; j < td.stops.length; j++){
          if (td.stops[j].dof === 1) continue;
          const t2 = td.effArr[j];
          const node = { type:'ride', tid:srv.tid, routeId:td.routeId, headsign:td.headsign,
            boardSid:sid, alightSid:td.stops[j].sid, boardIdx:srv.idx, alightIdx:j,
            dep:ed, arr:t2, depS:td.stops[srv.idx].dep, arrS:td.stops[j].arr,
            live:!!td.live, delta:(td.live && td.live.delay != null) ? td.live.delay : null, parent:lab.node };
          addCand(td.stops[j].sid, t2, node);
          const ex = cur.get(td.stops[j].sid);
          if (!ex || t2 < ex.t) cur.set(td.stops[j].sid, { t:t2, wm:0, node:node });
        }
      }
    });
    relaxWalk(cur);
    cur.forEach(function(lab, sid){ addCand(sid, lab.t, lab.node); });
  }
  return cands;
}

function planConnection(oLat, oLng, dLat, dLng, depSec, dateStr, maxTransfers, nowDay){
  const t0 = performance.now();
  if (!PL.ready || PL.dateKey !== dateStr) plannerInit(dateStr);
  if (!PL.trips || !PL.trips.size)
    return { error: 'Brak aktywnych kursów na dzień ' + dateStr + ' (sprawdź kalendarz).' };
  const acc = nearStops([oLat, oLng], PLCFG.ACCESS_M);
  if (!acc.length) return { error: 'Brak przystanków w promieniu 1,5 km od punktu A.' };
  const egr = nearStops([dLat, dLng], PLCFG.ACCESS_M);
  if (!egr.length) return { error: 'Brak przystanków w promieniu 1,5 km od punktu B.' };
  const egrMap = new Map();
  for (let i = 0; i < egr.length; i++) egrMap.set(egr[i].sid, egr[i]);

  /* ZAPEŁNIANIE: szukaj aż FILL_TARGET różnych linii (lub 3 h horyzontu);
     UI doczepia kolejne karty przy przewijaniu */
  const bySig = new Map();
  let dep = depSec, rounds = 0;
  let kept = [];
  while (rounds < PLCFG.FILL_ROUNDS){
    rounds++;
    const cands = searchRound(oLat, oLng, dLat, dLng, acc, egrMap, dep, maxTransfers);
    let maxFirst = -1;
    for (let i = 0; i < cands.length; i++){
      const c = cands[i];
      const ex = bySig.get(c.sig);
      if (!ex || c.arrive < ex.arrive){
        if (!c._n){ normalizeTransfers(c); c._n = true; }
        bySig.set(c.sig, c);
      }
      if (c.firstDep != null && c.firstDep > maxFirst) maxFirst = c.firstDep;
    }
    kept = rationalKeep(dedupeFinalLine(paretoKeep(Array.from(bySig.values()))), nowDay);
    if (kept.length >= PLCFG.FILL_TARGET) break;
    if (maxFirst >= 0) dep = Math.max(dep + 300, maxFirst + 60);
    else dep += PLCFG.MAX_WAIT;
    if (dep > depSec + PLCFG.FILL_HORIZON) break;
  }

  const arr = kept;
  const dDirect = havM([oLat, oLng], [dLat, dLng]);
  let walk = null;
  if (dDirect <= 4500) walk = { sec: walkSec(dDirect), dist: dDirect };
  return { journeys: arr.slice(0, PLCFG.LIST_CAP), total: arr.length, walk: walk,
    depSec: depSec, dateStr: dateStr, stats: { ms: Math.round(performance.now() - t0),
      trips: PL.trips.size, stops: PL.stopSrv.size, live: PL.liveTids.size, rounds: rounds } };
}
window.PLANNER = {
  plan: planConnection, init: plannerInit, applyLive: plannerApplyLive,
  setSpeed: function(kmh){ PL.speedKmh = (kmh === 10) ? 10 : 5; },
  PL: PL, PLCFG: PLCFG, havM: havM, walkSec: walkSec
};