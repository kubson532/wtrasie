'use strict';
/* app_3.js — ekran trasy, rysowanie mapy, bąbelki, sheety.
   FIX: forceSheet→ROUTE_SHEET.force, stop deps jako LISTA, routeDot bez tooltipu. */

const BUS_LINE_C = cssVar('--bus-line-c', '#d95f14');
const BUS_GRAY_C = cssVar('--bus-gray-c', '#8b95a0');

function stopPos(sid){ const s = G.stops.get(sid); return s ? [s.lat, s.lon] : null; }
function stopName(sid){ const s = G.stops.get(sid); return s ? s.name : ('#' + sid); }
/* FIX: bez tooltipu — klik otwiera bąbelek (koniec z podwójnym dymkiem) */
function routeDot(latlng, sid, gray){
  const m = L.circleMarker(latlng, { renderer: svgRenderer,
    radius: 6, weight: 4, color: gray ? BUS_GRAY_C : BUS_LINE_C, fillColor: '#ffffff', fillOpacity: 1 });
  m.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
  const hit = L.circleMarker(latlng, { renderer: svgRenderer,
    radius: 15, opacity: 0, fillOpacity: 0, fill: false, interactive: true });
  hit.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
  return L.layerGroup([m, hit]);
}
function pinIcon(letter, cls){
  return L.divIcon({ className:'pp-wrap', iconSize:[26,38], iconAnchor:[13,36],
    html:'<div class="pp ' + cls + '"><b>' + letter + '</b></div>' });
}
const shapeSliceCache = new Map();
function shapeSlice(shapeId, fromPt, toPt){
  const key = shapeId + '|' + fromPt[0].toFixed(5) + ',' + fromPt[1].toFixed(5) + '|' + toPt[0].toFixed(5) + ',' + toPt[1].toFixed(5);
  if (shapeSliceCache.has(key)) return shapeSliceCache.get(key);
  let out = null;
  const pts = shapePoints(shapeId);
  if (pts && pts.length >= 2){
    let bi = -1, bd = Infinity, ai = -1, ad = Infinity;
    for (let i = 0; i < pts.length; i++){
      const p = [pts[i][1], pts[i][2]];
      const d1 = PLANNER.havM(p, fromPt); if (d1 < bd){ bd = d1; bi = i; }
      const d2 = PLANNER.havM(p, toPt);   if (d2 < ad){ ad = d2; ai = i; }
    }
    if (bi >= 0 && ai >= 0 && bi !== ai && bd < 300 && ad < 300){
      out = [];
      const lo = Math.min(bi, ai), hi = Math.max(bi, ai);
      for (let i = lo; i <= hi; i++) out.push([pts[i][1], pts[i][2]]);
    }
  }
  shapeSliceCache.set(key, out);
  return out;
}
const LNC = { key:null, map:new Map() };
function lineInfo(lineId){
  const ds = feedDateStr();
  if (LNC.key !== ds){ LNC.key = ds; LNC.map = new Map(); }
  if (LNC.map.has(lineId)) return LNC.map.get(lineId);
  ensureActive();
  const act = S.activeCache;
  const groups = new Map();
  G.trips.forEach(function(tr, tid){
    if (tr.route_id !== lineId) return;
    if (act && !act.has(tr.service_id)) return;
    const st = tripStops(tid);
    if (!st || st.length < 2) return;
    const key = tr.headsign || ('Kierunek ' + lineId);
    let g = groups.get(key);
    if (!g){ g = { headsign: tr.headsign || ('Kierunek ' + lineId), tids: [], repStops: 0, rep: null, shapeId: tr.shape_id }; groups.set(key, g); }
    g.tids.push(tid);
    if (st.length > g.repStops){ g.repStops = st.length; g.rep = tid; g.shapeId = tr.shape_id; }
  });
  const out = Array.from(groups.values());
  out.sort(function(a,b){ return a.headsign.localeCompare(b.headsign, 'pl'); });
  LNC.map.set(lineId, out);
  return out;
}
function variantIdxForTrip(lineId, tid){
  if (tid == null) return 0;
  const vs = lineInfo(lineId);
  for (let i = 0; i < vs.length; i++)
    if (vs[i].tids.indexOf(String(tid)) >= 0) return i;
  return 0;
}

let stopPopup = null;
function showStopPop(sid){
  const s = G.stops.get(sid);
  if (!s) return;
  if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  const html = '<div class="spb"><span class="spb-n">' + esc(s.name) + '</span>' +
    '<button class="spb-go" data-sid="' + esc(sid) + '" title="Otwórz przystanek"><svg class="ic"><use href="#i-arrow"/></svg></button></div>';
  stopPopup = L.popup({ closeButton:false, className:'stop-bubble', offset:[0,-8], autoPan:false })
    .setLatLng([s.lat, s.lon]).setContent(html).openOn(map);
}
document.addEventListener('click', function(e){
  const g = e.target.closest('.spb-go');
  if (g && g.dataset.sid){
    if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
    openRoute('stop', { stopId: g.dataset.sid, from: 'map' });
  }
});

function openRoute(mode, opts){
  opts = opts || {};
  if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  focusLayer.clearLayers();
  dotLayer.clearLayers();
  if (mode === 'journey' && opts.journey === 'walk') mode = 'walk';
  const f = { mode: mode, from: (CUR === 'route' ? 'map' : CUR), tab: null,
    journey: (mode === 'journey') ? opts.journey : null,
    lineId: opts.lineId || null,
    varIdx: (opts.varIdx != null) ? opts.varIdx : 0,
    fromStop: opts.fromStop || null,
    stopId: opts.stopId || null,
    tid: opts.tid || null,
    vid: opts.vid || null };
  if (mode === 'line') f.tab = opts.fromStop ? 'deps' : 'stops';
  if (mode === 'stop') f.tab = 'dep';
  ROUTE.stack.push(f);
  renderRoute();
  go('route', true);
  drawRouteMap(f, true);
  refreshVisibility();
  if (ROUTE_SHEET && (mode === 'stop' || mode === 'vehicle')) ROUTE_SHEET.force(2);
}
function routeTitle(f){
  const t = $('#route-title');
  if (f.mode === 'journey'){
    const xt = f.journey.transfers === 0 ? 'bezpośrednio' : (f.journey.transfers + ' przesiadki');
    t.innerHTML = '<b>Połączenie</b><small>' + xt + ' · na miejscu ' + fmtT(f.journey.arrive) + '</small>';
  } else if (f.mode === 'walk'){
    t.innerHTML = '<b>Pieszo</b><small>' + fmtDist(PLUI.last ? PLANNER.havM([PLUI.last.a.lat, PLUI.last.a.lng], [PLUI.last.b.lat, PLUI.last.b.lng]) : 0) + '</small>';
  } else if (f.mode === 'line'){
    const r = G.routes.get(f.lineId);
    const vs = lineInfo(f.lineId);
    t.innerHTML = '<b>Linia ' + esc(r ? r.short : f.lineId) + '</b><small>' + vs.length + (vs.length === 1 ? ' wariant' : ' warianty') + '</small>';
  } else if (f.mode === 'trip'){
    const tr = G.trips.get(String(f.tid));
    const r = tr && G.routes.get(tr.route_id);
    t.innerHTML = '<b>Kurs ' + esc(r ? r.short : (tr ? tr.route_id : '?')) + '</b><small>' + esc(tr ? tr.headsign : '') + '</small>';
  } else if (f.mode === 'stop'){
    const s = G.stops.get(f.stopId);
    t.innerHTML = s ? '<b>' + esc(s.name) + '</b><small>przystanek ' + esc(s.code || s.id) + (s.zone ? ' · strefa ' + esc(s.zone) : '') + '</small>' : '<b>Przystanek</b>';
  } else {
    const v = S.vehicles.get(f.vid);
    t.innerHTML = v ? '<b>Linia ' + esc(v.lineName) + '</b><small>' + esc(v.trip ? v.trip.headsign : '') + '</small>' : '<b>Pojazd</b>';
  }
}
function renderRoute(keepScroll){
  const f = routeActive();
  if (!f) return;
  routeTitle(f);
  const tabs = $('#route-tabs'), vars = $('#route-variants'), content = $('#route-content');
  const sc = keepScroll ? content.scrollTop : 0;
  Live.items = [];
  let tabsHtml = '';
  if (f.mode === 'line'){
    if (f.fromStop) tabsHtml += '<button class="rtab' + (f.tab === 'deps' ? ' on' : '') + '" data-tab="deps"><svg class="ic"><use href="#i-clock"/></svg>Odjazdy</button>';
    tabsHtml += '<button class="rtab' + (f.tab === 'stops' ? ' on' : '') + '" data-tab="stops"><svg class="ic"><use href="#i-pin"/></svg>Przystanki</button>';
  } else if (f.mode === 'stop'){
    tabsHtml = '<button class="rtab' + (f.tab === 'dep' ? ' on' : '') + '" data-tab="dep"><svg class="ic"><use href="#i-clock"/></svg>Odjazdy</button>' +
               '<button class="rtab' + (f.tab === 'sch' ? ' on' : '') + '" data-tab="sch"><svg class="ic"><use href="#i-bus"/></svg>Linie</button>';
  }
  tabs.innerHTML = tabsHtml;
  tabs.hidden = !tabsHtml;
  if (f.mode === 'line'){
    const vs = lineInfo(f.lineId);
    let vh = '';
    for (let i = 0; i < vs.length; i++){
      vh += '<button class="vchip' + (i === f.varIdx ? ' on' : '') + '" data-var="' + i + '">' + esc(vs[i].headsign) + '<small>' + vs[i].tids.length + ' kurs.</small></button>';
    }
    vars.innerHTML = vh;
    vars.hidden = !vs.length;
  } else vars.hidden = true;
  if (f.mode === 'journey') content.innerHTML = journeyTimelineHtml(f);
  else if (f.mode === 'walk') content.innerHTML = walkTimelineHtml();
  else if (f.mode === 'line'){
    if (f.tab === 'deps') content.innerHTML = lineDepsHtml(f);
    else content.innerHTML = lineStopsHtml(f);
  }
  else if (f.mode === 'trip') content.innerHTML = tripHtml(f);
  else if (f.mode === 'stop') content.innerHTML = stopContentHtml(f);
  else content.innerHTML = vehicleHtml(f);
  content.scrollTop = sc;
  tickLive();
  if (f.mode === 'vehicle'){
    requestAnimationFrame(function(){
      const nowEl = content.querySelector('.now') || content.querySelector('li.end');
      if (nowEl) content.scrollTop = nowEl.offsetTop - content.clientHeight/2 + nowEl.offsetHeight/2;
    });
  }
}
function walkTimelineHtml(){
  const PP = PLUI.last;
  if (!PP) return '<div class="empty">Brak danych.</div>';
  const d = PLANNER.havM([PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]);
  return '<div class="tl"><div class="tl-row">' +
    '<div class="tl-rail"><span class="tl-dot" style="background:var(--ok);border-color:var(--ok)"><svg class="ic"><use href="#i-target"/></svg></span></div>' +
    '<div class="tl-main"><b>Start</b><small>' + esc(PP.a.label || '') + '</small></div></div>' +
    '<div class="tl-row"><div class="tl-rail"><span class="tl-dot"><svg class="ic"><use href="#i-walk"/></svg></span></div>' +
    '<div class="tl-main"><b>Pieszo · ' + fmtDist(d) + '</b><small id="walk-dur">~' + fmtDur(PLANNER.walkSec(d)) + '</small></div></div>' +
    '<div class="tl-row"><div class="tl-rail"><span class="tl-dot" style="background:var(--accent);border-color:var(--accent)"><svg class="ic"><use href="#i-target"/></svg></span></div>' +
    '<div class="tl-main"><b>Cel</b><small>' + esc(PP.b.label || '') + '</small></div></div></div>';
}
function journeyTimelineHtml(f){
  const j = f.journey;
  const ds0 = dayStartUnix();
  let idc = 0, rideNo = 0;
  const out = [];
  const PP = PLUI.last;
  function row(rail, main, time, sub){
    return '<div class="tl-row' + (sub ? ' tl-sub' : '') + '"' + (sub ? ' data-sid="' + sub + '"' : '') + '>' +
      '<div class="tl-rail">' + rail + '</div>' +
      '<div class="tl-main">' + main + '</div>' +
      '<div class="tl-time">' + time + '</div></div>';
  }
  out.push(row(
    '<span class="tl-dot" style="background:var(--ok);border-color:var(--ok)"><svg class="ic"><use href="#i-target"/></svg></span>',
    '<b>Start</b>' + (PP && PP.a && PP.a.label ? '<small>' + esc(PP.a.label) + '</small>' : ''),
    '<b>' + fmtT(PP ? PP.depSec : 0) + '</b>'
  ));
  for (let i = 0; i < j.legs.length; i++){
    const leg = j.legs[i];
    if (leg.type === 'walk'){
      out.push(row(
        '<span class="tl-dot"><svg class="ic"><use href="#i-walk"/></svg></span>',
        '<b>Przejdź · ' + fmtDist(leg.dist) + '</b><small>~' + fmtDur(leg.vDur || leg.sec) + '</small>',
        '<b>~' + fmtDur(leg.vDur || leg.sec) + '</b>'
      ));
    } else {
      const r = G.routes.get(leg.routeId);
      const lineShort = r ? r.short : leg.routeId;
      const color = legColor(rideNo); rideNo++;
      out.push(row(
        '<span class="tl-dot" style="background:' + color + ';border-color:' + color + '"><b>' + esc(lineShort) + '</b></span>',
        '<b>Wsiądź · linia ' + esc(lineShort) + '</b><small>' + esc(leg.headsign || '') + '</small>',
        timeCell(null, ds0 + leg.depS, null, 'jt' + (idc++) + '_w')
      ));
      const tRows = tripRowsLive(leg.tid) || [];
      for (let k = leg.boardIdx + 1; k < leg.alightIdx && k < tRows.length; k++){
        const w = tRows[k];
        if (!w) continue;
        out.push(row('<span class="tl-sdot"></span>',
          '<b>' + esc(stopName(w.sid)) + '</b>',
          timeCell(w.depL, ds0 + w.dep, w.delay, 'jt' + (idc++) + '_'), w.sid));
      }
      const al = tRows[leg.alightIdx];
      out.push(row(
        '<span class="tl-dot"><svg class="ic"><use href="#i-pin"/></svg></span>',
        '<b>Wysiądź · ' + esc(stopName(leg.alightSid)) + '</b>',
        al ? timeCell(al.depL, ds0 + al.dep, al.delay, 'jt' + (idc++) + '_') : '<b>' + fmtT(leg.arr) + '</b>'
      ));
      const nx = j.legs[i + 1];
      if (nx && nx.type === 'ride'){
        out.push(row(
          '<span class="tl-dot"><svg class="ic"><use href="#i-refresh"/></svg></span>',
          '<b>Przesiadka</b><small>oczekiwanie ' + fmtDur(Math.max(0, nx.dep - leg.arr)) + '</small>',
          '<b>' + fmtDur(Math.max(0, nx.dep - leg.arr)) + '</b>'
        ));
      }
    }
  }
  out.push(row(
    '<span class="tl-dot" style="background:var(--accent);border-color:var(--accent)"><svg class="ic"><use href="#i-target"/></svg></span>',
    '<b>Cel</b>' + (PP && PP.b && PP.b.label ? '<small>' + esc(PP.b.label) + '</small>' : ''),
    '<b>' + fmtT(j.arrive) + '</b>'
  ));
  return '<div class="tl">' + out.join('') + '</div>';
}
/* ===== LISTA odjazdów (nie kafle): nr, cel, czas/min, opóźnienie ===== */
function depListRow(d, pfx){
  const route = d.trip ? G.routes.get(d.trip.route_id) : null;
  const line = route ? route.short : (d.trip ? d.trip.route_id : '·');
  const head = d.trip ? (d.trip.headsign || '—') : '—';
  const vid = S.tripVeh.get(d.tid) || null;
  const v = vid ? S.vehicles.get(vid) : null;
  return '<li data-trip="' + esc(d.tid) + '">' +
    '<span class="bl" style="--c:' + lineColor(d.trip ? d.trip.route_id : line) + '">' + esc(line) + '</span>' +
    '<span class="bd">' + esc(head) + (v && v.n.plate ? ' <small>tab ' + esc(v.n.plate) + '</small>' : '') + '</span>' +
    timeCell(d.rt ? d.est : null, d.depUnix, d.rt ? d.delay : null, pfx) + '</li>';
}
function stopDepsListHtml(sid){
  const all = stopDepartures(sid);
  BOARD.deps = all;
  const deps = all.slice(0, BOARD.limit);
  if (!deps.length) return '<div class="empty">Brak odjazdów dziś.</div>';
  let h = '<ul class="board">';
  for (let i = 0; i < deps.length; i++) h += depListRow(deps[i], 'bd' + i + '_');
  h += '</ul>';
  if (BOARD.limit < all.length) h += '<div class="loadmore">przewiń — więcej (' + (all.length - BOARD.limit) + ')</div>';
  return h;
}
function stopLinesTilesHtml(sid){
  ensureActive();
  const act = S.activeCache, now = clockNow(), ds0 = dayStartUnix();
  const byRoute = new Map();
  const list = G.stopIndex.get(String(sid)) || [];
  for (let i = 0; i < list.length; i++){
    const tid = list[i][0], dep = list[i][2], pu = list[i][3], seq = list[i][1];
    if (pu === 1) continue;
    const tr = G.trips.get(tid);
    if (!tr) continue;
    if (act && !act.has(tr.service_id)) continue;
    let est = ds0 + dep, delay = null;
    const tu = S.tu.get(tid);
    if (tu){
      const lr = liveRowFor(tid, seq);
      if (lr){ if (lr.depL != null) est = lr.depL; delay = lr.delay; }
      else if (tu.delay != null){ est = ds0 + dep + tu.delay; delay = tu.delay; }
    }
    if (est < now - 150) continue;
    let o = byRoute.get(tr.route_id);
    if (!o) byRoute.set(tr.route_id, { routeId: tr.route_id, next: est, delay: delay, tid: tid });
    else if (est < o.next){ o.next = est; o.delay = delay; o.tid = tid; }
  }
  const arr = Array.from(byRoute.values());
  arr.sort(function(a,b){
    const ra = G.routes.get(a.routeId), rb = G.routes.get(b.routeId);
    return natCmp(ra ? ra.short : a.routeId, rb ? rb.short : b.routeId);
  });
  if (!arr.length) return '<div class="empty">Brak linii dziś.</div>';
  let h = '<div class="tgrid">';
  for (let i = 0; i < arr.length; i++){
    const o = arr[i];
    const r = G.routes.get(o.routeId);
    h += '<div class="tile" data-line="' + esc(o.routeId) + '" data-trip="' + esc(o.tid || '') + '">' +
      '<div class="tile-ln">' + esc(r ? r.short : o.routeId) + '</div>' +
      '<div class="tile-t">' + timeCell(S.tu.has(o.tid) ? o.next : null, o.next, o.delay, 'sl' + i + '_') + '</div></div>';
  }
  return h + '</div>';
}
function stopContentHtml(f){
  return (f.tab === 'sch') ? stopLinesTilesHtml(f.stopId) : stopDepsListHtml(f.stopId);
}
function lineDepsHtml(f){
  ensureActive();
  const act = S.activeCache, now = clockNow(), ds0 = dayStartUnix();
  const out = [];
  const list = G.stopIndex.get(String(f.fromStop)) || [];
  for (let i = 0; i < list.length; i++){
    const tid = list[i][0], seq = list[i][1], dep = list[i][2], pu = list[i][3];
    if (pu === 1) continue;
    const tr = G.trips.get(tid);
    if (!tr || tr.route_id !== f.lineId) continue;
    if (act && !act.has(tr.service_id)) continue;
    let est = ds0 + dep, rt = false, delay = null;
    const tu = S.tu.get(tid);
    if (tu){
      rt = true;
      const lr = liveRowFor(tid, seq);
      if (lr){ if (lr.depL != null) est = lr.depL; delay = lr.delay; }
      else if (tu.delay != null){ est = ds0 + dep + tu.delay; delay = tu.delay; }
    }
    if (est < now - 150) continue;
    out.push({ tid: tid, est: est, depUnix: ds0 + dep, rt: rt, delay: delay, trip: tr });
  }
  out.sort(function(a,b){ return a.est - b.est; });
  if (!out.length) return '<div class="empty">Brak odjazdów.</div>';
  let h = '<ul class="board">';
  for (let i = 0; i < out.length; i++) h += depListRow(out[i], 'ld' + i + '_');
  return h + '</ul>';
}
function lineStopsHtml(f){
  const vs = lineInfo(f.lineId);
  const v = vs[f.varIdx];
  if (!v) return '<div class="empty">Brak wariantów dziś.</div>';
  const rows = tripRowsLive(v.rep) || [];
  const ds0 = dayStartUnix();
  const items = [];
  for (let i = 0; i < rows.length; i++){
    const w = rows[i];
    items.push('<li class="end" data-sid="' + esc(w.sid) + '">' +
      '<span class="n">' + esc(stopName(w.sid)) + '</span>' +
      timeCell(w.depL, ds0 + w.dep, w.delay, 'ls' + i + '_') + '</li>');
  }
  return '<ol class="rs-stops">' + items.join('') + '</ol>';
}
/* FIX: linia → tylko nr linii na badge, bez taboru */
function lineVehiclesHtml(f){
  const vs = [];
  S.vehicles.forEach(function(v){ if (v.routeId === f.lineId) vs.push(v); });
  if (!vs.length) return '<div class="empty">Brak pojazdów na żywo.</div>';
  const items = [];
  for (let i = 0; i < vs.length; i++){
    const v = vs[i];
    const tu = v.n.tripId != null ? S.tu.get(String(v.n.tripId)) : null;
    const delay = tu ? tu.delay : null;
    items.push('<button class="veh-row" data-vid="' + esc(v.id) + '">' +
      '<span class="ln-sm">' + esc(v.lineName) + '</span>' +
      '<span class="vr-main"><b>' + esc(v.trip ? v.trip.headsign : v.lineName) + '</b>' +
      (delay != null ? '<small class="' + dlyCls(delay) + '">' + delayText(delay) + '</small>' : '') + '</span>' +
      '<span class="vr-next">szczegóły</span></button>');
  }
  return items.join('');
}
function vehicleHtml(f){
  const v = S.vehicles.get(f.vid);
  if (!v) return '<div class="empty">Pojazd już niedostępny.</div>';
  const n = v.n;
  const rows = (n.tripId != null) ? tripRowsLive(String(n.tripId)) : null;
  const curSeq = n.seq || 0;
  let delay = null;
  if (rows){
    for (let i = 0; i < rows.length; i++) if (rows[i].seq >= curSeq){ delay = rows[i].delay; break; }
    if (delay == null && rows.length) delay = rows[rows.length-1].delay;
  }
  let dHtml = '';
  if (rows){
    const ds0 = dayStartUnix();
    const items = [];
    for (let i = 0; i < rows.length; i++){
      const w = rows[i];
      const passed = (curSeq > 0 && w.seq < curSeq);
      const isNow = (w.seq === curSeq);
      items.push('<li class="' + (isNow ? 'now' : '') + (passed ? ' passed' : '') + '" data-sid="' + esc(w.sid) + '">' +
        '<span class="n">' + esc(stopName(w.sid)) + '</span>' +
        (!passed ? timeCell(w.depL, ds0 + w.dep, w.delay, 'vs' + i + '_')
                 : '<span class="mcol"><span class="mclock">' + fmtUnix(w.depL != null ? w.depL : ds0 + w.dep) + '</span></span>') + '</li>');
    }
    dHtml = '<ol class="rs-stops">' + items.join('') + '</ol>';
  } else {
    dHtml = '<div class="empty">Brak kursu w GTFS — tylko dane live.</div>';
  }
  const spd = (n.speed != null) ? Math.round(n.speed * 3.6) : null;
  const occ = (n.occupancy != null && OCC_TXT[n.occupancy]) ? OCC_TXT[n.occupancy] : null;
  const stTxt = (n.status != null && STATUS_TXT[n.status]) ? STATUS_TXT[n.status] : '';
  return '<div class="rs-card"><span class="ln-sm">' + esc(v.lineName) + '</span>' +
    '<div><b>' + esc(v.trip ? v.trip.headsign : 'Kurs') + '</b>' +
    '<small>' + esc([n.plate ? 'tab. ' + n.plate : '', n.label ? 'tabor ' + n.label : ''].filter(Boolean).join(' · ') || '—') + '</small>' +
    '<small>' + esc([stTxt, spd != null ? '~' + spd + ' km/h' : '', occ].filter(Boolean).join(' · ')) + '</small></div></div>' +
    (delay != null ? '<div style="padding:0 2px 8px">' + dlyTag(delay) + '</div>' : '') +
    dHtml +
    '<div class="rs-acts"><button id="rt-line"><svg class="ic"><use href="#i-bus"/></svg>Pokaż linię</button></div>';
}
function tripHtml(f){
  const tr = G.trips.get(String(f.tid));
  if (!tr) return '<div class="empty">Nieznany kurs.</div>';
  const raw = tripStops(String(f.tid));
  const rows = tripRowsLive(String(f.tid)) || [];
  const r = G.routes.get(tr.route_id);
  const lineShort = r ? r.short : tr.route_id;
  const vid = S.tripVeh.get(String(f.tid)) || null;
  const v = vid ? S.vehicles.get(vid) : null;
  let tIdx = -1;
  if (raw) for (let i = 0; i < raw.length; i++) if (String(raw[i][1]) === String(f.fromStop)) { tIdx = i; break; }
  const tRow = tIdx >= 0 ? rows[tIdx] : null;
  const ds0 = dayStartUnix();
  let delay = null;
  if (tRow) delay = tRow.delay;
  const curSeq = v ? (v.n.seq || 0) : 0;
  const items = [];
  for (let i = 0; i < rows.length; i++){
    const w = rows[i];
    const passed = v && w.seq < curSeq;
    const isTarget = (i === tIdx);
    const isNow = v && w.seq === curSeq;
    items.push('<li class="' + (isTarget ? 'end' : '') + (isNow ? ' now' : '') + (passed ? ' passed' : '') + '" data-sid="' + esc(w.sid) + '">' +
      '<span class="n">' + esc(stopName(w.sid)) + (isTarget ? ' · Twój przystanek' : '') + '</span>' +
      (!passed ? timeCell(w.depL, ds0 + w.dep, w.delay, 'tp' + i + '_')
               : '<span class="mcol"><span class="mclock">' + fmtUnix(w.depL != null ? w.depL : ds0 + w.dep) + '</span></span>') + '</li>');
  }
  return '<div class="rs-card"><span class="ln-sm">' + esc(lineShort) + '</span>' +
    '<div><b>' + esc(tr.headsign || lineShort) + '</b>' +
    '<small>' + (tRow ? esc(stopName(f.fromStop)) : '') + '</small></div></div>' +
    (delay != null ? '<div style="padding:0 2px 8px">' + dlyTag(delay) + '</div>' : '') +
    '<ol class="rs-stops">' + items.join('') + '</ol>' +
    '<div class="rs-acts"><button id="rt-line"><svg class="ic"><use href="#i-bus"/></svg>Pokaż linię</button></div>';
}

function fitVisible(bounds, keepZoom){
  if (!bounds || !bounds.isValid()) return;
  const topH = 56;
  let sheetH = 56;
  const sh = $('#route-sheet');
  if (sh) sheetH = sh.getBoundingClientRect().height + 16;
  if (keepZoom && map.getZoom() >= 13){ map.panTo(bounds.getCenter()); return; }
  map.fitBounds(bounds, { paddingTopLeft:[40, topH], paddingBottomRight:[40, sheetH], maxZoom: 14 });
}
function drawRouteMap(f, fit){
  focusLayer.clearLayers();
  dotLayer.clearLayers();
  let bounds = null;
  function addPt(p){ if (!bounds) bounds = L.latLngBounds([p]); else bounds.extend(p); }
  if (f.mode === 'walk'){
    const PP = PLUI.last;
    if (PP){
      focusLayer.addLayer(L.marker([PP.a.lat, PP.a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
      focusLayer.addLayer(L.marker([PP.b.lat, PP.b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
      const coords = (PP.walk && PP.walk.vCoords && PP.walk.vCoords.length > 1) ? PP.walk.vCoords : [[PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]];
      focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color:'#98a2ad', weight:4, dashArray:'2 8' }));
      addPt([PP.a.lat, PP.a.lng]); addPt([PP.b.lat, PP.b.lng]);
      PLANNER.valhallaWalk([[PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]]).then(function(v){
        if (v && v.coords && v.coords.length > 1 && routeActive() === f){
          PP.walk = PP.walk || {};
          PP.walk.vCoords = v.coords;
          focusLayer.clearLayers(); dotLayer.clearLayers();
          drawRouteMap(f, false);
          const el = document.getElementById('walk-dur');
          if (el) el.textContent = '~' + fmtDur(PLANNER.walkSec(v.dist || 0)) + ' · chodniki';
        }
      }).catch(function(){});
    }
  } else if (f.mode === 'journey'){
    const PP = PLUI.last;
    if (PP){
      focusLayer.addLayer(L.marker([PP.a.lat, PP.a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
      focusLayer.addLayer(L.marker([PP.b.lat, PP.b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
      addPt([PP.a.lat, PP.a.lng]); addPt([PP.b.lat, PP.b.lng]);
    }
    const legs = f.journey.legs;
    let rideNo = 0;
    for (let i = 0; i < legs.length; i++){
      const leg = legs[i];
      if (leg.type === 'walk'){
        const fp = leg.fromPt ? [leg.fromPt.lat, leg.fromPt.lng] : stopPos(leg.fromSid);
        const tp = leg.toPt ? [leg.toPt.lat, leg.toPt.lng] : stopPos(leg.toSid);
        if (fp && tp){
          const coords = leg.vCoords && leg.vCoords.length > 1 ? leg.vCoords : [fp, tp];
          focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color:'#98a2ad', weight:4, dashArray:'2 8' }));
          addPt(fp); addPt(tp);
        }
      } else {
        const color = legColor(rideNo); rideNo++;
        const coords = rideCoordsOf(leg);
        if (coords && coords.length > 1){
          focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color: color, weight: 5, opacity:.95 }));
          for (let c = 0; c < coords.length; c += 2) addPt(coords[c]);
        }
        const tr = G.trips.get(leg.tid);
        const bvid = tr && S.tripVeh.get(String(leg.tid));
        const bv = bvid ? S.vehicles.get(bvid) : null;
        const boardPt = stopPos(leg.boardSid);
        if (bv && boardPt && (bv.n.seq || 0) <= leg.boardIdx){
          let gcoords = null;
          if (tr && tr.shape_id) gcoords = shapeSlice(tr.shape_id, boardPt, [bv.cur.lat, bv.cur.lng]);
          if (!gcoords){
            gcoords = [[bv.cur.lat, bv.cur.lng]];
            const raw = tripStops(leg.tid) || [];
            let cIdx = 0;
            for (let k = 0; k < raw.length; k++) if (raw[k][0] <= (bv.n.seq || 0)) cIdx = k;
            for (let k = cIdx; k <= leg.boardIdx && k < raw.length; k++){
              const p = stopPos(raw[k][1]); if (p) gcoords.push(p);
            }
            gcoords.push(boardPt);
          }
          if (gcoords && gcoords.length > 1)
            focusLayer.addLayer(L.polyline(gcoords, { renderer: svgRenderer, color: BUS_GRAY_C, weight: 4, opacity: .9 }));
          const raw = tripStops(leg.tid) || [];
          let cIdx = 0;
          for (let k = 0; k < raw.length; k++) if (raw[k][0] <= (bv.n.seq || 0)) cIdx = k;
          for (let k = cIdx; k <= leg.boardIdx && k < raw.length; k++){
            const p = stopPos(raw[k][1]);
            if (p){ dotLayer.addLayer(routeDot(p, String(raw[k][1]), true)); addPt(p); }
          }
        }
        const rows = tripStops(leg.tid);
        if (rows){
          for (let k = leg.boardIdx; k <= leg.alightIdx && k < rows.length; k++){
            const p = stopPos(rows[k][1]);
            if (p){ dotLayer.addLayer(routeDot(p, String(rows[k][1]), false)); addPt(p); }
          }
        }
      }
    }
  } else if (f.mode === 'line'){
    const vs = lineInfo(f.lineId);
    const vr = vs[f.varIdx];
    if (vr){
      const shp = shapePoints(vr.shapeId);
      if (shp){
        const ll = shp.map(function(p){ return [p[1], p[2]]; });
        focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .92 }));
        for (let i = 0; i < ll.length; i += 2) addPt(ll[i]);
      }
      const rows = tripStops(vr.rep);
      if (rows){
        for (let i = 0; i < rows.length; i++){
          const p = stopPos(rows[i][1]);
          if (p){ dotLayer.addLayer(routeDot(p, String(rows[i][1]), false)); addPt(p); }
        }
      }
    }
  } else if (f.mode === 'vehicle'){
    const v = S.vehicles.get(f.vid);
    if (v){
      const shp = shapePoints(v.trip && v.trip.shape_id);
      if (shp){
        const ll = shp.map(function(p){ return [p[1], p[2]]; });
        focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .9 }));
      }
      const rows = (v.n.tripId != null) ? tripStops(String(v.n.tripId)) : null;
      if (rows){
        for (let i = 0; i < rows.length; i++){
          const p = stopPos(rows[i][1]);
          if (p) dotLayer.addLayer(routeDot(p, String(rows[i][1]), false));
        }
      }
      if (fit) map.setView([v.to.lat, v.to.lng], Math.max(map.getZoom(), 13));
    }
  } else if (f.mode === 'trip'){
    const tr = G.trips.get(String(f.tid));
    const raw = tripStops(String(f.tid)) || [];
    const shp = shapePoints(tr && tr.shape_id);
    if (shp){
      const ll = shp.map(function(p){ return [p[1], p[2]]; });
      focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .9 }));
      for (let i = 0; i < ll.length; i += 2) addPt(ll[i]);
    }
    let tIdx = -1;
    for (let i = 0; i < raw.length; i++) if (String(raw[i][1]) === String(f.fromStop)) { tIdx = i; break; }
    for (let i = 0; i < raw.length; i++){
      const p = stopPos(raw[i][1]);
      if (p){ dotLayer.addLayer(routeDot(p, String(raw[i][1]), false)); addPt(p); }
    }
    if (tIdx >= 0){
      const p = stopPos(raw[tIdx][1]);
      if (p) focusLayer.addLayer(L.circleMarker(p, { renderer: svgRenderer, radius: 10, weight: 4, color: '#ff5c1a', fillColor: '#fff', fillOpacity: 1, interactive: false }));
    }
  } else if (f.mode === 'stop'){
    const s = G.stops.get(f.stopId);
    if (s){
      focusLayer.addLayer(L.circleMarker([s.lat, s.lon], { renderer: svgRenderer,
        radius: 10, weight: 4, color: '#ff5c1a', fillColor: '#fff', fillOpacity: 1, interactive: false }));
      if (fit) map.setView([s.lat, s.lon], Math.max(map.getZoom(), 15));
    }
  }
  syncDotVis();
  if (fit && bounds && bounds.isValid()){
    fitVisible(bounds, true);
  }
}
function rideCoordsOf(leg){
  const b = stopPos(leg.boardSid), a = stopPos(leg.alightSid);
  if (b && a){
    const trip = G.trips.get(leg.tid);
    if (trip && trip.shape_id){
      const s = shapeSlice(trip.shape_id, b, a);
      if (s) return s;
    }
  }
  const rows = tripStops(leg.tid);
  if (rows){
    const out = [];
    for (let i = leg.boardIdx; i <= leg.alightIdx; i++){
      const p = stopPos(rows[i][1]); if (p) out.push(p);
    }
    if (out.length > 1) return out;
  }
  return (b && a) ? [b, a] : null;
}
 $('#route-fitbtn').addEventListener('click', function(){
  const f = routeActive();
  if (f) drawRouteMap(f, true);
});
 $('#route-tabs').addEventListener('click', function(e){
  const b = e.target.closest('[data-tab]');
  const f = routeActive();
  if (b && f){ f.tab = b.dataset.tab; renderRoute(); }
});
 $('#route-variants').addEventListener('click', function(e){
  const b = e.target.closest('[data-var]');
  const f = routeActive();
  if (b && f){ f.varIdx = +b.dataset.var; renderRoute(); drawRouteMap(f, true); }
});
 $('#route-content').addEventListener('click', function(e){
  const f = routeActive();
  if (!f) return;
  const tile = e.target.closest('.tile');
  if (tile){
    if (tile.dataset.trip){
      const tr = G.trips.get(tile.dataset.trip);
      if (tr) openRoute('trip', { tid: tile.dataset.trip, lineId: tr.route_id,
        fromStop: (f.mode === 'line' || f.mode === 'stop') ? (f.fromStop || f.stopId) : null });
      return;
    }
    if (tile.dataset.line){
      openRoute('line', { lineId: tile.dataset.line,
        varIdx: variantIdxForTrip(tile.dataset.line, tile.dataset.trip || null),
        fromStop: (f.mode === 'stop') ? f.stopId : null });
      return;
    }
  }
  const vehRow = e.target.closest('.veh-row');
  if (vehRow && vehRow.dataset.vid){ openRoute('vehicle', { vid: vehRow.dataset.vid }); return; }
  const stopRow = e.target.closest('[data-sid]');
  if (stopRow){
    const p = stopPos(stopRow.dataset.sid);
    if (p) map.setView(p, Math.max(map.getZoom(), 15));
    showStopPop(stopRow.dataset.sid);
    return;
  }
  if (e.target.closest('#rt-line')){
    let lineId = null, tid = null;
    if (f.mode === 'vehicle'){ const v = S.vehicles.get(f.vid); lineId = v && v.routeId; tid = v && v.n.tripId; }
    else if (f.mode === 'trip'){ const tr = G.trips.get(String(f.tid)); lineId = tr && tr.route_id; tid = f.tid; }
    if (lineId) openRoute('line', { lineId: lineId, varIdx: variantIdxForTrip(lineId, tid), from: 'route' });
  }
});
 $('#route-content').addEventListener('scroll', function(){
  const f = routeActive();
  const el = $('#route-content');
  if (!f || f.mode !== 'stop' || f.tab !== 'dep') return;
  if (el.scrollTop + el.clientHeight > el.scrollHeight - 140){
    if (BOARD.limit < BOARD.deps.length){
      BOARD.limit += 20;
      renderRoute(true);
    }
  }
});

function makeSheetDrag(sheet, grip, heightsFn, storeKey, onTap){
  function saveIdx(i){ try { localStorage.setItem(storeKey, String(i)); } catch (e){} }
  function apply(i, anim){
    idx = Math.max(0, Math.min(heightsFn().length - 1, i));
    if (!anim) sheet.classList.add('noanim');
    sheet.style.height = heightsFn()[idx] + 'px';
    if (!anim) requestAnimationFrame(function(){ sheet.classList.remove('noanim'); });
    saveIdx(idx);
  }
  let idx = 1;
  try { idx = Math.max(0, Math.min(heightsFn().length - 1, +(localStorage.getItem(storeKey) || 1))); } catch (e){}
  apply(idx, false);
  let sy = 0, sh = 0, drag = false, vy = 0, lastY = 0, lastT = 0, moved = false;
  grip.addEventListener('touchstart', function(e){
    drag = true; moved = false;
    sy = e.touches[0].clientY;
    sh = sheet.getBoundingClientRect().height;
    vy = 0; lastY = sy; lastT = Date.now();
    sheet.classList.add('noanim');
  }, { passive: true });
  grip.addEventListener('touchmove', function(e){
    if (!drag) return;
    const y = e.touches[0].clientY;
    if (Math.abs(y - sy) > 4) moved = true;
    let h = sh + (sy - y);
    const H = heightsFn();
    if (h < H[0]) h = H[0];
    if (h > H[H.length - 1]) h = H[H.length - 1];
    sheet.style.height = h + 'px';
    const t = Date.now();
    if (t > lastT) vy = (y - lastY) / (t - lastT);
    lastY = y; lastT = t;
  }, { passive: true });
  function end(){
    if (!drag) return;
    drag = false;
    sheet.classList.remove('noanim');
    const H = heightsFn();
    const cur = sheet.getBoundingClientRect().height;
    let ni = 0;
    if (vy > 0.7){ ni = 0; for (let i = 0; i < H.length; i++) if (H[i] < cur - 2) ni = i; }
    else if (vy < -0.7){ ni = H.length - 1; for (let i = H.length - 1; i >= 0; i--) if (H[i] > cur + 2) ni = i; }
    else { let bd = 1e9; for (let i = 0; i < H.length; i++){ const d = Math.abs(H[i] - cur); if (d < bd){ bd = d; ni = i; } } }
    apply(ni, true);
  }
  grip.addEventListener('touchend', end);
  grip.addEventListener('touchcancel', end);
  grip.addEventListener('click', function(){ if (!moved && onTap) onTap(apply, idx); });
  window.addEventListener('resize', function(){ apply(idx, false); });
  return {
    apply: apply,
    force: function(i){
      const H = heightsFn();
      const h = H[Math.max(0, Math.min(H.length - 1, i))];
      sheet.classList.add('noanim');
      sheet.style.height = h + 'px';
      requestAnimationFrame(function(){ sheet.classList.remove('noanim'); });
    },
    getIdx: function(){ return idx; }
  };
}
let routeLastOpen = 1;
const ROUTE_SHEET = makeSheetDrag($('#route-sheet'), $('#rs-grip'),
  function(){ return [44, Math.round(innerHeight * .20), Math.round(innerHeight * .45), Math.min(Math.round(innerHeight * .85), innerHeight - 60)]; },
  'ztm-sheet-route',
  function(apply, idx){
    if (idx === 0) apply(Math.max(1, routeLastOpen), true);
    else { routeLastOpen = idx; apply(0, true); }
  });
makeSheetDrag($('#home-sheet'), $('#hs-grip'),
  function(){ return [44, Math.round(innerHeight * .42)]; },
  'ztm-sheet-home',
  function(apply, idx){ apply(idx === 0 ? 1 : 0, true); });
makeSheetDrag($('#lines-sheet'), $('#ls-grip'),
  function(){ return [44, Math.round(innerHeight * .40)]; },
  'ztm-sheet-lines',
  function(apply, idx){ apply(idx === 0 ? 1 : 0, true); });