'use strict';
/* app.js — ZESTAW 20260924c (pojedynczy plik).
   FIX: lineColor przywrócony; klik w przystanek działa (crash ustąpił);
   selektor dnia rozkładu; Valhalla valhalla1 (działający); priorytet
   szukajki linia→tabor→rejestracja; kafle bez liczników; litera strefy. */

const APP_VER = '20260924c';
(function versionCheck(){
  const m = document.querySelector('meta[name="app-ver"]');
  if (!m || m.getAttribute('content') !== APP_VER){
    document.body.innerHTML = '<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;background:#0b0d10;color:#eceae4;font:14px/1.6 system-ui;text-align:center">Niezgodne wersje plików.<br>Nadpisz <b>index.php</b> i <b>js/app.js</b> z zestawu 20260924c i odśwież.</div>';
    throw new Error('version mismatch');
  }
})();

const CFG = {
  RT: [
    { url: 'https://www.mpkrzeszow.pl/gtfs/rt/gtfsrt.pb', label: 'API — bezpośrednio' },
    { url: '?_rt=1', label: 'API — proxy PHP' },
    { url: '?_rt=1&cached=1', label: 'ostatnia dobra kopia', cache: true }
  ],
  GTFS_DIR: 'gtfs/',
  REFRESH_MS: 10000
};
const PERF = { mobile:false, animMs:900 };
(function(){
  try { PERF.mobile = matchMedia('(pointer: coarse)').matches || innerWidth <= 700; }
  catch (e){ PERF.mobile = innerWidth <= 700; }
  PERF.animMs = PERF.mobile ? 700 : 900;
})();
const QPB = (function(){ try { return new URLSearchParams(location.search).get('pb') === '1'; } catch (e){ return false; } })();

/* ===== narzędzia ===== */
function $(s){ return document.querySelector(s); }
function p2(n){ return String(n).padStart(2, '0'); }
function esc(s){
  s = (s == null) ? '' : String(s);
  return s.replace(/[&<>"']/g, function(c){
    return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]; });
}
function cssVar(name, fallback){
  try { const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim(); return v || fallback; }
  catch (e){ return fallback; }
}
function hmsToSec(s){
  if (!s) return null;
  const a = s.split(':');
  if (a.length < 3) return null;
  const h = +a[0], m = +a[1], x = +a[2];
  if (!isFinite(h)) return null;
  return h*3600 + m*60 + x;
}
function fmtSD(sec){ if (sec == null) return '–:–';
  return p2(Math.floor(sec/3600)%24) + ':' + p2(Math.floor(sec/60)%60); }
function fmtUnix(u){ if (!isFinite(u)) return '--:--';
  const d = new Date(u*1000); return p2(d.getHours()) + ':' + p2(d.getMinutes()); }
function fmtUnixS(u){ if (!isFinite(u)) return '--:--:--';
  const d = new Date(u*1000); return p2(d.getHours())+':'+p2(d.getMinutes())+':'+p2(d.getSeconds()); }
function fmtDist(m){ return m < 1000 ? Math.round(m) + ' m' : (m/1000).toFixed(1) + ' km'; }
function fmtDur(sec){ const m = Math.max(1, Math.round(sec/60));
  if (m < 60) return m + ' min';
  return Math.floor(m/60) + ' h ' + (m%60) + ' min'; }
function fmtT(sec){
  const m = Math.floor(sec/60), h = Math.floor(m/60), day = Math.floor(h/24);
  const s = p2(h%24) + ':' + p2(m%60);
  return day > 0 ? s + ' (+1d)' : s;
}
function fmtMin(d){
  if (d <= 45) return 'teraz';
  if (d < 3600) return Math.ceil(d/60) + 'min';
  const mm = Math.ceil(d/60);
  return Math.floor(mm/60) + 'h' + p2(mm%60);
}
function delayText(sec){
  if (sec == null) return null;
  const m = Math.round(Math.abs(sec)/60);
  if (m === 0) return 'na czas';
  return sec > 0 ? ('opóźnienie ' + m + ' min') : ('przyspieszenie ' + m + ' min');
}
function dlyCls(sec){ return (sec != null && sec < 0) ? 'md-early' : 'md-late'; }
function dlyTag(sec){
  if (sec == null) return '';
  return '<span class="bdel ' + dlyCls(sec) + '">' + delayText(sec) + '</span>';
}
function baseName(s){ return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
function natCmp(a,b){ return String(a).localeCompare(String(b),'pl',{numeric:true}); }
function easeOut(t){ return 1 - Math.pow(1 - t, 3); }
function toast(msg, err){
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : '');
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(function(){ t.style.transition = 'opacity .4s'; t.style.opacity = '0';
    setTimeout(function(){ t.remove(); }, 420); }, 5000);
}
window.addEventListener('error', function(e){ if (e && e.message) toast('Błąd JS: ' + e.message, true); });
window.addEventListener('unhandledrejection', function(e){
  const r = e.reason;
  toast('Błąd asynchr.: ' + ((r && r.message) ? r.message : String(r)), true);
});
const CYCLE = ['#5b8def','#e8590c','#2f9e44','#9c36b5','#e03131','#0c8599','#f08c00','#6741d9','#20c997','#c2255c'];
function legColor(i){ return CYCLE[i % CYCLE.length]; }
/* FIX: przywrócone — usunięte przez pomyłkę, kładło cały openRoute */
function lineColor(key){
  let h = 0; const s = String(key);
  for (let i = 0; i < s.length; i++) h = (h*31 + s.charCodeAt(i)) >>> 0;
  const PAL = ['#F5C244','#F09C3F','#E9702E','#E2512C','#C94D38','#B8562F','#9BA846','#6FA46B','#4FA98E','#3E9AA6','#6E93AC','#8C8A56'];
  return PAL[h % PAL.length];
}

function toks(s){
  s = String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  s = s.replace(/\//g, ' ');
  const raw = s.split(/[^a-z0-9]+/);
  const out = [];
  for (let i = 0; i < raw.length; i++){
    const t = raw[i];
    if (!t || t === 'nz' || /^\d+$/.test(t)) continue;
    out.push(t);
  }
  return out;
}
function matchScore(qt, st){
  if (!qt.length) return 0;
  let sc = 0;
  for (let i = 0; i < qt.length; i++){
    const q = qt[i];
    let best = 0;
    for (let j = 0; j < st.length; j++){
      const t = st[j];
      if (t === q){ best = 3; break; }
      if (t.indexOf(q) === 0 && best < 2) best = 2;
      else if (t.indexOf(q) > 0 && best < 1) best = 1;
    }
    if (!best) return -1;
    sc += best;
  }
  return sc;
}

/* liczniki live — po ID, rozwiązywane po renderze */
const Live = { items: [] };
function liveAdd(id, t){ Live.items.push({ id: id, t: t }); }
function tickLive(){
  if (document.hidden) return;
  const now = clockNow();
  const alive = [];
  for (let i = 0; i < Live.items.length; i++){
    const it = Live.items[i];
    const el = document.getElementById(it.id);
    if (el){ el.textContent = fmtMin(it.t - now); alive.push(it); }
  }
  Live.items = alive;
  const c = $('#clock'); if (c) c.textContent = fmtUnixS(now);
}
function timeCell(depL, schedAbs, delay, pfx){
  let h = '<span class="mcol">';
  if (depL != null){
    h += '<span class="mmain" id="' + pfx + 'e"></span>';
    liveAdd(pfx + 'e', depL);
    if (delay != null && delay > 60) h += '<span class="mdelay md-late">+' + Math.round(delay/60) + ' min</span>';
    else if (delay != null && delay < -60) h += '<span class="mdelay md-early">−' + Math.round(-delay/60) + ' min</span>';
  } else if (schedAbs != null){
    h += '<span class="mclock big">' + fmtUnix(schedAbs) + '</span>';
  }
  h += '</span>';
  return h;
}

/* ===== GTFS statyczny ===== */
const G = { routes:new Map(), trips:new Map(), stops:new Map(), stopTimes:new Map(),
  stopIndex:new Map(), shapes:new Map(), calRows:[], calDates:new Map(), stopArea:new Map(), feedInfo:null };
let stopsArray = [];
function parseCSVLine(l){
  if (l.indexOf('"') < 0) return l.split(',');
  const out = []; let cur = '', q = false;
  for (let i = 0; i < l.length; i++){
    const c = l[i];
    if (q){ if (c === '"'){ if (l[i+1] === '"'){ cur += '"'; i++; } else q = false; } else cur += c; }
    else { if (c === '"') q = true; else if (c === ','){ out.push(cur); cur = ''; } else cur += c; }
  }
  out.push(cur); return out;
}
async function fetchGTFS(file, reqCol){
  const att = [CFG.GTFS_DIR + file, '?_gf=' + encodeURIComponent(file)];
  let lastErr = '';
  for (let i = 0; i < att.length; i++){
    try {
      const res = await fetch(att[i], { cache: 'force-cache' });
      if (!res.ok){ lastErr = 'HTTP ' + res.status; continue; }
      const text = await res.text();
      if (text.slice(0, 400).replace(/^\uFEFF/, '').indexOf(reqCol) < 0){ lastErr = 'to nie ' + file; continue; }
      return text;
    } catch (e){ lastErr = e.message; }
  }
  throw new Error('Nie udało się wczytać ' + file + ' (' + lastErr + ')');
}
function tableRows(text){
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  const lines = text.split('\n');
  while (lines.length && lines[lines.length-1].trim() === '') lines.pop();
  const cols = {};
  parseCSVLine(lines[0]).forEach(function(h, i){ cols[h.trim()] = i; });
  return { cols: cols, lines: lines };
}
function ldFile(name){ const li = document.createElement('li');
  li.innerHTML = esc(name) + ' <i>…</i>'; $('#ld-files').appendChild(li); return li; }
function ldOk(li, info){ li.classList.add('done'); li.querySelector('i').textContent = info; }
async function loadStatic(){
  const plan = [
    ['feed_info.txt','feed_publisher_name',false], ['routes.txt','route_id',false],
    ['trips.txt','trip_id',true], ['stops.txt','stop_id',true],
    ['stop_areas.txt','stop_id',false],
    ['calendar_dates.txt','service_id',false], ['calendar.txt','service_id',false],
    ['stop_times.txt','trip_id',true], ['shapes.txt','shape_id',false]
  ];
  let done = 0;
  for (let p = 0; p < plan.length; p++){
    const file = plan[p][0], req = plan[p][1], mand = plan[p][2];
    const li = ldFile(file);
    $('#ld-msg').textContent = 'Wczytywanie ' + file + '…';
    let text = null;
    try { text = await fetchGTFS(file, req); } catch (e){ if (mand) throw e; }
    if (text == null){ ldOk(li, 'pominięty'); done++;
      $('#ld-bar').style.width = (done/plan.length*100)+'%'; continue; }
    const t = tableRows(text), cols = t.cols, lines = t.lines;
    if (file === 'feed_info.txt'){
      const r = parseCSVLine(lines[1] || ''); G.feedInfo = {};
      for (const k in cols) G.feedInfo[k] = r[cols[k]];
    } else if (file === 'routes.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.route_id]) continue;
        G.routes.set(c[cols.route_id], { id:c[cols.route_id],
          short:c[cols.route_short_name] || c[cols.route_id], long:c[cols.route_long_name] || '' }); }
    } else if (file === 'trips.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.trip_id]; if (!id) continue;
        G.trips.set(id, { route_id:c[cols.route_id], service_id:c[cols.service_id],
          headsign:c[cols.trip_headsign] || '', shape_id:c[cols.shape_id] || '', brigade:c[cols.brigade] || '' }); }
    } else if (file === 'stops.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.stop_id]; if (!id) continue;
        const s = { id:id, code:c[cols.stop_code] || '', name:c[cols.stop_name] || id,
          lat:+c[cols.stop_lat], lon:+c[cols.stop_lon],
          street:c[cols.street_name] || '', town:c[cols.town_name] || '', zone:c[cols.zone_id] || '' };
        G.stops.set(id, s); stopsArray.push(s); }
    } else if (file === 'stop_areas.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const aid = c[cols.area_id], sid = c[cols.stop_id];
        if (!aid || !sid) continue;
        G.stopArea.set(sid, aid);
        const st = G.stops.get(sid);
        if (st && !st.zone) st.zone = aid;
      }
    } else if (file === 'calendar_dates.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.service_id]) continue;
        const d = c[cols.date];
        if (!G.calDates.has(d)) G.calDates.set(d, []);
        G.calDates.get(d).push([c[cols.service_id], c[cols.exception_type]]); }
    } else if (file === 'calendar.txt'){
      const dn = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.service_id]) continue;
        const mask = [];
        for (let d = 0; d < 7; d++) mask.push(c[cols[dn[d]]] === '1');
        G.calRows.push({ sid:c[cols.service_id], mask:mask, start:c[cols.start_date], end:c[cols.end_date] }); }
    } else if (file === 'stop_times.txt'){
      const iT=cols.trip_id, iA=cols.arrival_time, iD=cols.departure_time, iS=cols.stop_id,
            iQ=cols.stop_sequence, iP=(cols.pickup_type!==undefined)?cols.pickup_type:-1,
            iO=(cols.drop_off_type!==undefined)?cols.drop_off_type:-1;
      let t0 = performance.now();
      for (let i = 1; i < lines.length; i++){
        const l = lines[i]; if (l === '') continue;
        const c = (l.indexOf('"') < 0) ? l.split(',') : parseCSVLine(l);
        const tid = c[iT]; if (!tid) continue;
        const seq = +c[iQ] || 0, sid = c[iS]; if (!sid) continue;
        let arr = hmsToSec(c[iA]), dep = hmsToSec(c[iD]);
        if (arr == null) arr = dep; if (dep == null) dep = arr; if (dep == null) continue;
        const pu = (iP >= 0) ? ((c[iP] === '') ? 0 : +c[iP]) : 0;
        const dof = (iO >= 0) ? ((c[iO] === '') ? 0 : +c[iO]) : 0;
        let tt = G.stopTimes.get(tid); if (!tt){ tt = []; G.stopTimes.set(tid, tt); }
        tt.push([seq, sid, arr, dep, pu, dof]);
        let ss = G.stopIndex.get(sid); if (!ss){ ss = []; G.stopIndex.set(sid, ss); }
        ss.push([tid, seq, dep, pu]);
        if ((i & 65535) === 0 && performance.now() - t0 > 40){
          $('#ld-bar').style.width = ((done + i/lines.length)/plan.length*100)+'%';
          $('#ld-msg').textContent = 'stop_times… ' + ((i/lines.length*100)|0) + '%';
          await new Promise(function(r){ setTimeout(r); }); t0 = performance.now();
        }
      }
    } else if (file === 'shapes.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.shape_id]; if (!id) continue;
        let a = G.shapes.get(id); if (!a){ a = []; G.shapes.set(id, a); }
        a.push([+c[cols.shape_pt_sequence] || 0, +c[cols.shape_pt_lat], +c[cols.shape_pt_lon]]); }
    }
    ldOk(li, (text.length/1024).toFixed(0) + ' KB');
    done++; $('#ld-bar').style.width = (done/plan.length*100)+'%';
    await new Promise(function(r){ setTimeout(r, 10); });
  }
}
function tripStops(tid){
  const a = G.stopTimes.get(tid); if (!a) return null;
  if (!a._s){ a.sort(function(x,y){ return x[0]-y[0]; }); a._s = true; }
  return a;
}
function shapePoints(id){
  const a = G.shapes.get(id); if (!a || !a.length) return null;
  if (!a._s){ a.sort(function(x,y){ return x[0]-y[0]; }); a._s = true; }
  return a;
}

/* ===== stan ===== */
const S = { vehicles:new Map(), tu:new Map(), alerts:[], tripVeh:new Map(),
  feedBase: Math.floor(Date.now()/1000), feedReal: Date.now(),
  routeFilter:null, firstFit:false, refreshing:false,
  errToasted:false, activeCache:null, activeDate:null, pickHide:false };
const SEL = { stop:null };
const ROUTE = { stack:[] };
const PLUI = { a:null, b:null, last:null };
const BOARD = { limit:20, deps:[] };
const STOPS = { q:'', limit:40, sorted:null };
const ALERTS = { sig:null, dismissed:null };
const REC = { routes:[], stops:[] };
const SDAY = { cur:'today', list:null };
function routeActive(){ return ROUTE.stack.length ? ROUTE.stack[ROUTE.stack.length-1] : null; }
function clockNow(){ return S.feedBase + (Date.now() - S.feedReal)/1000; }
function dayStartUnix(){ const d = new Date(S.feedBase*1000); d.setHours(0,0,0,0); return Math.floor(d.getTime()/1000); }
function feedDateStr(){ const d = new Date(S.feedBase*1000);
  return d.getFullYear() + '-' + p2(d.getMonth()+1) + '-' + p2(d.getDate()); }
function activeServices(ds){
  const set = new Set(); const g = ds.replace(/-/g, '');
  const dow = new Date(ds + 'T12:00:00').getDay();
  const idx = (dow === 0) ? 6 : dow - 1;
  for (let i = 0; i < G.calRows.length; i++){
    const c = G.calRows[i];
    if (g >= c.start && g <= c.end && c.mask[idx]) set.add(c.sid);
  }
  const ex = G.calDates.get(g);
  if (ex) for (let i = 0; i < ex.length; i++){
    if (ex[i][1] === '1') set.add(ex[i][0]); else set.delete(ex[i][0]);
  }
  return set.size ? set : null;
}
function ensureActive(){
  const ds = feedDateStr();
  if (S.activeDate !== ds){ S.activeCache = activeServices(ds); S.activeDate = ds; }
}
const STATUS_TXT = ['dojeżdża do przystanku','na przystanku','w trasie'];
const OCC_TXT = ['pusty','dużo miejsc','kilka miejsc','tylko stojące','ścisk','pełny','nie przyjmuje pasażerów'];
const CAUSE_TXT = ['przyczyna nieznana','inna przyczyna','usterka techn.','strajk','demonstracja','wypadek','święto','pogoda','konserwacja','remont','policja','incydent med.'];
const EFFECT_TXT = ['skutek nieznany','inny skutek','brak kursów','ograniczony rozkład','istotne opóźnienia','objazd','kursy dodatkowe','zmieniony rozkład','przystanek przeniesiony','brak skutku','utrudnienia dla wózków'];

function tripRowsLive(tid){
  const rows = tripStops(tid);
  if (!rows) return null;
  const tu = S.tu.get(String(tid));
  const ds0 = dayStartUnix();
  const out = [];
  if (!tu){
    for (let i = 0; i < rows.length; i++)
      out.push({ sid:String(rows[i][1]), seq:rows[i][0], dep:rows[i][3], depL:null, delay:null });
    return out;
  }
  const stuBySeq = new Map();
  const stus = tu.stops || [];
  for (let i = 0; i < stus.length; i++)
    if (stus[i].seq != null) stuBySeq.set(stus[i].seq, stus[i]);
  let carry = (tu.delay != null) ? tu.delay : null;
  for (let i = 0; i < rows.length; i++){
    const r = rows[i];
    const stu = stuBySeq.get(r[0]);
    if (stu){
      if (stu.depDelay != null) carry = stu.depDelay;
      else if (stu.arrDelay != null) carry = stu.arrDelay;
    }
    let depL = null;
    if (stu){
      if (stu.depTime) depL = stu.depTime;
      else if (stu.arrTime) depL = stu.arrTime;
    }
    if (depL == null) depL = ds0 + r[3] + (carry != null ? carry : 0);
    out.push({ sid:String(r[1]), seq:r[0], dep:r[3], depL:depL, delay:carry });
  }
  return out;
}
function liveRowFor(tid, seq){
  const rows = tripRowsLive(tid);
  if (!rows) return null;
  for (let i = 0; i < rows.length; i++) if (rows[i].seq === seq) return rows[i];
  return null;
}

/* ===== PROFILE DNIA ROZKŁADU (szkolny/pozaszkolny/sobota/niedziela) ===== */
function buildDayProfiles(){
  const sat = new Set(), sun = new Set();
  const wdCount = new Map();      /* service_id → liczba dni roboczych */
  G.calDates.forEach(function(list, date){
    const d8 = date.slice(0,4)+'-'+date.slice(4,6)+'-'+date.slice(6,8);
    const wd8 = new Date(d8 + 'T12:00:00').getDay();
    list.forEach(function(row){
      if (row[1] !== '1') return;
      if (wd8 === 6) sat.add(row[0]);
      else if (wd8 === 0) sun.add(row[0]);
      else wdCount.set(row[0], (wdCount.get(row[0])||0) + 1);
    });
  });
  G.calRows.forEach(function(c){
    if (c.mask[5]) sat.add(c.sid);
    if (c.mask[6]) sun.add(c.sid);
    for (let i = 0; i < 5; i++) if (c.mask[i]) wdCount.set(c.sid, (wdCount.get(c.sid)||0) + 1);
  });
  const out = [{ key:'today', label:'Dziś', services:null, live:true }];
  const wdIds = Array.from(wdCount.keys()).sort();
  const letters = ['A','B','C','D'];
  for (let i = 0; i < wdIds.length; i++){
    out.push({ key:'wd_' + wdIds[i],
      label: wdIds.length > 1 ? ('Dzień roboczy ' + letters[i]) : 'Dzień roboczy',
      sub: 's' + wdIds[i],
      services: new Set([wdIds[i]]), live:false });
  }
  if (sat.size) out.push({ key:'sat', label:'Sobota', services:sat, live:false });
  if (sun.size) out.push({ key:'sun', label:'Niedziela / święto', services:sun, live:false });
  return out;
}
function dayProfiles(){
  if (!SDAY.list) SDAY.list = buildDayProfiles();
  return SDAY.list;
}
function curProfile(){
  const ps = dayProfiles();
  for (let i = 0; i < ps.length; i++) if (ps[i].key === SDAY.cur) return ps[i];
  return ps[0];
}
function detectDefaultDay(){
  const act = activeServices(feedDateStr());
  if (!act) return 'today';
  const ps = dayProfiles();
  for (let i = 1; i < ps.length; i++){
    const sv = ps[i].services;
    if (!sv || sv.size !== act.size) continue;
    let same = true;
    act.forEach(function(s){ if (!sv.has(s)) same = false; });
    if (same) return ps[i].key;
  }
  /* dzień roboczy nie pokrywa się 1:1 (np. dziś = szk+po szk.) → dopasuj wg weekday */
  const wd = new Date().getDay();
  if (wd === 6){ for (let i = 1; i < ps.length; i++) if (ps[i].key === 'sat') return 'sat'; }
  if (wd === 0){ for (let i = 1; i < ps.length; i++) if (ps[i].key === 'sun') return 'sun'; }
  if (wd >= 1 && wd <= 5){
    for (let i = 1; i < ps.length; i++)
      if (ps[i].key.indexOf('wd_') === 0 && ps[i].services.size >= (act.size||1)) return ps[i].key;
  }
  return 'today';
}
function daySelectorHtml(){
  const ps = dayProfiles();
  let h = '<div class="vchips" style="padding:0 0 8px">';
  for (let i = 0; i < ps.length; i++){
    h += '<button class="vchip' + (SDAY.cur === ps[i].key ? ' on' : '') + '" data-day="' + i + '">' +
      esc(ps[i].label) + (ps[i].sub ? '<small>' + esc(ps[i].sub) + '</small>' : '') + '</button>';
  }
  return h + '</div>';
}

/* ===== motyw + podkłady ===== */
let THEME_MODE = 'dark', THEME = 'dark';
const BASEMAPS = [
  { id:'dark', name:'Ciemna', desc:'OSM z ciemnym filtrem', filter:'invert(1) hue-rotate(185deg) brightness(.92) contrast(.85) saturate(.45)',
    make:function(){ return L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      { maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }); } },
  { id:'light', name:'Jasna', desc:'standardowy OpenStreetMap', filter:'',
    make:function(){ return L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      { maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }); } },
  { id:'sat', name:'Satelita', desc:'zdjęcia lotnicze (Esri)', filter:'brightness(.95) saturate(.85)',
    make:function(){ return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      { maxZoom:19, attribution:'Imagery &copy; Esri, Maxar, Earthstar Geographics' }); } },
  { id:'topo', name:'Topograficzna', desc:'teren i drogi (Esri Topo)', filter:'',
    make:function(){ return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
      { maxZoom:19, attribution:'&copy; Esri, OpenStreetMap contributors' }); } }
];
const BASE = { id:'dark', layer:null, manual:false };
function setBasemapById(id){
  const b = BASEMAPS.find(function(x){ return x.id === id; }) || BASEMAPS[0];
  BASE.id = b.id;
  if (BASE.layer) map.removeLayer(BASE.layer);
  BASE.layer = b.make().addTo(map);
  const c = BASE.layer.getContainer();
  if (c) c.style.filter = b.filter || 'none';
}
function applyBasemapNow(id){
  setBasemapById(id);
  map.invalidateSize();
  if (BASE.layer && BASE.layer.redraw) BASE.layer.redraw();
}
function saveBasemap(id){ try { localStorage.setItem('ztm-basemap', id); } catch (e){} }
function chooseBasemap(id){
  BASE.manual = true;
  saveBasemap(id);
  renderSettings();
  if (CUR !== 'map'){ go('map'); setTimeout(function(){ applyBasemapNow(id); }, 160); }
  else applyBasemapNow(id);
}
function setTheme(t){
  THEME = t;
  document.documentElement.setAttribute('data-theme', t);
  $('#btn-theme').innerHTML = '<svg class="ic"><use href="#i-' + (t === 'dark' ? 'sun' : 'moon') + '"/></svg>';
  const mc = document.querySelector('meta[name=theme-color]');
  if (mc) mc.setAttribute('content', t === 'dark' ? '#0b0d10' : '#e8edf3');
  if (!BASE.manual) setBasemapById(t === 'light' ? 'light' : 'dark');
}
function applyThemeMode(mode){
  THEME_MODE = mode;
  try { localStorage.setItem('ztm-theme', mode); } catch (e){}
  let t = mode;
  if (mode === 'auto'){
    try { t = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'; }
    catch (e){ t = 'dark'; }
  }
  setTheme(t);
  renderSettings();
}
function renderSettings(){
  document.querySelectorAll('#set-theme [data-v]').forEach(function(b){
    b.classList.toggle('on', b.dataset.v === THEME_MODE);
  });
  $('#set-maps').innerHTML = BASEMAPS.map(function(m){
    return '<button class="set-map' + (BASE.id === m.id ? ' on' : '') + '" data-m="' + m.id + '">' +
      '<span class="sw sw-' + m.id + '"></span>' +
      '<span class="sm"><b>' + m.name + '</b><small>' + m.desc + '</small></span></button>';
  }).join('');
}
 $('#set-theme').addEventListener('click', function(e){
  const b = e.target.closest('[data-v]');
  if (b) applyThemeMode(b.dataset.v);
});
 $('#set-maps').addEventListener('click', function(e){
  const b = e.target.closest('[data-m]');
  if (b) chooseBasemap(b.dataset.m);
});
 $('#btn-theme').addEventListener('click', function(){ applyThemeMode(THEME === 'dark' ? 'light' : 'dark'); });
 $('#btn-settings').addEventListener('click', function(){ go('settings'); });
 $('#btn-layers').addEventListener('click', function(){
  let i = 0;
  for (let k = 0; k < BASEMAPS.length; k++) if (BASEMAPS[k].id === BASE.id) i = k;
  const nb = BASEMAPS[(i + 1) % BASEMAPS.length];
  BASE.manual = true; saveBasemap(nb.id); applyBasemapNow(nb.id);
  toast('Podkład: ' + nb.name);
});

/* ===== mapa ===== */
const map = L.map('map', { zoomControl:false, attributionControl:true, markerZoomAnimation:!PERF.mobile });
map.setView([50.0413, 21.9990], 13);
map.attributionControl.setPrefix('');
const focusLayer = L.layerGroup().addTo(map);
const dotLayer = L.layerGroup().addTo(map);
const pointLayer = L.layerGroup().addTo(map);
const gpsLayer = L.layerGroup().addTo(map);
const trailLayer = L.layerGroup().addTo(map);
const stopRenderer = L.canvas({ padding:.4 });
const svgRenderer = L.svg({ padding:.3 });
let stopLayerFull = null, stopLayerThin = null;
function buildStopLayers(){
  stopLayerFull = L.layerGroup();
  stopLayerThin = L.layerGroup();
  const grid = new Map();
  const CELL = 0.002;
  let i = 0;
  const total = stopsArray.length;
  function chunk(){
    if (document.hidden){ requestAnimationFrame(chunk); return; }
    const end = Math.min(i + 500, total);
    for (; i < end; i++){
      const s = stopsArray[i];
      if (!isFinite(s.lat) || !isFinite(s.lon)) continue;
      const sid = s.id;
      const m = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:4.5,
        weight:2, color:'#98a2ad', fillColor:'#39404a', fillOpacity:1 });
      m.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
      m.addTo(stopLayerFull);
      const hit = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:14,
        opacity:0, fillOpacity:0, fill:false, interactive:true });
      hit.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
      hit.addTo(stopLayerFull);
      const k = Math.floor(s.lat / CELL) + '_' + Math.floor(s.lon / CELL);
      if (!grid.has(k)){
        grid.set(k, 1);
        const m2 = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:4.5,
          weight:2, color:'#98a2ad', fillColor:'#39404a', fillOpacity:1 });
        m2.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
        m2.addTo(stopLayerThin);
      }
    }
    if (i < total) requestAnimationFrame(chunk); else updateStopsVis();
  }
  requestAnimationFrame(chunk);
}
function updateStopsVis(){
  if (!stopLayerFull) return;
  const z = map.getZoom();
  let layer = null;
  if (CUR === 'map' && !S.pickHide){
    if (z >= 15) layer = stopLayerFull;
    else if (z >= 13) layer = stopLayerThin;
  }
  if (stopLayerFull !== layer && map.hasLayer(stopLayerFull)) map.removeLayer(stopLayerFull);
  if (stopLayerThin !== layer && map.hasLayer(stopLayerThin)) map.removeLayer(stopLayerThin);
  if (layer && !map.hasLayer(layer)) layer.addTo(map);
}
function syncDotVis(){
  if (map.getZoom() >= 11){ if (!map.hasLayer(dotLayer)) dotLayer.addTo(map); }
  else if (map.hasLayer(dotLayer)) map.removeLayer(dotLayer);
}
let mvT = null;
map.on('moveend zoomend', function(){
  clearTimeout(mvT);
  mvT = setTimeout(function(){ refreshVisibility(); updateStopsVis(); syncDotVis(); syncDirVis(); }, 80);
});
map.on('dragstart', function(){ if (GPS.followCam) GPS.followCam = false; });
map.on('click', function(e){
  if (PICK){ setPlanPoint(PICK, e.latlng.lat, e.latlng.lng); return; }
});

/* ===== GPS + ślad ===== */
const GPS = { on:false, lat:null, lng:null, watch:null, marker:null, ring:null, followCam:false };
const TRAIL = { pts: [] };
function trailAdd(lat, lng){
  const t = Date.now();
  TRAIL.pts = TRAIL.pts.filter(function(p){ return t - p.t < 300000; });
  const last = TRAIL.pts[TRAIL.pts.length - 1];
  if (last && PLANNER.havM([last.lat, last.lng], [lat, lng]) < 5){ last.t = t; return; }
  TRAIL.pts.push({ lat: lat, lng: lng, t: t });
  if (TRAIL.pts.length > 150) TRAIL.pts.shift();
  trailRedraw();
}
function trailRedraw(){
  trailLayer.clearLayers();
  if (TRAIL.pts.length < 2){
    if (TRAIL.pts.length === 1)
      L.circleMarker([TRAIL.pts[0].lat, TRAIL.pts[0].lng], { radius:3, weight:1, color:'#fff', fillColor:'#2f8fff', fillOpacity:.9, interactive:false }).addTo(trailLayer);
    return;
  }
  const ll = TRAIL.pts.map(function(p){ return [p.lat, p.lng]; });
  L.polyline(ll, { color:'#2f8fff', weight:3, opacity:.55, interactive:false }).addTo(trailLayer);
  for (let i = 0; i < ll.length; i++)
    L.circleMarker(ll[i], { radius:3, weight:1, color:'#fff', fillColor:'#2f8fff', fillOpacity:.9, interactive:false }).addTo(trailLayer);
}
function setGpsFieldText(){
  const inp = $('#hp-a');
  const row = $('#hp-a-row');
  if (GPS.on){
    inp.value = 'Moja lokalizacja (aktywna)';
    row.classList.add('gps-on');
  } else {
    if (inp.value.indexOf('Moja lokalizacja') === 0) inp.value = '';
    row.classList.remove('gps-on');
  }
}
function toggleGps(){
  if (GPS.on){
    if (GPS.watch != null) navigator.geolocation.clearWatch(GPS.watch);
    GPS.on = false; GPS.followCam = false; GPS.watch = null;
    gpsLayer.clearLayers(); GPS.marker = null; GPS.ring = null;
    TRAIL.pts = []; trailLayer.clearLayers();
    $('#btn-gps').classList.remove('on');
    setGpsFieldText();
    renderStopsList._sig = null; renderStopsList();
    return;
  }
  if (!navigator.geolocation){ toast('Geolokalizacja niedostępna (HTTPS lub localhost)', true); return; }
  GPS.on = true;
  $('#btn-gps').classList.add('on');
  setGpsFieldText();
  GPS.watch = navigator.geolocation.watchPosition(function(p){
    const first = (GPS.lat == null);
    GPS.lat = p.coords.latitude; GPS.lng = p.coords.longitude;
    drawGps(p.coords.accuracy || 0);
    trailAdd(GPS.lat, GPS.lng);
    if (first){ renderStopsList._sig = null; renderStopsList(); }
    if (GPS.followCam && (CUR === 'map')) map.panTo([GPS.lat, GPS.lng], { animate:true, duration:.6 });
  }, function(err){
    toast('Lokalizacja: ' + (err.message || 'brak zgody'), true);
    toggleGps();
  }, { enableHighAccuracy:true, maximumAge:3000, timeout:12000 });
}
function drawGps(accM){
  if (GPS.marker) GPS.marker.setLatLng([GPS.lat, GPS.lng]);
  else {
    GPS.marker = L.marker([GPS.lat, GPS.lng], { zIndexOffset:900, interactive:false,
      icon: L.divIcon({ className:'', iconSize:[16,16], iconAnchor:[8,8], html:'<div class="gps-dot"></div>' }) }).addTo(gpsLayer);
    GPS.followCam = true;
    if (CUR === 'map') map.panTo([GPS.lat, GPS.lng]);
  }
  if (GPS.ring){ GPS.ring.setLatLng([GPS.lat, GPS.lng]); GPS.ring.setRadius(accM || 25); }
  else GPS.ring = L.circle([GPS.lat, GPS.lng], { radius:accM || 25, weight:1,
    color:'#2f8fff', opacity:.5, fillOpacity:.08, interactive:false }).addTo(gpsLayer);
}
 $('#btn-gps').addEventListener('click', toggleGps);

/* ===== SHAPE INDEX ===== */
const SHAPE_IDX = new Map();
function shapeIndex(shapeId){
  if (SHAPE_IDX.has(shapeId)) return SHAPE_IDX.get(shapeId);
  const pts = shapePoints(shapeId);
  if (!pts || pts.length < 2){ SHAPE_IDX.set(shapeId, null); return null; }
  const ll = pts.map(function(p){ return [p[1], p[2]]; });
  const cum = [0];
  for (let i = 1; i < ll.length; i++) cum.push(cum[i-1] + PLANNER.havM(ll[i-1], ll[i]));
  const idx = { pts: ll, cum: cum, total: cum[cum.length-1] };
  SHAPE_IDX.set(shapeId, idx);
  return idx;
}
function projectOnShape(idx, lat, lng){
  let bd = Infinity, bseg = 0, bt = 0, bx = lat, by = lng;
  for (let i = 0; i < idx.pts.length - 1; i++){
    const a = idx.pts[i], b = idx.pts[i+1];
    const dx = b[0]-a[0], dy = b[1]-a[1];
    const len2 = dx*dx + dy*dy;
    let t = 0;
    if (len2 > 0){
      t = ((lat-a[0])*dx + (lng-a[1])*dy) / len2;
      t = Math.max(0, Math.min(1, t));
    }
    const px = a[0] + t*dx, py = a[1] + t*dy;
    const d = PLANNER.havM([lat,lng],[px,py]);
    if (d < bd){ bd = d; bseg = i; bt = t; bx = px; by = py; }
  }
  const dAlong = idx.cum[bseg] + bt * ((idx.cum[bseg+1]-idx.cum[bseg]) || 0);
  return { lat: bx, lng: by, d: dAlong, dist: bd };
}
function pointAtDist(idx, d){
  const cum = idx.cum;
  if (d <= 0) return idx.pts[0];
  if (d >= idx.total) return idx.pts[idx.pts.length-1];
  let lo = 0, hi = cum.length - 1;
  while (lo < hi - 1){ const m = (lo+hi)>>1; if (cum[m] <= d) lo = m; else hi = m; }
  const t = (d - cum[lo]) / ((cum[lo+1]-cum[lo]) || 1);
  const a = idx.pts[lo], b = idx.pts[lo+1];
  return [a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t];
}

/* ===== pojazdy ===== */
function viewBoundsOrNull(){
  if (CUR !== 'map' && CUR !== 'route') return null;
  try { if (map._loaded) return map.getBounds().pad(0.25); } catch (e){}
  return null;
}
function vehVisible(v){
  if (S.pickHide) return false;
  if (CUR === 'route'){
    const f = routeActive();
    if (!f) return false;
    if (f.mode === 'vehicle') return v.id === f.vid;
    if (f.mode === 'line') return v.routeId === f.lineId;
    if (f.mode === 'journey'){
      const legs = f.journey.legs;
      for (let i = 0; i < legs.length; i++)
        if (legs[i].type === 'ride' && v.n && String(v.n.tripId) === String(legs[i].tid)) return true;
      return false;
    }
    if (f.mode === 'trip'){
      const vid = S.tripVeh.get(String(f.tid));
      return !!vid && v.id === vid;
    }
    return false;
  }
  if (S.routeFilter && v.routeId !== S.routeFilter) return false;
  const b = viewBoundsOrNull();
  if (b && !b.contains([v.to.lat, v.to.lng])) return false;
  return true;
}
function attachV(v){
  const el = v.marker.getElement();
  if (el){
    v.el = el;
    v.bodyEl = el.querySelector('.vm-body');
    v.dirEl = el.querySelector('.vm-dir');
    if (v.bodyEl) v.bodyEl.textContent = v.lineName;
    if (v.dirEl) v.dirEl.style.display = (map.getZoom() >= 15) ? '' : 'none';
  }
}
function syncDirVis(){
  const on = map.getZoom() >= 15;
  S.vehicles.forEach(function(v){
    if (v.dirEl && v.dirEl.style.display !== (on ? '' : 'none'))
      v.dirEl.style.display = on ? '' : 'none';
  });
}
function syncVehMarker(v){
  if (CUR !== 'map' && CUR !== 'route') return;
  const vis = vehVisible(v);
  if (vis && !v.onMap){ v.marker.addTo(map); v.onMap = true; attachV(v); }
  else if (!vis && v.onMap){ map.removeLayer(v.marker); v.onMap = false; v.el = v.bodyEl = v.dirEl = null; }
}
function makeBusMarker(line){
  const w = PERF.mobile ? 60 : 56, h = PERF.mobile ? 34 : 30;
  return L.marker([0,0], { zIndexOffset:600, riseOnHover:!PERF.mobile,
    icon: L.divIcon({ className:'vm-wrap', iconSize:[w,h], iconAnchor:[w/2,h/2],
      html:'<div class="vm"><div class="vm-dir"><svg viewBox="0 0 24 24"><path d="M12 3l7 18-7-5.4L5 21z" fill="currentColor" stroke="none"/></svg></div>' +
           '<div class="vm-body">' + esc(line) + '</div></div>' }) });
}
function computeBearing(a, b){
  const dy = b.lat - a.lat, dx = (b.lng - a.lng) * Math.cos(a.lat*Math.PI/180);
  const d = Math.sqrt(dx*dx + dy*dy);
  if (d < 0.00004) return null;
  return (Math.atan2(dx, dy)*180/Math.PI + 360) % 360;
}
function lerpAngle(a, b, k){
  let d = b - a;
  while (d > 180) d -= 360;
  while (d < -180) d += 360;
  return a + d*k;
}
function upsertVehicle(id, n){
  if (n.lat == null || n.lng == null || !isFinite(n.lat) || !isFinite(n.lng)) return null;
  const trip = (n.tripId != null) ? G.trips.get(String(n.tripId)) : null;
  const routeId = (trip && trip.route_id) || n.routeId || null;
  const route = routeId ? G.routes.get(routeId) : null;
  const lineName = (route && route.short) || routeId || '·';
  const now = performance.now();
  let v = S.vehicles.get(id);
  let shpIdx = null, toLat = n.lat, toLng = n.lng, toD = null;
  if (trip && trip.shape_id){
    shpIdx = shapeIndex(trip.shape_id);
    if (shpIdx){
      const pr = projectOnShape(shpIdx, n.lat, n.lng);
      if (pr.dist < 60){ toLat = pr.lat; toLng = pr.lng; toD = pr.d; }
    }
  }
  if (!v){
    v = { id:id, marker: makeBusMarker(lineName),
      from:{lat:toLat,lng:toLng}, to:{lat:toLat,lng:toLng},
      shapeIdx:shpIdx, fromD:toD, toD:toD,
      t0: now - PERF.animMs, cur:{lat:toLat,lng:toLng}, brgShown:null,
      done:true, onMap:false, el:null, bodyEl:null, dirEl:null, tip:lineName };
    v.marker.on('click', function(e){ L.DomEvent.stop(e); openRoute('vehicle', { vid:id, from:'map' }); });
    v.marker.bindTooltip('Linia ' + lineName, { direction:'top', offset:[0,-14] });
    v.marker.setLatLng([toLat, toLng]);
    S.vehicles.set(id, v);
    syncVehMarker(v);
  } else {
    const sameShape = (v.shapeIdx === shpIdx);
    v.shapeIdx = shpIdx;
    v.from = { lat: v.cur.lat, lng: v.cur.lng };
    v.to = { lat: toLat, lng: toLng };
    v.fromD = sameShape ? v.toD : null;
    v.toD = toD;
    let anim = v.onMap && map.getZoom() >= 14;
    if (anim){
      try {
        const p1 = map.latLngToContainerPoint([v.cur.lat, v.cur.lng]);
        const p2 = map.latLngToContainerPoint([toLat, toLng]);
        const dx = p1.x - p2.x, dy = p1.y - p2.y;
        if (dx*dx + dy*dy < 9) anim = false;
        else {
          const vb = viewBoundsOrNull();
          if (vb && !vb.contains([toLat, toLng])) anim = false;
        }
      } catch (e){ anim = false; }
    }
    if (anim){ v.t0 = now; v.done = false; }
    else {
      v.cur = { lat: toLat, lng: toLng };
      v.marker.setLatLng([toLat, toLng]);
      v.t0 = now - PERF.animMs; v.done = true;
    }
    if (v.tip !== lineName){ v.tip = lineName; v.marker.setTooltipContent('Linia ' + lineName); }
    if (v.bodyEl && v.bodyEl.textContent !== lineName) v.bodyEl.textContent = lineName;
    syncVehMarker(v);
  }
  v.n = n; v.trip = trip; v.route = route; v.routeId = routeId;
  v.lineName = lineName;
  return v;
}
function removeVehicle(id){
  const v = S.vehicles.get(id);
  if (!v) return;
  if (v.onMap) map.removeLayer(v.marker);
  S.vehicles.delete(id);
  const f = routeActive();
  if (f && f.mode === 'vehicle' && f.vid === id){
    ROUTE.stack.pop();
    if (!routeActive()) go('map', true);
    else refreshRoute();
    return;
  }
  if (f && f.mode === 'trip' && S.tripVeh.get(String(f.tid)) === id) refreshRoute();
}
function refreshRoute(){
  const f = routeActive();
  if (!f) return;
  renderRoute(true);
  drawRouteMap(f, false);
}
function refreshVisibility(){ S.vehicles.forEach(syncVehMarker); }
function animTick(){
  requestAnimationFrame(animTick);
  if (document.hidden) return;
  animTick._f = !animTick._f;
  if (S.vehicles.size > 40 && animTick._f) return;
  const nowMs = performance.now();
  S.vehicles.forEach(function(v){
    if (!v.onMap || v.done) return;
    let t = (nowMs - v.t0) / PERF.animMs;
    if (!(t > 0)) t = 0;
    if (t >= 1) t = 1;
    const k = easeOut(t);
    if (v.shapeIdx && v.fromD != null && v.toD != null){
      const d = v.fromD + (v.toD - v.fromD) * k;
      const p = pointAtDist(v.shapeIdx, d);
      v.cur.lat = p[0]; v.cur.lng = p[1];
      if (map.getZoom() >= 15){
        const p2 = pointAtDist(v.shapeIdx, Math.min(v.shapeIdx.total, d + 20));
        const brg = computeBearing({lat:p[0],lng:p[1]},{lat:p2[0],lng:p2[1]});
        if (brg != null && v.dirEl) v.dirEl.style.transform = 'rotate(' + brg.toFixed(1) + 'deg)';
      }
    } else {
      v.cur.lat = v.from.lat + (v.to.lat - v.from.lat) * k;
      v.cur.lng = v.from.lng + (v.to.lng - v.from.lng) * k;
    }
    v.marker.setLatLng([v.cur.lat, v.cur.lng]);
    if (t >= 1) v.done = true;
  });
}
requestAnimationFrame(animTick);
const UPQ = { list:[], t:null };
function queueUpserts(list){
  for (let i = 0; i < list.length; i++) UPQ.list.push(list[i]);
  if (!UPQ.t) UPQ.t = setTimeout(processUpserts, 0);
}
function processUpserts(){
  const t0 = performance.now();
  while (UPQ.list.length && performance.now() - t0 < 8){
    const n = UPQ.list.shift();
    upsertVehicle(n.id, n);
  }
  if (UPQ.list.length) UPQ.t = setTimeout(processUpserts, 30);
  else UPQ.t = null;
}

/* ===== pomocnicze trasy ===== */
const BUS_LINE_C = cssVar('--bus-line-c', '#d95f14');
const BUS_GRAY_C = cssVar('--bus-gray-c', '#8b95a0');
function stopPos(sid){ const s = G.stops.get(sid); return s ? [s.lat, s.lon] : null; }
function stopName(sid){ const s = G.stops.get(sid); return s ? s.name : ('#' + sid); }
function routeDot(latlng, sid, gray){
  const m = L.circleMarker(latlng, { renderer: svgRenderer,
    radius: 6, weight: 4, color: gray ? BUS_GRAY_C : BUS_LINE_C, fillColor: '#ffffff', fillOpacity: 1 });
  m.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
  const hit = L.circleMarker(latlng, { renderer: svgRenderer,
    radius: 15, opacity: 0, fillOpacity: 0, fill: false, interactive: true });
  hit.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
  return L.layerGroup([m, hit]);
}
function pinIcon(letter, cls){
  return L.divIcon({ className:'pp-wrap', iconSize:[26,38], iconAnchor:[13,36],
    html:'<div class="pp ' + cls + '"><b>' + letter + '</b></div>' });
}
const shapeSliceCache = new Map();
function shapeSlice(shapeId, fromPt, toPt){
  const key = shapeId + '|' + fromPt[0].toFixed(5) + ',' + fromPt[1].toFixed(5) + '|' + toPt[0].toFixed(5) + ',' + toPt[1].toFixed(5);
  if (shapeSliceCache.has(key)) return shapeSliceCache.get(key);
  let out = null;
  const pts = shapePoints(shapeId);
  if (pts && pts.length >= 2){
    let bi = -1, bd = Infinity, ai = -1, ad = Infinity;
    for (let i = 0; i < pts.length; i++){
      const p = [pts[i][1], pts[i][2]];
      const d1 = PLANNER.havM(p, fromPt); if (d1 < bd){ bd = d1; bi = i; }
      const d2 = PLANNER.havM(p, toPt);   if (d2 < ad){ ad = d2; ai = i; }
    }
    if (bi >= 0 && ai >= 0 && bi !== ai && bd < 300 && ad < 300){
      out = [];
      const lo = Math.min(bi, ai), hi = Math.max(bi, ai);
      for (let i = lo; i <= hi; i++) out.push([pts[i][1], pts[i][2]]);
    }
  }
  shapeSliceCache.set(key, out);
  return out;
}
const LNC = { key:null, map:new Map() };
function lineInfo(lineId){
  const ds = feedDateStr();
  if (LNC.key !== ds){ LNC.key = ds; LNC.map = new Map(); }
  if (LNC.map.has(lineId)) return LNC.map.get(lineId);
  ensureActive();
  const act = S.activeCache;
  const groups = new Map();
  G.trips.forEach(function(tr, tid){
    if (tr.route_id !== lineId) return;
    if (act && !act.has(tr.service_id)) return;
    const st = tripStops(tid);
    if (!st || st.length < 2) return;
    const key = tr.headsign || ('Kierunek ' + lineId);
    let g = groups.get(key);
    if (!g){ g = { headsign: tr.headsign || ('Kierunek ' + lineId), tids: [], repStops: 0, rep: null, shapeId: tr.shape_id }; groups.set(key, g); }
    g.tids.push(tid);
    if (st.length > g.repStops){ g.repStops = st.length; g.rep = tid; g.shapeId = tr.shape_id; }
  });
  const out = Array.from(groups.values());
  out.sort(function(a,b){ return a.headsign.localeCompare(b.headsign, 'pl'); });
  LNC.map.set(lineId, out);
  return out;
}
function variantIdxForTrip(lineId, tid){
  if (tid == null) return 0;
  const vs = lineInfo(lineId);
  for (let i = 0; i < vs.length; i++)
    if (vs[i].tids.indexOf(String(tid)) >= 0) return i;
  return 0;
}

/* ===== bąbelek przystanku ===== */
let stopPopup = null;
function showStopPop(sid){
  const s = G.stops.get(sid);
  if (!s) return;
  if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  const html = '<div class="spb"><span class="spb-n">' + esc(s.name) + '</span>' +
    '<button class="spb-go" data-sid="' + esc(sid) + '" title="Otwórz przystanek"><svg class="ic"><use href="#i-arrow"/></svg></button></div>';
  stopPopup = L.popup({ closeButton:false, className:'stop-bubble', offset:[0,-8], autoPan:false })
    .setLatLng([s.lat, s.lon]).setContent(html).openOn(map);
}
document.addEventListener('click', function(e){
  const g = e.target.closest('.spb-go');
  if (g && g.dataset.sid){
    if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
    openRoute('stop', { stopId: g.dataset.sid, from: 'map' });
  }
});

/* ===== EKRAN TRASY ===== */
function openRoute(mode, opts){
  opts = opts || {};
  if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  focusLayer.clearLayers();
  dotLayer.clearLayers();
  if (mode === 'journey' && opts.journey === 'walk') mode = 'walk';
  const f = { mode: mode, from: (CUR === 'route' ? 'map' : CUR), tab: null,
    journey: (mode === 'journey') ? opts.journey : null,
    lineId: opts.lineId || null,
    varIdx: (opts.varIdx != null) ? opts.varIdx : 0,
    fromStop: opts.fromStop || null,
    stopId: opts.stopId || null,
    tid: opts.tid || null,
    vid: opts.vid || null };
  if (mode === 'line') f.tab = opts.fromStop ? 'deps' : 'stops';
  if (mode === 'stop') f.tab = 'dep';
  ROUTE.stack.push(f);
  renderRoute();
  go('route', true);
  drawRouteMap(f, true);
  refreshVisibility();
  if (ROUTE_SHEET && (mode === 'stop' || mode === 'vehicle')) ROUTE_SHEET.force(2);
}
function routeTitle(f){
  const t = $('#route-title');
  if (f.mode === 'journey'){
    const xt = f.journey.transfers === 0 ? 'bezpośrednio' : (f.journey.transfers + ' przesiadki');
    t.innerHTML = '<b>Połączenie</b><small>' + xt + ' · na miejscu ' + fmtT(f.journey.arrive) + '</small>';
  } else if (f.mode === 'walk'){
    t.innerHTML = '<b>Pieszo</b><small>' + fmtDist(PLUI.last ? PLANNER.havM([PLUI.last.a.lat, PLUI.last.a.lng], [PLUI.last.b.lat, PLUI.last.b.lng]) : 0) + '</small>';
  } else if (f.mode === 'line'){
    const r = G.routes.get(f.lineId);
    const vs = lineInfo(f.lineId);
    t.innerHTML = '<b>Linia ' + esc(r ? r.short : f.lineId) + '</b><small>' + vs.length + (vs.length === 1 ? ' wariant' : ' warianty') + '</small>';
  } else if (f.mode === 'trip'){
    const tr = G.trips.get(String(f.tid));
    const r = tr && G.routes.get(tr.route_id);
    t.innerHTML = '<b>Kurs ' + esc(r ? r.short : (tr ? tr.route_id : '?')) + '</b><small>' + esc(tr ? tr.headsign : '') + '</small>';
  } else if (f.mode === 'stop'){
    const s = G.stops.get(f.stopId);
    t.innerHTML = s ? '<b>' + esc(s.name) + '</b><small>przystanek ' + esc(s.code || s.id) + (s.zone ? ' · strefa ' + esc(s.zone) : '') + '</small>' : '<b>Przystanek</b>';
  } else {
    const v = S.vehicles.get(f.vid);
    t.innerHTML = v ? '<b>Linia ' + esc(v.lineName) + '</b><small>' + esc(v.trip ? v.trip.headsign : '') + '</small>' : '<b>Pojazd</b>';
  }
}
function renderRoute(keepScroll){
  const f = routeActive();
  if (!f) return;
  routeTitle(f);
  const tabs = $('#route-tabs'), vars = $('#route-variants'), content = $('#route-content');
  const sc = keepScroll ? content.scrollTop : 0;
  Live.items = [];
  let tabsHtml = '';
  if (f.mode === 'line'){
    if (f.fromStop) tabsHtml += '<button class="rtab' + (f.tab === 'deps' ? ' on' : '') + '" data-tab="deps"><svg class="ic"><use href="#i-clock"/></svg>Odjazdy</button>';
    tabsHtml += '<button class="rtab' + (f.tab === 'stops' ? ' on' : '') + '" data-tab="stops"><svg class="ic"><use href="#i-pin"/></svg>Przystanki</button>';
  } else if (f.mode === 'stop'){
    tabsHtml = '<button class="rtab' + (f.tab === 'dep' ? ' on' : '') + '" data-tab="dep"><svg class="ic"><use href="#i-clock"/></svg>Odjazdy</button>' +
               '<button class="rtab' + (f.tab === 'sch' ? ' on' : '') + '" data-tab="sch"><svg class="ic"><use href="#i-bus"/></svg>Linie</button>';
  }
  tabs.innerHTML = tabsHtml;
  tabs.hidden = !tabsHtml;
  if (f.mode === 'line'){
    const vs = lineInfo(f.lineId);
    let vh = '';
    for (let i = 0; i < vs.length; i++){
      vh += '<button class="vchip' + (i === f.varIdx ? ' on' : '') + '" data-var="' + i + '">' + esc(vs[i].headsign) + '<small>' + vs[i].tids.length + ' kurs.</small></button>';
    }
    vars.innerHTML = vh;
    vars.hidden = !vs.length;
  } else vars.hidden = true;
  if (f.mode === 'journey') content.innerHTML = journeyTimelineHtml(f);
  else if (f.mode === 'walk') content.innerHTML = walkTimelineHtml();
  else if (f.mode === 'line'){
    if (f.tab === 'deps') content.innerHTML = lineDepsHtml(f);
    else content.innerHTML = lineStopsHtml(f);
  }
  else if (f.mode === 'trip') content.innerHTML = tripHtml(f);
  else if (f.mode === 'stop'){
    content.innerHTML = daySelectorHtml() + stopContentHtml(f);
  }
  else content.innerHTML = vehicleHtml(f);
  content.scrollTop = sc;
  tickLive();
  if (f.mode === 'vehicle'){
    requestAnimationFrame(function(){
      const nowEl = content.querySelector('.now') || content.querySelector('li.end');
      if (nowEl) content.scrollTop = nowEl.offsetTop - content.clientHeight/2 + nowEl.offsetHeight/2;
    });
  }
}
function walkTimelineHtml(){
  const PP = PLUI.last;
  if (!PP) return '<div class="empty">Brak danych.</div>';
  const d = PLANNER.havM([PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]);
  return '<div class="tl"><div class="tl-row">' +
    '<div class="tl-rail"><span class="tl-dot" style="background:var(--ok);border-color:var(--ok)"><svg class="ic"><use href="#i-target"/></svg></span></div>' +
    '<div class="tl-main"><b>Start</b><small>' + esc(PP.a.label || '') + '</small></div></div>' +
    '<div class="tl-row"><div class="tl-rail"><span class="tl-dot"><svg class="ic"><use href="#i-walk"/></svg></span></div>' +
    '<div class="tl-main"><b>Pieszo · ' + fmtDist(d) + '</b><small id="walk-dur">~' + fmtDur(PLANNER.walkSec(d)) + '</small></div></div>' +
    '<div class="tl-row"><div class="tl-rail"><span class="tl-dot" style="background:var(--accent);border-color:var(--accent)"><svg class="ic"><use href="#i-target"/></svg></span></div>' +
    '<div class="tl-main"><b>Cel</b><small>' + esc(PP.b.label || '') + '</small></div></div></div>';
}
function journeyTimelineHtml(f){
  const j = f.journey;
  const ds0 = dayStartUnix();
  let idc = 0, rideNo = 0;
  const out = [];
  const PP = PLUI.last;
  function row(rail, main, time, sub){
    return '<div class="tl-row' + (sub ? ' tl-sub' : '') + '"' + (sub ? ' data-sid="' + sub + '"' : '') + '>' +
      '<div class="tl-rail">' + rail + '</div>' +
      '<div class="tl-main">' + main + '</div>' +
      '<div class="tl-time">' + time + '</div></div>';
  }
  out.push(row(
    '<span class="tl-dot" style="background:var(--ok);border-color:var(--ok)"><svg class="ic"><use href="#i-target"/></svg></span>',
    '<b>Start</b>' + (PP && PP.a && PP.a.label ? '<small>' + esc(PP.a.label) + '</small>' : ''),
    '<b>' + fmtT(PP ? PP.depSec : 0) + '</b>'
  ));
  for (let i = 0; i < j.legs.length; i++){
    const leg = j.legs[i];
    if (leg.type === 'walk'){
      out.push(row(
        '<span class="tl-dot"><svg class="ic"><use href="#i-walk"/></svg></span>',
        '<b>Przejdź · ' + fmtDist(leg.dist) + '</b><small>~' + fmtDur(leg.vDur || leg.sec) + '</small>',
        '<b>~' + fmtDur(leg.vDur || leg.sec) + '</b>'
      ));
    } else {
      const r = G.routes.get(leg.routeId);
      const lineShort = r ? r.short : leg.routeId;
      const color = legColor(rideNo); rideNo++;
      out.push(row(
        '<span class="tl-dot" style="background:' + color + ';border-color:' + color + '"><b>' + esc(lineShort) + '</b></span>',
        '<b>Wsiądź · linia ' + esc(lineShort) + '</b><small>' + esc(leg.headsign || '') + '</small>',
        timeCell(null, ds0 + leg.depS, null, 'jt' + (idc++) + '_w')
      ));
      const tRows = tripRowsLive(leg.tid) || [];
      for (let k = leg.boardIdx + 1; k < leg.alightIdx && k < tRows.length; k++){
        const w = tRows[k];
        if (!w) continue;
        out.push(row('<span class="tl-sdot"></span>',
          '<b>' + esc(stopName(w.sid)) + '</b>',
          timeCell(w.depL, ds0 + w.dep, w.delay, 'jt' + (idc++) + '_'), w.sid));
      }
      const al = tRows[leg.alightIdx];
      out.push(row(
        '<span class="tl-dot"><svg class="ic"><use href="#i-pin"/></svg></span>',
        '<b>Wysiądź · ' + esc(stopName(leg.alightSid)) + '</b>',
        al ? timeCell(al.depL, ds0 + al.dep, al.delay, 'jt' + (idc++) + '_') : '<b>' + fmtT(leg.arr) + '</b>'
      ));
      const nx = j.legs[i + 1];
      if (nx && nx.type === 'ride'){
        out.push(row(
          '<span class="tl-dot"><svg class="ic"><use href="#i-refresh"/></svg></span>',
          '<b>Przesiadka</b><small>oczekiwanie ' + fmtDur(Math.max(0, nx.dep - leg.arr)) + '</small>',
          '<b>' + fmtDur(Math.max(0, nx.dep - leg.arr)) + '</b>'
        ));
      }
    }
  }
  out.push(row(
    '<span class="tl-dot" style="background:var(--accent);border-color:var(--accent)"><svg class="ic"><use href="#i-target"/></svg></span>',
    '<b>Cel</b>' + (PP && PP.b && PP.b.label ? '<small>' + esc(PP.b.label) + '</small>' : ''),
    '<b>' + fmtT(j.arrive) + '</b>'
  ));
  return '<div class="tl">' + out.join('') + '</div>';
}
/* lista odjazdów: nr linii, cel, minuty/godzina, opóźnienie */
function depListRow(d, pfx, useLive){
  const route = d.trip ? G.routes.get(d.trip.route_id) : null;
  const line = route ? route.short : (d.trip ? d.trip.route_id : '·');
  const head = d.trip ? (d.trip.headsign || '—') : '—';
  return '<li data-trip="' + esc(d.tid) + '">' +
    '<span class="bl" style="--c:' + lineColor(d.trip ? d.trip.route_id : line) + '">' + esc(line) + '</span>' +
    '<span class="bd">' + esc(head) + '</span>' +
    timeCell((useLive && d.rt) ? d.est : null, d.depUnix, (useLive && d.rt) ? d.delay : null, pfx) + '</li>';
}
function stopDepartures(stopId, services, useLive){
  const act = services || activeServices(feedDateStr());
  const ds0 = dayStartUnix();
  const now = clockNow();
  const deps = [];
  const list = G.stopIndex.get(String(stopId)) || [];
  for (let i = 0; i < list.length; i++){
    const tid = list[i][0], seq = list[i][1], dep = list[i][2], pu = list[i][3];
    if (pu === 1) continue;
    const trip = G.trips.get(tid);
    if (!trip) continue;
    if (act && !act.has(trip.service_id)) continue;
    const depUnix = ds0 + dep;
    let est = depUnix, rt = false, delay = null;
    if (useLive){
      if (depUnix < now - 150) continue;
      const tu = S.tu.get(tid);
      if (tu){
        rt = true;
        const lr = liveRowFor(tid, seq);
        if (lr){ if (lr.depL != null) est = lr.depL; delay = lr.delay; }
        else if (tu.delay != null){ est = depUnix + tu.delay; delay = tu.delay; }
      }
      if (est < now - 150) continue;
    }
    deps.push({ tid: tid, depUnix: depUnix, est: est, rt: rt, delay: delay, trip: trip });
  }
  deps.sort(function(a,b){ return a.est - b.est; });
  return deps;
}
function stopDepsListHtml(sid){
  const p = curProfile();
  const all = stopDepartures(sid, p.services, p.live);
  BOARD.deps = all;
  const deps = all.slice(0, BOARD.limit);
  if (!deps.length) return '<div class="empty">Brak odjazdów dla tego dnia.</div>';
  let h = '<ul class="board">';
  for (let i = 0; i < deps.length; i++) h += depListRow(deps[i], 'bd' + i + '_', p.live);
  h += '</ul>';
  if (BOARD.limit < all.length) h += '<div class="loadmore">przewiń — więcej (' + (all.length - BOARD.limit) + ')</div>';
  return h;
}
function stopLinesTilesHtml(sid){
  const p = curProfile();
  const all = stopDepartures(sid, p.services, p.live);
  const byRoute = new Map();
  for (let i = 0; i < all.length; i++){
    const d = all[i];
    const rid = d.trip ? d.trip.route_id : '?';
    let o = byRoute.get(rid);
    if (!o) byRoute.set(rid, { routeId: rid, next: d.est, delay: d.delay, tid: d.tid, rt: d.rt });
    else if (d.est < o.next){ o.next = d.est; o.delay = d.delay; o.tid = d.tid; o.rt = d.rt; }
  }
  const arr = Array.from(byRoute.values());
  arr.sort(function(a,b){
    const ra = G.routes.get(a.routeId), rb = G.routes.get(b.routeId);
    return natCmp(ra ? ra.short : a.routeId, rb ? rb.short : b.routeId);
  });
  if (!arr.length) return '<div class="empty">Brak linii dla tego dnia.</div>';
  let h = '<div class="tgrid">';
  for (let i = 0; i < arr.length; i++){
    const o = arr[i];
    const r = G.routes.get(o.routeId);
    h += '<div class="tile" data-line="' + esc(o.routeId) + '" data-trip="' + esc(o.tid || '') + '">' +
      '<div class="tile-ln">' + esc(r ? r.short : o.routeId) + '</div>' +
      '<div class="tile-t">' + timeCell((p.live && o.rt) ? o.next : null, o.next, (p.live && o.rt) ? o.delay : null, 'sl' + i + '_') + '</div></div>';
  }
  return h + '</div>';
}
function stopContentHtml(f){
  return (f.tab === 'sch') ? stopLinesTilesHtml(f.stopId) : stopDepsListHtml(f.stopId);
}
function lineDepsHtml(f){
  ensureActive();
  const act = S.activeCache, now = clockNow(), ds0 = dayStartUnix();
  const out = [];
  const list = G.stopIndex.get(String(f.fromStop)) || [];
  for (let i = 0; i < list.length; i++){
    const tid = list[i][0], seq = list[i][1], dep = list[i][2], pu = list[i][3];
    if (pu === 1) continue;
    const tr = G.trips.get(tid);
    if (!tr || tr.route_id !== f.lineId) continue;
    if (act && !act.has(tr.service_id)) continue;
    let est = ds0 + dep, rt = false, delay = null;
    const tu = S.tu.get(tid);
    if (tu){
      rt = true;
      const lr = liveRowFor(tid, seq);
      if (lr){ if (lr.depL != null) est = lr.depL; delay = lr.delay; }
      else if (tu.delay != null){ est = ds0 + dep + tu.delay; delay = tu.delay; }
    }
    if (est < now - 150) continue;
    out.push({ tid: tid, est: est, depUnix: ds0 + dep, rt: rt, delay: delay, trip: tr });
  }
  out.sort(function(a,b){ return a.est - b.est; });
  if (!out.length) return '<div class="empty">Brak odjazdów.</div>';
  let h = '<ul class="board">';
  for (let i = 0; i < out.length; i++) h += depListRow(out[i], 'ld' + i + '_', true);
  return h + '</ul>';
}
function lineStopsHtml(f){
  const vs = lineInfo(f.lineId);
  const v = vs[f.varIdx];
  if (!v) return '<div class="empty">Brak wariantów dziś.</div>';
  const rows = tripRowsLive(v.rep) || [];
  const ds0 = dayStartUnix();
  const items = [];
  for (let i = 0; i < rows.length; i++){
    const w = rows[i];
    items.push('<li class="end" data-sid="' + esc(w.sid) + '">' +
      '<span class="n">' + esc(stopName(w.sid)) + '</span>' +
      timeCell(w.depL, ds0 + w.dep, w.delay, 'ls' + i + '_') + '</li>');
  }
  return '<ol class="rs-stops">' + items.join('') + '</ol>';
}
function lineVehiclesHtml(f){
  const vs = [];
  S.vehicles.forEach(function(v){ if (v.routeId === f.lineId) vs.push(v); });
  if (!vs.length) return '<div class="empty">Brak pojazdów na żywo.</div>';
  const items = [];
  for (let i = 0; i < vs.length; i++){
    const v = vs[i];
    const tu = v.n.tripId != null ? S.tu.get(String(v.n.tripId)) : null;
    const delay = tu ? tu.delay : null;
    items.push('<button class="veh-row" data-vid="' + esc(v.id) + '">' +
      '<span class="ln-sm">' + esc(v.lineName) + '</span>' +
      '<span class="vr-main"><b>' + esc(v.trip ? v.trip.headsign : v.lineName) + '</b>' +
      (delay != null ? '<small class="' + dlyCls(delay) + '">' + delayText(delay) + '</small>' : '') + '</span>' +
      '<span class="vr-next">szczegóły</span></button>');
  }
  return items.join('');
}
function vehicleHtml(f){
  const v = S.vehicles.get(f.vid);
  if (!v) return '<div class="empty">Pojazd już niedostępny.</div>';
  const n = v.n;
  const rows = (n.tripId != null) ? tripRowsLive(String(n.tripId)) : null;
  const curSeq = n.seq || 0;
  let delay = null;
  if (rows){
    for (let i = 0; i < rows.length; i++) if (rows[i].seq >= curSeq){ delay = rows[i].delay; break; }
    if (delay == null && rows.length) delay = rows[rows.length-1].delay;
  }
  let dHtml = '';
  if (rows){
    const ds0 = dayStartUnix();
    const items = [];
    for (let i = 0; i < rows.length; i++){
      const w = rows[i];
      const passed = (curSeq > 0 && w.seq < curSeq);
      const isNow = (w.seq === curSeq);
      items.push('<li class="' + (isNow ? 'now' : '') + (passed ? ' passed' : '') + '" data-sid="' + esc(w.sid) + '">' +
        '<span class="n">' + esc(stopName(w.sid)) + '</span>' +
        (!passed ? timeCell(w.depL, ds0 + w.dep, w.delay, 'vs' + i + '_')
                 : '<span class="mcol"><span class="mclock">' + fmtUnix(w.depL != null ? w.depL : ds0 + w.dep) + '</span></span>') + '</li>');
    }
    dHtml = '<ol class="rs-stops">' + items.join('') + '</ol>';
  } else {
    dHtml = '<div class="empty">Brak kursu w GTFS — tylko dane live.</div>';
  }
  const spd = (n.speed != null) ? Math.round(n.speed * 3.6) : null;
  const occ = (n.occupancy != null && OCC_TXT[n.occupancy]) ? OCC_TXT[n.occupancy] : null;
  const stTxt = (n.status != null && STATUS_TXT[n.status]) ? STATUS_TXT[n.status] : '';
  return '<div class="rs-card"><span class="ln-sm">' + esc(v.lineName) + '</span>' +
    '<div><b>' + esc(v.trip ? v.trip.headsign : 'Kurs') + '</b>' +
    '<small>' + esc([n.plate ? 'tab. ' + n.plate : '', n.label ? 'tabor ' + n.label : ''].filter(Boolean).join(' · ') || '—') + '</small>' +
    '<small>' + esc([stTxt, spd != null ? '~' + spd + ' km/h' : '', occ].filter(Boolean).join(' · ')) + '</small></div></div>' +
    (delay != null ? '<div style="padding:0 2px 8px">' + dlyTag(delay) + '</div>' : '') +
    dHtml +
    '<div class="rs-acts"><button id="rt-line"><svg class="ic"><use href="#i-bus"/></svg>Pokaż linię</button></div>';
}
function tripHtml(f){
  const tr = G.trips.get(String(f.tid));
  if (!tr) return '<div class="empty">Nieznany kurs.</div>';
  const raw = tripStops(String(f.tid));
  const rows = tripRowsLive(String(f.tid)) || [];
  const r = G.routes.get(tr.route_id);
  const lineShort = r ? r.short : tr.route_id;
  const vid = S.tripVeh.get(String(f.tid)) || null;
  const v = vid ? S.vehicles.get(vid) : null;
  let tIdx = -1;
  if (raw) for (let i = 0; i < raw.length; i++) if (String(raw[i][1]) === String(f.fromStop)) { tIdx = i; break; }
  const tRow = tIdx >= 0 ? rows[tIdx] : null;
  const ds0 = dayStartUnix();
  const delay = tRow ? tRow.delay : null;
  const curSeq = v ? (v.n.seq || 0) : 0;
  const items = [];
  for (let i = 0; i < rows.length; i++){
    const w = rows[i];
    const passed = v && w.seq < curSeq;
    const isTarget = (i === tIdx);
    const isNow = v && w.seq === curSeq;
    items.push('<li class="' + (isTarget ? 'end' : '') + (isNow ? ' now' : '') + (passed ? ' passed' : '') + '" data-sid="' + esc(w.sid) + '">' +
      '<span class="n">' + esc(stopName(w.sid)) + (isTarget ? ' · Twój przystanek' : '') + '</span>' +
      (!passed ? timeCell(w.depL, ds0 + w.dep, w.delay, 'tp' + i + '_')
               : '<span class="mcol"><span class="mclock">' + fmtUnix(w.depL != null ? w.depL : ds0 + w.dep) + '</span></span>') + '</li>');
  }
  return '<div class="rs-card"><span class="ln-sm">' + esc(lineShort) + '</span>' +
    '<div><b>' + esc(tr.headsign || lineShort) + '</b>' +
    '<small>' + (tRow ? esc(stopName(f.fromStop)) : '') + '</small></div></div>' +
    (delay != null ? '<div style="padding:0 2px 8px">' + dlyTag(delay) + '</div>' : '') +
    '<ol class="rs-stops">' + items.join('') + '</ol>' +
    '<div class="rs-acts"><button id="rt-line"><svg class="ic"><use href="#i-bus"/></svg>Pokaż linię</button></div>';
}

/* ===== rysowanie mapy ===== */
function fitVisible(bounds, keepZoom){
  if (!bounds || !bounds.isValid()) return;
  const topH = 56;
  let sheetH = 56;
  const sh = $('#route-sheet');
  if (sh) sheetH = sh.getBoundingClientRect().height + 16;
  if (keepZoom && map.getZoom() >= 13){ map.panTo(bounds.getCenter()); return; }
  map.fitBounds(bounds, { paddingTopLeft:[40, topH], paddingBottomRight:[40, sheetH], maxZoom: 14 });
}
function drawRouteMap(f, fit){
  focusLayer.clearLayers();
  dotLayer.clearLayers();
  let bounds = null;
  function addPt(p){ if (!bounds) bounds = L.latLngBounds([p]); else bounds.extend(p); }
  if (f.mode === 'walk'){
    const PP = PLUI.last;
    if (PP){
      focusLayer.addLayer(L.marker([PP.a.lat, PP.a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
      focusLayer.addLayer(L.marker([PP.b.lat, PP.b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
      const coords = (PP.walk && PP.walk.vCoords && PP.walk.vCoords.length > 1) ? PP.walk.vCoords : [[PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]];
      focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color:'#98a2ad', weight:4, dashArray:'2 8' }));
      addPt([PP.a.lat, PP.a.lng]); addPt([PP.b.lat, PP.b.lng]);
      PLANNER.valhallaWalk([[PP.a.lat, PP.a.lng], [PP.b.lat, PP.b.lng]]).then(function(v){
        if (v && v.coords && v.coords.length > 1 && routeActive() === f){
          PP.walk = PP.walk || {};
          PP.walk.vCoords = v.coords;
          focusLayer.clearLayers(); dotLayer.clearLayers();
          drawRouteMap(f, false);
          const el = document.getElementById('walk-dur');
          if (el) el.textContent = '~' + fmtDur(PLANNER.walkSec(v.dist || 0)) + ' · chodniki';
        }
      }).catch(function(){});
    }
  } else if (f.mode === 'journey'){
    const PP = PLUI.last;
    if (PP){
      focusLayer.addLayer(L.marker([PP.a.lat, PP.a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
      focusLayer.addLayer(L.marker([PP.b.lat, PP.b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
      addPt([PP.a.lat, PP.a.lng]); addPt([PP.b.lat, PP.b.lng]);
    }
    const legs = f.journey.legs;
    let rideNo = 0;
    for (let i = 0; i < legs.length; i++){
      const leg = legs[i];
      if (leg.type === 'walk'){
        const fp = leg.fromPt ? [leg.fromPt.lat, leg.fromPt.lng] : stopPos(leg.fromSid);
        const tp = leg.toPt ? [leg.toPt.lat, leg.toPt.lng] : stopPos(leg.toSid);
        if (fp && tp){
          const coords = leg.vCoords && leg.vCoords.length > 1 ? leg.vCoords : [fp, tp];
          focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color:'#98a2ad', weight:4, dashArray:'2 8' }));
          addPt(fp); addPt(tp);
        }
      } else {
        const color = legColor(rideNo); rideNo++;
        const coords = rideCoordsOf(leg);
        if (coords && coords.length > 1){
          focusLayer.addLayer(L.polyline(coords, { renderer: svgRenderer, color: color, weight: 5, opacity:.95 }));
          for (let c = 0; c < coords.length; c += 2) addPt(coords[c]);
        }
        const tr = G.trips.get(leg.tid);
        const bvid = tr && S.tripVeh.get(String(leg.tid));
        const bv = bvid ? S.vehicles.get(bvid) : null;
        const boardPt = stopPos(leg.boardSid);
        if (bv && boardPt && (bv.n.seq || 0) <= leg.boardIdx){
          let gcoords = null;
          if (tr && tr.shape_id) gcoords = shapeSlice(tr.shape_id, boardPt, [bv.cur.lat, bv.cur.lng]);
          if (!gcoords){
            gcoords = [[bv.cur.lat, bv.cur.lng]];
            const raw = tripStops(leg.tid) || [];
            let cIdx = 0;
            for (let k = 0; k < raw.length; k++) if (raw[k][0] <= (bv.n.seq || 0)) cIdx = k;
            for (let k = cIdx; k <= leg.boardIdx && k < raw.length; k++){
              const p = stopPos(raw[k][1]); if (p) gcoords.push(p);
            }
            gcoords.push(boardPt);
          }
          if (gcoords && gcoords.length > 1)
            focusLayer.addLayer(L.polyline(gcoords, { renderer: svgRenderer, color: BUS_GRAY_C, weight: 4, opacity: .9 }));
          const raw = tripStops(leg.tid) || [];
          let cIdx = 0;
          for (let k = 0; k < raw.length; k++) if (raw[k][0] <= (bv.n.seq || 0)) cIdx = k;
          for (let k = cIdx; k <= leg.boardIdx && k < raw.length; k++){
            const p = stopPos(raw[k][1]);
            if (p){ dotLayer.addLayer(routeDot(p, String(raw[k][1]), true)); addPt(p); }
          }
        }
        const rows = tripStops(leg.tid);
        if (rows){
          for (let k = leg.boardIdx; k <= leg.alightIdx && k < rows.length; k++){
            const p = stopPos(rows[k][1]);
            if (p){ dotLayer.addLayer(routeDot(p, String(rows[k][1]), false)); addPt(p); }
          }
        }
      }
    }
  } else if (f.mode === 'line'){
    const vs = lineInfo(f.lineId);
    const vr = vs[f.varIdx];
    if (vr){
      const shp = shapePoints(vr.shapeId);
      if (shp){
        const ll = shp.map(function(p){ return [p[1], p[2]]; });
        focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .92 }));
        for (let i = 0; i < ll.length; i += 2) addPt(ll[i]);
      }
      const rows = tripStops(vr.rep);
      if (rows){
        for (let i = 0; i < rows.length; i++){
          const p = stopPos(rows[i][1]);
          if (p){ dotLayer.addLayer(routeDot(p, String(rows[i][1]), false)); addPt(p); }
        }
      }
    }
  } else if (f.mode === 'vehicle'){
    const v = S.vehicles.get(f.vid);
    if (v){
      const shp = shapePoints(v.trip && v.trip.shape_id);
      if (shp){
        const ll = shp.map(function(p){ return [p[1], p[2]]; });
        focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .9 }));
      }
      const rows = (v.n.tripId != null) ? tripStops(String(v.n.tripId)) : null;
      if (rows){
        for (let i = 0; i < rows.length; i++){
          const p = stopPos(rows[i][1]);
          if (p) dotLayer.addLayer(routeDot(p, String(rows[i][1]), false));
        }
      }
      if (fit) map.setView([v.to.lat, v.to.lng], Math.max(map.getZoom(), 13));
    }
  } else if (f.mode === 'trip'){
    const tr = G.trips.get(String(f.tid));
    const raw = tripStops(String(f.tid)) || [];
    const shp = shapePoints(tr && tr.shape_id);
    if (shp){
      const ll = shp.map(function(p){ return [p[1], p[2]]; });
      focusLayer.addLayer(L.polyline(ll, { renderer: svgRenderer, color: BUS_LINE_C, weight: 5, opacity: .9 }));
      for (let i = 0; i < ll.length; i += 2) addPt(ll[i]);
    }
    let tIdx = -1;
    for (let i = 0; i < raw.length; i++) if (String(raw[i][1]) === String(f.fromStop)) { tIdx = i; break; }
    for (let i = 0; i < raw.length; i++){
      const p = stopPos(raw[i][1]);
      if (p){ dotLayer.addLayer(routeDot(p, String(raw[i][1]), false)); addPt(p); }
    }
    if (tIdx >= 0){
      const p = stopPos(raw[tIdx][1]);
      if (p) focusLayer.addLayer(L.circleMarker(p, { renderer: svgRenderer, radius: 10, weight: 4, color: '#ff5c1a', fillColor: '#fff', fillOpacity: 1, interactive: false }));
    }
  } else if (f.mode === 'stop'){
    const s = G.stops.get(f.stopId);
    if (s){
      focusLayer.addLayer(L.circleMarker([s.lat, s.lon], { renderer: svgRenderer,
        radius: 10, weight: 4, color: '#ff5c1a', fillColor: '#fff', fillOpacity: 1, interactive: false }));
      if (fit) map.setView([s.lat, s.lon], Math.max(map.getZoom(), 15));
    }
  }
  syncDotVis();
  if (fit && bounds && bounds.isValid()) fitVisible(bounds, true);
}
function rideCoordsOf(leg){
  const b = stopPos(leg.boardSid), a = stopPos(leg.alightSid);
  if (b && a){
    const trip = G.trips.get(leg.tid);
    if (trip && trip.shape_id){
      const s = shapeSlice(trip.shape_id, b, a);
      if (s) return s;
    }
  }
  const rows = tripStops(leg.tid);
  if (rows){
    const out = [];
    for (let i = leg.boardIdx; i <= leg.alightIdx; i++){
      const p = stopPos(rows[i][1]); if (p) out.push(p);
    }
    if (out.length > 1) return out;
  }
  return (b && a) ? [b, a] : null;
}
 $('#route-fitbtn').addEventListener('click', function(){
  const f = routeActive();
  if (f) drawRouteMap(f, true);
});
 $('#route-tabs').addEventListener('click', function(e){
  const b = e.target.closest('[data-tab]');
  const f = routeActive();
  if (b && f){ f.tab = b.dataset.tab; renderRoute(); }
});
 $('#route-variants').addEventListener('click', function(e){
  const b = e.target.closest('[data-var]');
  const f = routeActive();
  if (b && f){ f.varIdx = +b.dataset.var; renderRoute(); drawRouteMap(f, true); }
});
 $('#route-content').addEventListener('click', function(e){
  const f = routeActive();
  if (!f) return;
  const dayBtn = e.target.closest('[data-day]');
  if (dayBtn){
    SDAY.cur = dayProfiles()[+dayBtn.dataset.day].key;
    BOARD.limit = 20;
    renderRoute();
    return;
  }
  const tile = e.target.closest('.tile');
  if (tile){
    if (tile.dataset.trip){
      const tr = G.trips.get(tile.dataset.trip);
      if (tr) openRoute('trip', { tid: tile.dataset.trip, lineId: tr.route_id,
        fromStop: (f.mode === 'line' || f.mode === 'stop') ? (f.fromStop || f.stopId) : null });
      return;
    }
    if (tile.dataset.line){
      openRoute('line', { lineId: tile.dataset.line,
        varIdx: variantIdxForTrip(tile.dataset.line, tile.dataset.trip || null),
        fromStop: (f.mode === 'stop') ? f.stopId : null });
      return;
    }
  }
  const vehRow = e.target.closest('.veh-row');
  if (vehRow && vehRow.dataset.vid){ openRoute('vehicle', { vid: vehRow.dataset.vid }); return; }
  const stopRow = e.target.closest('[data-sid]');
  if (stopRow){
    const p = stopPos(stopRow.dataset.sid);
    if (p) map.setView(p, Math.max(map.getZoom(), 15));
    showStopPop(stopRow.dataset.sid);
    return;
  }
  if (e.target.closest('#rt-line')){
    let lineId = null, tid = null;
    if (f.mode === 'vehicle'){ const v = S.vehicles.get(f.vid); lineId = v && v.routeId; tid = v && v.n.tripId; }
    else if (f.mode === 'trip'){ const tr = G.trips.get(String(f.tid)); lineId = tr && tr.route_id; tid = f.tid; }
    if (lineId) openRoute('line', { lineId: lineId, varIdx: variantIdxForTrip(lineId, tid), from: 'route' });
  }
});
 $('#route-content').addEventListener('scroll', function(){
  const f = routeActive();
  const el = $('#route-content');
  if (!f || f.mode !== 'stop' || f.tab !== 'dep') return;
  if (el.scrollTop + el.clientHeight > el.scrollHeight - 140){
    if (BOARD.limit < BOARD.deps.length){
      BOARD.limit += 20;
      renderRoute(true);
    }
  }
});

/* ===== sheety ===== */
function makeSheetDrag(sheet, grip, heightsFn, storeKey, onTap){
  function saveIdx(i){ try { localStorage.setItem(storeKey, String(i)); } catch (e){} }
  function apply(i, anim){
    idx = Math.max(0, Math.min(heightsFn().length - 1, i));
    if (!anim) sheet.classList.add('noanim');
    sheet.style.height = heightsFn()[idx] + 'px';
    if (!anim) requestAnimationFrame(function(){ sheet.classList.remove('noanim'); });
    saveIdx(idx);
  }
  let idx = 1;
  try { idx = Math.max(0, Math.min(heightsFn().length - 1, +(localStorage.getItem(storeKey) || 1))); } catch (e){}
  apply(idx, false);
  let sy = 0, sh = 0, drag = false, vy = 0, lastY = 0, lastT = 0, moved = false;
  grip.addEventListener('touchstart', function(e){
    drag = true; moved = false;
    sy = e.touches[0].clientY;
    sh = sheet.getBoundingClientRect().height;
    vy = 0; lastY = sy; lastT = Date.now();
    sheet.classList.add('noanim');
  }, { passive: true });
  grip.addEventListener('touchmove', function(e){
    if (!drag) return;
    const y = e.touches[0].clientY;
    if (Math.abs(y - sy) > 4) moved = true;
    let h = sh + (sy - y);
    const H = heightsFn();
    if (h < H[0]) h = H[0];
    if (h > H[H.length - 1]) h = H[H.length - 1];
    sheet.style.height = h + 'px';
    const t = Date.now();
    if (t > lastT) vy = (y - lastY) / (t - lastT);
    lastY = y; lastT = t;
  }, { passive: true });
  function end(){
    if (!drag) return;
    drag = false;
    sheet.classList.remove('noanim');
    const H = heightsFn();
    const cur = sheet.getBoundingClientRect().height;
    let ni = 0;
    if (vy > 0.7){ ni = 0; for (let i = 0; i < H.length; i++) if (H[i] < cur - 2) ni = i; }
    else if (vy < -0.7){ ni = H.length - 1; for (let i = H.length - 1; i >= 0; i--) if (H[i] > cur + 2) ni = i; }
    else { let bd = 1e9; for (let i = 0; i < H.length; i++){ const d = Math.abs(H[i] - cur); if (d < bd){ bd = d; ni = i; } } }
    apply(ni, true);
  }
  grip.addEventListener('touchend', end);
  grip.addEventListener('touchcancel', end);
  grip.addEventListener('click', function(){ if (!moved && onTap) onTap(apply, idx); });
  window.addEventListener('resize', function(){ apply(idx, false); });
  return {
    apply: apply,
    force: function(i){
      const H = heightsFn();
      const h = H[Math.max(0, Math.min(H.length - 1, i))];
      sheet.classList.add('noanim');
      sheet.style.height = h + 'px';
      requestAnimationFrame(function(){ sheet.classList.remove('noanim'); });
    },
    getIdx: function(){ return idx; }
  };
}
let routeLastOpen = 1;
const ROUTE_SHEET = makeSheetDrag($('#route-sheet'), $('#rs-grip'),
  function(){ return [44, Math.round(innerHeight * .20), Math.round(innerHeight * .45), Math.min(Math.round(innerHeight * .85), innerHeight - 60)]; },
  'ztm-sheet-route',
  function(apply, idx){
    if (idx === 0) apply(Math.max(1, routeLastOpen), true);
    else { routeLastOpen = idx; apply(0, true); }
  });
makeSheetDrag($('#home-sheet'), $('#hs-grip'),
  function(){ return [44, Math.round(innerHeight * .42)]; },
  'ztm-sheet-home',
  function(apply, idx){ apply(idx === 0 ? 1 : 0, true); });
makeSheetDrag($('#lines-sheet'), $('#ls-grip'),
  function(){ return [44, Math.round(innerHeight * .40)]; },
  'ztm-sheet-lines',
  function(apply, idx){ apply(idx === 0 ? 1 : 0, true); });

/* ===== nawigacja ===== */
const SCREENS = {};
['home','stops','results','settings'].forEach(function(n){
  const el = document.getElementById('scr-' + n);
  if (el) SCREENS[n] = el;
});
let CUR = 'home', PICK = null;
function go(name, keepSel, noPush){
  const prev = CUR;
  if (!keepSel){
    pointLayer.clearLayers();
    PICK = null; S.pickHide = false; $('#pick-banner').hidden = true;
  }
  if (prev === 'route' && name !== 'route'){
    ROUTE.stack.length = 0;
    focusLayer.clearLayers(); dotLayer.clearLayers();
    if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  }
  const isMap = (name === 'map' || name === 'route');
  document.body.classList.toggle('show-map', isMap);
  document.body.classList.toggle('on-route', name === 'route');
  for (const k in SCREENS) SCREENS[k].classList.toggle('on', k === name);
  CUR = name;
  closeAc();
  syncNav();
  if (isMap) setTimeout(function(){
    map.invalidateSize();
    refreshVisibility(); updateStopsVis();
    if (name === 'route') syncDotVis();
    firstFitMaybe();
  }, 60);
  if (name === 'stops') renderStopsList();
  if (!noPush){ try { history.pushState({ ztm: name }, '', '#' + name); } catch (e){} }
}
window.addEventListener('popstate', function(e){
  const st = e.state && e.state.ztm;
  if (st === 'route'){
    if (ROUTE.stack.length > 1) ROUTE.stack.pop();
    const f = routeActive();
    if (f){ go('route', true, true); renderRoute(); drawRouteMap(f, false); return; }
    go('map', true, true);
    return;
  }
  if (st && SCREENS[st]) go(st, true, true);
  else go('map', true, true);
});
function routeBack(){
  if (history.length > 1){ history.back(); return; }
  if (ROUTE.stack.length > 1){ ROUTE.stack.pop(); renderRoute(); drawRouteMap(routeActive(), true); return; }
  const f = ROUTE.stack[0];
  ROUTE.stack.length = 0;
  focusLayer.clearLayers(); dotLayer.clearLayers();
  go(f && f.from && SCREENS[f.from] ? f.from : 'map', true);
}
 $('#route-back').addEventListener('click', routeBack);
document.querySelectorAll('[data-back]').forEach(function(b){
  b.addEventListener('click', function(){
    if (history.length > 1) history.back();
    else go('map');
  });
});
function syncNav(){
  let active = null;
  if (CUR === 'home' || CUR === 'results' || CUR === 'settings') active = 'home';
  else if (CUR === 'map' || CUR === 'route') active = 'buses';
  else active = 'stops';
  document.querySelectorAll('#bottomnav [data-nav]').forEach(function(b){
    b.classList.toggle('on', b.dataset.nav === active);
  });
}
document.querySelectorAll('#bottomnav [data-nav]').forEach(function(b){
  b.addEventListener('click', function(){
    const w = b.dataset.nav;
    if (w === 'home') go('home');
    else if (w === 'buses') go('map');
    else go('stops');
  });
});
function firstFitMaybe(){
  if (S.firstFit || !S.vehicles.size || CUR !== 'map') return;
  S.firstFit = true;
  const pts = [];
  S.vehicles.forEach(function(v){ pts.push([v.to.lat, v.to.lng]); });
  const b = L.latLngBounds(pts);
  if (b.isValid()) map.fitBounds(b, { padding:[50,50], maxZoom:13 });
}
 $('#btn-fit').addEventListener('click', function(){
  const pts = [];
  S.vehicles.forEach(function(v){ if (v.onMap) pts.push([v.to.lat, v.to.lng]); });
  if (pts.length){ const b = L.latLngBounds(pts); if (b.isValid()) map.fitBounds(b, { padding:[50,50], maxZoom:13 }); }
  else map.setView([50.0413, 21.999], 13);
});

/* X-iki */
document.querySelectorAll('.clr-x').forEach(function(btn){
  btn.addEventListener('click', function(){
    const inp = document.getElementById(btn.dataset.clear);
    if (!inp) return;
    inp.value = '';
    inp.dispatchEvent(new Event('input', { bubbles:true }));
    inp.focus();
  });
});
['hp-a','hp-b','stops-q','map-search'].forEach(function(id){
  const inp = document.getElementById(id);
  if (!inp) return;
  const btn = document.querySelector('.clr-x[data-clear="' + id + '"]');
  if (!btn) return;
  function upd(){ btn.hidden = !((document.activeElement === inp) || !!inp.value); }
  inp.addEventListener('input', upd);
  inp.addEventListener('focus', upd);
  inp.addEventListener('blur', function(){ setTimeout(upd, 120); });
  upd();
});

/* autouzupełnianie */
function buildAC(){
  const seen = new Set();
  STOPS.sorted = [];
  for (let i = 0; i < stopsArray.length; i++){
    const s = stopsArray[i];
    if (seen.has(s.name)) continue;
    seen.add(s.name);
    STOPS.sorted.push({ name:s.name, tt:toks(s.name), sid:s.id, code:s.code });
  }
  STOPS.sorted.sort(function(a,b){ return a.name.localeCompare(b.name, 'pl'); });
}
function acQuery(q, limit){
  const qt = toks(q);
  if (!qt.length || !STOPS.sorted) return [];
  const out = [];
  for (let i = 0; i < STOPS.sorted.length; i++){
    const s = STOPS.sorted[i];
    const sc = matchScore(qt, s.tt);
    if (sc >= 0) out.push({ s: s, sc: sc });
    if (out.length >= 120) break;
  }
  out.sort(function(a,b){ return b.sc - a.sc || a.s.name.localeCompare(b.s.name, 'pl'); });
  return out.slice(0, limit).map(function(o){ return o.s; });
}
function closeAc(){
  ['#ac-a','#ac-b','#map-ac'].forEach(function(s){ const el = $(s); if (el) el.hidden = true; });
}
function attachAC(inputSel, panelSel, onPick, topHtmlFn){
  const inp = $(inputSel), panel = $(panelSel);
  if (!inp || !panel) return;
  function render(){
    const q = inp.value.trim();
    let html = '';
    if (!q && topHtmlFn) html = topHtmlFn();
    else if (q){
      const res = acQuery(q, 8);
      html = res.map(function(rr){
        return '<button class="ac-item" data-sid="' + esc(rr.sid) + '"><svg class="ic"><use href="#i-pin"/></svg><span>' + esc(rr.name) + '</span><small>' + esc(rr.code || '') + '</small></button>';
      }).join('') || '<div class="ac-empty">Brak przystanków</div>';
    }
    panel.innerHTML = html;
    panel.hidden = !html;
  }
  inp.addEventListener('input', render);
  inp.addEventListener('focus', render);
  panel.addEventListener('click', function(e){
    const b = e.target.closest('[data-sid]');
    if (!b) return;
    if (onPick(b.dataset.sid) !== false) panel.hidden = true;
  });
  document.addEventListener('click', function(e){
    if (e.target !== inp && !panel.contains(e.target)) panel.hidden = true;
  });
}

/* historia */
function recLoad(){
  try { const r = JSON.parse(localStorage.getItem('ztm-rec') || '{}');
    REC.routes = Array.isArray(r.routes) ? r.routes : [];
    REC.stops = Array.isArray(r.stops) ? r.stops : [];
  } catch (e){}
}
function recSave(){ try { localStorage.setItem('ztm-rec', JSON.stringify(REC)); } catch (e){} }
function recRouteAdd(a, b){
  const A = { l: a.label || 'start', sid: a.sid || null, lat: a.sid ? null : a.lat, lng: a.sid ? null : a.lng, gps: (!a.sid && a.lat == null) };
  const B = { l: b.label || 'cel', sid: b.sid || null, lat: b.sid ? null : b.lat, lng: b.sid ? null : b.lng };
  REC.routes = REC.routes.filter(function(rr){ return !(rr.a.l === A.l && rr.b.l === B.l); });
  REC.routes.unshift({ a: A, b: B });
  REC.routes = REC.routes.slice(0, 6);
  recSave();
  renderHomeHist();
}
function recStopAdd(sid){
  REC.stops = REC.stops.filter(function(s){ return s !== sid; });
  REC.stops.unshift(sid);
  REC.stops = REC.stops.slice(0, 6);
  recSave();
}
function renderHomeHist(){
  const b = $('#home-hist-body');
  if (!b) return;
  let h = '';
  if (REC.routes.length){
    h += '<div class="hs-sec">Trasy</div>';
    for (let i = 0; i < REC.routes.length; i++){
      const rr = REC.routes[i];
      h += '<button class="hs-route" data-r="' + i + '"><svg class="ic"><use href="#i-arrow"/></svg><span><b>' + esc(rr.a.l) + '</b> → <b>' + esc(rr.b.l) + '</b></span></button>';
    }
  }
  const st = REC.stops.slice(0, 6).map(function(sid){ return G.stops.get(sid); }).filter(Boolean);
  if (st.length){
    h += '<div class="hs-sec">Przystanki</div><div class="hs-chips">';
    for (let i = 0; i < st.length; i++)
      h += '<button class="hchip" data-sid="' + esc(st[i].id) + '">' + esc(st[i].name) + '</button>';
    h += '</div>';
  }
  if (!h) h = '<div class="hs-empty">Historia pojawi się tutaj</div>';
  b.innerHTML = h;
}
function applyRecPoint(p, which){
  const inp = $(which === 'a' ? '#hp-a' : '#hp-b');
  if (p.gps){ PLUI[which] = null; inp.value = 'Moja lokalizacja'; return; }
  if (p.sid){
    const s = G.stops.get(p.sid);
    if (s){ PLUI[which] = null; inp.value = s.name; return; }
  }
  if (p.lat != null && p.lng != null){ PLUI[which] = { lat: p.lat, lng: p.lng }; inp.value = p.l; return; }
  inp.value = p.l || '';
}
document.addEventListener('click', function(e){
  const r = e.target.closest('#home-hist-body [data-r]');
  if (r){
    const rr = REC.routes[+r.dataset.r];
    if (rr){ applyRecPoint(rr.a, 'a'); applyRecPoint(rr.b, 'b'); }
    return;
  }
  const s = e.target.closest('#home-hist-body [data-sid]');
  if (s) openRoute('stop', { stopId: s.dataset.sid, from: 'stops' });
});

/* home / planer */
function drawPointPins(){
  pointLayer.clearLayers();
  const a = resolvePoint('a'), b = resolvePoint('b');
  if (a) pointLayer.addLayer(L.marker([a.lat, a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
  if (b) pointLayer.addLayer(L.marker([b.lat, b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
}
function setPick(which){
  PICK = which;
  S.pickHide = !!which;
  $('#pick-banner').hidden = !which;
  $('#pick-txt').textContent = which === 'a' ? 'Kliknij punkt STARTOWY (A)' : 'Kliknij punkt CELU (B)';
  drawPointPins();
  refreshVisibility();
  updateStopsVis();
  if (which) go('map', true);
}
function setPlanPoint(which, lat, lng){
  PLUI[which] = { lat: lat, lng: lng };
  $(which === 'a' ? '#hp-a' : '#hp-b').value = 'Punkt z mapy (' + lat.toFixed(4) + ', ' + lng.toFixed(4) + ')';
  PICK = null; S.pickHide = false;
  $('#pick-banner').hidden = true;
  drawPointPins();
  refreshVisibility();
  updateStopsVis();
  go('home', true);
}
 $('#pick-cancel').addEventListener('click', function(){
  PICK = null; S.pickHide = false;
  $('#pick-banner').hidden = true;
  refreshVisibility(); updateStopsVis();
  go('home', true);
});
 $('#hp-a-map').addEventListener('click', function(){ setPick('a'); });
 $('#hp-b-map').addEventListener('click', function(){ setPick('b'); });
 $('#hp-a-gps').addEventListener('click', function(){
  if (!GPS.on) toggleGps();
  else { PLUI.a = null; setGpsFieldText(); }
});
 $('#sp-walk').addEventListener('click', function(){
  PLANNER.setSpeed(5);
  $('#sp-walk').classList.add('on'); $('#sp-run').classList.remove('on');
});
 $('#sp-run').addEventListener('click', function(){
  PLANNER.setSpeed(10);
  $('#sp-run').classList.add('on'); $('#sp-walk').classList.remove('on');
});
function resolvePoint(which){
  const inp = $(which === 'a' ? '#hp-a' : '#hp-b');
  const txt = (inp.value || '').trim();
  if (txt && txt.indexOf('Punkt z mapy') !== 0 && txt.indexOf('Moja lokalizacja') !== 0){
    const res = acQuery(txt, 1);
    if (res.length){
      const s = G.stops.get(res[0].sid);
      if (s) return { lat: s.lat, lng: s.lon, label: s.name, sid: s.id };
    }
  }
  if (PLUI[which]) return PLUI[which];
  if (which === 'a' && GPS.on && GPS.lat != null) return { lat: GPS.lat, lng: GPS.lng, label: 'moja lokalizacja' };
  return null;
}
 $('#hp-go').addEventListener('click', function(){
  const a = resolvePoint('a'), b = resolvePoint('b');
  if (!b){ toast('Ustaw cel (B)', true); return; }
  if (!a){ toast('Ustaw start: przystanek, mapa lub lokalizacja', true); return; }
  if (PLANNER.havM([a.lat, a.lng], [b.lat, b.lng]) < 30){ toast('A i B to to samo miejsce', true); return; }
  recRouteAdd(a, b);
  const dateStr = $('#pl-date').value || feedDateStr();
  const tv = ($('#pl-time').value || fmtUnix(Math.floor(clockNow()))).split(':');
  const depSec = ((+tv[0]) || 0) * 3600 + ((+tv[1]) || 0) * 60;
  const xfers = +$('#pl-xfer').value;
  PLUI.last = { a: a, b: b, depSec: depSec, dateStr: dateStr, xfers: xfers, res: null, busy: false, depUsed: depSec };
  go('results');
  $('#res-body').innerHTML = '<div class="empty">Szukam połączeń…</div>';
  runSearch(true);
});
function runSearch(forceNow){
  const L = PLUI.last;
  if (!L || L.busy) return;
  L.busy = true;
  setTimeout(function(){
    let dep = L.depSec;
    if (forceNow && dep < clockNow() - dayStartUnix() - 60) dep = Math.floor(clockNow() - dayStartUnix());
    try {
      const res = PLANNER.plan(L.a.lat, L.a.lng, L.b.lat, L.b.lng, dep, L.dateStr, L.xfers);
      L.res = res;
      L.depUsed = dep;
      renderResults();
      refineWalksValhalla();
    } catch (err){
      if (CUR === 'results' && !L.res) $('#res-body').innerHTML = '<div class="empty">Błąd planera: ' + esc((err && err.message) || err) + '</div>';
    }
    L.busy = false;
  }, 30);
}
setInterval(function(){
  if (CUR === 'results' && PLUI.last && PLUI.last.res && !PLUI.last.busy) runSearch(true);
}, 10000);

/* ===== VALHALLA (działająca wersja — valhalla1, wg przykładu użytkownika) ===== */
const VALC = new Map();
function decodeValhallaPolyline(str){
  let index = 0, lat = 0, lon = 0;
  const coordinates = [];
  while (index < str.length){
    let result = 0, shift = 0, byte;
    do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
    lat += (result & 1) ? ~(result >> 1) : (result >> 1);
    result = 0; shift = 0;
    do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
    lon += (result & 1) ? ~(result >> 1) : (result >> 1);
    coordinates.push([lat / 1000000, lon / 1000000]);
  }
  return coordinates;
}
PLANNER.valhallaWalk = async function(pts){
  if (!pts || pts.length < 2 || !pts[0] || !pts[1]) return null;
  const key = pts[0][0].toFixed(5) + ',' + pts[0][1].toFixed(5) + '|' + pts[1][0].toFixed(5) + ',' + pts[1][1].toFixed(5);
  if (VALC.has(key)) return VALC.get(key);
  const body = {
    locations: [
      { lat: pts[0][0], lon: pts[0][1], type: 'break' },
      { lat: pts[1][0], lon: pts[1][1], type: 'break' }
    ],
    costing: 'pedestrian',
    units: 'kilometers',
    directions_options: { units: 'kilometers' }
  };
  const urls = ['https://valhalla1.openstreetmap.de/route', 'https://valhalla2.openstreetmap.de/route'];
  for (let u = 0; u < urls.length; u++){
    try {
      const ctl = new AbortController();
      const to = setTimeout(function(){ ctl.abort(); }, 8000);
      let res;
      try { res = await fetch(urls[u], { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(body), signal: ctl.signal }); }
      finally { clearTimeout(to); }
      if (!res.ok) continue;
      const data = await res.json();
      if (!data.trip || !data.trip.legs || !data.trip.legs.length) continue;
      const coords = decodeValhallaPolyline(data.trip.legs[0].shape);
      if (!coords || coords.length < 2) continue;
      const distKm = (data.trip.summary && data.trip.summary.length) ? data.trip.summary.length : 0;
      const out = { coords: coords, dist: distKm * 1000, dur: PLANNER.walkSec(distKm * 1000) };
      VALC.set(key, out);
      return out;
    } catch (e){}
  }
  VALC.set(key, null);
  return null;
};
let VALH_GEN = 0;
function refineWalksValhalla(){
  const L = PLUI.last;
  if (!L || !L.res || !L.res.journeys) return;
  const gen = ++VALH_GEN;
  const jobs = [];
  L.res.journeys.forEach(function(j){
    j.legs.forEach(function(leg){
      if (leg.type === 'walk') jobs.push({ j: j, leg: leg });
    });
  });
  if (L.res.walk) jobs.push({ walkMain: true });
  if (!jobs.length) return;
  let done = 0;
  jobs.forEach(function(job){
    const fp = job.walkMain ? [L.a.lat, L.a.lng] : (job.leg.fromPt ? [job.leg.fromPt.lat, job.leg.fromPt.lng] : stopPos(job.leg.fromSid));
    const tp = job.walkMain ? [L.b.lat, L.b.lng] : (job.leg.toPt ? [job.leg.toPt.lat, job.leg.toPt.lng] : stopPos(job.leg.toSid));
    if (!fp || !tp){ finish(); return; }
    PLANNER.valhallaWalk([fp, tp]).then(function(v){
      if (gen !== VALH_GEN) return;
      if (v && v.coords && v.dist != null){
        if (job.walkMain){ L.res.walk.vCoords = v.coords; }
        else { job.leg.vCoords = v.coords; job.leg.vDur = PLANNER.walkSec(v.dist); }
      }
      finish();
    }).catch(function(){ finish(); });
  });
  function finish(){
    done++;
    if (done >= jobs.length && gen === VALH_GEN){
      if (CUR === 'results') renderResults();
      const f = routeActive();
      if (f && (f.mode === 'journey' || f.mode === 'walk')) drawRouteMap(f, false);
    }
  }
}

/* ===== wyniki ===== */
function legWalkHtml(leg){
  const kind = (leg.kind === 'access') ? 'Dojście do przystanku' : ((leg.kind === 'egress') ? 'Dojście do celu' : 'Przesiadka pieszo');
  const dur = leg.vDur || leg.sec;
  return '<div class="leg leg-walk"><span class="lic"><span class="dotleg" style="--dc:#98a2ad"></span></span>' +
    '<span class="lmain"><span class="l1">' + kind + ' · ' + fmtDist(leg.dist) + (leg.vCoords ? ' · chodniki' : '') + '</span>' +
    '<span class="l2">~' + fmtDur(dur) + '</span></span></div>';
}
function legRideHtml(leg, rideNo){
  const route = G.routes.get(leg.routeId);
  const line = route ? route.short : (leg.routeId || '?');
  return '<div class="leg leg-ride"><span class="lic"><span class="dotleg" style="--dc:' + legColor(rideNo) + '"></span></span>' +
    '<span class="lmain"><span class="l1">' + esc(leg.headsign || line) + '</span>' +
    '<span class="l2">' + esc(stopName(leg.boardSid)) + ' → ' + esc(stopName(leg.alightSid)) + '</span></span>' +
    '<span class="lt">' + fmtT(leg.dep) + '→' + fmtT(leg.arr) + '</span></div>';
}
function journeyCard(j, idx){
  const legs = j.legs;
  let walkTotal = 0, firstRide = null, rideNo = 0;
  const parts = [];
  for (let i = 0; i < legs.length; i++){
    if (legs[i].type === 'walk'){ walkTotal += (legs[i].vDur || legs[i].sec); parts.push(legWalkHtml(legs[i])); }
    else {
      if (!firstRide) firstRide = legs[i];
      parts.push(legRideHtml(legs[i], rideNo)); rideNo++;
      const nx = legs[i+1];
      if (nx && nx.type === 'ride' && nx.boardSid === legs[i].alightSid)
        parts.push('<div class="xfer">' + esc(stopName(legs[i].alightSid)) + ' · ' + fmtDur(Math.max(0, nx.dep - legs[i].arr)) + '</div>');
    }
  }
  const isTop = (idx === 0);
  const badges = (isTop ? '<span class="jr-badge">najlepsza</span>' : '') +
    (j.transfers === 0 ? '<span class="jr-badge dir">bezpośrednia</span>' : '');
  const xt = (j.transfers === 0) ? 'bezpośrednio' : (j.transfers + (j.transfers === 1 ? ' przesiadka' : ' przesiadki'));
  const depTxt = firstRide ? '<span class="mmain" id="jc' + idx + 'e"></span>' : '';
  if (firstRide) liveAdd('jc' + idx + 'e', dayStartUnix() + firstRide.depS);
  return '<div class="jr' + (isTop ? ' best open' : '') + '" data-j="' + idx + '">' +
    '<div class="jr-top"><svg class="ic"><use href="#i-bus"/></svg>' +
    '<b>' + depTxt + ' → ' + fmtT(j.arrive) + '</b>' + badges +
    '<span class="jr-sum">' + xt + ' · ' + fmtDur(j.arrive - (PLUI.last.depUsed || PLUI.last.depSec)) + ' · pieszo ' + fmtDur(walkTotal) + '</span></div>' +
    '<div class="jr-body">' + parts.join('') + '</div>' +
    '<div class="jr-foot"><button data-act="map" data-j="' + idx + '"><svg class="ic" style="width:14px;height:14px"><use href="#i-fit"/></svg> Otwórz na mapie</button></div></div>';
}
function filterLiveJourneys(){
  const res = PLUI.last.res;
  if (!res || !res.journeys) return [];
  const ds0 = dayStartUnix();
  const now = clockNow();
  let live = res.journeys.filter(function(j){
    return j.firstDep == null || (ds0 + j.firstDep) > now - 900;
  });
  if (!live.length) live = res.journeys;
  return live;
}
function renderResults(){
  const PP = PLUI.last;
  if (!PP || !PP.res) return;
  const res = PP.res;
  if (res.error){ $('#res-body').innerHTML = '<div class="empty">' + esc(res.error) + '</div>'; return; }
  const live = filterLiveJourneys();
  let minArr = Infinity;
  for (let i = 0; i < live.length; i++) if (live[i].arrive < minArr) minArr = live[i].arrive;
  let html = '';
  if (res.walk && res.walk.sec < 2700){
    const wArr = (PP.depUsed || PP.depSec) + res.walk.sec;
    const best = (wArr <= minArr);
    html += '<div class="jr' + (best ? ' best' : '') + '" data-j="walk">' +
      '<div class="jr-top"><svg class="ic" style="color:var(--dim)"><use href="#i-walk"/></svg><b>Pieszo</b>' +
      (best ? '<span class="jr-badge">najszybciej</span>' : '') +
      '<span class="jr-sum">~' + fmtDur(res.walk.sec) + ' · ' + fmtDist(res.walk.dist) + '</span></div>' +
      '<div class="jr-foot"><button data-act="map" data-j="walk">Otwórz na mapie</button></div></div>';
  }
  for (let i = 0; i < live.length; i++) html += journeyCard(live[i], i);
  $('#res-body').innerHTML = html || '<div class="empty">Brak połączeń.</div>';
  tickLive();
}
 $('#res-body').addEventListener('click', function(e){
  const card = e.target.closest('.jr');
  if (!card) return;
  if (e.target.closest('[data-act="map"]')){
    if (card.dataset.j === 'walk'){ openRoute('walk', { from: 'results' }); return; }
    const live = filterLiveJourneys();
    const j = live[+card.dataset.j];
    if (j) openRoute('journey', { journey: j, from: 'results' });
    return;
  }
  if (e.target.closest('.jr-top')) card.classList.toggle('open');
});

/* ===== wyszukiwarka przystanków ===== */
function stopsMatches(){
  if (!STOPS.sorted) return [];
  const q = STOPS.q.trim();
  if (!q) return STOPS.sorted;
  const qt = toks(q);
  if (!qt.length) return STOPS.sorted;
  const out = [];
  for (let i = 0; i < STOPS.sorted.length; i++){
    if (matchScore(qt, STOPS.sorted[i].tt) >= 0) out.push(STOPS.sorted[i]);
    if (out.length >= 400) break;
  }
  out.sort(function(a,b){ return matchScore(qt,b.tt) - matchScore(qt,a.tt); });
  return out;
}
function stopsItemHtml(r){
  let dist = '';
  if (GPS.on && GPS.lat != null){
    const s = G.stops.get(r.sid);
    if (s) dist = '<span class="sdst">' + fmtDist(PLANNER.havM([GPS.lat, GPS.lng], [s.lat, s.lon])) + '</span>';
  }
  const s2 = G.stops.get(r.sid);
  const zone = (s2 && s2.zone) ? s2.zone : '';
  return '<button class="stop-item" data-sid="' + esc(r.sid) + '">' +
    '<span class="stop-main"><span class="stop-nrow">' +
    '<span class="stop-nm">' + esc(r.name) + '</span>' +
    (r.code ? '<span class="stop-code">' + esc(r.code) + '</span>' : '') +
    '</span></span>' + dist +
    (zone ? '<span class="zone-sq z' + esc(zone.toLowerCase()) + '" style="color:#fff" title="Strefa ' + esc(zone) + '">' + esc(zone) + '</span>' : '') +
    '</button>';
}
function renderStopsList(keepScroll){
  if (CUR !== 'stops' || !STOPS.sorted) return;
  const box = $('#stops-list');
  const sc = keepScroll ? box.scrollTop : 0;
  const q = STOPS.q.trim();
  const gpsOn = GPS.on && GPS.lat != null;
  let html = '';
  if (!q){
    const rec = REC.stops.slice(0, 3).map(function(sid){ return G.stops.get(sid); }).filter(Boolean);
    if (rec.length){
      html += '<div class="stops-sec">Ostatnie</div>';
      for (let i = 0; i < rec.length; i++) html += stopsItemHtml({ sid: rec[i].id, name: rec[i].name, code: rec[i].code });
    }
    if (gpsOn){
      const near = [];
      for (let i = 0; i < STOPS.sorted.length; i++){
        const s = G.stops.get(STOPS.sorted[i].sid);
        if (s) near.push({ r: STOPS.sorted[i], d: PLANNER.havM([GPS.lat, GPS.lng], [s.lat, s.lon]) });
      }
      near.sort(function(a,b){ return a.d - b.d; });
      html += '<div class="stops-sec">Najbliżej</div>';
      for (let i = 0; i < Math.min(10, near.length); i++) html += stopsItemHtml(near[i].r);
    }
  }
  const all = stopsMatches();
  html += '<div class="stops-sec">' + (q ? 'Wyniki (' + all.length + ')' : 'Wszystkie') + '</div>';
  const shown = all.slice(0, STOPS.limit);
  for (let i = 0; i < shown.length; i++) html += stopsItemHtml(shown[i]);
  if (!shown.length) html += '<div class="empty">Brak wyników.</div>';
  else if (STOPS.limit < all.length) html += '<div class="loadmore">przewiń — więcej (' + (all.length - STOPS.limit) + ')</div>';
  box.innerHTML = html;
  box.scrollTop = sc;
}
 $('#stops-q').addEventListener('input', function(){
  STOPS.q = $('#stops-q').value;
  STOPS.limit = 40;
  renderStopsList();
});
 $('#stops-list').addEventListener('click', function(e){
  const b = e.target.closest('[data-sid]');
  if (b){
    recStopAdd(b.dataset.sid);
    openRoute('stop', { stopId: b.dataset.sid, from: 'stops' });
  }
});
 $('#stops-list').addEventListener('touchstart', function(e){
  const b = e.target.closest('.stop-item');
  if (b){
    const nm = b.querySelector('.stop-nm');
    if (nm && nm.scrollWidth > nm.clientWidth + 2) b.classList.add('expanded');
  }
}, { passive: true });
 $('#stops-list').addEventListener('scroll', function(){
  const box = $('#stops-list');
  if (box.scrollTop + box.clientHeight > box.scrollHeight - 160){
    const all = stopsMatches();
    if (STOPS.limit < all.length){
      STOPS.limit += 40;
      renderStopsList(true);
    }
  }
});

/* ===== kafle linii (Autobusy) — BEZ liczników ===== */
function renderLinesSheet(){
  const box = $('#lines-body');
  if (!box) return;
  const ids = new Set();
  S.vehicles.forEach(function(v){ if (v.routeId) ids.add(v.routeId); });
  const arr = Array.from(ids).sort(function(a,b){
    const ra = G.routes.get(a), rb = G.routes.get(b);
    return natCmp((ra && ra.short) || a, (rb && rb.short) || b);
  });
  if (!arr.length){ box.innerHTML = '<div class="empty">Brak pojazdów na żywo.</div>'; return; }
  let h = '<div class="tgrid">';
  for (let i = 0; i < arr.length; i++){
    const id = arr[i], r = G.routes.get(id);
    h += '<div class="tile" data-line="' + esc(id) + '">' +
      '<div class="tile-ln">' + esc((r && r.short) || id) + '</div></div>';
  }
  box.innerHTML = h + '</div>';
}
 $('#lines-body').addEventListener('click', function(e){
  const b = e.target.closest('[data-line]');
  if (b) openRoute('line', { lineId: b.dataset.line, from: 'map' });
});

/* ===== szukajka mapy: linia → tabor → rejestracja → przystanek ===== */
function mapAcRender(){
  const inp = $('#map-search'), panel = $('#map-ac');
  const q = inp.value.trim();
  if (!q){ panel.hidden = true; return; }
  const qU = q.toUpperCase();
  const qn = baseName(q).replace(/\s+/g, '');
  const lineExact = [], lineStarts = [], lineHas = [];
  const rl = Array.from(G.routes.values());
  for (let i = 0; i < rl.length; i++){
    const r = rl[i];
    const sU = String(r.short).toUpperCase();
    if (sU === qU) lineExact.push(r);
    else if (sU.indexOf(qU) === 0) lineStarts.push(r);
    else if (sU.indexOf(qU) > 0 || baseName(r.long || '').indexOf(baseName(q)) >= 0) lineHas.push(r);
  }
  const tabor = [], plates = [];
  S.vehicles.forEach(function(v){
    const lab = String(v.n.label || '').toUpperCase();
    const plate = String(v.n.plate || '').toLowerCase().replace(/\s+/g, '');
    if (tabor.length < 4 && lab && lab.indexOf(qU) >= 0) tabor.push(v);
    else if (plates.length < 3 && plate && qn && plate.indexOf(qn) >= 0) plates.push(v);
  });
  const rows = [];
  const linePick = lineExact.concat(lineStarts, lineHas).slice(0, 4);
  for (let i = 0; i < linePick.length; i++){
    const r = linePick[i];
    rows.push('<button class="ac-item" data-line="' + esc(r.id) + '"><svg class="ic"><use href="#i-bus"/></svg><span><b>' + esc(r.short) + '</b> · ' + esc(r.long || '') + '</span></button>');
  }
  for (let i = 0; i < tabor.length; i++){
    const v = tabor[i];
    rows.push('<button class="ac-item" data-veh="' + esc(v.id) + '"><svg class="ic"><use href="#i-bus"/></svg><span><b>' + esc(v.n.label) + '</b> · tabor · linia ' + esc(v.lineName) + (v.n.plate ? ' · ' + esc(v.n.plate) : '') + '</span></button>');
  }
  for (let i = 0; i < plates.length; i++){
    const v = plates[i];
    rows.push('<button class="ac-item" data-veh="' + esc(v.id) + '"><svg class="ic"><use href="#i-bus"/></svg><span><b>' + esc(v.n.plate) + '</b> · rejestracja · linia ' + esc(v.lineName) + '</span></button>');
  }
  const stops = acQuery(q, 6);
  for (let i = 0; i < stops.length; i++)
    rows.push('<button class="ac-item" data-sid="' + esc(stops[i].sid) + '"><svg class="ic"><use href="#i-pin"/></svg><span>' + esc(stops[i].name) + '</span><small>' + esc(stops[i].code || '') + '</small></button>');
  panel.innerHTML = rows.join('') || '<div class="ac-empty">Brak wyników</div>';
  panel.hidden = false;
}
 $('#map-search').addEventListener('input', mapAcRender);
 $('#map-search').addEventListener('focus', mapAcRender);
 $('#map-ac').addEventListener('click', function(e){
  const vh = e.target.closest('[data-veh]');
  if (vh){ $('#map-ac').hidden = true; $('#map-search').value = ''; openRoute('vehicle', { vid: vh.dataset.veh, from: 'map' }); return; }
  const b = e.target.closest('[data-sid]');
  if (b){ $('#map-ac').hidden = true; $('#map-search').value = ''; showStopPop(b.dataset.sid); return; }
  const l = e.target.closest('[data-line]');
  if (l){ $('#map-ac').hidden = true; $('#map-search').value = ''; openRoute('line', { lineId: l.dataset.line, from: 'map' }); }
});
document.addEventListener('click', function(e){
  if (e.target !== $('#map-search') && !$('#map-ac').contains(e.target)) $('#map-ac').hidden = true;
});

/* ===== feed ===== */
async function fetchRT(){
  const errs = [];
  for (let i = 0; i < CFG.RT.length; i++){
    const src = CFG.RT[i];
    try {
      const res = await fetch(src.url, { cache:'no-store' });
      if (!res.ok){
        let t = '';
        try { t = (await res.text()).replace(/\s+/g,' ').slice(0, 90); } catch (e){}
        throw new Error('HTTP ' + res.status + (t ? ' — ' + t : ''));
      }
      const ab = await res.arrayBuffer();
      const gz = await PB.gunzip(new Uint8Array(ab));
      if (gz.warning && !gz.gunzipped) throw new Error(gz.warning);
      const kind = classify(gz.bytes);
      if (kind !== 'pb') throw new Error('serwer zwrócił: ' + kind);
      const F = parseGTFSRT(gz.bytes);
      F._src = src.label;
      F._cache = !!src.cache;
      return F;
    } catch (e){ errs.push(src.label + ': ' + ((e && e.message) ? e.message : String(e))); }
  }
  throw new Error(errs.join(' | '));
}
let DBG_TU = false;
function applyFeed(F){
  S.feedBase = F.timestamp; S.feedReal = Date.now();
  S.tu = F.updates; S.alerts = F.alerts;
  S.tripVeh = new Map();
  const seen = new Set();
  const list = [];
  for (let i = 0; i < F.vehicles.length; i++){
    const n = F.vehicles[i];
    seen.add(n.id);
    if (n.tripId != null) S.tripVeh.set(String(n.tripId), n.id);
    list.push(n);
  }
  const rm = [];
  S.vehicles.forEach(function(v, id){ if (!seen.has(id)) rm.push(id); });
  for (let i = 0; i < rm.length; i++) removeVehicle(rm[i]);
  queueUpserts(list);
  if (!DBG_TU){
    DBG_TU = true;
    let nTU = 0;
    F.updates.forEach(function(v){ nTU++; });
    console.log('[GTFS-RT] pojazdy: ' + F.vehicles.length + ' · TripUpdates: ' + nTU);
  }
  try { PLANNER.applyLive(S.tu, feedDateStr()); } catch (e){}
  LNC.key = null;
  renderLinesSheet();
  if (routeActive()) refreshRoute();
  renderAlerts();
}
function renderAlerts(){
  const bar = $('#alertbar'), list = $('#alerts-list');
  if (!S.alerts.length){ bar.hidden = true; list.hidden = true; ALERTS.sig = null; return; }
  ALERTS.sig = S.alerts.map(function(a){ return (a.header || '') + '|' + (a.desc || ''); }).join(';;');
  if (ALERTS.sig === ALERTS.dismissed){ bar.hidden = true; list.hidden = true; return; }
  bar.hidden = false;
  $('#alerts-sum').textContent = (S.alerts.length === 1)
    ? (S.alerts[0].header || 'komunikat przewoźnika')
    : S.alerts.length + ' komunikatów przewoźnika';
  list.innerHTML = S.alerts.map(function(a){
    const m = [];
    if (a.cause != null && CAUSE_TXT[a.cause]) m.push(CAUSE_TXT[a.cause]);
    if (a.effect != null && EFFECT_TXT[a.effect]) m.push(EFFECT_TXT[a.effect]);
    return '<div class="alr"><h4>' + esc(a.header || 'Komunikat') + '</h4>' +
      (a.desc ? '<p>' + esc(a.desc) + '</p>' : '') + '</div>';
  }).join('');
}
 $('#btn-alerts').addEventListener('click', function(){ const l = $('#alerts-list'); l.hidden = !l.hidden; });
 $('#alert-close').addEventListener('click', function(){
  ALERTS.dismissed = ALERTS.sig;
  $('#alertbar').hidden = true;
  $('#alerts-list').hidden = true;
});
async function refresh(force){
  if (S.refreshing) return;
  if (document.hidden && !force) return;
  S.refreshing = true;
  try {
    const F = await fetchRT();
    applyFeed(F);
    $('#feed-dot').className = 'dot ' + (F._cache ? 'file' : 'ok');
    $('#stat-feed-txt').textContent = (F._cache ? 'cache · ' : 'live · ') + fmtUnix(S.feedBase);
    S.errToasted = false;
  } catch (e){
    $('#feed-dot').className = 'dot err';
    $('#stat-feed-txt').textContent = 'błąd';
    if (!S.errToasted){ S.errToasted = true; toast('Feed nieudany: ' + ((e && e.message) || e), true); }
  } finally { S.refreshing = false; }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) refresh(true); });
 $('#feed-chip').addEventListener('click', function(){ refresh(true); });
async function loadPBFile(file){
  try {
    const ab = await file.arrayBuffer();
    const gz = await PB.gunzip(new Uint8Array(ab));
    const kind = classify(gz.bytes);
    if (kind !== 'pb') throw new Error('plik to: ' + kind);
    const F = parseGTFSRT(gz.bytes);
    F._src = 'plik'; F._cache = true;
    applyFeed(F);
    $('#feed-dot').className = 'dot file';
    $('#stat-feed-txt').textContent = 'plik · ' + fmtUnix(S.feedBase);
  } catch (e){ toast('Nie udało się wczytać .pb: ' + ((e && e.message) || e), true); }
}
 $('#btn-pbfile').addEventListener('click', function(){ $('#pbfile').click(); });
 $('#pbfile').addEventListener('change', function(e){
  const f = e.target.files && e.target.files[0];
  if (f) loadPBFile(f);
  e.target.value = '';
});
window.addEventListener('dragover', function(e){ e.preventDefault(); });
window.addEventListener('drop', function(e){
  e.preventDefault();
  const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (f && /\.(pb|gz)$/i.test(f.name)) loadPBFile(f);
});
let rzT = null;
window.addEventListener('resize', function(){
  clearTimeout(rzT);
  rzT = setTimeout(function(){ map.invalidateSize(); }, 200);
});

/* ?pb=1 */
async function dumpPB(){
  const st = document.createElement('style');
  st.textContent = 'html,body{height:auto;overflow:auto;background:#fff;color:#111}body{margin:0;padding:16px;font:12px/1.5 ui-monospace,Menlo,monospace}pre{white-space:pre-wrap;word-break:break-all;margin:0}';
  document.head.appendChild(st);
  document.body.innerHTML = '';
  const pre = document.createElement('pre');
  document.body.appendChild(pre);
  document.title = 'GTFS-RT — raw dump';
  pre.textContent = 'Pobieram feed…\n';
  try {
    const F = await fetchRT();
    const tuObj = {};
    F.updates.forEach(function(v, k){ tuObj[k] = v; });
    pre.textContent = JSON.stringify({
      _source: F._src,
      header: { timestamp: F.timestamp, iso: new Date(F.timestamp * 1000).toISOString() },
      vehiclesCount: F.vehicles.length, vehicles: F.vehicles,
      tripUpdatesCount: Object.keys(tuObj).length, tripUpdates: tuObj, alerts: F.alerts
    }, null, 2);
  } catch (e){ pre.textContent = 'BŁĄD: ' + ((e && e.message) || e); }
}

/* ===== start ===== */
(async function init(){
  if (QPB){ await dumpPB(); return; }
  try { history.replaceState({ ztm:'home' }, '', '#home'); } catch (e){}
  let mode = 'auto';
  try { mode = localStorage.getItem('ztm-theme') || 'auto'; } catch (e){}
  applyThemeMode(mode);
  try {
    const bm = localStorage.getItem('ztm-basemap');
    if (bm){ BASE.manual = true; setBasemapById(bm); }
  } catch (e){}
  recLoad();
  ldOk(ldFile('css/app.css'), 'liquid glass');
  ldOk(ldFile('js/pb-parser.js'), 'dekoder .pb');
  ldOk(ldFile('js/planner.js'), 'silnik live');
  ldOk(ldFile('js/app.js'), 'interfejs');
  try {
    await loadStatic();
    buildAC();
    buildStopLayers();
    renderHomeHist();
    SDAY.cur = detectDefaultDay();
    $('#pl-date').value = feedDateStr();
    $('#pl-time').value = fmtUnix(Math.floor(clockNow()));
    attachAC('#hp-b', '#ac-b', function(sid){
      const s = G.stops.get(sid);
      if (s) $('#hp-b').value = s.name;
      return true;
    });
    attachAC('#hp-a', '#ac-a', function(sid){
      if (sid === '__gps'){ if (!GPS.on) toggleGps(); else { PLUI.a = null; setGpsFieldText(); } return true; }
      if (sid === '__map'){ $('#ac-a').hidden = true; setPick('a'); return true; }
      const s = G.stops.get(sid);
      if (s) $('#hp-a').value = s.name;
      return true;
    }, function(){
      return '<button class="ac-item" data-sid="__gps"><svg class="ic"><use href="#i-gps"/></svg><span>Moja lokalizacja' + (GPS.on ? ' (aktywna)' : '') + '</span></button>' +
             '<button class="ac-item" data-sid="__map"><svg class="ic"><use href="#i-target"/></svg><span>Wskaż na mapie</span></button>';
    });
  } catch (e){
    $('#ld-msg').classList.add('err');
    $('#ld-msg').innerHTML = 'Nie udało się wczytać GTFS:<br><b>' + esc((e && e.message) || e) + '</b><br><br>Sprawdź katalog <b>gtfs/</b>.';
    return;
  }
  $('#ld-msg').textContent = 'Łączenie z API…';
  await refresh(true);
  $('#loading').classList.add('off');
  setTimeout(function(){ const l = $('#loading'); if (l) l.remove(); }, 500);
  setInterval(function(){ refresh(false); }, CFG.REFRESH_MS);
  setInterval(tickLive, 1000);
  renderStopsList();
  renderLinesSheet();
})();
window.TRACKER = { PB: PB, PBRT: window.PBRT, PLANNER: window.PLANNER, G: G, S: S, SEL: SEL, ROUTE: ROUTE, PLUI: PLUI, GPS: GPS, REC: REC, SDAY: SDAY };