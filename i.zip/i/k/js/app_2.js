'use strict';
/* app_2.js — motyw, mapa, GPS, POJAZDY. FIX: usunięty zoom-handler
   (powodował skoki linii podczas pinch); markery = tylko nr linii. */

let THEME_MODE = 'dark', THEME = 'dark';
const BASEMAPS = [
  { id:'dark', name:'Ciemna', desc:'OSM z ciemnym filtrem', filter:'invert(1) hue-rotate(185deg) brightness(.92) contrast(.85) saturate(.45)',
    make:function(){ return L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      { maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }); } },
  { id:'light', name:'Jasna', desc:'standardowy OpenStreetMap', filter:'',
    make:function(){ return L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      { maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }); } },
  { id:'sat', name:'Satelita', desc:'zdjęcia lotnicze (Esri)', filter:'brightness(.95) saturate(.85)',
    make:function(){ return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      { maxZoom:19, attribution:'Imagery &copy; Esri, Maxar, Earthstar Geographics' }); } },
  { id:'topo', name:'Topograficzna', desc:'teren i drogi (Esri Topo)', filter:'',
    make:function(){ return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
      { maxZoom:19, attribution:'&copy; Esri, OpenStreetMap contributors' }); } }
];
const BASE = { id:'dark', layer:null, manual:false };
function setBasemapById(id){
  const b = BASEMAPS.find(function(x){ return x.id === id; }) || BASEMAPS[0];
  BASE.id = b.id;
  if (BASE.layer) map.removeLayer(BASE.layer);
  BASE.layer = b.make().addTo(map);
  const c = BASE.layer.getContainer();
  if (c) c.style.filter = b.filter || 'none';
}
function applyBasemapNow(id){
  setBasemapById(id);
  map.invalidateSize();
  if (BASE.layer && BASE.layer.redraw) BASE.layer.redraw();
}
function saveBasemap(id){ try { localStorage.setItem('ztm-basemap', id); } catch (e){} }
function chooseBasemap(id){
  BASE.manual = true;
  saveBasemap(id);
  renderSettings();
  if (CUR !== 'map'){ go('map'); setTimeout(function(){ applyBasemapNow(id); }, 160); }
  else applyBasemapNow(id);
}
function setTheme(t){
  THEME = t;
  document.documentElement.setAttribute('data-theme', t);
  $('#btn-theme').innerHTML = '<svg class="ic"><use href="#i-' + (t === 'dark' ? 'sun' : 'moon') + '"/></svg>';
  const mc = document.querySelector('meta[name=theme-color]');
  if (mc) mc.setAttribute('content', t === 'dark' ? '#0b0d10' : '#e8edf3');
  if (!BASE.manual) setBasemapById(t === 'light' ? 'light' : 'dark');
}
function applyThemeMode(mode){
  THEME_MODE = mode;
  try { localStorage.setItem('ztm-theme', mode); } catch (e){}
  let t = mode;
  if (mode === 'auto'){
    try { t = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'; }
    catch (e){ t = 'dark'; }
  }
  setTheme(t);
  renderSettings();
}
function renderSettings(){
  document.querySelectorAll('#set-theme [data-v]').forEach(function(b){
    b.classList.toggle('on', b.dataset.v === THEME_MODE);
  });
  $('#set-maps').innerHTML = BASEMAPS.map(function(m){
    return '<button class="set-map' + (BASE.id === m.id ? ' on' : '') + '" data-m="' + m.id + '">' +
      '<span class="sw sw-' + m.id + '"></span>' +
      '<span class="sm"><b>' + m.name + '</b><small>' + m.desc + '</small></span></button>';
  }).join('');
}
 $('#set-theme').addEventListener('click', function(e){
  const b = e.target.closest('[data-v]');
  if (b) applyThemeMode(b.dataset.v);
});
 $('#set-maps').addEventListener('click', function(e){
  const b = e.target.closest('[data-m]');
  if (b) chooseBasemap(b.dataset.m);
});
 $('#btn-theme').addEventListener('click', function(){ applyThemeMode(THEME === 'dark' ? 'light' : 'dark'); });
 $('#btn-settings').addEventListener('click', function(){ go('settings'); });
 $('#btn-layers').addEventListener('click', function(){
  let i = 0;
  for (let k = 0; k < BASEMAPS.length; k++) if (BASEMAPS[k].id === BASE.id) i = k;
  const nb = BASEMAPS[(i + 1) % BASEMAPS.length];
  BASE.manual = true; saveBasemap(nb.id); applyBasemapNow(nb.id);
  toast('Podkład: ' + nb.name);
});

const map = L.map('map', { zoomControl:false, attributionControl:true, markerZoomAnimation:!PERF.mobile });
map.setView([50.0413, 21.9990], 13);
map.attributionControl.setPrefix('');
const focusLayer = L.layerGroup().addTo(map);
const dotLayer = L.layerGroup().addTo(map);
const pointLayer = L.layerGroup().addTo(map);
const gpsLayer = L.layerGroup().addTo(map);
const trailLayer = L.layerGroup().addTo(map);
const stopRenderer = L.canvas({ padding:.4 });
const svgRenderer = L.svg({ padding:.3 });
let stopLayerFull = null, stopLayerThin = null;
function buildStopLayers(){
  stopLayerFull = L.layerGroup();
  stopLayerThin = L.layerGroup();
  const grid = new Map();
  const CELL = 0.002;
  let i = 0;
  const total = stopsArray.length;
  function chunk(){
    if (document.hidden){ requestAnimationFrame(chunk); return; }
    const end = Math.min(i + 500, total);
    for (; i < end; i++){
      const s = stopsArray[i];
      if (!isFinite(s.lat) || !isFinite(s.lon)) continue;
      const sid = s.id;
      const m = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:4.5,
        weight:2, color:'#98a2ad', fillColor:'#39404a', fillOpacity:1 });
      m.bindTooltip(esc(s.name) + (s.code ? ' <b>' + esc(s.code) + '</b>' : ''), { direction:'top', offset:[0,-6] });
      m.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
      m.addTo(stopLayerFull);
      const hit = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:14,
        opacity:0, fillOpacity:0, fill:false, interactive:true });
      hit.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
      hit.addTo(stopLayerFull);
      const k = Math.floor(s.lat / CELL) + '_' + Math.floor(s.lon / CELL);
      if (!grid.has(k)){
        grid.set(k, 1);
        const m2 = L.circleMarker([s.lat, s.lon], { renderer:stopRenderer, radius:4.5,
          weight:2, color:'#98a2ad', fillColor:'#39404a', fillOpacity:1 });
        m2.bindTooltip(esc(s.name), { direction:'top', offset:[0,-6] });
        m2.on('click', function(e){ L.DomEvent.stop(e); showStopPop(sid); });
        m2.addTo(stopLayerThin);
      }
    }
    if (i < total) requestAnimationFrame(chunk); else updateStopsVis();
  }
  requestAnimationFrame(chunk);
}
function updateStopsVis(){
  if (!stopLayerFull) return;
  const z = map.getZoom();
  let layer = null;
  if (CUR === 'map' && !S.pickHide){
    if (z >= 15) layer = stopLayerFull;
    else if (z >= 13) layer = stopLayerThin;
  }
  if (stopLayerFull !== layer && map.hasLayer(stopLayerFull)) map.removeLayer(stopLayerFull);
  if (stopLayerThin !== layer && map.hasLayer(stopLayerThin)) map.removeLayer(stopLayerThin);
  if (layer && !map.hasLayer(layer)) layer.addTo(map);
}
function syncDotVis(){
  if (map.getZoom() >= 11){ if (!map.hasLayer(dotLayer)) dotLayer.addTo(map); }
  else if (map.hasLayer(dotLayer)) map.removeLayer(dotLayer);
}
/* FIX: tylko moveend/zoomend — koniec z przeskokami podczas pinch */
let mvT = null;
map.on('moveend zoomend', function(){
  clearTimeout(mvT);
  mvT = setTimeout(function(){ refreshVisibility(); updateStopsVis(); syncDotVis(); syncDirVis(); }, 80);
});
map.on('dragstart', function(){ if (GPS.followCam) GPS.followCam = false; });
map.on('click', function(e){
  if (PICK){ setPlanPoint(PICK, e.latlng.lat, e.latlng.lng); return; }
});

const GPS = { on:false, lat:null, lng:null, watch:null, marker:null, ring:null, followCam:false };
const TRAIL = { pts: [] };
function trailAdd(lat, lng){
  const t = Date.now();
  TRAIL.pts = TRAIL.pts.filter(function(p){ return t - p.t < 300000; });
  const last = TRAIL.pts[TRAIL.pts.length - 1];
  if (last && PLANNER.havM([last.lat, last.lng], [lat, lng]) < 5){ last.t = t; return; }
  TRAIL.pts.push({ lat: lat, lng: lng, t: t });
  if (TRAIL.pts.length > 150) TRAIL.pts.shift();
  trailRedraw();
}
function trailRedraw(){
  trailLayer.clearLayers();
  if (TRAIL.pts.length < 2){
    if (TRAIL.pts.length === 1)
      L.circleMarker([TRAIL.pts[0].lat, TRAIL.pts[0].lng], { radius:3, weight:1, color:'#fff', fillColor:'#2f8fff', fillOpacity:.9, interactive:false }).addTo(trailLayer);
    return;
  }
  const ll = TRAIL.pts.map(function(p){ return [p.lat, p.lng]; });
  L.polyline(ll, { color:'#2f8fff', weight:3, opacity:.55, interactive:false }).addTo(trailLayer);
  for (let i = 0; i < ll.length; i++)
    L.circleMarker(ll[i], { radius:3, weight:1, color:'#fff', fillColor:'#2f8fff', fillOpacity:.9, interactive:false }).addTo(trailLayer);
}
function setGpsFieldText(){
  const inp = $('#hp-a');
  const row = $('#hp-a-row');
  if (GPS.on){
    inp.value = 'Moja lokalizacja (aktywna)';
    row.classList.add('gps-on');
  } else {
    if (inp.value.indexOf('Moja lokalizacja') === 0) inp.value = '';
    row.classList.remove('gps-on');
  }
}
function toggleGps(){
  if (GPS.on){
    if (GPS.watch != null) navigator.geolocation.clearWatch(GPS.watch);
    GPS.on = false; GPS.followCam = false; GPS.watch = null;
    gpsLayer.clearLayers(); GPS.marker = null; GPS.ring = null;
    TRAIL.pts = []; trailLayer.clearLayers();
    $('#btn-gps').classList.remove('on');
    setGpsFieldText();
    renderStopsList._sig = null; renderStopsList();
    return;
  }
  if (!navigator.geolocation){ toast('Geolokalizacja niedostępna (HTTPS lub localhost)', true); return; }
  GPS.on = true;
  $('#btn-gps').classList.add('on');
  setGpsFieldText();
  GPS.watch = navigator.geolocation.watchPosition(function(p){
    const first = (GPS.lat == null);
    GPS.lat = p.coords.latitude; GPS.lng = p.coords.longitude;
    drawGps(p.coords.accuracy || 0);
    trailAdd(GPS.lat, GPS.lng);
    if (first){ renderStopsList._sig = null; renderStopsList(); }
    if (GPS.followCam && (CUR === 'map')) map.panTo([GPS.lat, GPS.lng], { animate:true, duration:.6 });
  }, function(err){
    toast('Lokalizacja: ' + (err.message || 'brak zgody'), true);
    toggleGps();
  }, { enableHighAccuracy:true, maximumAge:3000, timeout:12000 });
}
function drawGps(accM){
  if (GPS.marker) GPS.marker.setLatLng([GPS.lat, GPS.lng]);
  else {
    GPS.marker = L.marker([GPS.lat, GPS.lng], { zIndexOffset:900, interactive:false,
      icon: L.divIcon({ className:'', iconSize:[16,16], iconAnchor:[8,8], html:'<div class="gps-dot"></div>' }) }).addTo(gpsLayer);
    GPS.followCam = true;
    if (CUR === 'map') map.panTo([GPS.lat, GPS.lng]);
  }
  if (GPS.ring){ GPS.ring.setLatLng([GPS.lat, GPS.lng]); GPS.ring.setRadius(accM || 25); }
  else GPS.ring = L.circle([GPS.lat, GPS.lng], { radius:accM || 25, weight:1,
    color:'#2f8fff', opacity:.5, fillOpacity:.08, interactive:false }).addTo(gpsLayer);
}
 $('#btn-gps').addEventListener('click', toggleGps);

const SHAPE_IDX = new Map();
function shapeIndex(shapeId){
  if (SHAPE_IDX.has(shapeId)) return SHAPE_IDX.get(shapeId);
  const pts = shapePoints(shapeId);
  if (!pts || pts.length < 2){ SHAPE_IDX.set(shapeId, null); return null; }
  const ll = pts.map(function(p){ return [p[1], p[2]]; });
  const cum = [0];
  for (let i = 1; i < ll.length; i++) cum.push(cum[i-1] + PLANNER.havM(ll[i-1], ll[i]));
  const idx = { pts: ll, cum: cum, total: cum[cum.length-1] };
  SHAPE_IDX.set(shapeId, idx);
  return idx;
}
function projectOnShape(idx, lat, lng){
  let bd = Infinity, bseg = 0, bt = 0, bx = lat, by = lng;
  for (let i = 0; i < idx.pts.length - 1; i++){
    const a = idx.pts[i], b = idx.pts[i+1];
    const dx = b[0]-a[0], dy = b[1]-a[1];
    const len2 = dx*dx + dy*dy;
    let t = 0;
    if (len2 > 0){
      t = ((lat-a[0])*dx + (lng-a[1])*dy) / len2;
      t = Math.max(0, Math.min(1, t));
    }
    const px = a[0] + t*dx, py = a[1] + t*dy;
    const d = PLANNER.havM([lat,lng],[px,py]);
    if (d < bd){ bd = d; bseg = i; bt = t; bx = px; by = py; }
  }
  const dAlong = idx.cum[bseg] + bt * ((idx.cum[bseg+1]-idx.cum[bseg]) || 0);
  return { lat: bx, lng: by, d: dAlong, dist: bd };
}
function pointAtDist(idx, d){
  const cum = idx.cum;
  if (d <= 0) return idx.pts[0];
  if (d >= idx.total) return idx.pts[idx.pts.length-1];
  let lo = 0, hi = cum.length - 1;
  while (lo < hi - 1){ const m = (lo+hi)>>1; if (cum[m] <= d) lo = m; else hi = m; }
  const t = (d - cum[lo]) / ((cum[lo+1]-cum[lo]) || 1);
  const a = idx.pts[lo], b = idx.pts[lo+1];
  return [a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t];
}

function viewBoundsOrNull(){
  if (CUR !== 'map' && CUR !== 'route') return null;
  try { if (map._loaded) return map.getBounds().pad(0.25); } catch (e){}
  return null;
}
function vehVisible(v){
  if (S.pickHide) return false;
  if (CUR === 'route'){
    const f = routeActive();
    if (!f) return false;
    if (f.mode === 'vehicle') return v.id === f.vid;
    if (f.mode === 'line') return v.routeId === f.lineId;
    if (f.mode === 'journey'){
      const legs = f.journey.legs;
      for (let i = 0; i < legs.length; i++)
        if (legs[i].type === 'ride' && v.n && String(v.n.tripId) === String(legs[i].tid)) return true;
      return false;
    }
    if (f.mode === 'trip'){
      const vid = S.tripVeh.get(String(f.tid));
      return !!vid && v.id === vid;
    }
    return false;  /* stop, walk → normalny widok */
  }
  if (S.routeFilter && v.routeId !== S.routeFilter) return false;
  const b = viewBoundsOrNull();
  if (b && !b.contains([v.to.lat, v.to.lng])) return false;
  return true;
}
function attachV(v){
  const el = v.marker.getElement();
  if (el){
    v.el = el;
    v.bodyEl = el.querySelector('.vm-body');
    v.dirEl = el.querySelector('.vm-dir');
    if (v.bodyEl) v.bodyEl.textContent = v.lineName;
    if (v.dirEl) v.dirEl.style.display = (map.getZoom() >= 15) ? '' : 'none';
  }
}
function syncDirVis(){
  const on = map.getZoom() >= 15;
  S.vehicles.forEach(function(v){
    if (v.dirEl && v.dirEl.style.display !== (on ? '' : 'none'))
      v.dirEl.style.display = on ? '' : 'none';
  });
}
function syncVehMarker(v){
  if (CUR !== 'map' && CUR !== 'route') return;
  const vis = vehVisible(v);
  if (vis && !v.onMap){ v.marker.addTo(map); v.onMap = true; attachV(v); }
  else if (!vis && v.onMap){ map.removeLayer(v.marker); v.onMap = false; v.el = v.bodyEl = v.dirEl = null; }
}
/* FIX: marker pokazuje TYLKO nr linii */
function makeBusMarker(line){
  const w = PERF.mobile ? 60 : 56, h = PERF.mobile ? 34 : 30;
  return L.marker([0,0], { zIndexOffset:600, riseOnHover:!PERF.mobile,
    icon: L.divIcon({ className:'vm-wrap', iconSize:[w,h], iconAnchor:[w/2,h/2],
      html:'<div class="vm"><div class="vm-dir"><svg viewBox="0 0 24 24"><path d="M12 3l7 18-7-5.4L5 21z" fill="currentColor" stroke="none"/></svg></div>' +
           '<div class="vm-body">' + esc(line) + '</div></div>' }) });
}
function computeBearing(a, b){
  const dy = b.lat - a.lat, dx = (b.lng - a.lng) * Math.cos(a.lat*Math.PI/180);
  const d = Math.sqrt(dx*dx + dy*dy);
  if (d < 0.00004) return null;
  return (Math.atan2(dx, dy)*180/Math.PI + 360) % 360;
}
function lerpAngle(a, b, k){
  let d = b - a;
  while (d > 180) d -= 360;
  while (d < -180) d += 360;
  return a + d*k;
}
function upsertVehicle(id, n){
  if (n.lat == null || n.lng == null || !isFinite(n.lat) || !isFinite(n.lng)) return null;
  const trip = (n.tripId != null) ? G.trips.get(String(n.tripId)) : null;
  const routeId = (trip && trip.route_id) || n.routeId || null;
  const route = routeId ? G.routes.get(routeId) : null;
  const lineName = (route && route.short) || routeId || '·';
  const now = performance.now();
  let v = S.vehicles.get(id);
  let shpIdx = null, toLat = n.lat, toLng = n.lng, toD = null;
  if (trip && trip.shape_id){
    shpIdx = shapeIndex(trip.shape_id);
    if (shpIdx){
      const pr = projectOnShape(shpIdx, n.lat, n.lng);
      if (pr.dist < 60){ toLat = pr.lat; toLng = pr.lng; toD = pr.d; }
    }
  }
  if (!v){
    v = { id:id, marker: makeBusMarker(lineName),
      from:{lat:toLat,lng:toLng}, to:{lat:toLat,lng:toLng},
      shapeIdx:shpIdx, fromD:toD, toD:toD,
      t0: now - PERF.animMs, cur:{lat:toLat,lng:toLng}, brgShown:null,
      done:true, onMap:false, el:null, bodyEl:null, dirEl:null, tip:lineName };
    v.marker.on('click', function(e){ L.DomEvent.stop(e); openRoute('vehicle', { vid:id, from:'map' }); });
    v.marker.bindTooltip('Linia ' + lineName, { direction:'top', offset:[0,-14] });
    v.marker.setLatLng([toLat, toLng]);
    S.vehicles.set(id, v);
    syncVehMarker(v);
  } else {
    const sameShape = (v.shapeIdx === shpIdx);
    v.shapeIdx = shpIdx;
    v.from = { lat: v.cur.lat, lng: v.cur.lng };
    v.to = { lat: toLat, lng: toLng };
    v.fromD = sameShape ? v.toD : null;
    v.toD = toD;
    let anim = v.onMap && map.getZoom() >= 14;
    if (anim){
      try {
        const p1 = map.latLngToContainerPoint([v.cur.lat, v.cur.lng]);
        const p2 = map.latLngToContainerPoint([toLat, toLng]);
        const dx = p1.x - p2.x, dy = p1.y - p2.y;
        if (dx*dx + dy*dy < 9) anim = false;
        else {
          const vb = viewBoundsOrNull();
          if (vb && !vb.contains([toLat, toLng])) anim = false;
        }
      } catch (e){ anim = false; }
    }
    if (anim){ v.t0 = now; v.done = false; }
    else {
      v.cur = { lat: toLat, lng: toLng };
      v.marker.setLatLng([toLat, toLng]);
      v.t0 = now - PERF.animMs; v.done = true;
    }
    if (v.tip !== lineName){ v.tip = lineName; v.marker.setTooltipContent('Linia ' + lineName); }
    if (v.bodyEl && v.bodyEl.textContent !== lineName) v.bodyEl.textContent = lineName;
    syncVehMarker(v);
  }
  v.n = n; v.trip = trip; v.route = route; v.routeId = routeId;
  v.lineName = lineName;
  return v;
}
function removeVehicle(id){
  const v = S.vehicles.get(id);
  if (!v) return;
  if (v.onMap) map.removeLayer(v.marker);
  S.vehicles.delete(id);
  const f = routeActive();
  if (f && f.mode === 'vehicle' && f.vid === id){
    ROUTE.stack.pop();
    if (!routeActive()) go('map', true);
    else refreshRoute();
    return;
  }
  if (f && f.mode === 'trip' && S.tripVeh.get(String(f.tid)) === id) refreshRoute();
}
function refreshRoute(){
  const f = routeActive();
  if (!f) return;
  renderRoute(true);
  drawRouteMap(f, false);
}
function refreshVisibility(){ S.vehicles.forEach(syncVehMarker); }
function animTick(){
  requestAnimationFrame(animTick);
  if (document.hidden) return;
  animTick._f = !animTick._f;
  if (S.vehicles.size > 40 && animTick._f) return;
  const nowMs = performance.now();
  S.vehicles.forEach(function(v){
    if (!v.onMap || v.done) return;
    let t = (nowMs - v.t0) / PERF.animMs;
    if (!(t > 0)) t = 0;
    if (t >= 1) t = 1;
    const k = easeOut(t);
    if (v.shapeIdx && v.fromD != null && v.toD != null){
      const d = v.fromD + (v.toD - v.fromD) * k;
      const p = pointAtDist(v.shapeIdx, d);
      v.cur.lat = p[0]; v.cur.lng = p[1];
      if (map.getZoom() >= 15){
        const p2 = pointAtDist(v.shapeIdx, Math.min(v.shapeIdx.total, d + 20));
        const brg = computeBearing({lat:p[0],lng:p[1]},{lat:p2[0],lng:p2[1]});
        if (brg != null && v.dirEl) v.dirEl.style.transform = 'rotate(' + brg.toFixed(1) + 'deg)';
      }
    } else {
      v.cur.lat = v.from.lat + (v.to.lat - v.from.lat) * k;
      v.cur.lng = v.from.lng + (v.to.lng - v.from.lng) * k;
    }
    v.marker.setLatLng([v.cur.lat, v.cur.lng]);
    if (t >= 1) v.done = true;
  });
}
requestAnimationFrame(animTick);
const UPQ = { list:[], t:null };
function queueUpserts(list){
  for (let i = 0; i < list.length; i++) UPQ.list.push(list[i]);
  if (!UPQ.t) UPQ.t = setTimeout(processUpserts, 0);
}
function processUpserts(){
  const t0 = performance.now();
  while (UPQ.list.length && performance.now() - t0 < 8){
    const n = UPQ.list.shift();
    upsertVehicle(n.id, n);
  }
  if (UPQ.list.length) UPQ.t = setTimeout(processUpserts, 30);
  else UPQ.t = null;
}