'use strict';
/* app_1.js — utilities, formatery, GTFS, stan. FIX: liveAdd zapisuje ID
   (nie element) — elementy rozwiązywane w tickLive po renderze. */

const APP_VER = '20260924b';
(function versionCheck(){
  const m = document.querySelector('meta[name="app-ver"]');
  if (!m || m.getAttribute('content') !== APP_VER){
    document.body.innerHTML = '<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;background:#0b0d10;color:#eceae4;font:14px/1.6 system-ui;text-align:center">Niezgodne wersje plików.<br>Nadpisz <b>index.php</b>, <b>css/app.css</b> i <b>js/app_*.js</b> z zestawu 20260924b i odśwież.</div>';
    throw new Error('version mismatch');
  }
})();

const CFG = {
  RT: [
    { url: 'https://www.mpkrzeszow.pl/gtfs/rt/gtfsrt.pb', label: 'API — bezpośrednio' },
    { url: '?_rt=1', label: 'API — proxy PHP' },
    { url: '?_rt=1&cached=1', label: 'ostatnia dobra kopia', cache: true }
  ],
  GTFS_DIR: 'gtfs/',
  REFRESH_MS: 10000
};
const PERF = { mobile:false, animMs:900 };
(function(){
  try { PERF.mobile = matchMedia('(pointer: coarse)').matches || innerWidth <= 700; }
  catch (e){ PERF.mobile = innerWidth <= 700; }
  PERF.animMs = PERF.mobile ? 700 : 900;
})();
const QPB = (function(){ try { return new URLSearchParams(location.search).get('pb') === '1'; } catch (e){ return false; } })();

function $(s){ return document.querySelector(s); }
function p2(n){ return String(n).padStart(2, '0'); }
function esc(s){
  s = (s == null) ? '' : String(s);
  return s.replace(/[&<>"']/g, function(c){
    return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]; });
}
function cssVar(name, fallback){
  try { const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim(); return v || fallback; }
  catch (e){ return fallback; }
}
function hmsToSec(s){
  if (!s) return null;
  const a = s.split(':');
  if (a.length < 3) return null;
  const h = +a[0], m = +a[1], x = +a[2];
  if (!isFinite(h)) return null;
  return h*3600 + m*60 + x;
}
function fmtSD(sec){ if (sec == null) return '–:–';
  return p2(Math.floor(sec/3600)%24) + ':' + p2(Math.floor(sec/60)%60); }
function fmtUnix(u){ if (!isFinite(u)) return '--:--';
  const d = new Date(u*1000); return p2(d.getHours()) + ':' + p2(d.getMinutes()); }
function fmtUnixS(u){ if (!isFinite(u)) return '--:--:--';
  const d = new Date(u*1000); return p2(d.getHours())+':'+p2(d.getMinutes())+':'+p2(d.getSeconds()); }
function fmtDist(m){ return m < 1000 ? Math.round(m) + ' m' : (m/1000).toFixed(1) + ' km'; }
function fmtDur(sec){ const m = Math.max(1, Math.round(sec/60));
  if (m < 60) return m + ' min';
  return Math.floor(m/60) + ' h ' + (m%60) + ' min'; }
function fmtT(sec){
  const m = Math.floor(sec/60), h = Math.floor(m/60), day = Math.floor(h/24);
  const s = p2(h%24) + ':' + p2(m%60);
  return day > 0 ? s + ' (+1d)' : s;
}
function fmtMin(d){
  if (d <= 45) return 'teraz';
  if (d < 3600) return Math.ceil(d/60) + 'min';
  const mm = Math.ceil(d/60);
  return Math.floor(mm/60) + 'h' + p2(mm%60);
}
function delayText(sec){
  if (sec == null) return null;
  const m = Math.round(Math.abs(sec)/60);
  if (m === 0) return 'na czas';
  return sec > 0 ? ('opóźnienie ' + m + ' min') : ('przyspieszenie ' + m + ' min');
}
function dlyCls(sec){ return (sec != null && sec < 0) ? 'md-early' : 'md-late'; }
function dlyTag(sec){
  if (sec == null) return '';
  return '<span class="bdel ' + dlyCls(sec) + '">' + delayText(sec) + '</span>';
}
function baseName(s){ return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
function natCmp(a,b){ return String(a).localeCompare(String(b),'pl',{numeric:true}); }
function easeOut(t){ return 1 - Math.pow(1 - t, 3); }
function toast(msg, err){
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : '');
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(function(){ t.style.transition = 'opacity .4s'; t.style.opacity = '0';
    setTimeout(function(){ t.remove(); }, 420); }, 5000);
}
window.addEventListener('error', function(e){ if (e && e.message) toast('Błąd JS: ' + e.message, true); });
window.addEventListener('unhandledrejection', function(e){
  const r = e.reason;
  toast('Błąd asynchr.: ' + ((r && r.message) ? r.message : String(r)), true);
});
const CYCLE = ['#5b8def','#e8590c','#2f9e44','#9c36b5','#e03131','#0c8599','#f08c00','#6741d9','#20c997','#c2255c'];
function legColor(i){ return CYCLE[i % CYCLE.length]; }

function toks(s){
  s = String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  s = s.replace(/\//g, ' ');
  const raw = s.split(/[^a-z0-9]+/);
  const out = [];
  for (let i = 0; i < raw.length; i++){
    const t = raw[i];
    if (!t || t === 'nz' || /^\d+$/.test(t)) continue;
    out.push(t);
  }
  return out;
}
function matchScore(qt, st){
  if (!qt.length) return 0;
  let sc = 0;
  for (let i = 0; i < qt.length; i++){
    const q = qt[i];
    let best = 0;
    for (let j = 0; j < st.length; j++){
      const t = st[j];
      if (t === q){ best = 3; break; }
      if (t.indexOf(q) === 0 && best < 2) best = 2;
      else if (t.indexOf(q) > 0 && best < 1) best = 1;
    }
    if (!best) return -1;
    sc += best;
  }
  return sc;
}

/* ===== FIX: liveAdd zapisuje ID (nie element) ===== */
const Live = { items: [] };
function liveAdd(id, t){
  Live.items.push({ id: id, t: t });
}
function tickLive(){
  if (document.hidden) return;
  const now = clockNow();
  const alive = [];
  for (let i = 0; i < Live.items.length; i++){
    const it = Live.items[i];
    const el = document.getElementById(it.id);
    if (el){
      el.textContent = fmtMin(it.t - now);
      alive.push(it);
    }
    /* element nie istnieje → usuń z listy (auto-cleanup) */
  }
  Live.items = alive;
  const c = $('#clock'); if (c) c.textContent = fmtUnixS(now);
}
function timeCell(depL, schedAbs, delay, pfx){
  let h = '<span class="mcol">';
  if (depL != null){
    h += '<span class="mmain" id="' + pfx + 'e"></span>';
    liveAdd(pfx + 'e', depL);
    if (delay != null && delay > 60) h += '<span class="mdelay md-late">+' + Math.round(delay/60) + ' min</span>';
    else if (delay != null && delay < -60) h += '<span class="mdelay md-early">−' + Math.round(-delay/60) + ' min</span>';
  } else if (schedAbs != null){
    h += '<span class="mclock big">' + fmtUnix(schedAbs) + '</span>';
  }
  h += '</span>';
  return h;
}

const G = { routes:new Map(), trips:new Map(), stops:new Map(), stopTimes:new Map(),
  stopIndex:new Map(), shapes:new Map(), calRows:[], calDates:new Map(), stopArea:new Map(), feedInfo:null };
let stopsArray = [];
function parseCSVLine(l){
  if (l.indexOf('"') < 0) return l.split(',');
  const out = []; let cur = '', q = false;
  for (let i = 0; i < l.length; i++){
    const c = l[i];
    if (q){ if (c === '"'){ if (l[i+1] === '"'){ cur += '"'; i++; } else q = false; } else cur += c; }
    else { if (c === '"') q = true; else if (c === ','){ out.push(cur); cur = ''; } else cur += c; }
  }
  out.push(cur); return out;
}
async function fetchGTFS(file, reqCol){
  const att = [CFG.GTFS_DIR + file, '?_gf=' + encodeURIComponent(file)];
  let lastErr = '';
  for (let i = 0; i < att.length; i++){
    try {
      const res = await fetch(att[i], { cache: 'force-cache' });
      if (!res.ok){ lastErr = 'HTTP ' + res.status; continue; }
      const text = await res.text();
      if (text.slice(0, 400).replace(/^\uFEFF/, '').indexOf(reqCol) < 0){ lastErr = 'to nie ' + file; continue; }
      return text;
    } catch (e){ lastErr = e.message; }
  }
  throw new Error('Nie udało się wczytać ' + file + ' (' + lastErr + ')');
}
function tableRows(text){
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  const lines = text.split('\n');
  while (lines.length && lines[lines.length-1].trim() === '') lines.pop();
  const cols = {};
  parseCSVLine(lines[0]).forEach(function(h, i){ cols[h.trim()] = i; });
  return { cols: cols, lines: lines };
}
function ldFile(name){ const li = document.createElement('li');
  li.innerHTML = esc(name) + ' <i>…</i>'; $('#ld-files').appendChild(li); return li; }
function ldOk(li, info){ li.classList.add('done'); li.querySelector('i').textContent = info; }
async function loadStatic(){
  const plan = [
    ['feed_info.txt','feed_publisher_name',false], ['routes.txt','route_id',false],
    ['trips.txt','trip_id',true], ['stops.txt','stop_id',true],
    ['stop_areas.txt','stop_id',false],
    ['calendar_dates.txt','service_id',false], ['calendar.txt','service_id',false],
    ['stop_times.txt','trip_id',true], ['shapes.txt','shape_id',false]
  ];
  let done = 0;
  for (let p = 0; p < plan.length; p++){
    const file = plan[p][0], req = plan[p][1], mand = plan[p][2];
    const li = ldFile(file);
    $('#ld-msg').textContent = 'Wczytywanie ' + file + '…';
    let text = null;
    try { text = await fetchGTFS(file, req); } catch (e){ if (mand) throw e; }
    if (text == null){ ldOk(li, 'pominięty'); done++;
      $('#ld-bar').style.width = (done/plan.length*100)+'%'; continue; }
    const t = tableRows(text), cols = t.cols, lines = t.lines;
    if (file === 'feed_info.txt'){
      const r = parseCSVLine(lines[1] || ''); G.feedInfo = {};
      for (const k in cols) G.feedInfo[k] = r[cols[k]];
    } else if (file === 'routes.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.route_id]) continue;
        G.routes.set(c[cols.route_id], { id:c[cols.route_id],
          short:c[cols.route_short_name] || c[cols.route_id], long:c[cols.route_long_name] || '' }); }
    } else if (file === 'trips.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.trip_id]; if (!id) continue;
        G.trips.set(id, { route_id:c[cols.route_id], service_id:c[cols.service_id],
          headsign:c[cols.trip_headsign] || '', shape_id:c[cols.shape_id] || '', brigade:c[cols.brigade] || '' }); }
    } else if (file === 'stops.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.stop_id]; if (!id) continue;
        const s = { id:id, code:c[cols.stop_code] || '', name:c[cols.stop_name] || id,
          lat:+c[cols.stop_lat], lon:+c[cols.stop_lon],
          street:c[cols.street_name] || '', town:c[cols.town_name] || '', zone:c[cols.zone_id] || '' };
        G.stops.set(id, s); stopsArray.push(s); }
    } else if (file === 'stop_areas.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const aid = c[cols.area_id], sid = c[cols.stop_id];
        if (!aid || !sid) continue;
        G.stopArea.set(sid, aid);
        const st = G.stops.get(sid);
        if (st && !st.zone) st.zone = aid;
      }
    } else if (file === 'calendar_dates.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.service_id]) continue;
        const d = c[cols.date];
        if (!G.calDates.has(d)) G.calDates.set(d, []);
        G.calDates.get(d).push([c[cols.service_id], c[cols.exception_type]]); }
    } else if (file === 'calendar.txt'){
      const dn = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        if (!c[cols.service_id]) continue;
        const mask = [];
        for (let d = 0; d < 7; d++) mask.push(c[cols[dn[d]]] === '1');
        G.calRows.push({ sid:c[cols.service_id], mask:mask, start:c[cols.start_date], end:c[cols.end_date] }); }
    } else if (file === 'stop_times.txt'){
      const iT=cols.trip_id, iA=cols.arrival_time, iD=cols.departure_time, iS=cols.stop_id,
            iQ=cols.stop_sequence, iP=(cols.pickup_type!==undefined)?cols.pickup_type:-1,
            iO=(cols.drop_off_type!==undefined)?cols.drop_off_type:-1;
      let t0 = performance.now();
      for (let i = 1; i < lines.length; i++){
        const l = lines[i]; if (l === '') continue;
        const c = (l.indexOf('"') < 0) ? l.split(',') : parseCSVLine(l);
        const tid = c[iT]; if (!tid) continue;
        const seq = +c[iQ] || 0, sid = c[iS]; if (!sid) continue;
        let arr = hmsToSec(c[iA]), dep = hmsToSec(c[iD]);
        if (arr == null) arr = dep; if (dep == null) dep = arr; if (dep == null) continue;
        const pu = (iP >= 0) ? ((c[iP] === '') ? 0 : +c[iP]) : 0;
        const dof = (iO >= 0) ? ((c[iO] === '') ? 0 : +c[iO]) : 0;
        let tt = G.stopTimes.get(tid); if (!tt){ tt = []; G.stopTimes.set(tid, tt); }
        tt.push([seq, sid, arr, dep, pu, dof]);
        let ss = G.stopIndex.get(sid); if (!ss){ ss = []; G.stopIndex.set(sid, ss); }
        ss.push([tid, seq, dep, pu]);
        if ((i & 65535) === 0 && performance.now() - t0 > 40){
          $('#ld-bar').style.width = ((done + i/lines.length)/plan.length*100)+'%';
          $('#ld-msg').textContent = 'stop_times… ' + ((i/lines.length*100)|0) + '%';
          await new Promise(function(r){ setTimeout(r); }); t0 = performance.now();
        }
      }
    } else if (file === 'shapes.txt'){
      for (let i = 1; i < lines.length; i++){ const c = parseCSVLine(lines[i]);
        const id = c[cols.shape_id]; if (!id) continue;
        let a = G.shapes.get(id); if (!a){ a = []; G.shapes.set(id, a); }
        a.push([+c[cols.shape_pt_sequence] || 0, +c[cols.shape_pt_lat], +c[cols.shape_pt_lon]]); }
    }
    ldOk(li, (text.length/1024).toFixed(0) + ' KB');
    done++; $('#ld-bar').style.width = (done/plan.length*100)+'%';
    await new Promise(function(r){ setTimeout(r, 10); });
  }
}
function tripStops(tid){
  const a = G.stopTimes.get(tid); if (!a) return null;
  if (!a._s){ a.sort(function(x,y){ return x[0]-y[0]; }); a._s = true; }
  return a;
}
function shapePoints(id){
  const a = G.shapes.get(id); if (!a || !a.length) return null;
  if (!a._s){ a.sort(function(x,y){ return x[0]-y[0]; }); a._s = true; }
  return a;
}

const S = { vehicles:new Map(), tu:new Map(), alerts:[], tripVeh:new Map(),
  feedBase: Math.floor(Date.now()/1000), feedReal: Date.now(),
  routeFilter:null, firstFit:false, refreshing:false,
  errToasted:false, activeCache:null, activeDate:null, pickHide:false };
const SEL = { stop:null };
const STOP = { tab:'dep' };
const ROUTE = { stack:[] };
const PLUI = { a:null, b:null, last:null };
const BOARD = { limit:20, deps:[] };
const STOPS = { q:'', limit:40, sorted:null };
const ALERTS = { sig:null, dismissed:null };
const REC = { routes:[], stops:[] };
function routeActive(){ return ROUTE.stack.length ? ROUTE.stack[ROUTE.stack.length-1] : null; }
function clockNow(){ return S.feedBase + (Date.now() - S.feedReal)/1000; }
function dayStartUnix(){ const d = new Date(S.feedBase*1000); d.setHours(0,0,0,0); return Math.floor(d.getTime()/1000); }
function feedDateStr(){ const d = new Date(S.feedBase*1000);
  return d.getFullYear() + '-' + p2(d.getMonth()+1) + '-' + p2(d.getDate()); }
function activeServices(ds){
  const set = new Set(); const g = ds.replace(/-/g, '');
  const dow = new Date(ds + 'T12:00:00').getDay();
  const idx = (dow === 0) ? 6 : dow - 1;
  for (let i = 0; i < G.calRows.length; i++){
    const c = G.calRows[i];
    if (g >= c.start && g <= c.end && c.mask[idx]) set.add(c.sid);
  }
  const ex = G.calDates.get(g);
  if (ex) for (let i = 0; i < ex.length; i++){
    if (ex[i][1] === '1') set.add(ex[i][0]); else set.delete(ex[i][0]);
  }
  return set.size ? set : null;
}
function ensureActive(){
  const ds = feedDateStr();
  if (S.activeDate !== ds){ S.activeCache = activeServices(ds); S.activeDate = ds; }
}
const STATUS_TXT = ['dojeżdża do przystanku','na przystanku','w trasie'];
const OCC_TXT = ['pusty','dużo miejsc','kilka miejsc','tylko stojące','ścisk','pełny','nie przyjmuje pasażerów'];
const CAUSE_TXT = ['przyczyna nieznana','inna przyczyna','usterka techn.','strajk','demonstracja','wypadek','święto','pogoda','konserwacja','remont','policja','incydent med.'];
const EFFECT_TXT = ['skutek nieznany','inny skutek','brak kursów','ograniczony rozkład','istotne opóźnienia','objazd','kursy dodatkowe','zmieniony rozkład','przystanek przeniesiony','brak skutku','utrudnienia dla wózków'];

function tripRowsLive(tid){
  const rows = tripStops(tid);
  if (!rows) return null;
  const tu = S.tu.get(String(tid));
  const ds0 = dayStartUnix();
  const out = [];
  if (!tu){
    for (let i = 0; i < rows.length; i++)
      out.push({ sid:String(rows[i][1]), seq:rows[i][0], dep:rows[i][3], depL:null, delay:null });
    return out;
  }
  const stuBySeq = new Map();
  const stus = tu.stops || [];
  for (let i = 0; i < stus.length; i++)
    if (stus[i].seq != null) stuBySeq.set(stus[i].seq, stus[i]);
  let carry = (tu.delay != null) ? tu.delay : null;
  for (let i = 0; i < rows.length; i++){
    const r = rows[i];
    const stu = stuBySeq.get(r[0]);
    if (stu){
      if (stu.depDelay != null) carry = stu.depDelay;
      else if (stu.arrDelay != null) carry = stu.arrDelay;
    }
    let depL = null;
    if (stu){
      if (stu.depTime) depL = stu.depTime;
      else if (stu.arrTime) depL = stu.arrTime;
    }
    if (depL == null) depL = ds0 + r[3] + (carry != null ? carry : 0);
    out.push({ sid:String(r[1]), seq:r[0], dep:r[3], depL:depL, delay:carry });
  }
  return out;
}
function liveRowFor(tid, seq){
  const rows = tripRowsLive(tid);
  if (!rows) return null;
  for (let i = 0; i < rows.length; i++) if (rows[i].seq === seq) return rows[i];
  return null;
}