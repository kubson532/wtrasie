'use strict';
/* app_4.js — ekrany, wyniki (FIX: firstDep+dayStartUnix zamiast firstDep vs unix),
   przystanki, kafle linii, feed, X-iki, init. */

const SCREENS = {};
['home','stops','results','settings'].forEach(function(n){
  const el = document.getElementById('scr-' + n);
  if (el) SCREENS[n] = el;
});
let CUR = 'home', PICK = null;
function go(name, keepSel, noPush){
  const prev = CUR;
  if (!keepSel){
    SEL.stop = null;
    pointLayer.clearLayers();
    PICK = null; S.pickHide = false; $('#pick-banner').hidden = true;
  }
  if (prev === 'route' && name !== 'route'){
    ROUTE.stack.length = 0;
    focusLayer.clearLayers(); dotLayer.clearLayers();
    if (stopPopup){ map.closePopup(stopPopup); stopPopup = null; }
  }
  const isMap = (name === 'map' || name === 'route');
  document.body.classList.toggle('show-map', isMap);
  document.body.classList.toggle('on-route', name === 'route');
  for (const k in SCREENS) SCREENS[k].classList.toggle('on', k === name);
  CUR = name;
  closeAc();
  syncNav();
  if (isMap) setTimeout(function(){
    map.invalidateSize();
    refreshVisibility(); updateStopsVis();
    if (name === 'route') syncDotVis();
    firstFitMaybe();
  }, 60);
  if (name === 'stops') renderStopsList();
  if (!noPush){ try { history.pushState({ ztm: name }, '', '#' + name); } catch (e){} }
}
window.addEventListener('popstate', function(e){
  const st = e.state && e.state.ztm;
  if (st === 'route'){
    if (ROUTE.stack.length > 1) ROUTE.stack.pop();
    const f = routeActive();
    if (f){ go('route', true, true); renderRoute(); drawRouteMap(f, false); return; }
    go('map', true, true);
    return;
  }
  if (st && SCREENS[st]) go(st, true, true);
  else go('map', true, true);
});
function routeBack(){
  if (history.length > 1){ history.back(); return; }
  if (ROUTE.stack.length > 1){ ROUTE.stack.pop(); renderRoute(); drawRouteMap(routeActive(), true); return; }
  const f = ROUTE.stack[0];
  ROUTE.stack.length = 0;
  focusLayer.clearLayers(); dotLayer.clearLayers();
  go(f && f.from && SCREENS[f.from] ? f.from : 'map', true);
}
 $('#route-back').addEventListener('click', routeBack);
document.querySelectorAll('[data-back]').forEach(function(b){
  b.addEventListener('click', function(){
    if (history.length > 1) history.back();
    else go('map');
  });
});
function syncNav(){
  let active = null;
  if (CUR === 'home' || CUR === 'results' || CUR === 'settings') active = 'home';
  else if (CUR === 'map' || CUR === 'route') active = 'buses';
  else active = 'stops';
  document.querySelectorAll('#bottomnav [data-nav]').forEach(function(b){
    b.classList.toggle('on', b.dataset.nav === active);
  });
}
document.querySelectorAll('#bottomnav [data-nav]').forEach(function(b){
  b.addEventListener('click', function(){
    const w = b.dataset.nav;
    if (w === 'home') go('home');
    else if (w === 'buses') go('map');
    else go('stops');
  });
});
function firstFitMaybe(){
  if (S.firstFit || !S.vehicles.size || CUR !== 'map') return;
  S.firstFit = true;
  const pts = [];
  S.vehicles.forEach(function(v){ pts.push([v.to.lat, v.to.lng]); });
  const b = L.latLngBounds(pts);
  if (b.isValid()) map.fitBounds(b, { padding:[50,50], maxZoom:13 });
}
 $('#btn-fit').addEventListener('click', function(){
  const pts = [];
  S.vehicles.forEach(function(v){ if (v.onMap) pts.push([v.to.lat, v.to.lng]); });
  if (pts.length){ const b = L.latLngBounds(pts); if (b.isValid()) map.fitBounds(b, { padding:[50,50], maxZoom:13 }); }
  else map.setView([50.0413, 21.999], 13);
});

document.querySelectorAll('.clr-x').forEach(function(btn){
  btn.addEventListener('click', function(){
    const inp = document.getElementById(btn.dataset.clear);
    if (!inp) return;
    inp.value = '';
    inp.dispatchEvent(new Event('input', { bubbles:true }));
    inp.focus();
  });
});
['hp-a','hp-b','stops-q','map-search'].forEach(function(id){
  const inp = document.getElementById(id);
  if (!inp) return;
  const btn = document.querySelector('.clr-x[data-clear="' + id + '"]');
  if (!btn) return;
  function upd(){
    const focused = (document.activeElement === inp);
    btn.hidden = !(focused || !!inp.value);
  }
  inp.addEventListener('input', upd);
  inp.addEventListener('focus', upd);
  inp.addEventListener('blur', function(){ setTimeout(upd, 120); });
  upd();
});

function buildAC(){
  const seen = new Set();
  STOPS.sorted = [];
  for (let i = 0; i < stopsArray.length; i++){
    const s = stopsArray[i];
    if (seen.has(s.name)) continue;
    seen.add(s.name);
    STOPS.sorted.push({ name:s.name, tt:toks(s.name), sid:s.id, code:s.code });
  }
  STOPS.sorted.sort(function(a,b){ return a.name.localeCompare(b.name, 'pl'); });
}
function acQuery(q, limit){
  const qt = toks(q);
  if (!qt.length || !STOPS.sorted) return [];
  const out = [];
  for (let i = 0; i < STOPS.sorted.length; i++){
    const s = STOPS.sorted[i];
    const sc = matchScore(qt, s.tt);
    if (sc >= 0) out.push({ s: s, sc: sc });
    if (out.length >= 120) break;
  }
  out.sort(function(a,b){ return b.sc - a.sc || a.s.name.localeCompare(b.s.name, 'pl'); });
  return out.slice(0, limit).map(function(o){ return o.s; });
}
function closeAc(){
  ['#ac-a','#ac-b','#map-ac'].forEach(function(s){ const el = $(s); if (el) el.hidden = true; });
}
function attachAC(inputSel, panelSel, onPick, topHtmlFn){
  const inp = $(inputSel), panel = $(panelSel);
  if (!inp || !panel) return;
  function render(){
    const q = inp.value.trim();
    let html = '';
    if (!q && topHtmlFn) html = topHtmlFn();
    else if (q){
      const res = acQuery(q, 8);
      html = res.map(function(rr){
        return '<button class="ac-item" data-sid="' + esc(rr.sid) + '"><svg class="ic"><use href="#i-pin"/></svg><span>' + esc(rr.name) + '</span><small>' + esc(rr.code || '') + '</small></button>';
      }).join('') || '<div class="ac-empty">Brak przystanków</div>';
    }
    panel.innerHTML = html;
    panel.hidden = !html;
  }
  inp.addEventListener('input', render);
  inp.addEventListener('focus', render);
  panel.addEventListener('click', function(e){
    const b = e.target.closest('[data-sid]');
    if (!b) return;
    if (onPick(b.dataset.sid) !== false) panel.hidden = true;
  });
  document.addEventListener('click', function(e){
    if (e.target !== inp && !panel.contains(e.target)) panel.hidden = true;
  });
}

function recLoad(){
  try { const r = JSON.parse(localStorage.getItem('ztm-rec') || '{}');
    REC.routes = Array.isArray(r.routes) ? r.routes : [];
    REC.stops = Array.isArray(r.stops) ? r.stops : [];
  } catch (e){}
}
function recSave(){ try { localStorage.setItem('ztm-rec', JSON.stringify(REC)); } catch (e){} }
function recRouteAdd(a, b){
  const A = { l: a.label || 'start', sid: a.sid || null, lat: a.sid ? null : a.lat, lng: a.sid ? null : a.lng, gps: (!a.sid && a.lat == null) };
  const B = { l: b.label || 'cel', sid: b.sid || null, lat: b.sid ? null : b.lat, lng: b.sid ? null : b.lng };
  REC.routes = REC.routes.filter(function(rr){ return !(rr.a.l === A.l && rr.b.l === B.l); });
  REC.routes.unshift({ a: A, b: B });
  REC.routes = REC.routes.slice(0, 6);
  recSave();
  renderHomeHist();
}
function recStopAdd(sid){
  REC.stops = REC.stops.filter(function(s){ return s !== sid; });
  REC.stops.unshift(sid);
  REC.stops = REC.stops.slice(0, 6);
  recSave();
}
function renderHomeHist(){
  const b = $('#home-hist-body');
  if (!b) return;
  let h = '';
  if (REC.routes.length){
    h += '<div class="hs-sec">Trasy</div>';
    for (let i = 0; i < REC.routes.length; i++){
      const rr = REC.routes[i];
      h += '<button class="hs-route" data-r="' + i + '"><svg class="ic"><use href="#i-arrow"/></svg><span><b>' + esc(rr.a.l) + '</b> → <b>' + esc(rr.b.l) + '</b></span></button>';
    }
  }
  const st = REC.stops.slice(0, 6).map(function(sid){ return G.stops.get(sid); }).filter(Boolean);
  if (st.length){
    h += '<div class="hs-sec">Przystanki</div><div class="hs-chips">';
    for (let i = 0; i < st.length; i++)
      h += '<button class="hchip" data-sid="' + esc(st[i].id) + '">' + esc(st[i].name) + '</button>';
    h += '</div>';
  }
  if (!h) h = '<div class="hs-empty">Historia pojawi się tutaj</div>';
  b.innerHTML = h;
}
function applyRecPoint(p, which){
  const inp = $(which === 'a' ? '#hp-a' : '#hp-b');
  if (p.gps){ PLUI[which] = null; inp.value = 'Moja lokalizacja'; return; }
  if (p.sid){
    const s = G.stops.get(p.sid);
    if (s){ PLUI[which] = null; inp.value = s.name; return; }
  }
  if (p.lat != null && p.lng != null){ PLUI[which] = { lat: p.lat, lng: p.lng }; inp.value = p.l; return; }
  inp.value = p.l || '';
}
document.addEventListener('click', function(e){
  const r = e.target.closest('#home-hist-body [data-r]');
  if (r){
    const rr = REC.routes[+r.dataset.r];
    if (rr){ applyRecPoint(rr.a, 'a'); applyRecPoint(rr.b, 'b'); }
    return;
  }
  const s = e.target.closest('#home-hist-body [data-sid]');
  if (s) openRoute('stop', { stopId: s.dataset.sid, from: 'stops' });
});

function drawPointPins(){
  pointLayer.clearLayers();
  const a = resolvePoint('a'), b = resolvePoint('b');
  if (a) pointLayer.addLayer(L.marker([a.lat, a.lng], { icon: pinIcon('A','pp-a'), zIndexOffset:800 }));
  if (b) pointLayer.addLayer(L.marker([b.lat, b.lng], { icon: pinIcon('B','pp-b'), zIndexOffset:800 }));
}
function setPick(which){
  PICK = which;
  S.pickHide = !!which;
  $('#pick-banner').hidden = !which;
  $('#pick-txt').textContent = which === 'a' ? 'Kliknij punkt STARTOWY (A)' : 'Kliknij punkt CELU (B)';
  drawPointPins();
  refreshVisibility();
  updateStopsVis();
  if (which) go('map', true);
}
function setPlanPoint(which, lat, lng){
  PLUI[which] = { lat: lat, lng: lng };
  $(which === 'a' ? '#hp-a' : '#hp-b').value = 'Punkt z mapy (' + lat.toFixed(4) + ', ' + lng.toFixed(4) + ')';
  PICK = null; S.pickHide = false;
  $('#pick-banner').hidden = true;
  drawPointPins();
  refreshVisibility();
  updateStopsVis();
  go('home', true);
}
 $('#pick-cancel').addEventListener('click', function(){
  PICK = null; S.pickHide = false;
  $('#pick-banner').hidden = true;
  refreshVisibility(); updateStopsVis();
  go('home', true);
});
 $('#hp-a-map').addEventListener('click', function(){ setPick('a'); });
 $('#hp-b-map').addEventListener('click', function(){ setPick('b'); });
 $('#hp-a-gps').addEventListener('click', function(){
  if (!GPS.on) toggleGps();
  else { PLUI.a = null; setGpsFieldText(); }
});
 $('#sp-walk').addEventListener('click', function(){
  PLANNER.setSpeed(5);
  $('#sp-walk').classList.add('on'); $('#sp-run').classList.remove('on');
});
 $('#sp-run').addEventListener('click', function(){
  PLANNER.setSpeed(10);
  $('#sp-run').classList.add('on'); $('#sp-walk').classList.remove('on');
});
function resolvePoint(which){
  const inp = $(which === 'a' ? '#hp-a' : '#hp-b');
  const txt = (inp.value || '').trim();
  if (txt && txt.indexOf('Punkt z mapy') !== 0 && txt.indexOf('Moja lokalizacja') !== 0){
    const res = acQuery(txt, 1);
    if (res.length){
      const s = G.stops.get(res[0].sid);
      if (s) return { lat: s.lat, lng: s.lon, label: s.name, sid: s.id };
    }
  }
  if (PLUI[which]) return PLUI[which];
  if (which === 'a' && GPS.on && GPS.lat != null) return { lat: GPS.lat, lng: GPS.lng, label: 'moja lokalizacja' };
  return null;
}
 $('#hp-go').addEventListener('click', function(){
  const a = resolvePoint('a'), b = resolvePoint('b');
  if (!b){ toast('Ustaw cel (B)', true); return; }
  if (!a){ toast('Ustaw start: przystanek, mapa lub lokalizacja', true); return; }
  if (PLANNER.havM([a.lat, a.lng], [b.lat, b.lng]) < 30){ toast('A i B to to samo miejsce', true); return; }
  recRouteAdd(a, b);
  const dateStr = $('#pl-date').value || feedDateStr();
  const tv = ($('#pl-time').value || fmtUnix(Math.floor(clockNow()))).split(':');
  const depSec = ((+tv[0]) || 0) * 3600 + ((+tv[1]) || 0) * 60;
  const xfers = +$('#pl-xfer').value;
  PLUI.last = { a: a, b: b, depSec: depSec, dateStr: dateStr, xfers: xfers, res: null, busy: false, depUsed: depSec };
  go('results');
  $('#res-body').innerHTML = '<div class="empty">Szukam połączeń…</div>';
  runSearch(true);
});
function runSearch(forceNow){
  const L = PLUI.last;
  if (!L || L.busy) return;
  L.busy = true;
  setTimeout(function(){
    let dep = L.depSec;
    if (forceNow && dep < clockNow() - dayStartUnix() - 60) dep = Math.floor(clockNow() - dayStartUnix());
    try {
      const res = PLANNER.plan(L.a.lat, L.a.lng, L.b.lat, L.b.lng, dep, L.dateStr, L.xfers);
      L.res = res;
      L.depUsed = dep;
      renderResults();
      refineWalksValhalla();
    } catch (err){
      if (CUR === 'results' && !L.res) $('#res-body').innerHTML = '<div class="empty">Błąd planera: ' + esc((err && err.message) || err) + '</div>';
    }
    L.busy = false;
  }, 30);
}
setInterval(function(){
  if (CUR === 'results' && PLUI.last && PLUI.last.res && !PLUI.last.busy) runSearch(true);
}, 10000);
let VALH_GEN = 0;
function refineWalksValhalla(){
  const L = PLUI.last;
  if (!L || !L.res || !L.res.journeys) return;
  const gen = ++VALH_GEN;
  const jobs = [];
  L.res.journeys.forEach(function(j){
    j.legs.forEach(function(leg){
      if (leg.type === 'walk') jobs.push({ j: j, leg: leg });
    });
  });
  if (L.res.walk) jobs.push({ walkMain: true });
  if (!jobs.length) return;
  let done = 0;
  jobs.forEach(function(job){
    const fp = job.walkMain ? [L.a.lat, L.a.lng] : (job.leg.fromPt ? [job.leg.fromPt.lat, job.leg.fromPt.lng] : stopPos(job.leg.fromSid));
    const tp = job.walkMain ? [L.b.lat, L.b.lng] : (job.leg.toPt ? [job.leg.toPt.lat, job.leg.toPt.lng] : stopPos(job.leg.toSid));
    if (!fp || !tp){ finish(); return; }
    PLANNER.valhallaWalk([fp, tp]).then(function(v){
      if (gen !== VALH_GEN) return;
      if (v && v.coords && v.dist != null){
        if (job.walkMain){ L.res.walk.vCoords = v.coords; }
        else { job.leg.vCoords = v.coords; job.leg.vDur = PLANNER.walkSec(v.dist); }
      }
      finish();
    }).catch(function(){ finish(); });
  });
  function finish(){
    done++;
    if (done >= jobs.length && gen === VALH_GEN){
      if (CUR === 'results') renderResults();
      const f = routeActive();
      if (f && (f.mode === 'journey' || f.mode === 'walk')) drawRouteMap(f, false);
    }
  }
}

function legWalkHtml(leg){
  const kind = (leg.kind === 'access') ? 'Dojście do przystanku' : ((leg.kind === 'egress') ? 'Dojście do celu' : 'Przesiadka pieszo');
  const dur = leg.vDur || leg.sec;
  return '<div class="leg leg-walk"><span class="lic"><span class="dotleg" style="--dc:#98a2ad"></span></span>' +
    '<span class="lmain"><span class="l1">' + kind + ' · ' + fmtDist(leg.dist) + (leg.vCoords ? ' · chodniki' : '') + '</span>' +
    '<span class="l2">~' + fmtDur(dur) + '</span></span></div>';
}
function legRideHtml(leg, rideNo){
  const route = G.routes.get(leg.routeId);
  const line = route ? route.short : (leg.routeId || '?');
  return '<div class="leg leg-ride"><span class="lic"><span class="dotleg" style="--dc:' + legColor(rideNo) + '"></span></span>' +
    '<span class="lmain"><span class="l1">' + esc(leg.headsign || line) + '</span>' +
    '<span class="l2">' + esc(stopName(leg.boardSid)) + ' → ' + esc(stopName(leg.alightSid)) + '</span></span>' +
    '<span class="lt">' + fmtT(leg.dep) + '→' + fmtT(leg.arr) + '</span></div>';
}
function journeyCard(j, idx){
  const legs = j.legs;
  let walkTotal = 0, firstRide = null, rideNo = 0;
  const parts = [];
  for (let i = 0; i < legs.length; i++){
    if (legs[i].type === 'walk'){ walkTotal += (legs[i].vDur || legs[i].sec); parts.push(legWalkHtml(legs[i])); }
    else {
      if (!firstRide) firstRide = legs[i];
      parts.push(legRideHtml(legs[i], rideNo)); rideNo++;
      const nx = legs[i+1];
      if (nx && nx.type === 'ride' && nx.boardSid === legs[i].alightSid)
        parts.push('<div class="xfer">' + esc(stopName(legs[i].alightSid)) + ' · ' + fmtDur(Math.max(0, nx.dep - legs[i].arr)) + '</div>');
    }
  }
  const isTop = (idx === 0);
  const badges = (isTop ? '<span class="jr-badge">najlepsza</span>' : '') +
    (j.transfers === 0 ? '<span class="jr-badge dir">bezpośrednia</span>' : '');
  const xt = (j.transfers === 0) ? 'bezpośrednio' : (j.transfers + (j.transfers === 1 ? ' przesiadka' : ' przesiadki'));
  const depTxt = firstRide ? '<span class="mmain" id="jc' + idx + 'e"></span>' : '';
  if (firstRide) liveAdd('jc' + idx + 'e', dayStartUnix() + firstRide.depS);
  return '<div class="jr' + (isTop ? ' best open' : '') + '" data-j="' + idx + '">' +
    '<div class="jr-top"><svg class="ic"><use href="#i-bus"/></svg>' +
    '<b>' + depTxt + ' → ' + fmtT(j.arrive) + '</b>' + badges +
    '<span class="jr-sum">' + xt + ' · ' + fmtDur(j.arrive - (PLUI.last.depUsed || PLUI.last.depSec)) + ' · pieszo ' + fmtDur(walkTotal) + '</span></div>' +
    '<div class="jr-body">' + parts.join('') + '</div>' +
    '<div class="jr-foot"><button data-act="map" data-j="' + idx + '"><svg class="ic" style="width:14px;height:14px"><use href="#i-fit"/></svg> Otwórz na mapie</button></div></div>';
}
/* FIX: firstDep (sec from midnight) + dayStartUnix() = unix → porównanie z clockNow() */
function filterLiveJourneys(){
  const res = PLUI.last.res;
  if (!res || !res.journeys) return [];
  const ds0 = dayStartUnix();
  const now = clockNow();
  let live = res.journeys.filter(function(j){
    return j.firstDep == null || (ds0 + j.firstDep) > now - 900;
  });
  if (!live.length) live = res.journeys;
  return live;
}
function renderResults(){
  const PP = PLUI.last;
  if (!PP || !PP.res) return;
  const res = PP.res;
  if (res.error){ $('#res-body').innerHTML = '<div class="empty">' + esc(res.error) + '</div>'; return; }
  const live = filterLiveJourneys();
  let minArr = Infinity;
  for (let i = 0; i < live.length; i++) if (live[i].arrive < minArr) minArr = live[i].arrive;
  let html = '';
  if (res.walk && res.walk.sec < 2700){
    const wArr = (PP.depUsed || PP.depSec) + res.walk.sec;
    const best = (wArr <= minArr);
    html += '<div class="jr' + (best ? ' best' : '') + '" data-j="walk">' +
      '<div class="jr-top"><svg class="ic" style="color:var(--dim)"><use href="#i-walk"/></svg><b>Pieszo</b>' +
      (best ? '<span class="jr-badge">najszybciej</span>' : '') +
      '<span class="jr-sum">~' + fmtDur(res.walk.sec) + ' · ' + fmtDist(res.walk.dist) + '</span></div>' +
      '<div class="jr-foot"><button data-act="map" data-j="walk">Otwórz na mapie</button></div></div>';
  }
  for (let i = 0; i < live.length; i++) html += journeyCard(live[i], i);
  $('#res-body').innerHTML = html || '<div class="empty">Brak połączeń.</div>';
  tickLive();
}
 $('#res-body').addEventListener('click', function(e){
  const card = e.target.closest('.jr');
  if (!card) return;
  if (e.target.closest('[data-act="map"]')){
    if (card.dataset.j === 'walk'){ openRoute('walk', { from: 'results' }); return; }
    const live = filterLiveJourneys();
    const j = live[+card.dataset.j];
    if (j) openRoute('journey', { journey: j, from: 'results' });
    return;
  }
  if (e.target.closest('.jr-top')) card.classList.toggle('open');
});

function stopDepartures(stopId){
  ensureActive();
  const act = S.activeCache, now = clockNow(), ds0 = dayStartUnix();
  const deps = [];
  const list = G.stopIndex.get(String(stopId)) || [];
  for (let i = 0; i < list.length; i++){
    const tid = list[i][0], seq = list[i][1], dep = list[i][2], pu = list[i][3];
    if (pu === 1) continue;
    const trip = G.trips.get(tid);
    if (act && (!trip || !act.has(trip.service_id))) continue;
    const depUnix = ds0 + dep;
    if (depUnix < now - 150) continue;
    let est = depUnix, rt = false, delay = null;
    const tu = S.tu.get(tid);
    if (tu){
      rt = true;
      const lr = liveRowFor(tid, seq);
      if (lr){ if (lr.depL != null) est = lr.depL; delay = lr.delay; }
      else if (tu.delay != null){ est = depUnix + tu.delay; delay = tu.delay; }
    }
    if (est < now - 150) continue;
    deps.push({ tid: tid, depUnix: depUnix, est: est, rt: rt, delay: delay, trip: trip });
  }
  deps.sort(function(a,b){ return a.est - b.est; });
  return deps;
}

function stopsMatches(){
  if (!STOPS.sorted) return [];
  const q = STOPS.q.trim();
  if (!q) return STOPS.sorted;
  const qt = toks(q);
  if (!qt.length) return STOPS.sorted;
  const out = [];
  for (let i = 0; i < STOPS.sorted.length; i++){
    if (matchScore(qt, STOPS.sorted[i].tt) >= 0) out.push(STOPS.sorted[i]);
    if (out.length >= 400) break;
  }
  out.sort(function(a,b){ return matchScore(qt,b.tt) - matchScore(qt,a.tt); });
  return out;
}
function stopsItemHtml(r){
  let dist = '';
  if (GPS.on && GPS.lat != null){
    const s = G.stops.get(r.sid);
    if (s) dist = '<span class="sdst">' + fmtDist(PLANNER.havM([GPS.lat, GPS.lng], [s.lat, s.lon])) + '</span>';
  }
  const s2 = G.stops.get(r.sid);
  const zone = (s2 && s2.zone) ? s2.zone : '';
  return '<button class="stop-item" data-sid="' + esc(r.sid) + '">' +
    '<span class="stop-main"><span class="stop-nrow">' +
    '<span class="stop-nm">' + esc(r.name) + '</span>' +
    (r.code ? '<span class="stop-code">' + esc(r.code) + '</span>' : '') +
    '</span></span>' + dist +
    (zone ? '<span class="zone-sq z' + esc(zone.toLowerCase()) + '">' + esc(zone) + '</span>' : '') +
    '</button>';
}
function renderStopsList(keepScroll){
  if (CUR !== 'stops' || !STOPS.sorted) return;
  const box = $('#stops-list');
  const sc = keepScroll ? box.scrollTop : 0;
  const q = STOPS.q.trim();
  const gpsOn = GPS.on && GPS.lat != null;
  let html = '';
  if (!q){
    const rec = REC.stops.slice(0, 3).map(function(sid){ return G.stops.get(sid); }).filter(Boolean);
    if (rec.length){
      html += '<div class="stops-sec">Ostatnie</div>';
      for (let i = 0; i < rec.length; i++) html += stopsItemHtml({ sid: rec[i].id, name: rec[i].name, code: rec[i].code });
    }
    if (gpsOn){
      const near = [];
      for (let i = 0; i < STOPS.sorted.length; i++){
        const s = G.stops.get(STOPS.sorted[i].sid);
        if (s) near.push({ r: STOPS.sorted[i], d: PLANNER.havM([GPS.lat, GPS.lng], [s.lat, s.lon]) });
      }
      near.sort(function(a,b){ return a.d - b.d; });
      html += '<div class="stops-sec">Najbliżej</div>';
      for (let i = 0; i < Math.min(10, near.length); i++) html += stopsItemHtml(near[i].r);
    }
  }
  const all = stopsMatches();
  html += '<div class="stops-sec">' + (q ? 'Wyniki (' + all.length + ')' : 'Wszystkie') + '</div>';
  const shown = all.slice(0, STOPS.limit);
  for (let i = 0; i < shown.length; i++) html += stopsItemHtml(shown[i]);
  if (!shown.length) html += '<div class="empty">Brak wyników.</div>';
  else if (STOPS.limit < all.length) html += '<div class="loadmore">przewiń — więcej (' + (all.length - STOPS.limit) + ')</div>';
  box.innerHTML = html;
  box.scrollTop = sc;
}
 $('#stops-q').addEventListener('input', function(){
  STOPS.q = $('#stops-q').value;
  STOPS.limit = 40;
  renderStopsList();
});
 $('#stops-list').addEventListener('click', function(e){
  const b = e.target.closest('[data-sid]');
  if (b){
    recStopAdd(b.dataset.sid);
    openRoute('stop', { stopId: b.dataset.sid, from: 'stops' });
  }
});
 $('#stops-list').addEventListener('touchstart', function(e){
  const b = e.target.closest('.stop-item');
  if (b){
    const nm = b.querySelector('.stop-nm');
    if (nm && nm.scrollWidth > nm.clientWidth + 2) b.classList.add('expanded');
  }
}, { passive: true });
 $('#stops-list').addEventListener('scroll', function(){
  const box = $('#stops-list');
  if (box.scrollTop + box.clientHeight > box.scrollHeight - 160){
    const all = stopsMatches();
    if (STOPS.limit < all.length){
      STOPS.limit += 40;
      renderStopsList(true);
    }
  }
});

function renderLinesSheet(){
  const box = $('#lines-body');
  if (!box) return;
  const counts = new Map();
  S.vehicles.forEach(function(v){
    if (v.routeId) counts.set(v.routeId, (counts.get(v.routeId) || 0) + 1);
  });
  const ids = Array.from(counts.keys()).sort(function(a,b){
    const ra = G.routes.get(a), rb = G.routes.get(b);
    return natCmp((ra && ra.short) || a, (rb && rb.short) || b);
  });
  if (!ids.length){ box.innerHTML = '<div class="empty">Brak pojazdów na żywo.</div>'; return; }
  let h = '<div class="tgrid">';
  for (let i = 0; i < ids.length; i++){
    const id = ids[i], r = G.routes.get(id);
    h += '<div class="tile" data-line="' + esc(id) + '">' +
      '<div class="tile-ln">' + esc((r && r.short) || id) + '</div>' +
      '<div class="tile-cnt">' + counts.get(id) + '</div></div>';
  }
  box.innerHTML = h + '</div>';
}
 $('#lines-body').addEventListener('click', function(e){
  const b = e.target.closest('[data-line]');
  if (b) openRoute('line', { lineId: b.dataset.line, from: 'map' });
});

function mapAcRender(){
  const inp = $('#map-search'), panel = $('#map-ac');
  const q = inp.value.trim();
  if (!q){ panel.hidden = true; return; }
  const rows = [];
  const rl = Array.from(G.routes.values());
  const qtn = toks(q);
  for (let i = 0; i < rl.length && rows.length < 4; i++){
    const r = rl[i];
    if (matchScore(qtn, toks(r.short)) >= 0 || matchScore(qtn, toks(r.long || '')) >= 0)
      rows.push('<button class="ac-item" data-line="' + esc(r.id) + '"><svg class="ic"><use href="#i-bus"/></svg><span><b>' + esc(r.short) + '</b> · ' + esc(r.long || '') + '</span></button>');
  }
  const vs = [];
  const q2 = baseName(q).replace(/\s+/g, '');
  S.vehicles.forEach(function(v){
    if (vs.length >= 5) return;
    const lab = String(v.n.label || '');
    const plate = String(v.n.plate || '').toLowerCase().replace(/\s+/g, '');
    if ((lab && baseName(lab).indexOf(baseName(q)) >= 0) || (plate && q2 && plate.indexOf(q2) >= 0)) vs.push(v);
  });
  for (let i = 0; i < vs.length; i++){
    const v = vs[i];
    rows.push('<button class="ac-item" data-veh="' + esc(v.id) + '"><svg class="ic"><use href="#i-bus"/></svg><span><b>' + esc(v.n.label || v.lineName) + '</b> · linia ' + esc(v.lineName) + '</span></button>');
  }
  const stops = acQuery(q, 6);
  for (let i = 0; i < stops.length; i++)
    rows.push('<button class="ac-item" data-sid="' + esc(stops[i].sid) + '"><svg class="ic"><use href="#i-pin"/></svg><span>' + esc(stops[i].name) + '</span><small>' + esc(stops[i].code || '') + '</small></button>');
  panel.innerHTML = rows.join('') || '<div class="ac-empty">Brak wyników</div>';
  panel.hidden = false;
}
 $('#map-search').addEventListener('input', mapAcRender);
 $('#map-search').addEventListener('focus', mapAcRender);
 $('#map-ac').addEventListener('click', function(e){
  const vh = e.target.closest('[data-veh]');
  if (vh){ $('#map-ac').hidden = true; $('#map-search').value = ''; openRoute('vehicle', { vid: vh.dataset.veh, from: 'map' }); return; }
  const b = e.target.closest('[data-sid]');
  if (b){ $('#map-ac').hidden = true; $('#map-search').value = ''; showStopPop(b.dataset.sid); return; }
  const l = e.target.closest('[data-line]');
  if (l){ $('#map-ac').hidden = true; $('#map-search').value = ''; openRoute('line', { lineId: l.dataset.line, from: 'map' }); }
});
document.addEventListener('click', function(e){
  if (e.target !== $('#map-search') && !$('#map-ac').contains(e.target)) $('#map-ac').hidden = true;
});

async function fetchRT(){
  const errs = [];
  for (let i = 0; i < CFG.RT.length; i++){
    const src = CFG.RT[i];
    try {
      const res = await fetch(src.url, { cache:'no-store' });
      if (!res.ok){
        let t = '';
        try { t = (await res.text()).replace(/\s+/g,' ').slice(0, 90); } catch (e){}
        throw new Error('HTTP ' + res.status + (t ? ' — ' + t : ''));
      }
      const ab = await res.arrayBuffer();
      const gz = await PB.gunzip(new Uint8Array(ab));
      if (gz.warning && !gz.gunzipped) throw new Error(gz.warning);
      const kind = classify(gz.bytes);
      if (kind !== 'pb') throw new Error('serwer zwrócił: ' + kind);
      const F = parseGTFSRT(gz.bytes);
      F._src = src.label;
      F._cache = !!src.cache;
      return F;
    } catch (e){ errs.push(src.label + ': ' + ((e && e.message) ? e.message : String(e))); }
  }
  throw new Error(errs.join(' | '));
}
let DBG_TU = false;
function applyFeed(F){
  S.feedBase = F.timestamp; S.feedReal = Date.now();
  S.tu = F.updates; S.alerts = F.alerts;
  S.tripVeh = new Map();
  const seen = new Set();
  const list = [];
  for (let i = 0; i < F.vehicles.length; i++){
    const n = F.vehicles[i];
    seen.add(n.id);
    if (n.tripId != null) S.tripVeh.set(String(n.tripId), n.id);
    list.push(n);
  }
  const rm = [];
  S.vehicles.forEach(function(v, id){ if (!seen.has(id)) rm.push(id); });
  for (let i = 0; i < rm.length; i++) removeVehicle(rm[i]);
  queueUpserts(list);
  if (!DBG_TU){
    DBG_TU = true;
    let nTU = 0;
    F.updates.forEach(function(v){ nTU++; });
    console.log('[GTFS-RT] pojazdy: ' + F.vehicles.length + ' · TripUpdates: ' + nTU);
  }
  try { PLANNER.applyLive(S.tu, feedDateStr()); } catch (e){}
  LNC.key = null;
  renderLinesSheet();
  if (routeActive()) refreshRoute();
  renderAlerts();
}
function renderAlerts(){
  const bar = $('#alertbar'), list = $('#alerts-list');
  if (!S.alerts.length){ bar.hidden = true; list.hidden = true; ALERTS.sig = null; return; }
  ALERTS.sig = S.alerts.map(function(a){ return (a.header || '') + '|' + (a.desc || ''); }).join(';;');
  if (ALERTS.sig === ALERTS.dismissed){ bar.hidden = true; list.hidden = true; return; }
  bar.hidden = false;
  $('#alerts-sum').textContent = (S.alerts.length === 1)
    ? (S.alerts[0].header || 'komunikat przewoźnika')
    : S.alerts.length + ' komunikatów przewoźnika';
  list.innerHTML = S.alerts.map(function(a){
    const m = [];
    if (a.cause != null && CAUSE_TXT[a.cause]) m.push(CAUSE_TXT[a.cause]);
    if (a.effect != null && EFFECT_TXT[a.effect]) m.push(EFFECT_TXT[a.effect]);
    return '<div class="alr"><h4>' + esc(a.header || 'Komunikat') + '</h4>' +
      (a.desc ? '<p>' + esc(a.desc) + '</p>' : '') + '</div>';
  }).join('');
}
 $('#btn-alerts').addEventListener('click', function(){ const l = $('#alerts-list'); l.hidden = !l.hidden; });
 $('#alert-close').addEventListener('click', function(){
  ALERTS.dismissed = ALERTS.sig;
  $('#alertbar').hidden = true;
  $('#alerts-list').hidden = true;
});
async function refresh(force){
  if (S.refreshing) return;
  if (document.hidden && !force) return;
  S.refreshing = true;
  try {
    const F = await fetchRT();
    applyFeed(F);
    $('#feed-dot').className = 'dot ' + (F._cache ? 'file' : 'ok');
    $('#stat-feed-txt').textContent = (F._cache ? 'cache · ' : 'live · ') + fmtUnix(S.feedBase);
    S.errToasted = false;
  } catch (e){
    $('#feed-dot').className = 'dot err';
    $('#stat-feed-txt').textContent = 'błąd';
    if (!S.errToasted){ S.errToasted = true; toast('Feed nieudany: ' + ((e && e.message) || e), true); }
  } finally { S.refreshing = false; }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) refresh(true); });
 $('#feed-chip').addEventListener('click', function(){ refresh(true); });
async function loadPBFile(file){
  try {
    const ab = await file.arrayBuffer();
    const gz = await PB.gunzip(new Uint8Array(ab));
    const kind = classify(gz.bytes);
    if (kind !== 'pb') throw new Error('plik to: ' + kind);
    const F = parseGTFSRT(gz.bytes);
    F._src = 'plik'; F._cache = true;
    applyFeed(F);
    $('#feed-dot').className = 'dot file';
    $('#stat-feed-txt').textContent = 'plik · ' + fmtUnix(S.feedBase);
  } catch (e){ toast('Nie udało się wczytać .pb: ' + ((e && e.message) || e), true); }
}
 $('#btn-pbfile').addEventListener('click', function(){ $('#pbfile').click(); });
 $('#pbfile').addEventListener('change', function(e){
  const f = e.target.files && e.target.files[0];
  if (f) loadPBFile(f);
  e.target.value = '';
});
window.addEventListener('dragover', function(e){ e.preventDefault(); });
window.addEventListener('drop', function(e){
  e.preventDefault();
  const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (f && /\.(pb|gz)$/i.test(f.name)) loadPBFile(f);
});
let rzT = null;
window.addEventListener('resize', function(){
  clearTimeout(rzT);
  rzT = setTimeout(function(){ map.invalidateSize(); }, 200);
});

async function dumpPB(){
  const st = document.createElement('style');
  st.textContent = 'html,body{height:auto;overflow:auto;background:#fff;color:#111}body{margin:0;padding:16px;font:12px/1.5 ui-monospace,Menlo,monospace}pre{white-space:pre-wrap;word-break:break-all;margin:0}';
  document.head.appendChild(st);
  document.body.innerHTML = '';
  const pre = document.createElement('pre');
  document.body.appendChild(pre);
  document.title = 'GTFS-RT — raw dump';
  pre.textContent = 'Pobieram feed…\n';
  try {
    const F = await fetchRT();
    const tuObj = {};
    F.updates.forEach(function(v, k){ tuObj[k] = v; });
    pre.textContent = JSON.stringify({
      _source: F._src,
      header: { timestamp: F.timestamp, iso: new Date(F.timestamp * 1000).toISOString() },
      vehiclesCount: F.vehicles.length, vehicles: F.vehicles,
      tripUpdatesCount: Object.keys(tuObj).length, tripUpdates: tuObj, alerts: F.alerts
    }, null, 2);
  } catch (e){ pre.textContent = 'BŁĄD: ' + ((e && e.message) || e); }
}

(async function init(){
  if (QPB){ await dumpPB(); return; }
  try { history.replaceState({ ztm:'home' }, '', '#home'); } catch (e){}
  let mode = 'auto';
  try { mode = localStorage.getItem('ztm-theme') || 'auto'; } catch (e){}
  applyThemeMode(mode);
  try {
    const bm = localStorage.getItem('ztm-basemap');
    if (bm){ BASE.manual = true; setBasemapById(bm); }
  } catch (e){}
  recLoad();
  ldOk(ldFile('css/app.css'), 'liquid glass');
  ldOk(ldFile('js/pb-parser.js'), 'dekoder .pb');
  ldOk(ldFile('js/planner.js'), 'silnik live');
  ldOk(ldFile('js/app_1–4.js'), 'interfejs');
  try {
    await loadStatic();
    buildAC();
    buildStopLayers();
    renderHomeHist();
    $('#pl-date').value = feedDateStr();
    $('#pl-time').value = fmtUnix(Math.floor(clockNow()));
    attachAC('#hp-b', '#ac-b', function(sid){
      const s = G.stops.get(sid);
      if (s) $('#hp-b').value = s.name;
      return true;
    });
    attachAC('#hp-a', '#ac-a', function(sid){
      if (sid === '__gps'){ if (!GPS.on) toggleGps(); else { PLUI.a = null; setGpsFieldText(); } return true; }
      if (sid === '__map'){ $('#ac-a').hidden = true; setPick('a'); return true; }
      const s = G.stops.get(sid);
      if (s) $('#hp-a').value = s.name;
      return true;
    }, function(){
      return '<button class="ac-item" data-sid="__gps"><svg class="ic"><use href="#i-gps"/></svg><span>Moja lokalizacja' + (GPS.on ? ' (aktywna)' : '') + '</span></button>' +
             '<button class="ac-item" data-sid="__map"><svg class="ic"><use href="#i-target"/></svg><span>Wskaż na mapie</span></button>';
    });
  } catch (e){
    $('#ld-msg').classList.add('err');
    $('#ld-msg').innerHTML = 'Nie udało się wczytać GTFS:<br><b>' + esc((e && e.message) || e) + '</b><br><br>Sprawdź katalog <b>gtfs/</b>.';
    return;
  }
  $('#ld-msg').textContent = 'Łączenie z API…';
  await refresh(true);
  $('#loading').classList.add('off');
  setTimeout(function(){ const l = $('#loading'); if (l) l.remove(); }, 500);
  setInterval(function(){ refresh(false); }, CFG.REFRESH_MS);
  setInterval(tickLive, 1000);
  renderStopsList();
  renderLinesSheet();
})();
window.TRACKER = { PB: PB, PBRT: window.PBRT, PLANNER: window.PLANNER, G: G, S: S, SEL: SEL, ROUTE: ROUTE, PLUI: PLUI, GPS: GPS, REC: REC };