<?php
/* =====================================================================
   ZTM Rzeszów — index.php (zestaw 20260924c — pojedynczy js/app.js)
   ?_rt=1        → proxy feedu GTFS-RT (gzip, SSL, UA, cache)
   ?_rt=1&cached → ostatnia dobra kopia (gtfsrt-cache.pb)
   ?_gf=plik.txt → pliki z katalogu gtfs/
   ?_diag=1      → co serwer MPK naprawdę zwraca
   ===================================================================== */
const RT_URL  = 'https://www.mpkrzeszow.pl/gtfs/rt/gtfsrt.pb';
const RT_URL2 = 'https://mpkrzeszow.pl/gtfs/rt/gtfsrt.pb';
const UA      = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
const CACHE_F = __DIR__ . '/gtfsrt-cache.pb';

function rt_fetch($url){
  if (function_exists('curl_init')){
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
      CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
      CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 12, CURLOPT_ENCODING => '',
      CURLOPT_USERAGENT => UA,
      // TESTY LOKALNE — przed produkcją: true / 2 !
      CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0,
      CURLOPT_HTTPHEADER => array('Accept: application/x-protobuf, application/octet-stream, */*'),
    ));
    $data = curl_exec($ch);
    $err  = ($data === false) ? curl_error($ch) : '';
    curl_close($ch);
    if (is_string($data) && $data !== '') return array($data, '');
    return array(false, 'cURL: ' . ($err !== '' ? $err : 'pusta odpowiedź'));
  }
  if (ini_get('allow_url_fopen')){
    $ctx = stream_context_create(array(
      'http' => array('timeout' => 12, 'follow_location' => 1, 'max_redirects' => 5,
        'header' => "User-Agent: " . UA . "\r\nAccept: application/x-protobuf, */*\r\n"),
      'ssl' => array('verify_peer' => false, 'verify_peer_name' => false),
    ));
    $data = @file_get_contents($url, false, $ctx);
    if (is_string($data) && $data !== '') return array($data, '');
    return array(false, 'file_get_contents: nieudane');
  }
  return array(false, 'brak cURL i allow_url_fopen');
}
function rt_gunzip($d){
  if (is_string($d) && substr($d, 0, 2) === "\x1f\x8b" && function_exists('gzdecode')){
    $g = gzdecode($d);
    if (is_string($g) && $g !== '') return $g;
  }
  return $d;
}
function rt_looks_pb($d){
  if (!is_string($d) || $d === '') return false;
  $h = substr($d, 0, 300);
  if (stripos($h, '<!doctype') !== false || stripos($h, '<html') !== false) return false;
  if (preg_match('/^\s*[{[]/', $h)) return false;
  if ($d[0] === "\x0a") return true;
  $n = min(strlen($d), 600); $p = 0;
  for ($i = 0; $i < $n; $i++){ $b = ord($d[$i]); if ($b===9||$b===10||b===13||($b>=32&&$b<127)) $p++; }
  return ($p / $n) <= 0.9;
}
if (isset($_GET['_diag'])){
  header('Content-Type: text/plain; charset=utf-8');
  echo "== DIAGNOZA == ".date('Y-m-d H:i:s')." | PHP ".PHP_VERSION."\n";
  foreach (array(RT_URL, RT_URL2) as $u){
    echo "--- $u ---\n";
    list($d, $e) = rt_fetch($u);
    if ($d === false){ echo "BŁĄD: $e\n"; continue; }
    if (substr($d, 0, 2) === "\x1f\x8b") $d = rt_gunzip($d);
    echo strlen($d)." B | hex: ".bin2hex(substr($d, 0, 16))."\n";
    echo rt_looks_pb($d) ? "=> OK (0x0A, binarne)\n" : "=> TO NIE JEST .pb\n";
  }
  exit;
}
if (isset($_GET['_rt'])){
  if (!isset($_GET['cached'])){
    foreach (array(RT_URL, RT_URL2) as $u){
      list($d, $e) = rt_fetch($u);
      if ($d === false) continue;
      $d = rt_gunzip($d);
      if (!is_string($d) || $d === '') continue;
      if (rt_looks_pb($d)){
        @file_put_contents(CACHE_F, $d);
        header('Content-Type: application/x-protobuf');
        header('X-Tracker-Source: live');
        echo $d; exit;
      }
    }
  }
  if (is_file(CACHE_F)){
    header('Content-Type: application/x-protobuf');
    header('X-Tracker-Source: cache');
    readfile(CACHE_F); exit;
  }
  http_response_code(502);
  header('Content-Type: text/plain; charset=utf-8');
  echo 'PROXY: nieudane pobranie .pb — diagnoza: index.php?_diag=1';
  exit;
}
if (isset($_GET['_gf'])){
  $wl = array('agency.txt','areas.txt','attributions.txt','calendar.txt','calendar_dates.txt',
    'fare_leg_rules.txt','fare_media.txt','fare_products.txt','fare_transfer_rules.txt',
    'feed_info.txt','frequencies.txt','levels.txt','pathways.txt','rider_categories.txt',
    'route_networks.txt','routes.txt','shapes.txt','stop_areas.txt','stop_times.txt',
    'stops.txt','timeframes.txt','transfers.txt','translations.txt','trips.txt');
  $f = basename((string)$_GET['_gf']);
  if (!in_array($f, $wl, true)){ http_response_code(400); exit; }
  $p = __DIR__ . '/gtfs/' . $f;
  if (!is_file($p)){ http_response_code(404); header('Content-Type: text/plain; charset=utf-8');
    echo 'brak gtfs/' . $f . ' — rozpakuj ZIP do katalogu gtfs/'; exit; }
  header('Content-Type: text/plain; charset=utf-8');
  readfile($p); exit;
}
?><!DOCTYPE html>
<html lang="pl" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0b0d10">
<meta name="app-ver" content="20260924c">
<title>ZTM Rzeszów — na żywo</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%23101214'/%3E%3Crect x='6' y='6' width='20' height='20' rx='4' fill='%23ff5c1a'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<link rel="stylesheet" href="css/app.css">
</head>
<body>

<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
  <symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20.5 20.5L16.2 16.2"/></symbol>
  <symbol id="i-bus" viewBox="0 0 24 24"><rect x="5" y="3.5" width="14" height="12.5" rx="2.5"/><path d="M5 9.5h14M7 18.5V16M17 18.5V16"/><circle cx="8.3" cy="18.7" r="1.8"/><circle cx="15.7" cy="18.7" r="1.8"/></symbol>
  <symbol id="i-pin" viewBox="0 0 24 24"><path d="M12 21.5c-4.5-4.8-6.8-8.1-6.8-10.7a6.8 6.8 0 1 1 13.6 0c0 2.6-2.3 5.9-6.8 10.7z"/><circle cx="12" cy="10.5" r="2.4"/></symbol>
  <symbol id="i-walk" viewBox="0 0 24 24"><circle cx="13" cy="4.5" r="1.9"/><path d="M13 8l-2.5 4 2 2.5.5 4"/><path d="M13 8l3.5 2 2.5-.5"/><path d="M10.5 12l-3 1.5-1 3.5"/></symbol>
  <symbol id="i-run" viewBox="0 0 24 24"><circle cx="15" cy="4.5" r="1.9"/><path d="M16 8l-4 2-1 4 3 2 1 5"/><path d="M11 10l-3.5.5L5 14"/><path d="M16 8l3 2 2-.5"/><path d="M15 16l-4 1"/></symbol>
  <symbol id="i-layers" viewBox="0 0 24 24"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13.5l9 5 9-5"/></symbol>
  <symbol id="i-gps" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3"/></symbol>
  <symbol id="i-back" viewBox="0 0 24 24"><path d="M14.5 5l-7 7 7 7"/></symbol>
  <symbol id="i-x" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol>
  <symbol id="i-alert" viewBox="0 0 24 24"><path d="M12 4L2.5 20.5h19z"/><path d="M12 10v4.5M12 17.6v.2"/></symbol>
  <symbol id="i-home" viewBox="0 0 24 24"><path d="M3 11l9-8 9 8"/><path d="M5.5 10v10h5v-6h3v6h5V10"/></symbol>
  <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M19.1 4.9l-1.8 1.8M6.7 17.3l-1.8 1.8"/></symbol>
  <symbol id="i-moon" viewBox="0 0 24 24"><path d="M20 14.5A8.5 8.5 0 1 1 9.5 4 7 7 0 0 0 20 14.5z"/></symbol>
  <symbol id="i-target" viewBox="0 0 24 24"><circle cx="12" cy="12" r="7.5"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/><circle cx="12" cy="12" r="2.5"/></symbol>
  <symbol id="i-fit" viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></symbol>
  <symbol id="i-upload" viewBox="0 0 24 24"><path d="M12 15V4M7 8l5-5 5 5"/><path d="M4 15v4h16v-4"/></symbol>
  <symbol id="i-refresh" viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 3v4h-4"/></symbol>
  <symbol id="i-gear" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1-1.55 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.55-1 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.09a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.55h.09a1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.09a1.7 1.7 0 0 0 1.55 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.55 1z"/></symbol>
  <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></symbol>
  <symbol id="i-arrow" viewBox="0 0 24 24"><path d="M4 12h15M13 5l7 7-7 7"/></symbol>
</defs></svg>

<header id="topbar" class="glass">
  <span class="brand-mark">ZTM</span>
  <div id="clock">–:–:–</div>
  <button id="feed-chip" title="Odśwież"><span class="dot" id="feed-dot"></span><span id="stat-feed-txt">łączenie…</span></button>
  <button id="btn-theme" class="icon-btn" title="Motyw"><svg class="ic"><use href="#i-moon"/></svg></button>
  <button id="btn-settings" class="icon-btn" title="Ustawienia"><svg class="ic"><use href="#i-gear"/></svg></button>
</header>

<div id="alertbar" class="glass" hidden>
  <svg class="ic"><use href="#i-alert"/></svg>
  <span id="alerts-sum"></span>
  <button id="btn-alerts">szczegóły</button>
  <button id="alert-close" class="icon-btn" title="Ukryj"><svg class="ic"><use href="#i-x"/></svg></button>
</div>
<div id="alerts-list" class="glass" hidden></div>

<div id="maproot">
  <div id="map"></div>
  <div class="map-top map-only">
    <div class="map-search glass">
      <svg class="ic"><use href="#i-search"/></svg>
      <input id="map-search" placeholder="Linia, tabor, rejestracja, przystanek…" autocomplete="off" spellcheck="false">
      <button class="clr-x" data-clear="map-search" hidden title="Wyczyść"><svg class="ic"><use href="#i-x"/></svg></button>
      <div class="ac glass" id="map-ac" hidden></div>
    </div>
  </div>
  <div class="map-actions map-only">
    <button id="btn-layers" class="icon-btn glass" title="Podkład mapy"><svg class="ic"><use href="#i-layers"/></svg></button>
    <button id="btn-gps" class="icon-btn glass" title="Moja lokalizacja"><svg class="ic"><use href="#i-gps"/></svg></button>
    <button id="btn-fit" class="icon-btn glass" title="Dopasuj"><svg class="ic"><use href="#i-fit"/></svg></button>
    <button id="btn-pbfile" class="icon-btn glass" title="Wczytaj .pb"><svg class="ic"><use href="#i-upload"/></svg></button>
  </div>
  <div id="pick-banner" class="glass map-only" hidden>
    <svg class="ic"><use href="#i-target"/></svg><span id="pick-txt"></span>
    <button id="pick-cancel">Anuluj</button>
  </div>
  <header id="route-head" class="glass">
    <button id="route-back" class="icon-btn" title="Wstecz"><svg class="ic"><use href="#i-back"/></svg></button>
    <div id="route-title" class="scr-head-txt"></div>
    <button id="route-fitbtn" class="icon-btn" title="Dopasuj"><svg class="ic"><use href="#i-fit"/></svg></button>
  </header>
  <div id="route-sheet" class="glass">
    <div class="sheet-grip" id="rs-grip"><i></i></div>
    <div id="route-tabs" class="rtabs" hidden></div>
    <div id="route-variants" class="vchips" hidden></div>
    <div id="route-content" class="rs-content"></div>
  </div>
  <div id="lines-sheet" class="glass map-only">
    <div class="sheet-grip ls-grip" id="ls-grip"><i></i><span>Linie</span></div>
    <div class="ls-body" id="lines-body"></div>
  </div>
</div>

<section id="scr-home" class="screen on">
  <div class="scr-body">
    <div class="home-wrap">
      <h1>Dokąd chcesz<br>dojechać?</h1>
      <div class="hp-field">
        <div class="hp-row">
          <svg class="ic hp-ic-b"><use href="#i-pin"/></svg>
          <input id="hp-b" placeholder="Cel" autocomplete="off" spellcheck="false">
          <button class="clr-x" data-clear="hp-b" hidden title="Wyczyść"><svg class="ic"><use href="#i-x"/></svg></button>
          <button id="hp-b-map" class="icon-btn" title="Wskaż na mapie"><svg class="ic"><use href="#i-target"/></svg></button>
        </div>
        <div class="ac glass" id="ac-b" hidden></div>
      </div>
      <div class="hp-field">
        <div class="hp-row" id="hp-a-row">
          <svg class="ic hp-ic-a"><use href="#i-walk"/></svg>
          <input id="hp-a" placeholder="Skąd — domyślnie moja lokalizacja" autocomplete="off" spellcheck="false">
          <button class="clr-x" data-clear="hp-a" hidden title="Wyczyść"><svg class="ic"><use href="#i-x"/></svg></button>
          <button id="hp-a-gps" class="icon-btn" title="Moja lokalizacja"><svg class="ic"><use href="#i-gps"/></svg></button>
          <button id="hp-a-map" class="icon-btn" title="Wskaż na mapie"><svg class="ic"><use href="#i-target"/></svg></button>
        </div>
        <div class="ac glass" id="ac-a" hidden></div>
      </div>
      <div class="hp-opts">
        <input type="date" id="pl-date">
        <input type="time" id="pl-time">
        <select id="pl-xfer">
          <option value="0">bez przesiadek</option>
          <option value="1">maks 1</option>
          <option value="2" selected>maks 2 przesiadki</option>
          <option value="3">maks 3</option>
        </select>
      </div>
      <div class="hp-speed glass2">
        <button id="sp-walk" class="on"><svg class="ic"><use href="#i-walk"/></svg>Marsz</button>
        <button id="sp-run"><svg class="ic"><use href="#i-run"/></svg>Bieg</button>
      </div>
      <button id="hp-go" class="primary"><svg class="ic"><use href="#i-search"/></svg>Szukaj połączenia</button>
    </div>
  </div>
  <div id="home-sheet" class="glass">
    <div class="sheet-grip hs-grip" id="hs-grip"><i></i><span>Ostatnie</span></div>
    <div class="hs-body" id="home-hist-body"></div>
  </div>
</section>

<section id="scr-stops" class="screen">
  <div class="stops-search glass">
    <svg class="ic"><use href="#i-search"/></svg>
    <input id="stops-q" placeholder="Szukaj przystanku…" autocomplete="off" spellcheck="false">
    <button class="clr-x" data-clear="stops-q" hidden title="Wyczyść"><svg class="ic"><use href="#i-x"/></svg></button>
  </div>
  <div class="scr-body" id="stops-list"></div>
</section>

<section id="scr-results" class="screen">
  <header class="scr-head glass">
    <button class="icon-btn" data-back><svg class="ic"><use href="#i-back"/></svg></button>
    <div class="scr-head-txt"><b>Połączenia</b></div>
  </header>
  <div class="scr-body" id="res-body"></div>
</section>

<section id="scr-settings" class="screen">
  <header class="scr-head glass">
    <button class="icon-btn" data-back><svg class="ic"><use href="#i-back"/></svg></button>
    <div class="scr-head-txt"><b>Ustawienia</b></div>
  </header>
  <div class="scr-body">
    <div class="set-sec">Motyw</div>
    <div class="set-seg glass2" id="set-theme">
      <button data-v="dark"><svg class="ic"><use href="#i-moon"/></svg>Ciemny</button>
      <button data-v="light"><svg class="ic"><use href="#i-sun"/></svg>Jasny</button>
      <button data-v="auto">Auto</button>
    </div>
    <div class="set-sec">Podkład mapy</div>
    <div id="set-maps" class="set-maps"></div>
  </div>
</section>

<nav id="bottomnav" class="glass">
  <button data-nav="home"><svg class="ic"><use href="#i-home"/></svg><span>Planuj</span></button>
  <button data-nav="buses"><svg class="ic"><use href="#i-bus"/></svg><span>Autobusy</span></button>
  <button data-nav="stops"><svg class="ic"><use href="#i-pin"/></svg><span>Przystanki</span></button>
</nav>

<div id="loading">
  <div class="ld-box glass2">
    <div class="ld-brand"><span>ZTM</span><em>Rzeszów · live</em></div>
    <div class="ld-bar"><i id="ld-bar"></i></div>
    <ul id="ld-files"></ul>
    <p id="ld-msg">Ładowanie…</p>
  </div>
</div>
<div id="toasts"></div>
<input type="file" id="pbfile" accept=".pb,.gz" hidden>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="js/pb-parser.js"></script>
<script src="js/planner.js"></script>
<script src="js/app.js"></script>
</body>
</html>