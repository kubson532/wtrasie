package online.wtrasie.app;

import android.graphics.Color;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Stop / line search. Priorities: a numeric query starts with line numbers,
 * a text query starts with stop names, then stop numbers; geocoded stops and
 * places (any city — picking one switches the city) come last.
 *
 * v1.3.0: normalized names are precomputed once per stop-list change, queries
 * are debounced (120 ms) and geocode results carry transit modes, so train
 * stations get a proper station icon and open the real station, not the
 * nearest bus stop.
 */
public class SearchSheet extends Sheet {

    public interface Listener {
        void onLocalStopPicked(Models.Stop stop);

        void onPlacePicked(Api.Place place);

        void onVehiclePicked(Models.Vehicle vehicle);
    }

    private static final int TYPE_SECTION = 0, TYPE_FAV = 1, TYPE_RECENT = 2, TYPE_NEAR = 3,
            TYPE_LOCAL = 4, TYPE_PLACE = 5, TYPE_LINE = 6, TYPE_VEHICLE = 7;

    private static class Row {
        int type;
        Models.Stop stop;
        Api.Place place;
        Favorites.Entry entry;
        Models.Route line;
        Models.Vehicle vehicle;
        double dist = -1;
        String title;
    }

    /** Precomputed, lowercased search index over the current stop list. */
    private static class StopIdx {
        final Models.Stop stop;
        final String normName;
        final String normCode;

        StopIdx(Models.Stop s) {
            stop = s;
            normName = Ui.norm(s.name);
            normCode = s.code == null ? "" : Ui.norm(s.code);
        }
    }

    private final MainActivity act;
    private final Listener listener;
    private final EditText search;
    private final ImageButton clear;
    private final ListView list;
    private final SearchAdapter adapter;
    private final List<Row> rows = new ArrayList<>();
    private final Handler debounce = new Handler(Looper.getMainLooper());
    private final Runnable debounceRun = this::runQuery;
    private String lastQuery = null;
    private int pendingGeocode = 0;
    private List<StopIdx> idx = new ArrayList<>();
    private List<StopIdx> nearSorted;
    private List<Models.Vehicle> wideVehicles; // wide-area fetch for the open line

    public SearchSheet(MainActivity act, Listener listener) {
        super(act, R.layout.sheet_search);
        this.act = act;
        this.listener = listener;

        search = findViewById(R.id.stopSearch);
        clear = findViewById(R.id.stopClear);
        list = findViewById(R.id.stopList);
        adapter = new SearchAdapter();
        list.setAdapter(adapter);

        setDragHandle(findViewById(R.id.searchHeader));

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                Ui.setVisible(clear, s.length() > 0);
                // debounce: no full rescan on every keystroke (search lag fix)
                debounce.removeCallbacks(debounceRun);
                debounce.postDelayed(debounceRun, 120);
            }
        });

        clear.setOnClickListener(v -> {
            search.setText("");
            debounce.removeCallbacks(debounceRun);
            runQuery();
        });

        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos < 0 || pos >= rows.size()) return;
            Row r = rows.get(pos);
            try {
                if (r.vehicle != null) {
                    listener.onVehiclePicked(r.vehicle);
                } else if (r.line != null) {
                    showLineVehicles(r.line);
                } else if (r.place != null) {
                    listener.onPlacePicked(r.place);
                } else if (r.stop != null) {
                    listener.onLocalStopPicked(r.stop);
                }
            } catch (Throwable ignored) {
            }
        });
    }

    /** Rebuild the search index when the stop list changes. */
    public void onStopsChanged() {
        List<StopIdx> n = new ArrayList<>();
        for (Models.Stop s : act.map.getStops()) {
            n.add(new StopIdx(s));
        }
        idx = n;
        nearSorted = null;
    }

    @Override
    public void show() {
        super.show();
        search.setText("");
        onStopsChanged();
        runQuery();
    }

    public void openWithKeyboard() {
        show();
        search.requestFocus();
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) act.getSystemService(MainActivity.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(search, 0);
    }

    private void runQuery() {
        String q = search.getText().toString().trim();
        lastQuery = q;
        if (q.isEmpty() || !q.equals(lineFilter)) {
            lineFilter = null; // typing again leaves the line-vehicle list
            wideVehicles = null;
        }
        rebuild(q);
        if (q.length() >= 2) geocode(q);
    }

    private String lineFilter = null; // route name while listing a line's vehicles

    /**
     * Shows the live vehicles of one line; the user gets here by tapping a line
     * result. v1.4.0: vehicles come from a wide-area fetch too, so the list
     * works even when the line is outside the current viewport.
     */
    private void showLineVehicles(Models.Route line) {
        lineFilter = line.name;
        search.setText(line.name);
        rebuild(line.name);
        double lat = act.currentCity != null ? act.currentCity.lat : 52.23;
        double lon = act.currentCity != null ? act.currentCity.lon : 21.01;
        act.fetchWideVehicles(lat, lon, line.type == 2 || line.type == 1, vehicles -> {
            if (lineFilter == null || getState() == HIDDEN) return;
            wideVehicles = vehicles;
            rebuild(lineFilter);
        });
    }

    private boolean isNumericQuery(String q) {
        int digits = 0;
        for (char ch : q.toCharArray()) {
            if (Character.isDigit(ch)) digits++;
            else if (ch != ' ' && ch != '.' && ch != '-') return false;
        }
        return digits > 0;
    }

    private void section(String title) {
        Row r = new Row();
        r.type = TYPE_SECTION;
        r.title = title;
        rows.add(r);
    }

    private void rebuild(String q) {
        rows.clear();
        Location loc = act.getLastLocation();
        String n = Ui.norm(q);

        if (n.isEmpty()) {
            List<Favorites.Entry> favs = act.favorites.list();
            if (!favs.isEmpty()) {
                section(act.getString(R.string.section_favorites));
                for (Favorites.Entry e : favs) {
                    Row r = new Row();
                    r.type = TYPE_FAV;
                    r.entry = e;
                    r.stop = entryToStop(e);
                    rows.add(r);
                }
            }
            List<Favorites.Entry> recents = act.favorites.recents();
            if (!recents.isEmpty()) {
                section(act.getString(R.string.section_recent));
                for (Favorites.Entry e : recents) {
                    if (act.favorites.isFavorite(e.stopId)) continue;
                    Row r = new Row();
                    r.type = TYPE_RECENT;
                    r.entry = e;
                    r.stop = entryToStop(e);
                    rows.add(r);
                }
            }
            if (loc != null && act.currentCity != null && !act.currentCity.nationwide) {
                if (nearSorted == null) {
                    nearSorted = new ArrayList<>(idx);
                    final double lat = loc.getLatitude(), lon = loc.getLongitude();
                    Collections.sort(nearSorted, (a, b) -> Double.compare(
                            Ui.distM(lat, lon, a.stop.lat, a.stop.lon),
                            Ui.distM(lat, lon, b.stop.lat, b.stop.lon)));
                }
                boolean sec = false;
                for (int i = 0; i < nearSorted.size() && rows.size() < 40; i++) {
                    if (!sec) {
                        section(act.getString(R.string.section_near));
                        sec = true;
                    }
                    Row r = new Row();
                    r.type = TYPE_NEAR;
                    r.stop = nearSorted.get(i).stop;
                    r.dist = Ui.distM(loc.getLatitude(), loc.getLongitude(), r.stop.lat, r.stop.lon);
                    rows.add(r);
                }
            }
            adapter.notifyDataSetChanged();
            return;
        }

        // ---- line-vehicle mode (a line was picked)
        if (lineFilter != null && n.equals(Ui.norm(lineFilter))) {
            List<Models.Vehicle> vehicles = new ArrayList<>(act.map.getVehicles());
            if (wideVehicles != null) {
                // merge the wide-area fetch, dedup by rtKey
                java.util.Set<String> seen = new java.util.HashSet<>();
                for (Models.Vehicle v : vehicles) seen.add(v.rtKey());
                for (Models.Vehicle v : wideVehicles) {
                    if (seen.add(v.rtKey())) vehicles.add(v);
                }
            }
            List<Models.Vehicle> onLine = new ArrayList<>();
            for (Models.Vehicle v : vehicles) {
                if (Ui.norm(v.routeName).equals(Ui.norm(lineFilter))) onLine.add(v);
            }
            section(lineFilter.toUpperCase() + " · " + Ui.plPlural(onLine.size(), "pojazd"));
            if (onLine.isEmpty()) {
                Row r = new Row();
                r.type = TYPE_SECTION;
                r.title = act.getString(R.string.no_vehicles_on_route);
                rows.add(r);
            }
            Location loc2 = act.getLastLocation();
            for (Models.Vehicle v : onLine) {
                Row r = new Row();
                r.type = TYPE_VEHICLE;
                r.vehicle = v;
                if (loc2 != null) r.dist = Ui.distM(loc2.getLatitude(), loc2.getLongitude(), v.lat, v.lon);
                rows.add(r);
            }
            adapter.notifyDataSetChanged();
            return;
        }

        boolean filterTechnical = act.prefs.filterTechnical();

        // ---- line matches (distinct routes of the current city)
        Map<String, Models.Route> lines = new LinkedHashMap<>();
        for (Models.Stop s : act.map.getStops()) {
            if (s.routes == null) continue;
            for (Models.Route r : s.routes) {
                if (r.name == null || r.name.isEmpty()) continue;
                if (Models.hiddenByTechnicalFilter(r.name, filterTechnical)) continue;
                if (Ui.norm(r.name).contains(n) || Ui.norm(r.longName).contains(n)) {
                    if (!lines.containsKey(r.id)) lines.put(r.id, r);
                }
            }
        }
        List<Models.Route> lineList = new ArrayList<>(lines.values());
        Collections.sort(lineList, (a, b) -> {
            boolean ap = Ui.norm(a.name).startsWith(n), bp = Ui.norm(b.name).startsWith(n);
            if (ap != bp) return ap ? -1 : 1;
            return a.name.compareToIgnoreCase(b.name);
        });

        // ---- stops by name / code (precomputed index — no per-keystroke normalization)
        List<Models.Stop> byName = new ArrayList<>();
        List<Models.Stop> byCode = new ArrayList<>();
        for (StopIdx e : idx) {
            if (byName.size() < 24 && e.normName.contains(n)) byName.add(e.stop);
            if (byCode.size() < 12 && !e.normCode.isEmpty()
                    && e.normCode.contains(n) && !byName.contains(e.stop)) byCode.add(e.stop);
        }

        boolean numeric = isNumericQuery(q);
        if (numeric) {
            if (!lineList.isEmpty()) {
                section(act.getString(R.string.section_lines));
                for (Models.Route r : lineList) {
                    Row row = new Row();
                    row.type = TYPE_LINE;
                    row.line = r;
                    rows.add(row);
                }
            }
            addStopRows(byName, R.string.section_stops, loc);
            addStopRows(byCode, R.string.section_stop_numbers, loc);
        } else {
            addStopRows(byName, R.string.section_stops, loc);
            addStopRows(byCode, R.string.section_stop_numbers, loc);
            if (!lineList.isEmpty()) {
                section(act.getString(R.string.section_lines));
                for (Models.Route r : lineList) {
                    Row row = new Row();
                    row.type = TYPE_LINE;
                    row.line = r;
                    rows.add(row);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void addStopRows(List<Models.Stop> stops, int sectionRes, Location loc) {
        if (stops.isEmpty()) return;
        section(act.getString(sectionRes));
        for (Models.Stop s : stops) {
            Row r = new Row();
            r.type = TYPE_LOCAL;
            r.stop = s;
            if (loc != null) r.dist = Ui.distM(loc.getLatitude(), loc.getLongitude(), s.lat, s.lon);
            rows.add(r);
        }
    }

    private Models.Stop entryToStop(Favorites.Entry e) {
        Models.Stop s = new Models.Stop();
        s.id = e.stopId;
        s.city = e.city;
        s.name = e.name;
        s.code = e.code;
        s.types = new int[]{e.type};
        s.lat = e.lat;
        s.lon = e.lon;
        return s;
    }

    private void geocode(String q) {
        final int gen = ++pendingGeocode;
        Api.getJson(Api.geocodeUrl(q), (json, err) -> {
            if (gen != pendingGeocode) return; // stale response
            if (json == null) return;
            List<Api.Place> places = Api.Place.parse(json);
            if (places.isEmpty()) return;
            String currentQuery = lastQuery == null ? "" : lastQuery;
            if (!Ui.norm(currentQuery).contains(Ui.norm(q))) return;
            // geocoded STOPS (any city) come before plain places
            int existing = rows.size();
            int addedStops = 0, addedPlaces = 0;
            for (Api.Place p : places) {
                boolean dup = false;
                for (Row r : rows) {
                    if (r.stop != null && Ui.distM(r.stop.lat, r.stop.lon, p.lat, p.lon) < 150
                            && Ui.norm(r.stop.name).equals(Ui.norm(p.name))) {
                        dup = true;
                        break;
                    }
                }
                if (dup) continue;
                if (p.isStop) {
                    if (addedStops == 0) section(act.getString(R.string.section_stops_other_cities));
                    Row r = new Row();
                    r.type = TYPE_PLACE;
                    r.place = p;
                    rows.add(r);
                    addedStops++;
                } else if (addedPlaces < 4) {
                    if (addedPlaces == 0) section(act.getString(R.string.section_places));
                    Row r = new Row();
                    r.type = TYPE_PLACE;
                    r.place = p;
                    rows.add(r);
                    addedPlaces++;
                }
            }
            if (addedStops > 0 || addedPlaces > 0) adapter.notifyDataSetChanged();
        });
    }

    private class SearchAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size() == 0 ? 1 : rows.size();
        }

        @Override
        public Object getItem(int pos) {
            return pos;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public int getViewTypeCount() {
            return 3;
        }

        @Override
        public int getItemViewType(int pos) {
            if (rows.isEmpty()) return 2;
            return rows.get(pos).type == TYPE_SECTION ? 1 : 0;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            if (rows.isEmpty()) {
                if (cv == null || cv.getId() != R.id.emptyText) {
                    cv = LayoutInflater.from(act).inflate(R.layout.empty_state, parent, false);
                }
                return cv;
            }
            Row r = rows.get(pos);
            if (r.type == TYPE_SECTION) {
                View v = cv;
                if (v == null || v.getId() != R.id.sectionTitle) {
                    v = LayoutInflater.from(act).inflate(R.layout.row_section, parent, false);
                }
                ((TextView) v.findViewById(R.id.sectionTitle)).setText(r.title);
                return v;
            }
            View v = cv;
            if (v == null || v.getId() != R.id.stopRowName) {
                v = LayoutInflater.from(act).inflate(R.layout.row_stop, parent, false);
            }
            TextView name = v.findViewById(R.id.stopRowName);
            TextView sub = v.findViewById(R.id.stopRowSub);
            TextView dist = v.findViewById(R.id.stopRowDist);
            ImageView icon = v.findViewById(R.id.stopRowIcon);

            if (r.vehicle != null) {
                Models.Vehicle ve = r.vehicle;
                bindPill(name, VehicleSheet.vehicleLabel(ve), act.vehicleColor(ve));
                String s2 = ve.headsign != null ? ve.headsign : "";
                if (ve.delay != null) {
                    String dt = Ui.fmtDelay(ve.delay);
                    s2 += (s2.isEmpty() ? "" : " · ") + (dt.isEmpty() ? act.getString(R.string.planowo) : dt);
                }
                sub.setText(s2);
                if (r.dist >= 0) dist.setText(Ui.fmtDist(r.dist));
                else dist.setText("");
                icon.setImageResource(Models.typeIcon(ve.typeInt()));
                icon.setColorFilter(act.vehicleColor(ve));
            } else if (r.line != null) {
                int lineColor = act.prefs.keepOriginalColors()
                        ? r.line.color : Models.typeColor(r.line.type);
                bindPill(name, r.line.name, lineColor);
                sub.setText(r.line.longName != null ? r.line.longName : "");
                dist.setText("");
                icon.setImageResource(Models.typeIcon(r.line.type));
                icon.setColorFilter(lineColor);
            } else if (r.place != null) {
                bindPlain(name, r.place.name);
                // geocoded stop: city + mode icon (train station / bus / tram…)
                Cities.City c = Cities.byName(cityNameOf(r.place));
                String s2 = c != null ? c.name : (r.place.country != null ? r.place.country : "");
                sub.setText(s2);
                dist.setText("");
                icon.setImageResource(r.place.modeIcon());
                icon.setColorFilter(r.place.modeColor());
            } else if (r.stop != null) {
                // v1.4.0: full title "Pl. Wolności 04"; no adjacent-stop text
                bindPlain(name, Ui.stopTitle(r.stop.name, r.stop.code));
                String s2 = "";
                if (r.type == TYPE_FAV || r.type == TYPE_RECENT) {
                    Cities.City c = Cities.bySlug(r.stop.city);
                    s2 = c != null ? c.name : "";
                }
                sub.setText(s2);
                if (r.dist >= 0) dist.setText(Ui.fmtDist(r.dist));
                else dist.setText("");
                int type = r.stop.mainType();
                icon.setImageResource(r.stop.isStation() ? R.drawable.ic_station : Models.stopIcon(type));
                icon.setColorFilter(Models.stopColor(type));
            }
            return v;
        }

        /** Pill rows: the badge must shrink to its content, not stretch. */
        private void bindPill(TextView name, String text, int color) {
            Ui.setPill(name, text, color);
            name.setTextSize(15);
            name.setPadding(Ui.dp(act, 10), Ui.dp(act, 3), Ui.dp(act, 10), Ui.dp(act, 3));
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) name.getLayoutParams();
            lp.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            name.setLayoutParams(lp);
        }

        private void bindPlain(TextView name, String text) {
            name.setText(text);
            name.setTextSize(15);
            name.setBackground(null);
            name.setPadding(0, 0, 0, 0);
            name.setTextColor(act.getResources().getColor(R.color.text_primary));
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) name.getLayoutParams();
            lp.width = LinearLayout.LayoutParams.MATCH_PARENT;
            name.setLayoutParams(lp);
        }
    }

    /** "pl-Gdańsk Dworzec Główny 11" / "pl-PKP-Intercity_7500_parent" -> readable city part. */
    private static String cityNameOf(Api.Place p) {
        try {
            String id = p.id;
            if (id != null && id.contains("-") && id.lastIndexOf('_') > id.indexOf('-')) {
                return id.substring(id.indexOf('-') + 1, id.lastIndexOf('_')).replace('_', ' ');
            }
        } catch (Throwable ignored) {
        }
        return "";
    }
}
