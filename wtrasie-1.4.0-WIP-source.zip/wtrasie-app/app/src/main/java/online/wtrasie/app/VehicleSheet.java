package online.wtrasie.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

/**
 * Live vehicle preview: the whole trip (already-served stops included) drawn as
 * a timeline — scheduled times struck through with estimates below, the vehicle
 * marker moving between stops by traveled percentage, per-stop delay text and
 * a countdown on the right. Details live behind the "i" button.
 */
public class VehicleSheet extends Sheet {

    private final MainActivity act;
    private final TextView route, headsign, delay, status;
    private final android.widget.ProgressBar progress;
    private final View statusWrap;
    private final ImageButton btnLink, btnInfo, btnClose;
    private final ScrollView routeScroll;
    private final RouteTimelineView timeline;

    private Models.Vehicle vehicle;
    private Cities.City city;
    private Gtfs.Trip trip;
    private long serviceDayMs; // midnight of the GTFS service day
    private String currentId;
    private boolean tripRequested = false;
    private boolean tripRetried = false;
    private boolean tripJustLoaded = false; // auto-scroll once, when the trip loads
    private boolean userScrolled = false;   // after that, never fight the user
    private int loadGen = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable rebuildTick = new Runnable() {
        @Override
        public void run() {
            if (getState() == HIDDEN) return;
            rebuildRows();
            ui.postDelayed(this, 8000);
        }
    };

    public VehicleSheet(MainActivity act) {
        super(act, R.layout.sheet_vehicle);
        this.act = act;

        route = findViewById(R.id.vehicleRoute);
        headsign = findViewById(R.id.vehicleHeadsign);
        delay = findViewById(R.id.vehicleDelay);
        status = findViewById(R.id.routeStatus);
        progress = findViewById(R.id.routeProgress);
        statusWrap = findViewById(R.id.routeStatusWrap);
        btnLink = findViewById(R.id.btnVehicleLink);
        btnInfo = findViewById(R.id.btnVehicleInfo);
        btnClose = findViewById(R.id.btnCloseVehicle);
        routeScroll = findViewById(R.id.routeScroll);
        timeline = findViewById(R.id.routeTimeline);
        timeline.setListener(row -> act.openStopFromRoute(row.stopId, row.name, row.lat, row.lon));
        // v1.3.0: the list never scrolls itself back — only a manual scroll or
        // the single initial positioning after the trip loads
        routeScroll.setOnTouchListener((v, ev) -> {
            userScrolled = true;
            return false;
        });

        setDragHandle(findViewById(R.id.vehicleHeader));

        btnClose.setOnClickListener(v -> hide());
        btnInfo.setOnClickListener(v -> showDetails());
        btnLink.setOnClickListener(v -> {
            try {
                if (vehicle != null && vehicle.url != null && !vehicle.url.isEmpty()) {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(vehicle.url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                }
            } catch (Throwable ignored) {
            }
        });
    }

    public String getCurrentVehicleId() {
        return currentId;
    }

    public Models.Vehicle getVehicle() {
        return vehicle;
    }

    public Cities.City getCity() {
        return city;
    }

    public void open(Cities.City city, Models.Vehicle v) {
        this.city = city;
        this.vehicle = v;
        this.currentId = v.id;
        this.trip = null;
        this.tripRequested = false;
        this.tripRetried = false;
        this.tripJustLoaded = false;
        this.userScrolled = false;
        fill(v);
        show();
        setStatus(R.string.loading_route);
        requestTrip();
        ui.removeCallbacks(rebuildTick);
        ui.postDelayed(rebuildTick, 8000);
    }

    @Override
    public void hide() {
        super.hide();
        ui.removeCallbacks(rebuildTick);
        try {
            act.onVehiclePreviewClosed();
        } catch (Throwable ignored) {
        }
    }

    /** Called from the positions poll with fresh data. */
    public void update(Models.Vehicle v) {
        if (v == null || !v.id.equals(currentId)) return;
        this.vehicle = v;
        if (getState() != HIDDEN) {
            fill(v);
            rebuildRows();
        }
    }

    // ---------------------------------------------------------------- data

    private void requestTrip() {
        if (tripRequested || vehicle == null || city == null) return;
        tripRequested = true;
        final int gen = ++loadGen;
        final String agency = vehicle.agency == null || vehicle.agency.isEmpty() ? "default" : vehicle.agency;
        GtfsRt.vehicleTrips(city.slug, agency, (map, err) -> {
            if (gen != loadGen || getState() == HIDDEN) return;
            GtfsRt.Vp vp = GtfsRt.find(map, vehicle.rtKey());
            if (vp != null && vp.tripId != null && !vp.tripId.isEmpty()) {
                final long base = Gtfs.serviceDayEpoch(vp.startDate);
                Gtfs.loadTrip(act, city.slug, agency, vp.tripId, (t, e) -> {
                    if (gen != loadGen || getState() == HIDDEN) return;
                    if (t != null && !t.stops.isEmpty()) {
                        trip = t;
                        serviceDayMs = base > 0 ? base : guessServiceDay(t);
                        setStatus(-1);
                        timeline.setRoute(act.vehicleColor(vehicle), vehicle.typeInt());
                        tripJustLoaded = true;
                        rebuildRows();
                        act.onVehicleTripLoaded(t);
                    } else if (e != null && "network".equals(e)) {
                        retryTripOnce();
                    } else {
                        fallbackRows();
                    }
                });
            } else if (err != null) {
                retryTripOnce();
            } else {
                // no realtime trip match — try matching by route+brigade in GTFS trips
                fallbackRows();
            }
        });
    }

    /** One silent retry after a network hiccup. */
    private void retryTripOnce() {
        if (getState() == HIDDEN || tripRetried) {
            if (getState() != HIDDEN) fallbackRows();
            return;
        }
        tripRetried = true;
        setStatus(R.string.loading_route);
        ui.postDelayed(() -> {
            if (getState() == HIDDEN) return;
            tripRequested = false;
            requestTrip();
        }, 2500);
    }

    /** When the RT feed has no trip, estimate the service day from the timetable itself. */
    private long guessServiceDay(Gtfs.Trip t) {
        long now = System.currentTimeMillis();
        Calendar c = new GregorianCalendar();
        c.setTimeZone(TimeZone.getDefault());
        for (int add = 0; add >= -1; add--) {
            Calendar d = (GregorianCalendar) c.clone();
            d.add(Calendar.DAY_OF_YEAR, add);
            d.set(Calendar.HOUR_OF_DAY, 0);
            d.set(Calendar.MINUTE, 0);
            d.set(Calendar.SECOND, 0);
            d.set(Calendar.MILLISECOND, 0);
            long base = d.getTimeInMillis();
            if (!t.stops.isEmpty()) {
                long first = base + t.stops.get(0).depSec * 1000L;
                long last = base + t.stops.get(t.stops.size() - 1).arrSec * 1000L;
                if (now >= first - 3600_000L && now <= last + 3600_000L) return base;
            }
        }
        Calendar d = (GregorianCalendar) c.clone();
        d.set(Calendar.HOUR_OF_DAY, 0);
        d.set(Calendar.MINUTE, 0);
        d.set(Calendar.SECOND, 0);
        d.set(Calendar.MILLISECOND, 0);
        return d.getTimeInMillis();
    }

    private void fallbackRows() {
        if (vehicle == null) return;
        if (vehicle.upcoming == null || vehicle.upcoming.length == 0) {
            setStatus(R.string.no_trip_data);
            return;
        }
        List<RouteTimelineView.Row> rows = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Models.Upcoming u : vehicle.upcoming) {
            RouteTimelineView.Row r = new RouteTimelineView.Row();
            r.name = u.name;
            long eta = u.scheduledArrival > 0 ? u.scheduledArrival : u.scheduledDeparture;
            r.schedMs = eta;
            r.estMs = vehicle.delay == null ? 0 : eta + vehicle.delay;
            r.passed = r.estMs > 0 && r.estMs < now;
            fillDelay(r);
            fillCount(r);
            rows.add(r);
        }
        setStatus(-1);
        timeline.setRoute(act.vehicleColor(vehicle), vehicle.typeInt());
        timeline.setRows(rows, rows.size(), 1f, false);
    }

    // ---------------------------------------------------------------- rendering

    private void fill(Models.Vehicle v) {
        Ui.setPill(route, vehicleLabel(v), act.vehicleColor(v));
        headsign.setText(v.headsign == null || v.headsign.isEmpty() ? "?" : v.headsign);

        // delay: "Planowo" when on time, "—" only when there is no data at all
        if (v.delay == null) {
            delay.setText("—");
            delay.setTextColor(0xFF9AA0A6);
        } else {
            String dt = Ui.fmtDelay(v.delay);
            if (dt.isEmpty()) {
                delay.setText(R.string.planowo);
                delay.setTextColor(0xFF146C2E);
            } else {
                delay.setText(dt);
                delay.setTextColor(Ui.delayColor(v.delay));
            }
        }
        Ui.setVisible(findViewById(R.id.realtimeIcon), true);
    }

    private void setStatus(int stringRes) {
        if (stringRes < 0) {
            statusWrap.setVisibility(GONE);
            routeScroll.setVisibility(VISIBLE);
        } else {
            status.setText(stringRes);
            statusWrap.setVisibility(VISIBLE);
            routeScroll.setVisibility(GONE);
        }
    }

    /**
     * Chip text of a vehicle. PKP trains: carrier + brigade number ("IC 5423").
     */
    static String vehicleLabel(Models.Vehicle v) {
        String name = v.routeName == null ? "" : v.routeName.trim();
        if (name.isEmpty()) name = "?";
        if (v.pkp) {
            String b = v.brigade == null ? "" : v.brigade.trim();
            if (!b.isEmpty() && !name.endsWith(b)) return name + " " + b;
        }
        return name;
    }

    /** Index of the next stop the vehicle heads to (trip-based). */
    private int nextStopIndex() {
        if (trip == null || trip.stops.isEmpty() || vehicle == null) return 0;
        // prefer the feed's own sequence
        if (vehicle.upcoming != null && vehicle.upcoming.length > 0) {
            int seq = vehicle.upcoming[0].sequence;
            if (seq >= 0) {
                for (int i = 0; i < trip.stops.size(); i++) {
                    if (trip.stops.get(i).seq == seq) return i;
                }
            }
            for (int i = 0; i < trip.stops.size(); i++) {
                if (trip.stops.get(i).name.equals(vehicle.upcoming[0].name)) {
                    return i;
                }
            }
        }
        // nearest stop ahead by geometry: the next stop is the closest one the vehicle approaches
        double bestD = Double.MAX_VALUE;
        int best = 0;
        for (int i = 0; i < trip.stops.size(); i++) {
            Gtfs.StopTime st = trip.stops.get(i);
            if (st.lat == 0 && st.lon == 0) continue;
            double d = Ui.distM(vehicle.lat, vehicle.lon, st.lat, st.lon);
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        // if we are past midway between best and the previous, the next stop is best+1
        if (best > 0) {
            Gtfs.StopTime prev = trip.stops.get(best - 1);
            double dPrev = Ui.distM(vehicle.lat, vehicle.lon, prev.lat, prev.lon);
            if (dPrev < bestD) return best + 1 < trip.stops.size() ? best + 1 : best;
        }
        return best;
    }

    /** % traveled between stop idx-1 and idx. */
    private float segmentProgress(int nextIdx) {
        if (trip == null || nextIdx <= 0 || nextIdx >= trip.stops.size() || vehicle == null) return 0;
        Gtfs.StopTime a = trip.stops.get(nextIdx - 1);
        Gtfs.StopTime b = trip.stops.get(nextIdx);
        double ab = Ui.distM(a.lat, a.lon, b.lat, b.lon);
        if (ab < 1) return 1;
        double av = Ui.distM(a.lat, a.lon, vehicle.lat, vehicle.lon);
        return (float) Math.max(0, Math.min(1, av / ab));
    }

    private void rebuildRows() {
        if (trip == null || trip.stops.isEmpty() || vehicle == null) return;
        long now = System.currentTimeMillis();
        long d = vehicle.delay == null ? 0 : vehicle.delay;
        int next = nextStopIndex();
        float prog = segmentProgress(next);
        boolean hasMarker = vehicle.lat != 0 || vehicle.lon != 0;

        List<RouteTimelineView.Row> rows = new ArrayList<>(trip.stops.size());
        for (int i = 0; i < trip.stops.size(); i++) {
            Gtfs.StopTime st = trip.stops.get(i);
            RouteTimelineView.Row r = new RouteTimelineView.Row();
            r.stopId = st.stopId;
            r.name = st.name;
            r.lat = st.lat;
            r.lon = st.lon;
            r.schedMs = serviceDayMs + (st.arrSec > 0 ? st.arrSec : st.depSec) * 1000L;
            r.estMs = vehicle.delay == null ? 0 : r.schedMs + d;
            r.passed = i < next || (r.estMs > 0 && r.estMs < now);
            fillDelay(r);
            fillCount(r);
            rows.add(r);
        }
        timeline.setRows(rows, next, prog, hasMarker);
        scrollToMarker();
    }

    private void fillDelay(RouteTimelineView.Row r) {
        if (vehicle == null || vehicle.delay == null) {
            r.delayText = "";
            return;
        }
        String dt = Ui.fmtDelay(vehicle.delay);
        if (dt.isEmpty()) {
            r.delayText = act.getString(R.string.planowo);
            r.delayColor = 0xFF146C2E;
        } else {
            r.delayText = dt;
            r.delayColor = Ui.delayColor(vehicle.delay);
        }
    }

    private void fillCount(RouteTimelineView.Row r) {
        if (r.passed) {
            r.countText = "";
            r.blink = false;
            return;
        }
        long now = System.currentTimeMillis();
        long est = r.estMs > 0 ? r.estMs : r.schedMs;
        String ct = Ui.fmtCountdown(est, now);
        if (ct == null) {
            r.countText = "";
        } else {
            r.countText = ct;
            r.blink = Ui.isBlinkCountdown(ct);
        }
    }

    private void scrollToMarker() {
        // v1.3.0: only the initial positioning; a list the user has scrolled
        // stays exactly where the user left it
        if (userScrolled || !tripJustLoaded) return;
        tripJustLoaded = false;
        final float y = timeline.markerY() - routeScroll.getHeight() / 2f + timeline.getTop();
        routeScroll.post(() -> {
            try {
                routeScroll.smoothScrollTo(0, Math.max(0, (int) y));
            } catch (Throwable ignored) {
            }
        });
    }

    // ---------------------------------------------------------------- details popup

    private void showDetails() {
        if (vehicle == null) return;
        StringBuilder sb = new StringBuilder();
        if (vehicle.model != null && !vehicle.model.isEmpty()) sb.append(vehicle.model).append("\n");
        if (!vehicle.id.isEmpty() && !vehicle.id.startsWith("_")) sb.append("#").append(vehicle.id).append("\n");
        if (vehicle.brigade != null && !vehicle.brigade.isEmpty()) sb.append("Brygada: ").append(vehicle.brigade).append("\n");
        if (vehicle.agency != null && !vehicle.agency.isEmpty()) sb.append("Przewoźnik: ").append(vehicle.agency);
        if (sb.length() == 0) sb.append("—");
        new AlertDialog.Builder(act)
                .setTitle(act.getString(R.string.app_name))
                .setMessage(sb.toString().trim())
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}
